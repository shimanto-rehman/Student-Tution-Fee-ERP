# Pioneer Dental API Documentation

**Last Updated:** 2025-11-02

---

## Table of Contents

1. [Overview](#overview)
2. [Authentication](#authentication)
3. [Quick Start](#quick-start)
4. [API Endpoints](#api-endpoints)
5. [Response Formats](#response-formats)
6. [Error Handling](#error-handling)

---

## Overview

The Pioneer Dental API provides a secure RESTful interface for accessing student billing information. All API endpoints use JWT (JSON Web Token) Bearer authentication.

**Base URL:** `http://localhost/pioneer-dental/api`

---

## Authentication

### Overview

All API endpoints require JWT Bearer token authentication. You must first obtain a token from the authentication endpoint before accessing any protected resources.

### Step 1: Obtain JWT Token

**Endpoint:** `POST /api/auth/login`

**Request:**
```json
{
  "client_id": "mtb_gateway",
  "client_secret": "mtb_secret_key_12345"
}
```

**Response:**
```json
{
  "success": true,
  "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "expires_in": 86400,
  "token_type": "Bearer"
}
```

### Step 2: Use Token for API Calls

Include the token in the `Authorization` header for all subsequent requests:

```
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...
```

---

## Quick Start

### 1. Get Token

```bash
curl -X POST http://localhost/pioneer-dental/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "client_id": "mtb_gateway",
    "client_secret": "mtb_secret_key_12345"
  }'
```

**Response:**
```json
{
  "success": true,
  "token": "YOUR_JWT_TOKEN_HERE",
  "expires_in": 86400,
  "token_type": "Bearer"
}
```

### 2. Use Token for API Requests

```bash
# Save token to variable
TOKEN="YOUR_JWT_TOKEN_HERE"

# Make API call with token
curl -X POST http://localhost/pioneer-dental/api/due-bills/check \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"student_id": 123, "phone": "01708086211"}'
```

### 3. Complete Workflow Example

```bash
#!/bin/bash

# Step 1: Login and get token
TOKEN=$(curl -s -X POST http://localhost/pioneer-dental/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"client_id":"mtb_gateway","client_secret":"mtb_secret_key_12345"}' \
  | grep -o '"token":"[^"]*' | cut -d'"' -f4)

# Step 2: Use token for API calls
curl -X POST http://localhost/pioneer-dental/api/due-bills/check \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"student_id": 123, "phone": "01708086211"}'
```

---

## API Endpoints

### Authentication Endpoints

#### POST /api/auth/login

Get JWT authentication token.

**Authentication:** Not required

**Request:**
```bash
curl -X POST http://localhost/pioneer-dental/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "client_id": "mtb_gateway",
    "client_secret": "mtb_secret_key_12345"
  }'
```

**Response:**
```json
{
  "success": true,
  "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "expires_in": 86400,
  "token_type": "Bearer"
}
```

#### GET /api/auth/validate

Validate a JWT token (for testing).

**Authentication:** Bearer token required

**Request:**
```bash
curl -X GET http://localhost/pioneer-dental/api/auth/validate \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

---

### Due Bills Endpoints

#### POST /api/due-bills/check

Retrieve all due bills for a student.

**Authentication:** Bearer token required

**Headers:**
```
Content-Type: application/json
Authorization: Bearer YOUR_TOKEN_HERE
```

**Request Body:**
```json
{
  "student_id": 123,
  "phone": "01708086211"
}
```

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| student_id | integer | Yes | Student's ID or Registration Number |
| phone | string | No | Student's or parent's phone number for verification |

**Success Response (200 OK):**
```json
{
  "status": "success",
  "message": "Due bills retrieved successfully",
  "student": {
    "id": 123,
    "name": "John Doe",
    "reg_no": 1842,
    "phone": "01708086211",
    "parent_phone": "01712345678",
    "address": "House 77, Road 8"
  },
  "bills": [
    {
      "bill_id": 1,
      "month_year": "2025-11",
      "bill_month": 11,
      "bill_year": 2025,
      "bill_unique_id": "PD202511001",
      "due_date": "2025-11-20",
      "payment_status": "Unpaid",
      "amount": {
        "base_amount": 10000.00,
        "late_fee": 150.00,
        "total_amount": 10150.00,
        "currency": "BDT"
      },
      "is_overdue": true
    }
  ],
  "summary": {
    "total_bills": 1,
    "total_amount": 10150.00,
    "total_late_fee": 150.00,
    "currency": "BDT"
  },
  "authentication": {
    "matched_by": "student_id_and_phone"
  }
}
```

**Example:**
```bash
curl -X POST http://localhost/pioneer-dental/api/due-bills/check \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{"student_id": 123, "phone": "01708086211"}'
```

#### GET /api/due-bills/get

Retrieve due bills using GET method.

**Authentication:** Bearer token required

**Query Parameters:** `student_id` (required), `phone` (optional)

**Example:**
```bash
curl -X GET "http://localhost/pioneer-dental/api/due-bills/get?student_id=123&phone=01708086211" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

---

### Paid Bills Endpoints

#### POST /api/paid-bills/check

Retrieve all paid bills for a student.

**Authentication:** Bearer token required

**Request Body:**
```json
{
  "student_id": 123,
  "phone": "01708086211"
}
```

**Example:**
```bash
curl -X POST http://localhost/pioneer-dental/api/paid-bills/check \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{"student_id": 123, "phone": "01708086211"}'
```

#### GET /api/paid-bills/get

Retrieve paid bills using GET method.

**Example:**
```bash
curl -X GET "http://localhost/pioneer-dental/api/paid-bills/get?student_id=123&phone=01708086211" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

---

### Cron Job Endpoints

#### POST /api/generate-monthly-fees

Generate monthly fees for all students (requires JWT authentication).

**Authentication:** Bearer token required

**Request Body (optional):**
```json
{
  "month": 11,
  "year": 2025,
  "due_day": 20
}
```

**Example:**
```bash
curl -X POST http://localhost/pioneer-dental/api/generate-monthly-fees \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -H "Content-Type: application/json" \
  -d '{"month": 11, "year": 2025, "due_day": 20}'
```

**Response:**
```json
{
  "success": true,
  "message": "Monthly fees generated successfully for November 2025",
  "data": {
    "month": 11,
    "year": 2025,
    "month_name": "November",
    "due_day": 20,
    "generated": 150,
    "skipped": 5,
    "total_students": 155,
    "errors": []
  },
  "timestamp": "2025-11-02 20:30:48"
}
```

**Cron Job Example:**
```bash
# First get a long-lived token or implement token refresh
# Then in cron:
0 2 2 * * curl -X POST "http://localhost/pioneer-dental/api/generate-monthly-fees" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" >> /var/log/monthly_fees.log 2>&1
```

---

### Payment Gateway Endpoints

#### POST /api/mtb/billing-info

Get billing information for MTB payment gateway.

**Authentication:** Bearer token required

#### POST /api/mtb/payment-callback

Handle payment callback from MTB gateway.

**Authentication:** Bearer token required

#### GET /api/mtb/payment-status/:transaction_id

Check payment status.

**Authentication:** Bearer token required

---

## Response Formats

### Success Response Format

```json
{
  "success": true,
  "message": "Operation completed successfully",
  "data": {
    // Response data here
  }
}
```

### Error Response Format

```json
{
  "success": false,
  "message": "Error description",
  "error": "ERROR_CODE"
}
```

---

## Error Handling

### Common HTTP Status Codes

| Status Code | Description |
|-------------|-------------|
| 200 | Success |
| 400 | Bad Request |
| 401 | Unauthorized |
| 404 | Not Found |
| 500 | Internal Server Error |

### Error Responses

#### 401 Unauthorized - Missing Token

```json
{
  "success": false,
  "message": "Bearer token not provided",
  "error": "Unauthorized"
}
```

#### 401 Unauthorized - Invalid Token

```json
{
  "success": false,
  "message": "Invalid or expired token",
  "error": "Unauthorized"
}
```

#### 401 Unauthorized - Invalid Credentials

```json
{
  "success": false,
  "message": "Invalid client credentials"
}
```

---

## Examples

### JavaScript Example

```javascript
// Step 1: Get token
async function getToken() {
  const response = await fetch('http://localhost/pioneer-dental/api/auth/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      client_id: 'mtb_gateway',
      client_secret: 'mtb_secret_key_12345'
    })
  });
  
  const data = await response.json();
  return data.token;
}

// Step 2: Make authenticated request
async function getDueBills(token, studentId, phone) {
  const response = await fetch('http://localhost/pioneer-dental/api/due-bills/check', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({
      student_id: studentId,
      phone: phone
    })
  });
  
  return await response.json();
}

// Usage
(async () => {
  const token = await getToken();
  const bills = await getDueBills(token, 123, '01708086211');
  console.log(bills);
})();
```

### Python Example

```python
import requests
import json

# Step 1: Get token
def get_token():
    url = 'http://localhost/pioneer-dental/api/auth/login'
    headers = {'Content-Type': 'application/json'}
    data = {
        'client_id': 'mtb_gateway',
        'client_secret': 'mtb_secret_key_12345'
    }
    
    response = requests.post(url, headers=headers, json=data)
    return response.json()['token']

# Step 2: Get due bills
def get_due_bills(token, student_id, phone):
    url = 'http://localhost/pioneer-dental/api/due-bills/check'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {token}'
    }
    data = {
        'student_id': student_id,
        'phone': phone
    }
    
    response = requests.post(url, headers=headers, json=data)
    return response.json()

# Usage
token = get_token()
bills = get_due_bills(token, 123, '01708086211')
print(json.dumps(bills, indent=2))
```

---

## Additional Resources

- **JWT Authentication:** See `JWT_AUTHENTICATION.md` for detailed JWT setup and configuration
- **API Test Cases:** See `API_TEST_CASES.md` for comprehensive test scenarios

---

## Support

For issues or questions, please contact the development team.

**API Version:** 1.0
