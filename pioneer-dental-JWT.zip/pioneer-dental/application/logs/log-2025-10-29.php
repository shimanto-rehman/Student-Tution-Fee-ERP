<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-10-29 04:50:30 --> Config Class Initialized
INFO - 2025-10-29 04:50:30 --> Hooks Class Initialized
DEBUG - 2025-10-29 04:50:30 --> UTF-8 Support Enabled
INFO - 2025-10-29 04:50:30 --> Utf8 Class Initialized
INFO - 2025-10-29 04:50:30 --> URI Class Initialized
INFO - 2025-10-29 04:50:30 --> Router Class Initialized
INFO - 2025-10-29 04:50:30 --> Output Class Initialized
INFO - 2025-10-29 04:50:30 --> Security Class Initialized
DEBUG - 2025-10-29 04:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 04:50:30 --> Input Class Initialized
INFO - 2025-10-29 04:50:30 --> Language Class Initialized
INFO - 2025-10-29 04:50:30 --> Loader Class Initialized
INFO - 2025-10-29 04:50:30 --> Helper loaded: url_helper
INFO - 2025-10-29 04:50:30 --> Database Driver Class Initialized
INFO - 2025-10-29 04:50:30 --> Controller Class Initialized
INFO - 2025-10-29 04:50:30 --> Model "Student_model" initialized
INFO - 2025-10-29 04:50:30 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 04:50:30 --> Model "Payment_model" initialized
INFO - 2025-10-29 04:50:30 --> Helper loaded: form_helper
INFO - 2025-10-29 04:50:30 --> Form Validation Class Initialized
DEBUG - 2025-10-29 04:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 04:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 07:27:13 --> Config Class Initialized
INFO - 2025-10-29 07:27:13 --> Hooks Class Initialized
DEBUG - 2025-10-29 07:27:13 --> UTF-8 Support Enabled
INFO - 2025-10-29 07:27:13 --> Utf8 Class Initialized
INFO - 2025-10-29 07:27:13 --> URI Class Initialized
INFO - 2025-10-29 07:27:13 --> Router Class Initialized
INFO - 2025-10-29 07:27:13 --> Output Class Initialized
INFO - 2025-10-29 07:27:13 --> Security Class Initialized
DEBUG - 2025-10-29 07:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 07:27:13 --> Input Class Initialized
INFO - 2025-10-29 07:27:13 --> Language Class Initialized
INFO - 2025-10-29 07:27:13 --> Loader Class Initialized
INFO - 2025-10-29 07:27:13 --> Helper loaded: url_helper
INFO - 2025-10-29 07:27:13 --> Database Driver Class Initialized
INFO - 2025-10-29 07:27:13 --> Controller Class Initialized
INFO - 2025-10-29 07:27:13 --> Model "Student_model" initialized
INFO - 2025-10-29 07:27:13 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 07:27:13 --> Model "Payment_model" initialized
INFO - 2025-10-29 07:27:13 --> Helper loaded: form_helper
INFO - 2025-10-29 07:27:13 --> Form Validation Class Initialized
DEBUG - 2025-10-29 07:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 07:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 07:27:14 --> Config Class Initialized
INFO - 2025-10-29 07:27:14 --> Hooks Class Initialized
DEBUG - 2025-10-29 07:27:14 --> UTF-8 Support Enabled
INFO - 2025-10-29 07:27:14 --> Utf8 Class Initialized
INFO - 2025-10-29 07:27:14 --> URI Class Initialized
INFO - 2025-10-29 07:27:14 --> Router Class Initialized
INFO - 2025-10-29 07:27:14 --> Output Class Initialized
INFO - 2025-10-29 07:27:14 --> Security Class Initialized
DEBUG - 2025-10-29 07:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 07:27:14 --> Input Class Initialized
INFO - 2025-10-29 07:27:14 --> Language Class Initialized
INFO - 2025-10-29 07:27:14 --> Loader Class Initialized
INFO - 2025-10-29 07:27:14 --> Helper loaded: url_helper
INFO - 2025-10-29 07:27:14 --> Database Driver Class Initialized
INFO - 2025-10-29 07:27:14 --> Controller Class Initialized
INFO - 2025-10-29 07:27:14 --> Model "Student_model" initialized
INFO - 2025-10-29 07:27:14 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 07:27:14 --> Model "Payment_model" initialized
INFO - 2025-10-29 07:27:14 --> Helper loaded: form_helper
INFO - 2025-10-29 07:27:14 --> Form Validation Class Initialized
DEBUG - 2025-10-29 07:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 07:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 07:27:15 --> Config Class Initialized
INFO - 2025-10-29 07:27:15 --> Hooks Class Initialized
DEBUG - 2025-10-29 07:27:15 --> UTF-8 Support Enabled
INFO - 2025-10-29 07:27:15 --> Utf8 Class Initialized
INFO - 2025-10-29 07:27:15 --> URI Class Initialized
INFO - 2025-10-29 07:27:15 --> Router Class Initialized
INFO - 2025-10-29 07:27:15 --> Output Class Initialized
INFO - 2025-10-29 07:27:15 --> Security Class Initialized
DEBUG - 2025-10-29 07:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 07:27:15 --> Input Class Initialized
INFO - 2025-10-29 07:27:15 --> Language Class Initialized
INFO - 2025-10-29 07:27:15 --> Loader Class Initialized
INFO - 2025-10-29 07:27:15 --> Helper loaded: url_helper
INFO - 2025-10-29 07:27:15 --> Database Driver Class Initialized
INFO - 2025-10-29 07:27:15 --> Controller Class Initialized
INFO - 2025-10-29 07:27:15 --> Model "Student_model" initialized
INFO - 2025-10-29 07:27:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 07:27:15 --> Model "Payment_model" initialized
INFO - 2025-10-29 07:27:15 --> Helper loaded: form_helper
INFO - 2025-10-29 07:27:15 --> Form Validation Class Initialized
DEBUG - 2025-10-29 07:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 07:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 07:27:15 --> Config Class Initialized
INFO - 2025-10-29 07:27:15 --> Hooks Class Initialized
DEBUG - 2025-10-29 07:27:15 --> UTF-8 Support Enabled
INFO - 2025-10-29 07:27:15 --> Utf8 Class Initialized
INFO - 2025-10-29 07:27:15 --> URI Class Initialized
INFO - 2025-10-29 07:27:15 --> Router Class Initialized
INFO - 2025-10-29 07:27:15 --> Output Class Initialized
INFO - 2025-10-29 07:27:15 --> Security Class Initialized
DEBUG - 2025-10-29 07:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 07:27:15 --> Input Class Initialized
INFO - 2025-10-29 07:27:15 --> Language Class Initialized
INFO - 2025-10-29 07:27:15 --> Loader Class Initialized
INFO - 2025-10-29 07:27:15 --> Helper loaded: url_helper
INFO - 2025-10-29 07:27:15 --> Database Driver Class Initialized
INFO - 2025-10-29 07:27:15 --> Controller Class Initialized
INFO - 2025-10-29 07:27:15 --> Model "Student_model" initialized
INFO - 2025-10-29 07:27:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 07:27:15 --> Model "Payment_model" initialized
INFO - 2025-10-29 07:27:15 --> Helper loaded: form_helper
INFO - 2025-10-29 07:27:15 --> Form Validation Class Initialized
DEBUG - 2025-10-29 07:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 07:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 07:27:15 --> Config Class Initialized
INFO - 2025-10-29 07:27:15 --> Hooks Class Initialized
DEBUG - 2025-10-29 07:27:15 --> UTF-8 Support Enabled
INFO - 2025-10-29 07:27:15 --> Utf8 Class Initialized
INFO - 2025-10-29 07:27:15 --> URI Class Initialized
INFO - 2025-10-29 07:27:15 --> Router Class Initialized
INFO - 2025-10-29 07:27:15 --> Output Class Initialized
INFO - 2025-10-29 07:27:15 --> Security Class Initialized
DEBUG - 2025-10-29 07:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 07:27:15 --> Input Class Initialized
INFO - 2025-10-29 07:27:15 --> Language Class Initialized
INFO - 2025-10-29 07:27:15 --> Loader Class Initialized
INFO - 2025-10-29 07:27:15 --> Helper loaded: url_helper
INFO - 2025-10-29 07:27:15 --> Database Driver Class Initialized
INFO - 2025-10-29 07:27:15 --> Controller Class Initialized
INFO - 2025-10-29 07:27:15 --> Model "Student_model" initialized
INFO - 2025-10-29 07:27:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 07:27:15 --> Model "Payment_model" initialized
INFO - 2025-10-29 07:27:15 --> Helper loaded: form_helper
INFO - 2025-10-29 07:27:15 --> Form Validation Class Initialized
DEBUG - 2025-10-29 07:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 07:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 07:27:16 --> Config Class Initialized
INFO - 2025-10-29 07:27:16 --> Hooks Class Initialized
DEBUG - 2025-10-29 07:27:16 --> UTF-8 Support Enabled
INFO - 2025-10-29 07:27:16 --> Utf8 Class Initialized
INFO - 2025-10-29 07:27:16 --> URI Class Initialized
INFO - 2025-10-29 07:27:16 --> Router Class Initialized
INFO - 2025-10-29 07:27:16 --> Output Class Initialized
INFO - 2025-10-29 07:27:16 --> Security Class Initialized
DEBUG - 2025-10-29 07:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 07:27:16 --> Input Class Initialized
INFO - 2025-10-29 07:27:16 --> Language Class Initialized
INFO - 2025-10-29 07:27:16 --> Loader Class Initialized
INFO - 2025-10-29 07:27:16 --> Helper loaded: url_helper
INFO - 2025-10-29 07:27:16 --> Database Driver Class Initialized
INFO - 2025-10-29 07:27:16 --> Controller Class Initialized
INFO - 2025-10-29 07:27:16 --> Model "Student_model" initialized
INFO - 2025-10-29 07:27:16 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 07:27:16 --> Model "Payment_model" initialized
INFO - 2025-10-29 07:27:16 --> Helper loaded: form_helper
INFO - 2025-10-29 07:27:16 --> Form Validation Class Initialized
DEBUG - 2025-10-29 07:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 07:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:14:55 --> Config Class Initialized
INFO - 2025-10-29 08:14:55 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:14:55 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:14:55 --> Utf8 Class Initialized
INFO - 2025-10-29 08:14:55 --> URI Class Initialized
INFO - 2025-10-29 08:14:55 --> Router Class Initialized
INFO - 2025-10-29 08:14:55 --> Output Class Initialized
INFO - 2025-10-29 08:14:55 --> Security Class Initialized
DEBUG - 2025-10-29 08:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:14:55 --> Input Class Initialized
INFO - 2025-10-29 08:14:55 --> Language Class Initialized
INFO - 2025-10-29 08:14:55 --> Loader Class Initialized
INFO - 2025-10-29 08:14:55 --> Helper loaded: url_helper
INFO - 2025-10-29 08:14:55 --> Database Driver Class Initialized
INFO - 2025-10-29 08:14:55 --> Controller Class Initialized
INFO - 2025-10-29 08:14:55 --> Model "Student_model" initialized
INFO - 2025-10-29 08:14:55 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:14:55 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:14:55 --> Helper loaded: form_helper
INFO - 2025-10-29 08:14:55 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:14:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:14:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 08:14:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:14:55 --> Final output sent to browser
DEBUG - 2025-10-29 08:14:55 --> Total execution time: 0.0875
INFO - 2025-10-29 08:15:00 --> Config Class Initialized
INFO - 2025-10-29 08:15:00 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:15:00 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:15:00 --> Utf8 Class Initialized
INFO - 2025-10-29 08:15:00 --> URI Class Initialized
INFO - 2025-10-29 08:15:00 --> Router Class Initialized
INFO - 2025-10-29 08:15:00 --> Output Class Initialized
INFO - 2025-10-29 08:15:00 --> Security Class Initialized
DEBUG - 2025-10-29 08:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:15:00 --> Input Class Initialized
INFO - 2025-10-29 08:15:00 --> Language Class Initialized
INFO - 2025-10-29 08:15:00 --> Loader Class Initialized
INFO - 2025-10-29 08:15:00 --> Helper loaded: url_helper
INFO - 2025-10-29 08:15:00 --> Database Driver Class Initialized
INFO - 2025-10-29 08:15:00 --> Controller Class Initialized
INFO - 2025-10-29 08:15:00 --> Model "Student_model" initialized
INFO - 2025-10-29 08:15:00 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:15:00 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:15:00 --> Helper loaded: form_helper
INFO - 2025-10-29 08:15:00 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:15:00 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:15:00 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 08:15:00 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:15:00 --> Final output sent to browser
DEBUG - 2025-10-29 08:15:00 --> Total execution time: 0.1167
INFO - 2025-10-29 08:15:02 --> Config Class Initialized
INFO - 2025-10-29 08:15:02 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:15:02 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:15:02 --> Utf8 Class Initialized
INFO - 2025-10-29 08:15:02 --> URI Class Initialized
INFO - 2025-10-29 08:15:02 --> Router Class Initialized
INFO - 2025-10-29 08:15:02 --> Output Class Initialized
INFO - 2025-10-29 08:15:02 --> Security Class Initialized
DEBUG - 2025-10-29 08:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:15:02 --> Input Class Initialized
INFO - 2025-10-29 08:15:02 --> Language Class Initialized
INFO - 2025-10-29 08:15:02 --> Loader Class Initialized
INFO - 2025-10-29 08:15:02 --> Helper loaded: url_helper
INFO - 2025-10-29 08:15:02 --> Database Driver Class Initialized
INFO - 2025-10-29 08:15:02 --> Controller Class Initialized
INFO - 2025-10-29 08:15:02 --> Model "Student_model" initialized
INFO - 2025-10-29 08:15:02 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:15:02 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:15:02 --> Helper loaded: form_helper
INFO - 2025-10-29 08:15:02 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:15:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:15:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 08:15:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:15:02 --> Final output sent to browser
DEBUG - 2025-10-29 08:15:02 --> Total execution time: 0.0792
INFO - 2025-10-29 08:16:08 --> Config Class Initialized
INFO - 2025-10-29 08:16:08 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:16:08 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:16:08 --> Utf8 Class Initialized
INFO - 2025-10-29 08:16:08 --> URI Class Initialized
INFO - 2025-10-29 08:16:08 --> Router Class Initialized
INFO - 2025-10-29 08:16:08 --> Output Class Initialized
INFO - 2025-10-29 08:16:08 --> Security Class Initialized
DEBUG - 2025-10-29 08:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:16:08 --> Input Class Initialized
INFO - 2025-10-29 08:16:08 --> Language Class Initialized
ERROR - 2025-10-29 08:16:08 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 08:16:12 --> Config Class Initialized
INFO - 2025-10-29 08:16:12 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:16:12 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:16:12 --> Utf8 Class Initialized
INFO - 2025-10-29 08:16:12 --> URI Class Initialized
INFO - 2025-10-29 08:16:12 --> Router Class Initialized
INFO - 2025-10-29 08:16:12 --> Output Class Initialized
INFO - 2025-10-29 08:16:12 --> Security Class Initialized
DEBUG - 2025-10-29 08:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:16:12 --> Input Class Initialized
INFO - 2025-10-29 08:16:12 --> Language Class Initialized
ERROR - 2025-10-29 08:16:12 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 08:16:17 --> Config Class Initialized
INFO - 2025-10-29 08:16:17 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:16:17 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:16:17 --> Utf8 Class Initialized
INFO - 2025-10-29 08:16:17 --> URI Class Initialized
INFO - 2025-10-29 08:16:17 --> Router Class Initialized
INFO - 2025-10-29 08:16:17 --> Output Class Initialized
INFO - 2025-10-29 08:16:17 --> Security Class Initialized
DEBUG - 2025-10-29 08:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:16:17 --> Input Class Initialized
INFO - 2025-10-29 08:16:17 --> Language Class Initialized
INFO - 2025-10-29 08:16:17 --> Loader Class Initialized
INFO - 2025-10-29 08:16:17 --> Helper loaded: url_helper
INFO - 2025-10-29 08:16:17 --> Database Driver Class Initialized
INFO - 2025-10-29 08:16:17 --> Controller Class Initialized
INFO - 2025-10-29 08:16:17 --> Model "Student_model" initialized
INFO - 2025-10-29 08:16:17 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:16:17 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:16:17 --> Helper loaded: form_helper
INFO - 2025-10-29 08:16:17 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:16:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:16:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 08:16:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:16:17 --> Final output sent to browser
DEBUG - 2025-10-29 08:16:17 --> Total execution time: 0.1477
INFO - 2025-10-29 08:16:24 --> Config Class Initialized
INFO - 2025-10-29 08:16:24 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:16:24 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:16:24 --> Utf8 Class Initialized
INFO - 2025-10-29 08:16:24 --> URI Class Initialized
INFO - 2025-10-29 08:16:24 --> Router Class Initialized
INFO - 2025-10-29 08:16:24 --> Output Class Initialized
INFO - 2025-10-29 08:16:24 --> Security Class Initialized
DEBUG - 2025-10-29 08:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:16:24 --> Input Class Initialized
INFO - 2025-10-29 08:16:24 --> Language Class Initialized
INFO - 2025-10-29 08:16:24 --> Loader Class Initialized
INFO - 2025-10-29 08:16:24 --> Helper loaded: url_helper
INFO - 2025-10-29 08:16:24 --> Database Driver Class Initialized
INFO - 2025-10-29 08:16:24 --> Controller Class Initialized
INFO - 2025-10-29 08:16:24 --> Model "Student_model" initialized
INFO - 2025-10-29 08:16:24 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:16:24 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:16:24 --> Helper loaded: form_helper
INFO - 2025-10-29 08:16:24 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:16:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:16:37 --> Config Class Initialized
INFO - 2025-10-29 08:16:37 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:16:37 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:16:37 --> Utf8 Class Initialized
INFO - 2025-10-29 08:16:37 --> URI Class Initialized
INFO - 2025-10-29 08:16:37 --> Router Class Initialized
INFO - 2025-10-29 08:16:37 --> Output Class Initialized
INFO - 2025-10-29 08:16:37 --> Security Class Initialized
DEBUG - 2025-10-29 08:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:16:37 --> Input Class Initialized
INFO - 2025-10-29 08:16:37 --> Language Class Initialized
INFO - 2025-10-29 08:16:37 --> Loader Class Initialized
INFO - 2025-10-29 08:16:37 --> Helper loaded: url_helper
INFO - 2025-10-29 08:16:37 --> Database Driver Class Initialized
INFO - 2025-10-29 08:16:37 --> Controller Class Initialized
INFO - 2025-10-29 08:16:37 --> Model "Student_model" initialized
INFO - 2025-10-29 08:16:37 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:16:37 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:16:37 --> Helper loaded: form_helper
INFO - 2025-10-29 08:16:37 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:16:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:16:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 08:16:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:16:37 --> Final output sent to browser
DEBUG - 2025-10-29 08:16:37 --> Total execution time: 0.1226
INFO - 2025-10-29 08:16:41 --> Config Class Initialized
INFO - 2025-10-29 08:16:41 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:16:41 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:16:41 --> Utf8 Class Initialized
INFO - 2025-10-29 08:16:41 --> URI Class Initialized
INFO - 2025-10-29 08:16:41 --> Router Class Initialized
INFO - 2025-10-29 08:16:41 --> Output Class Initialized
INFO - 2025-10-29 08:16:41 --> Security Class Initialized
DEBUG - 2025-10-29 08:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:16:41 --> Input Class Initialized
INFO - 2025-10-29 08:16:41 --> Language Class Initialized
INFO - 2025-10-29 08:16:41 --> Loader Class Initialized
INFO - 2025-10-29 08:16:41 --> Helper loaded: url_helper
INFO - 2025-10-29 08:16:41 --> Database Driver Class Initialized
INFO - 2025-10-29 08:16:42 --> Controller Class Initialized
INFO - 2025-10-29 08:16:42 --> Model "Student_model" initialized
INFO - 2025-10-29 08:16:42 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:16:42 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:16:42 --> Helper loaded: form_helper
INFO - 2025-10-29 08:16:42 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:16:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:16:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 08:16:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:16:42 --> Final output sent to browser
DEBUG - 2025-10-29 08:16:42 --> Total execution time: 0.1485
INFO - 2025-10-29 08:16:46 --> Config Class Initialized
INFO - 2025-10-29 08:16:46 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:16:46 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:16:46 --> Utf8 Class Initialized
INFO - 2025-10-29 08:16:46 --> URI Class Initialized
INFO - 2025-10-29 08:16:46 --> Router Class Initialized
INFO - 2025-10-29 08:16:46 --> Output Class Initialized
INFO - 2025-10-29 08:16:46 --> Security Class Initialized
DEBUG - 2025-10-29 08:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:16:46 --> Input Class Initialized
INFO - 2025-10-29 08:16:46 --> Language Class Initialized
INFO - 2025-10-29 08:16:46 --> Loader Class Initialized
INFO - 2025-10-29 08:16:46 --> Helper loaded: url_helper
INFO - 2025-10-29 08:16:46 --> Database Driver Class Initialized
INFO - 2025-10-29 08:16:46 --> Controller Class Initialized
INFO - 2025-10-29 08:16:46 --> Model "Student_model" initialized
INFO - 2025-10-29 08:16:46 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:16:46 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:16:46 --> Helper loaded: form_helper
INFO - 2025-10-29 08:16:46 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:16:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:16:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-29 08:16:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:16:46 --> Final output sent to browser
DEBUG - 2025-10-29 08:16:46 --> Total execution time: 0.0935
INFO - 2025-10-29 08:16:56 --> Config Class Initialized
INFO - 2025-10-29 08:16:56 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:16:56 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:16:56 --> Utf8 Class Initialized
INFO - 2025-10-29 08:16:56 --> URI Class Initialized
INFO - 2025-10-29 08:16:56 --> Router Class Initialized
INFO - 2025-10-29 08:16:56 --> Output Class Initialized
INFO - 2025-10-29 08:16:56 --> Security Class Initialized
DEBUG - 2025-10-29 08:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:16:56 --> Input Class Initialized
INFO - 2025-10-29 08:16:56 --> Language Class Initialized
ERROR - 2025-10-29 08:16:56 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 08:17:04 --> Config Class Initialized
INFO - 2025-10-29 08:17:04 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:17:04 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:17:04 --> Utf8 Class Initialized
INFO - 2025-10-29 08:17:04 --> URI Class Initialized
INFO - 2025-10-29 08:17:04 --> Router Class Initialized
INFO - 2025-10-29 08:17:04 --> Output Class Initialized
INFO - 2025-10-29 08:17:04 --> Security Class Initialized
DEBUG - 2025-10-29 08:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:17:04 --> Input Class Initialized
INFO - 2025-10-29 08:17:04 --> Language Class Initialized
ERROR - 2025-10-29 08:17:04 --> 404 Page Not Found: Payments/process
INFO - 2025-10-29 08:17:21 --> Config Class Initialized
INFO - 2025-10-29 08:17:21 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:17:21 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:17:21 --> Utf8 Class Initialized
INFO - 2025-10-29 08:17:21 --> URI Class Initialized
INFO - 2025-10-29 08:17:21 --> Router Class Initialized
INFO - 2025-10-29 08:17:21 --> Output Class Initialized
INFO - 2025-10-29 08:17:21 --> Security Class Initialized
DEBUG - 2025-10-29 08:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:17:21 --> Input Class Initialized
INFO - 2025-10-29 08:17:21 --> Language Class Initialized
INFO - 2025-10-29 08:17:21 --> Loader Class Initialized
INFO - 2025-10-29 08:17:21 --> Helper loaded: url_helper
INFO - 2025-10-29 08:17:21 --> Database Driver Class Initialized
INFO - 2025-10-29 08:17:21 --> Controller Class Initialized
INFO - 2025-10-29 08:17:21 --> Model "Student_model" initialized
INFO - 2025-10-29 08:17:21 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:17:21 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:17:21 --> Helper loaded: form_helper
INFO - 2025-10-29 08:17:21 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:17:21 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:17:21 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 08:17:21 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:17:21 --> Final output sent to browser
DEBUG - 2025-10-29 08:17:21 --> Total execution time: 0.1027
INFO - 2025-10-29 08:20:00 --> Config Class Initialized
INFO - 2025-10-29 08:20:00 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:20:00 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:20:00 --> Utf8 Class Initialized
INFO - 2025-10-29 08:20:00 --> URI Class Initialized
INFO - 2025-10-29 08:20:00 --> Router Class Initialized
INFO - 2025-10-29 08:20:00 --> Output Class Initialized
INFO - 2025-10-29 08:20:00 --> Security Class Initialized
DEBUG - 2025-10-29 08:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:20:00 --> Input Class Initialized
INFO - 2025-10-29 08:20:00 --> Language Class Initialized
INFO - 2025-10-29 08:20:00 --> Loader Class Initialized
INFO - 2025-10-29 08:20:00 --> Helper loaded: url_helper
INFO - 2025-10-29 08:20:00 --> Database Driver Class Initialized
INFO - 2025-10-29 08:20:00 --> Controller Class Initialized
INFO - 2025-10-29 08:20:00 --> Model "Student_model" initialized
INFO - 2025-10-29 08:20:00 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:20:00 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:20:00 --> Helper loaded: form_helper
INFO - 2025-10-29 08:20:00 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:20:00 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:20:00 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 08:20:00 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:20:00 --> Final output sent to browser
DEBUG - 2025-10-29 08:20:00 --> Total execution time: 0.1087
INFO - 2025-10-29 08:20:02 --> Config Class Initialized
INFO - 2025-10-29 08:20:02 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:20:02 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:20:02 --> Utf8 Class Initialized
INFO - 2025-10-29 08:20:02 --> URI Class Initialized
INFO - 2025-10-29 08:20:02 --> Router Class Initialized
INFO - 2025-10-29 08:20:02 --> Output Class Initialized
INFO - 2025-10-29 08:20:02 --> Security Class Initialized
DEBUG - 2025-10-29 08:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:20:02 --> Input Class Initialized
INFO - 2025-10-29 08:20:02 --> Language Class Initialized
ERROR - 2025-10-29 08:20:02 --> 404 Page Not Found: Payments/index
INFO - 2025-10-29 08:20:04 --> Config Class Initialized
INFO - 2025-10-29 08:20:04 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:20:04 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:20:04 --> Utf8 Class Initialized
INFO - 2025-10-29 08:20:04 --> URI Class Initialized
INFO - 2025-10-29 08:20:04 --> Router Class Initialized
INFO - 2025-10-29 08:20:04 --> Output Class Initialized
INFO - 2025-10-29 08:20:04 --> Security Class Initialized
DEBUG - 2025-10-29 08:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:20:04 --> Input Class Initialized
INFO - 2025-10-29 08:20:04 --> Language Class Initialized
INFO - 2025-10-29 08:20:04 --> Loader Class Initialized
INFO - 2025-10-29 08:20:04 --> Helper loaded: url_helper
INFO - 2025-10-29 08:20:04 --> Database Driver Class Initialized
INFO - 2025-10-29 08:20:04 --> Controller Class Initialized
INFO - 2025-10-29 08:20:04 --> Model "Student_model" initialized
INFO - 2025-10-29 08:20:04 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:20:04 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:20:04 --> Helper loaded: form_helper
INFO - 2025-10-29 08:20:04 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:20:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:20:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 08:20:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:20:04 --> Final output sent to browser
DEBUG - 2025-10-29 08:20:04 --> Total execution time: 0.0951
INFO - 2025-10-29 08:20:42 --> Config Class Initialized
INFO - 2025-10-29 08:20:42 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:20:42 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:20:42 --> Utf8 Class Initialized
INFO - 2025-10-29 08:20:42 --> URI Class Initialized
INFO - 2025-10-29 08:20:42 --> Router Class Initialized
INFO - 2025-10-29 08:20:42 --> Output Class Initialized
INFO - 2025-10-29 08:20:42 --> Security Class Initialized
DEBUG - 2025-10-29 08:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:20:42 --> Input Class Initialized
INFO - 2025-10-29 08:20:42 --> Language Class Initialized
INFO - 2025-10-29 08:20:42 --> Loader Class Initialized
INFO - 2025-10-29 08:20:42 --> Helper loaded: url_helper
INFO - 2025-10-29 08:20:42 --> Database Driver Class Initialized
INFO - 2025-10-29 08:20:42 --> Controller Class Initialized
INFO - 2025-10-29 08:20:42 --> Model "Student_model" initialized
INFO - 2025-10-29 08:20:42 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:20:42 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:20:42 --> Helper loaded: form_helper
INFO - 2025-10-29 08:20:42 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:20:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:20:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 08:20:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:20:42 --> Final output sent to browser
DEBUG - 2025-10-29 08:20:42 --> Total execution time: 0.0992
INFO - 2025-10-29 08:20:47 --> Config Class Initialized
INFO - 2025-10-29 08:20:47 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:20:47 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:20:47 --> Utf8 Class Initialized
INFO - 2025-10-29 08:20:47 --> URI Class Initialized
INFO - 2025-10-29 08:20:47 --> Router Class Initialized
INFO - 2025-10-29 08:20:47 --> Output Class Initialized
INFO - 2025-10-29 08:20:47 --> Security Class Initialized
DEBUG - 2025-10-29 08:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:20:47 --> Input Class Initialized
INFO - 2025-10-29 08:20:47 --> Language Class Initialized
INFO - 2025-10-29 08:20:47 --> Loader Class Initialized
INFO - 2025-10-29 08:20:47 --> Helper loaded: url_helper
INFO - 2025-10-29 08:20:47 --> Database Driver Class Initialized
INFO - 2025-10-29 08:20:47 --> Controller Class Initialized
INFO - 2025-10-29 08:20:47 --> Model "Student_model" initialized
INFO - 2025-10-29 08:20:47 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:20:47 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:20:47 --> Helper loaded: form_helper
INFO - 2025-10-29 08:20:47 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:20:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:20:50 --> Config Class Initialized
INFO - 2025-10-29 08:20:50 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:20:50 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:20:50 --> Utf8 Class Initialized
INFO - 2025-10-29 08:20:50 --> URI Class Initialized
INFO - 2025-10-29 08:20:50 --> Router Class Initialized
INFO - 2025-10-29 08:20:50 --> Output Class Initialized
INFO - 2025-10-29 08:20:50 --> Security Class Initialized
DEBUG - 2025-10-29 08:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:20:50 --> Input Class Initialized
INFO - 2025-10-29 08:20:50 --> Language Class Initialized
INFO - 2025-10-29 08:20:50 --> Loader Class Initialized
INFO - 2025-10-29 08:20:50 --> Helper loaded: url_helper
INFO - 2025-10-29 08:20:50 --> Database Driver Class Initialized
INFO - 2025-10-29 08:20:50 --> Controller Class Initialized
INFO - 2025-10-29 08:20:50 --> Model "Student_model" initialized
INFO - 2025-10-29 08:20:50 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:20:50 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:20:50 --> Helper loaded: form_helper
INFO - 2025-10-29 08:20:50 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:20:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:20:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-29 08:20:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:20:50 --> Final output sent to browser
DEBUG - 2025-10-29 08:20:50 --> Total execution time: 0.1279
INFO - 2025-10-29 08:22:16 --> Config Class Initialized
INFO - 2025-10-29 08:22:16 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:22:16 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:22:16 --> Utf8 Class Initialized
INFO - 2025-10-29 08:22:16 --> URI Class Initialized
INFO - 2025-10-29 08:22:16 --> Router Class Initialized
INFO - 2025-10-29 08:22:16 --> Output Class Initialized
INFO - 2025-10-29 08:22:16 --> Security Class Initialized
DEBUG - 2025-10-29 08:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:22:16 --> Input Class Initialized
INFO - 2025-10-29 08:22:16 --> Language Class Initialized
INFO - 2025-10-29 08:22:16 --> Loader Class Initialized
INFO - 2025-10-29 08:22:16 --> Helper loaded: url_helper
INFO - 2025-10-29 08:22:16 --> Database Driver Class Initialized
INFO - 2025-10-29 08:22:16 --> Controller Class Initialized
INFO - 2025-10-29 08:22:16 --> Model "Student_model" initialized
INFO - 2025-10-29 08:22:16 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:22:16 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:22:16 --> Helper loaded: form_helper
INFO - 2025-10-29 08:22:16 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:22:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:22:19 --> Config Class Initialized
INFO - 2025-10-29 08:22:19 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:22:19 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:22:19 --> Utf8 Class Initialized
INFO - 2025-10-29 08:22:19 --> URI Class Initialized
INFO - 2025-10-29 08:22:19 --> Router Class Initialized
INFO - 2025-10-29 08:22:19 --> Output Class Initialized
INFO - 2025-10-29 08:22:19 --> Security Class Initialized
DEBUG - 2025-10-29 08:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:22:19 --> Input Class Initialized
INFO - 2025-10-29 08:22:19 --> Language Class Initialized
INFO - 2025-10-29 08:22:19 --> Loader Class Initialized
INFO - 2025-10-29 08:22:19 --> Helper loaded: url_helper
INFO - 2025-10-29 08:22:19 --> Database Driver Class Initialized
INFO - 2025-10-29 08:22:19 --> Controller Class Initialized
INFO - 2025-10-29 08:22:19 --> Model "Student_model" initialized
INFO - 2025-10-29 08:22:19 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:22:19 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:22:19 --> Helper loaded: form_helper
INFO - 2025-10-29 08:22:19 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:22:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:22:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 08:22:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:22:19 --> Final output sent to browser
DEBUG - 2025-10-29 08:22:19 --> Total execution time: 0.1572
INFO - 2025-10-29 08:22:37 --> Config Class Initialized
INFO - 2025-10-29 08:22:37 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:22:37 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:22:37 --> Utf8 Class Initialized
INFO - 2025-10-29 08:22:37 --> URI Class Initialized
INFO - 2025-10-29 08:22:37 --> Router Class Initialized
INFO - 2025-10-29 08:22:37 --> Output Class Initialized
INFO - 2025-10-29 08:22:37 --> Security Class Initialized
DEBUG - 2025-10-29 08:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:22:37 --> Input Class Initialized
INFO - 2025-10-29 08:22:37 --> Language Class Initialized
INFO - 2025-10-29 08:22:37 --> Loader Class Initialized
INFO - 2025-10-29 08:22:37 --> Helper loaded: url_helper
INFO - 2025-10-29 08:22:37 --> Database Driver Class Initialized
INFO - 2025-10-29 08:22:37 --> Controller Class Initialized
INFO - 2025-10-29 08:22:37 --> Model "Student_model" initialized
INFO - 2025-10-29 08:22:37 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:22:37 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:22:37 --> Helper loaded: form_helper
INFO - 2025-10-29 08:22:37 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:22:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:22:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 08:22:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:22:37 --> Final output sent to browser
DEBUG - 2025-10-29 08:22:37 --> Total execution time: 0.1113
INFO - 2025-10-29 08:23:06 --> Config Class Initialized
INFO - 2025-10-29 08:23:06 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:23:06 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:23:06 --> Utf8 Class Initialized
INFO - 2025-10-29 08:23:06 --> URI Class Initialized
INFO - 2025-10-29 08:23:06 --> Router Class Initialized
INFO - 2025-10-29 08:23:06 --> Output Class Initialized
INFO - 2025-10-29 08:23:06 --> Security Class Initialized
DEBUG - 2025-10-29 08:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:23:06 --> Input Class Initialized
INFO - 2025-10-29 08:23:06 --> Language Class Initialized
INFO - 2025-10-29 08:23:06 --> Loader Class Initialized
INFO - 2025-10-29 08:23:06 --> Helper loaded: url_helper
INFO - 2025-10-29 08:23:06 --> Database Driver Class Initialized
INFO - 2025-10-29 08:23:06 --> Controller Class Initialized
INFO - 2025-10-29 08:23:06 --> Model "Student_model" initialized
INFO - 2025-10-29 08:23:06 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:23:06 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:23:06 --> Helper loaded: form_helper
INFO - 2025-10-29 08:23:06 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:23:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:23:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 08:23:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:23:06 --> Final output sent to browser
DEBUG - 2025-10-29 08:23:06 --> Total execution time: 0.1072
INFO - 2025-10-29 08:23:43 --> Config Class Initialized
INFO - 2025-10-29 08:23:43 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:23:43 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:23:43 --> Utf8 Class Initialized
INFO - 2025-10-29 08:23:43 --> URI Class Initialized
INFO - 2025-10-29 08:23:43 --> Router Class Initialized
INFO - 2025-10-29 08:23:43 --> Output Class Initialized
INFO - 2025-10-29 08:23:43 --> Security Class Initialized
DEBUG - 2025-10-29 08:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:23:43 --> Input Class Initialized
INFO - 2025-10-29 08:23:43 --> Language Class Initialized
INFO - 2025-10-29 08:23:43 --> Loader Class Initialized
INFO - 2025-10-29 08:23:43 --> Helper loaded: url_helper
INFO - 2025-10-29 08:23:43 --> Database Driver Class Initialized
INFO - 2025-10-29 08:23:43 --> Controller Class Initialized
INFO - 2025-10-29 08:23:43 --> Model "Student_model" initialized
INFO - 2025-10-29 08:23:43 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:23:43 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:23:43 --> Helper loaded: form_helper
INFO - 2025-10-29 08:23:43 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:23:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:23:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 08:23:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:23:43 --> Final output sent to browser
DEBUG - 2025-10-29 08:23:43 --> Total execution time: 0.1045
INFO - 2025-10-29 08:24:37 --> Config Class Initialized
INFO - 2025-10-29 08:24:37 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:24:37 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:24:37 --> Utf8 Class Initialized
INFO - 2025-10-29 08:24:37 --> URI Class Initialized
INFO - 2025-10-29 08:24:37 --> Router Class Initialized
INFO - 2025-10-29 08:24:37 --> Output Class Initialized
INFO - 2025-10-29 08:24:37 --> Security Class Initialized
DEBUG - 2025-10-29 08:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:24:37 --> Input Class Initialized
INFO - 2025-10-29 08:24:37 --> Language Class Initialized
INFO - 2025-10-29 08:24:37 --> Loader Class Initialized
INFO - 2025-10-29 08:24:37 --> Helper loaded: url_helper
INFO - 2025-10-29 08:24:37 --> Database Driver Class Initialized
INFO - 2025-10-29 08:24:37 --> Controller Class Initialized
INFO - 2025-10-29 08:24:37 --> Model "Student_model" initialized
INFO - 2025-10-29 08:24:37 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:24:37 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:24:37 --> Helper loaded: form_helper
INFO - 2025-10-29 08:24:37 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:24:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:24:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 08:24:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:24:37 --> Final output sent to browser
DEBUG - 2025-10-29 08:24:37 --> Total execution time: 0.1200
INFO - 2025-10-29 08:25:15 --> Config Class Initialized
INFO - 2025-10-29 08:25:15 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:25:15 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:25:15 --> Utf8 Class Initialized
INFO - 2025-10-29 08:25:15 --> URI Class Initialized
INFO - 2025-10-29 08:25:15 --> Router Class Initialized
INFO - 2025-10-29 08:25:15 --> Output Class Initialized
INFO - 2025-10-29 08:25:15 --> Security Class Initialized
DEBUG - 2025-10-29 08:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:25:15 --> Input Class Initialized
INFO - 2025-10-29 08:25:15 --> Language Class Initialized
INFO - 2025-10-29 08:25:15 --> Loader Class Initialized
INFO - 2025-10-29 08:25:15 --> Helper loaded: url_helper
INFO - 2025-10-29 08:25:15 --> Database Driver Class Initialized
INFO - 2025-10-29 08:25:15 --> Controller Class Initialized
INFO - 2025-10-29 08:25:15 --> Model "Student_model" initialized
INFO - 2025-10-29 08:25:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:25:15 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:25:15 --> Helper loaded: form_helper
INFO - 2025-10-29 08:25:15 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:25:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:25:17 --> Config Class Initialized
INFO - 2025-10-29 08:25:17 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:25:17 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:25:17 --> Utf8 Class Initialized
INFO - 2025-10-29 08:25:17 --> URI Class Initialized
INFO - 2025-10-29 08:25:17 --> Router Class Initialized
INFO - 2025-10-29 08:25:17 --> Output Class Initialized
INFO - 2025-10-29 08:25:17 --> Security Class Initialized
DEBUG - 2025-10-29 08:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:25:17 --> Input Class Initialized
INFO - 2025-10-29 08:25:17 --> Language Class Initialized
INFO - 2025-10-29 08:25:17 --> Loader Class Initialized
INFO - 2025-10-29 08:25:17 --> Helper loaded: url_helper
INFO - 2025-10-29 08:25:17 --> Database Driver Class Initialized
INFO - 2025-10-29 08:25:17 --> Controller Class Initialized
INFO - 2025-10-29 08:25:17 --> Model "Student_model" initialized
INFO - 2025-10-29 08:25:17 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:25:17 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:25:17 --> Helper loaded: form_helper
INFO - 2025-10-29 08:25:17 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:25:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:25:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 08:25:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:25:17 --> Final output sent to browser
DEBUG - 2025-10-29 08:25:17 --> Total execution time: 0.1451
INFO - 2025-10-29 08:25:21 --> Config Class Initialized
INFO - 2025-10-29 08:25:21 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:25:21 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:25:21 --> Utf8 Class Initialized
INFO - 2025-10-29 08:25:21 --> URI Class Initialized
INFO - 2025-10-29 08:25:21 --> Router Class Initialized
INFO - 2025-10-29 08:25:21 --> Output Class Initialized
INFO - 2025-10-29 08:25:21 --> Security Class Initialized
DEBUG - 2025-10-29 08:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:25:21 --> Input Class Initialized
INFO - 2025-10-29 08:25:21 --> Language Class Initialized
ERROR - 2025-10-29 08:25:21 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 08:25:26 --> Config Class Initialized
INFO - 2025-10-29 08:25:26 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:25:26 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:25:26 --> Utf8 Class Initialized
INFO - 2025-10-29 08:25:26 --> URI Class Initialized
INFO - 2025-10-29 08:25:26 --> Router Class Initialized
INFO - 2025-10-29 08:25:26 --> Output Class Initialized
INFO - 2025-10-29 08:25:26 --> Security Class Initialized
DEBUG - 2025-10-29 08:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:25:26 --> Input Class Initialized
INFO - 2025-10-29 08:25:26 --> Language Class Initialized
INFO - 2025-10-29 08:25:26 --> Loader Class Initialized
INFO - 2025-10-29 08:25:26 --> Helper loaded: url_helper
INFO - 2025-10-29 08:25:26 --> Database Driver Class Initialized
INFO - 2025-10-29 08:25:26 --> Controller Class Initialized
INFO - 2025-10-29 08:25:26 --> Model "Student_model" initialized
INFO - 2025-10-29 08:25:26 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:25:26 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:25:26 --> Helper loaded: form_helper
INFO - 2025-10-29 08:25:26 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:25:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:25:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 08:25:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:25:26 --> Final output sent to browser
DEBUG - 2025-10-29 08:25:26 --> Total execution time: 0.0983
INFO - 2025-10-29 08:25:32 --> Config Class Initialized
INFO - 2025-10-29 08:25:32 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:25:32 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:25:32 --> Utf8 Class Initialized
INFO - 2025-10-29 08:25:32 --> URI Class Initialized
INFO - 2025-10-29 08:25:32 --> Router Class Initialized
INFO - 2025-10-29 08:25:32 --> Output Class Initialized
INFO - 2025-10-29 08:25:32 --> Security Class Initialized
DEBUG - 2025-10-29 08:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:25:32 --> Input Class Initialized
INFO - 2025-10-29 08:25:32 --> Language Class Initialized
INFO - 2025-10-29 08:25:32 --> Loader Class Initialized
INFO - 2025-10-29 08:25:32 --> Helper loaded: url_helper
INFO - 2025-10-29 08:25:32 --> Database Driver Class Initialized
INFO - 2025-10-29 08:25:32 --> Controller Class Initialized
INFO - 2025-10-29 08:25:32 --> Model "Student_model" initialized
INFO - 2025-10-29 08:25:32 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:25:32 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:25:32 --> Helper loaded: form_helper
INFO - 2025-10-29 08:25:32 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:25:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:25:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 08:25:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:25:32 --> Final output sent to browser
DEBUG - 2025-10-29 08:25:32 --> Total execution time: 0.1195
INFO - 2025-10-29 08:25:35 --> Config Class Initialized
INFO - 2025-10-29 08:25:35 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:25:35 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:25:35 --> Utf8 Class Initialized
INFO - 2025-10-29 08:25:35 --> URI Class Initialized
INFO - 2025-10-29 08:25:35 --> Router Class Initialized
INFO - 2025-10-29 08:25:35 --> Output Class Initialized
INFO - 2025-10-29 08:25:35 --> Security Class Initialized
DEBUG - 2025-10-29 08:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:25:35 --> Input Class Initialized
INFO - 2025-10-29 08:25:35 --> Language Class Initialized
INFO - 2025-10-29 08:25:35 --> Loader Class Initialized
INFO - 2025-10-29 08:25:35 --> Helper loaded: url_helper
INFO - 2025-10-29 08:25:35 --> Database Driver Class Initialized
INFO - 2025-10-29 08:25:35 --> Controller Class Initialized
INFO - 2025-10-29 08:25:35 --> Model "Student_model" initialized
INFO - 2025-10-29 08:25:35 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:25:35 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:25:35 --> Helper loaded: form_helper
INFO - 2025-10-29 08:25:35 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:25:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:25:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 08:25:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:25:35 --> Final output sent to browser
DEBUG - 2025-10-29 08:25:35 --> Total execution time: 0.0990
INFO - 2025-10-29 08:25:54 --> Config Class Initialized
INFO - 2025-10-29 08:25:54 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:25:54 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:25:54 --> Utf8 Class Initialized
INFO - 2025-10-29 08:25:54 --> URI Class Initialized
INFO - 2025-10-29 08:25:54 --> Router Class Initialized
INFO - 2025-10-29 08:25:54 --> Output Class Initialized
INFO - 2025-10-29 08:25:54 --> Security Class Initialized
DEBUG - 2025-10-29 08:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:25:54 --> Input Class Initialized
INFO - 2025-10-29 08:25:54 --> Language Class Initialized
INFO - 2025-10-29 08:25:54 --> Loader Class Initialized
INFO - 2025-10-29 08:25:54 --> Helper loaded: url_helper
INFO - 2025-10-29 08:25:54 --> Database Driver Class Initialized
INFO - 2025-10-29 08:25:54 --> Controller Class Initialized
INFO - 2025-10-29 08:25:54 --> Model "Student_model" initialized
INFO - 2025-10-29 08:25:54 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:25:54 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:25:54 --> Helper loaded: form_helper
INFO - 2025-10-29 08:25:54 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:25:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:25:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 08:25:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:25:54 --> Final output sent to browser
DEBUG - 2025-10-29 08:25:54 --> Total execution time: 0.0993
INFO - 2025-10-29 08:25:56 --> Config Class Initialized
INFO - 2025-10-29 08:25:56 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:25:56 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:25:56 --> Utf8 Class Initialized
INFO - 2025-10-29 08:25:56 --> URI Class Initialized
INFO - 2025-10-29 08:25:56 --> Router Class Initialized
INFO - 2025-10-29 08:25:56 --> Output Class Initialized
INFO - 2025-10-29 08:25:56 --> Security Class Initialized
DEBUG - 2025-10-29 08:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:25:56 --> Input Class Initialized
INFO - 2025-10-29 08:25:56 --> Language Class Initialized
INFO - 2025-10-29 08:25:56 --> Loader Class Initialized
INFO - 2025-10-29 08:25:56 --> Helper loaded: url_helper
INFO - 2025-10-29 08:25:56 --> Database Driver Class Initialized
INFO - 2025-10-29 08:25:56 --> Controller Class Initialized
INFO - 2025-10-29 08:25:56 --> Model "Student_model" initialized
INFO - 2025-10-29 08:25:56 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:25:56 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:25:56 --> Helper loaded: form_helper
INFO - 2025-10-29 08:25:56 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:25:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:25:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 08:25:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:25:56 --> Final output sent to browser
DEBUG - 2025-10-29 08:25:56 --> Total execution time: 0.0963
INFO - 2025-10-29 08:26:51 --> Config Class Initialized
INFO - 2025-10-29 08:26:51 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:26:51 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:26:51 --> Utf8 Class Initialized
INFO - 2025-10-29 08:26:51 --> URI Class Initialized
INFO - 2025-10-29 08:26:51 --> Router Class Initialized
INFO - 2025-10-29 08:26:51 --> Output Class Initialized
INFO - 2025-10-29 08:26:51 --> Security Class Initialized
DEBUG - 2025-10-29 08:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:26:51 --> Input Class Initialized
INFO - 2025-10-29 08:26:51 --> Language Class Initialized
INFO - 2025-10-29 08:26:51 --> Loader Class Initialized
INFO - 2025-10-29 08:26:51 --> Helper loaded: url_helper
INFO - 2025-10-29 08:26:51 --> Database Driver Class Initialized
INFO - 2025-10-29 08:26:51 --> Controller Class Initialized
INFO - 2025-10-29 08:26:51 --> Model "Student_model" initialized
INFO - 2025-10-29 08:26:51 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:26:51 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:26:51 --> Helper loaded: form_helper
INFO - 2025-10-29 08:26:51 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:26:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-29 08:26:51 --> Config Class Initialized
INFO - 2025-10-29 08:26:51 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:26:51 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:26:51 --> Utf8 Class Initialized
INFO - 2025-10-29 08:26:51 --> URI Class Initialized
INFO - 2025-10-29 08:26:51 --> Router Class Initialized
INFO - 2025-10-29 08:26:51 --> Output Class Initialized
INFO - 2025-10-29 08:26:51 --> Security Class Initialized
DEBUG - 2025-10-29 08:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:26:51 --> Input Class Initialized
INFO - 2025-10-29 08:26:51 --> Language Class Initialized
INFO - 2025-10-29 08:26:51 --> Loader Class Initialized
INFO - 2025-10-29 08:26:51 --> Helper loaded: url_helper
INFO - 2025-10-29 08:26:51 --> Database Driver Class Initialized
INFO - 2025-10-29 08:26:51 --> Controller Class Initialized
INFO - 2025-10-29 08:26:51 --> Model "Student_model" initialized
INFO - 2025-10-29 08:26:51 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:26:51 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:26:51 --> Helper loaded: form_helper
INFO - 2025-10-29 08:26:51 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:26:51 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 08:26:51 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 08:26:51 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 08:26:51 --> Final output sent to browser
DEBUG - 2025-10-29 08:26:51 --> Total execution time: 0.1078
INFO - 2025-10-29 08:27:13 --> Config Class Initialized
INFO - 2025-10-29 08:27:13 --> Hooks Class Initialized
DEBUG - 2025-10-29 08:27:13 --> UTF-8 Support Enabled
INFO - 2025-10-29 08:27:13 --> Utf8 Class Initialized
INFO - 2025-10-29 08:27:13 --> URI Class Initialized
INFO - 2025-10-29 08:27:13 --> Router Class Initialized
INFO - 2025-10-29 08:27:13 --> Output Class Initialized
INFO - 2025-10-29 08:27:13 --> Security Class Initialized
DEBUG - 2025-10-29 08:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 08:27:13 --> Input Class Initialized
INFO - 2025-10-29 08:27:13 --> Language Class Initialized
INFO - 2025-10-29 08:27:13 --> Loader Class Initialized
INFO - 2025-10-29 08:27:13 --> Helper loaded: url_helper
INFO - 2025-10-29 08:27:13 --> Database Driver Class Initialized
INFO - 2025-10-29 08:27:13 --> Controller Class Initialized
INFO - 2025-10-29 08:27:13 --> Model "Student_model" initialized
INFO - 2025-10-29 08:27:13 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 08:27:13 --> Model "Payment_model" initialized
INFO - 2025-10-29 08:27:13 --> Helper loaded: form_helper
INFO - 2025-10-29 08:27:13 --> Form Validation Class Initialized
DEBUG - 2025-10-29 08:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 08:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 08:27:13 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:38:12 --> Config Class Initialized
INFO - 2025-10-29 10:38:12 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:38:12 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:38:12 --> Utf8 Class Initialized
INFO - 2025-10-29 10:38:12 --> URI Class Initialized
INFO - 2025-10-29 10:38:12 --> Router Class Initialized
INFO - 2025-10-29 10:38:12 --> Output Class Initialized
INFO - 2025-10-29 10:38:12 --> Security Class Initialized
DEBUG - 2025-10-29 10:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:38:12 --> Input Class Initialized
INFO - 2025-10-29 10:38:12 --> Language Class Initialized
INFO - 2025-10-29 10:38:12 --> Loader Class Initialized
INFO - 2025-10-29 10:38:12 --> Helper loaded: url_helper
INFO - 2025-10-29 10:38:12 --> Database Driver Class Initialized
INFO - 2025-10-29 10:38:12 --> Controller Class Initialized
INFO - 2025-10-29 10:38:12 --> Model "Student_model" initialized
INFO - 2025-10-29 10:38:12 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:38:12 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:38:12 --> Helper loaded: form_helper
INFO - 2025-10-29 10:38:12 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:38:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:38:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 10:38:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:38:12 --> Final output sent to browser
DEBUG - 2025-10-29 10:38:12 --> Total execution time: 0.1050
INFO - 2025-10-29 10:38:14 --> Config Class Initialized
INFO - 2025-10-29 10:38:14 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:38:14 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:38:14 --> Utf8 Class Initialized
INFO - 2025-10-29 10:38:14 --> URI Class Initialized
INFO - 2025-10-29 10:38:14 --> Router Class Initialized
INFO - 2025-10-29 10:38:14 --> Output Class Initialized
INFO - 2025-10-29 10:38:14 --> Security Class Initialized
DEBUG - 2025-10-29 10:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:38:14 --> Input Class Initialized
INFO - 2025-10-29 10:38:14 --> Language Class Initialized
INFO - 2025-10-29 10:38:14 --> Loader Class Initialized
INFO - 2025-10-29 10:38:14 --> Helper loaded: url_helper
INFO - 2025-10-29 10:38:14 --> Database Driver Class Initialized
INFO - 2025-10-29 10:38:14 --> Controller Class Initialized
INFO - 2025-10-29 10:38:14 --> Model "Student_model" initialized
INFO - 2025-10-29 10:38:14 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:38:14 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:38:14 --> Helper loaded: form_helper
INFO - 2025-10-29 10:38:14 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:38:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:38:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/edit.php
INFO - 2025-10-29 10:38:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:38:14 --> Final output sent to browser
DEBUG - 2025-10-29 10:38:14 --> Total execution time: 0.0960
INFO - 2025-10-29 10:38:19 --> Config Class Initialized
INFO - 2025-10-29 10:38:19 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:38:19 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:38:19 --> Utf8 Class Initialized
INFO - 2025-10-29 10:38:19 --> URI Class Initialized
INFO - 2025-10-29 10:38:19 --> Router Class Initialized
INFO - 2025-10-29 10:38:19 --> Output Class Initialized
INFO - 2025-10-29 10:38:19 --> Security Class Initialized
DEBUG - 2025-10-29 10:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:38:19 --> Input Class Initialized
INFO - 2025-10-29 10:38:19 --> Language Class Initialized
INFO - 2025-10-29 10:38:19 --> Loader Class Initialized
INFO - 2025-10-29 10:38:19 --> Helper loaded: url_helper
INFO - 2025-10-29 10:38:19 --> Database Driver Class Initialized
INFO - 2025-10-29 10:38:19 --> Controller Class Initialized
INFO - 2025-10-29 10:38:19 --> Model "Student_model" initialized
INFO - 2025-10-29 10:38:19 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:38:19 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:38:19 --> Helper loaded: form_helper
INFO - 2025-10-29 10:38:19 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:38:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:38:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-29 10:38:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:38:19 --> Final output sent to browser
DEBUG - 2025-10-29 10:38:19 --> Total execution time: 0.0885
INFO - 2025-10-29 10:38:23 --> Config Class Initialized
INFO - 2025-10-29 10:38:23 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:38:23 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:38:23 --> Utf8 Class Initialized
INFO - 2025-10-29 10:38:23 --> URI Class Initialized
INFO - 2025-10-29 10:38:23 --> Router Class Initialized
INFO - 2025-10-29 10:38:23 --> Output Class Initialized
INFO - 2025-10-29 10:38:23 --> Security Class Initialized
DEBUG - 2025-10-29 10:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:38:23 --> Input Class Initialized
INFO - 2025-10-29 10:38:23 --> Language Class Initialized
INFO - 2025-10-29 10:38:23 --> Loader Class Initialized
INFO - 2025-10-29 10:38:23 --> Helper loaded: url_helper
INFO - 2025-10-29 10:38:23 --> Database Driver Class Initialized
INFO - 2025-10-29 10:38:23 --> Controller Class Initialized
INFO - 2025-10-29 10:38:23 --> Model "Student_model" initialized
INFO - 2025-10-29 10:38:23 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:38:23 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:38:23 --> Helper loaded: form_helper
INFO - 2025-10-29 10:38:23 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:38:23 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:38:23 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 10:38:23 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:38:23 --> Final output sent to browser
DEBUG - 2025-10-29 10:38:23 --> Total execution time: 0.0954
INFO - 2025-10-29 10:38:24 --> Config Class Initialized
INFO - 2025-10-29 10:38:24 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:38:24 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:38:24 --> Utf8 Class Initialized
INFO - 2025-10-29 10:38:24 --> URI Class Initialized
INFO - 2025-10-29 10:38:24 --> Router Class Initialized
INFO - 2025-10-29 10:38:24 --> Output Class Initialized
INFO - 2025-10-29 10:38:24 --> Security Class Initialized
DEBUG - 2025-10-29 10:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:38:24 --> Input Class Initialized
INFO - 2025-10-29 10:38:24 --> Language Class Initialized
INFO - 2025-10-29 10:38:24 --> Loader Class Initialized
INFO - 2025-10-29 10:38:24 --> Helper loaded: url_helper
INFO - 2025-10-29 10:38:24 --> Database Driver Class Initialized
INFO - 2025-10-29 10:38:24 --> Controller Class Initialized
INFO - 2025-10-29 10:38:24 --> Model "Student_model" initialized
INFO - 2025-10-29 10:38:24 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:38:24 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:38:24 --> Helper loaded: form_helper
INFO - 2025-10-29 10:38:24 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:38:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:38:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-29 10:38:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:38:24 --> Final output sent to browser
DEBUG - 2025-10-29 10:38:24 --> Total execution time: 0.1023
INFO - 2025-10-29 10:38:26 --> Config Class Initialized
INFO - 2025-10-29 10:38:26 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:38:26 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:38:26 --> Utf8 Class Initialized
INFO - 2025-10-29 10:38:26 --> URI Class Initialized
INFO - 2025-10-29 10:38:26 --> Router Class Initialized
INFO - 2025-10-29 10:38:26 --> Output Class Initialized
INFO - 2025-10-29 10:38:26 --> Security Class Initialized
DEBUG - 2025-10-29 10:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:38:26 --> Input Class Initialized
INFO - 2025-10-29 10:38:26 --> Language Class Initialized
INFO - 2025-10-29 10:38:26 --> Loader Class Initialized
INFO - 2025-10-29 10:38:26 --> Helper loaded: url_helper
INFO - 2025-10-29 10:38:26 --> Database Driver Class Initialized
INFO - 2025-10-29 10:38:26 --> Controller Class Initialized
INFO - 2025-10-29 10:38:26 --> Model "Student_model" initialized
INFO - 2025-10-29 10:38:26 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:38:26 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:38:26 --> Helper loaded: form_helper
INFO - 2025-10-29 10:38:26 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:38:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:38:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 10:38:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:38:26 --> Final output sent to browser
DEBUG - 2025-10-29 10:38:26 --> Total execution time: 0.1240
INFO - 2025-10-29 10:38:27 --> Config Class Initialized
INFO - 2025-10-29 10:38:27 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:38:27 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:38:27 --> Utf8 Class Initialized
INFO - 2025-10-29 10:38:27 --> URI Class Initialized
INFO - 2025-10-29 10:38:27 --> Router Class Initialized
INFO - 2025-10-29 10:38:27 --> Output Class Initialized
INFO - 2025-10-29 10:38:27 --> Security Class Initialized
DEBUG - 2025-10-29 10:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:38:27 --> Input Class Initialized
INFO - 2025-10-29 10:38:27 --> Language Class Initialized
INFO - 2025-10-29 10:38:27 --> Loader Class Initialized
INFO - 2025-10-29 10:38:27 --> Helper loaded: url_helper
INFO - 2025-10-29 10:38:27 --> Database Driver Class Initialized
INFO - 2025-10-29 10:38:27 --> Controller Class Initialized
INFO - 2025-10-29 10:38:27 --> Model "Student_model" initialized
INFO - 2025-10-29 10:38:27 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:38:27 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:38:27 --> Helper loaded: form_helper
INFO - 2025-10-29 10:38:27 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:38:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:38:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 10:38:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:38:28 --> Final output sent to browser
DEBUG - 2025-10-29 10:38:28 --> Total execution time: 0.0987
INFO - 2025-10-29 10:38:29 --> Config Class Initialized
INFO - 2025-10-29 10:38:29 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:38:29 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:38:29 --> Utf8 Class Initialized
INFO - 2025-10-29 10:38:29 --> URI Class Initialized
INFO - 2025-10-29 10:38:29 --> Router Class Initialized
INFO - 2025-10-29 10:38:29 --> Output Class Initialized
INFO - 2025-10-29 10:38:29 --> Security Class Initialized
DEBUG - 2025-10-29 10:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:38:29 --> Input Class Initialized
INFO - 2025-10-29 10:38:29 --> Language Class Initialized
INFO - 2025-10-29 10:38:29 --> Loader Class Initialized
INFO - 2025-10-29 10:38:29 --> Helper loaded: url_helper
INFO - 2025-10-29 10:38:29 --> Database Driver Class Initialized
INFO - 2025-10-29 10:38:29 --> Controller Class Initialized
INFO - 2025-10-29 10:38:29 --> Model "Student_model" initialized
INFO - 2025-10-29 10:38:29 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:38:29 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:38:29 --> Helper loaded: form_helper
INFO - 2025-10-29 10:38:29 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:38:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:38:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 10:38:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:38:29 --> Final output sent to browser
DEBUG - 2025-10-29 10:38:29 --> Total execution time: 0.0764
INFO - 2025-10-29 10:38:35 --> Config Class Initialized
INFO - 2025-10-29 10:38:35 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:38:35 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:38:35 --> Utf8 Class Initialized
INFO - 2025-10-29 10:38:35 --> URI Class Initialized
INFO - 2025-10-29 10:38:35 --> Router Class Initialized
INFO - 2025-10-29 10:38:35 --> Output Class Initialized
INFO - 2025-10-29 10:38:35 --> Security Class Initialized
DEBUG - 2025-10-29 10:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:38:35 --> Input Class Initialized
INFO - 2025-10-29 10:38:35 --> Language Class Initialized
ERROR - 2025-10-29 10:38:35 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 10:38:55 --> Config Class Initialized
INFO - 2025-10-29 10:38:55 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:38:55 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:38:55 --> Utf8 Class Initialized
INFO - 2025-10-29 10:38:55 --> URI Class Initialized
INFO - 2025-10-29 10:38:55 --> Router Class Initialized
INFO - 2025-10-29 10:38:55 --> Output Class Initialized
INFO - 2025-10-29 10:38:55 --> Security Class Initialized
DEBUG - 2025-10-29 10:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:38:55 --> Input Class Initialized
INFO - 2025-10-29 10:38:55 --> Language Class Initialized
INFO - 2025-10-29 10:38:55 --> Loader Class Initialized
INFO - 2025-10-29 10:38:55 --> Helper loaded: url_helper
INFO - 2025-10-29 10:38:55 --> Database Driver Class Initialized
INFO - 2025-10-29 10:38:55 --> Controller Class Initialized
INFO - 2025-10-29 10:38:55 --> Model "Student_model" initialized
INFO - 2025-10-29 10:38:55 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:38:55 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:38:55 --> Helper loaded: form_helper
INFO - 2025-10-29 10:38:55 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:38:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:38:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 10:38:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:38:55 --> Final output sent to browser
DEBUG - 2025-10-29 10:38:55 --> Total execution time: 0.0963
INFO - 2025-10-29 10:39:19 --> Config Class Initialized
INFO - 2025-10-29 10:39:19 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:39:19 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:39:19 --> Utf8 Class Initialized
INFO - 2025-10-29 10:39:19 --> URI Class Initialized
INFO - 2025-10-29 10:39:19 --> Router Class Initialized
INFO - 2025-10-29 10:39:19 --> Output Class Initialized
INFO - 2025-10-29 10:39:19 --> Security Class Initialized
DEBUG - 2025-10-29 10:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:39:19 --> Input Class Initialized
INFO - 2025-10-29 10:39:19 --> Language Class Initialized
INFO - 2025-10-29 10:39:19 --> Loader Class Initialized
INFO - 2025-10-29 10:39:19 --> Helper loaded: url_helper
INFO - 2025-10-29 10:39:19 --> Database Driver Class Initialized
INFO - 2025-10-29 10:39:19 --> Controller Class Initialized
INFO - 2025-10-29 10:39:19 --> Model "Student_model" initialized
INFO - 2025-10-29 10:39:19 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:39:19 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:39:19 --> Helper loaded: form_helper
INFO - 2025-10-29 10:39:19 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:39:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-29 10:39:19 --> Config Class Initialized
INFO - 2025-10-29 10:39:19 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:39:19 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:39:19 --> Utf8 Class Initialized
INFO - 2025-10-29 10:39:19 --> URI Class Initialized
INFO - 2025-10-29 10:39:19 --> Router Class Initialized
INFO - 2025-10-29 10:39:19 --> Output Class Initialized
INFO - 2025-10-29 10:39:19 --> Security Class Initialized
DEBUG - 2025-10-29 10:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:39:19 --> Input Class Initialized
INFO - 2025-10-29 10:39:19 --> Language Class Initialized
INFO - 2025-10-29 10:39:19 --> Loader Class Initialized
INFO - 2025-10-29 10:39:19 --> Helper loaded: url_helper
INFO - 2025-10-29 10:39:19 --> Database Driver Class Initialized
INFO - 2025-10-29 10:39:19 --> Controller Class Initialized
INFO - 2025-10-29 10:39:19 --> Model "Student_model" initialized
INFO - 2025-10-29 10:39:19 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:39:19 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:39:19 --> Helper loaded: form_helper
INFO - 2025-10-29 10:39:19 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:39:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:39:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 10:39:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:39:19 --> Final output sent to browser
DEBUG - 2025-10-29 10:39:19 --> Total execution time: 0.0974
INFO - 2025-10-29 10:39:24 --> Config Class Initialized
INFO - 2025-10-29 10:39:24 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:39:24 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:39:24 --> Utf8 Class Initialized
INFO - 2025-10-29 10:39:24 --> URI Class Initialized
INFO - 2025-10-29 10:39:24 --> Router Class Initialized
INFO - 2025-10-29 10:39:24 --> Output Class Initialized
INFO - 2025-10-29 10:39:24 --> Security Class Initialized
DEBUG - 2025-10-29 10:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:39:24 --> Input Class Initialized
INFO - 2025-10-29 10:39:24 --> Language Class Initialized
INFO - 2025-10-29 10:39:24 --> Loader Class Initialized
INFO - 2025-10-29 10:39:24 --> Helper loaded: url_helper
INFO - 2025-10-29 10:39:24 --> Database Driver Class Initialized
INFO - 2025-10-29 10:39:24 --> Controller Class Initialized
INFO - 2025-10-29 10:39:24 --> Model "Student_model" initialized
INFO - 2025-10-29 10:39:24 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:39:24 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:39:24 --> Helper loaded: form_helper
INFO - 2025-10-29 10:39:24 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:39:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:39:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/edit.php
INFO - 2025-10-29 10:39:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:39:24 --> Final output sent to browser
DEBUG - 2025-10-29 10:39:24 --> Total execution time: 0.1269
INFO - 2025-10-29 10:39:26 --> Config Class Initialized
INFO - 2025-10-29 10:39:26 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:39:26 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:39:26 --> Utf8 Class Initialized
INFO - 2025-10-29 10:39:26 --> URI Class Initialized
INFO - 2025-10-29 10:39:26 --> Router Class Initialized
INFO - 2025-10-29 10:39:26 --> Output Class Initialized
INFO - 2025-10-29 10:39:26 --> Security Class Initialized
DEBUG - 2025-10-29 10:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:39:26 --> Input Class Initialized
INFO - 2025-10-29 10:39:26 --> Language Class Initialized
INFO - 2025-10-29 10:39:26 --> Loader Class Initialized
INFO - 2025-10-29 10:39:26 --> Helper loaded: url_helper
INFO - 2025-10-29 10:39:26 --> Database Driver Class Initialized
INFO - 2025-10-29 10:39:26 --> Controller Class Initialized
INFO - 2025-10-29 10:39:26 --> Model "Student_model" initialized
INFO - 2025-10-29 10:39:26 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:39:26 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:39:26 --> Helper loaded: form_helper
INFO - 2025-10-29 10:39:26 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:39:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:39:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-29 10:39:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:39:26 --> Final output sent to browser
DEBUG - 2025-10-29 10:39:26 --> Total execution time: 0.1098
INFO - 2025-10-29 10:39:32 --> Config Class Initialized
INFO - 2025-10-29 10:39:32 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:39:32 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:39:32 --> Utf8 Class Initialized
INFO - 2025-10-29 10:39:32 --> URI Class Initialized
INFO - 2025-10-29 10:39:32 --> Router Class Initialized
INFO - 2025-10-29 10:39:32 --> Output Class Initialized
INFO - 2025-10-29 10:39:32 --> Security Class Initialized
DEBUG - 2025-10-29 10:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:39:32 --> Input Class Initialized
INFO - 2025-10-29 10:39:32 --> Language Class Initialized
INFO - 2025-10-29 10:39:32 --> Loader Class Initialized
INFO - 2025-10-29 10:39:32 --> Helper loaded: url_helper
INFO - 2025-10-29 10:39:32 --> Database Driver Class Initialized
INFO - 2025-10-29 10:39:32 --> Controller Class Initialized
INFO - 2025-10-29 10:39:32 --> Model "Student_model" initialized
INFO - 2025-10-29 10:39:32 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:39:32 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:39:32 --> Helper loaded: form_helper
INFO - 2025-10-29 10:39:32 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:39:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:39:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 10:39:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:39:32 --> Final output sent to browser
DEBUG - 2025-10-29 10:39:32 --> Total execution time: 0.0921
INFO - 2025-10-29 10:41:04 --> Config Class Initialized
INFO - 2025-10-29 10:41:04 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:41:04 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:41:04 --> Utf8 Class Initialized
INFO - 2025-10-29 10:41:04 --> URI Class Initialized
INFO - 2025-10-29 10:41:04 --> Router Class Initialized
INFO - 2025-10-29 10:41:04 --> Output Class Initialized
INFO - 2025-10-29 10:41:04 --> Security Class Initialized
DEBUG - 2025-10-29 10:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:41:04 --> Input Class Initialized
INFO - 2025-10-29 10:41:04 --> Language Class Initialized
ERROR - 2025-10-29 10:41:04 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 10:42:08 --> Config Class Initialized
INFO - 2025-10-29 10:42:08 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:42:08 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:42:08 --> Utf8 Class Initialized
INFO - 2025-10-29 10:42:08 --> URI Class Initialized
INFO - 2025-10-29 10:42:08 --> Router Class Initialized
INFO - 2025-10-29 10:42:08 --> Output Class Initialized
INFO - 2025-10-29 10:42:08 --> Security Class Initialized
DEBUG - 2025-10-29 10:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:42:08 --> Input Class Initialized
INFO - 2025-10-29 10:42:08 --> Language Class Initialized
INFO - 2025-10-29 10:42:08 --> Loader Class Initialized
INFO - 2025-10-29 10:42:08 --> Helper loaded: url_helper
INFO - 2025-10-29 10:42:08 --> Database Driver Class Initialized
INFO - 2025-10-29 10:42:08 --> Controller Class Initialized
INFO - 2025-10-29 10:42:08 --> Model "Student_model" initialized
INFO - 2025-10-29 10:42:08 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:42:08 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:42:08 --> Helper loaded: form_helper
INFO - 2025-10-29 10:42:08 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:42:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:42:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-29 10:42:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:42:08 --> Final output sent to browser
DEBUG - 2025-10-29 10:42:08 --> Total execution time: 0.1352
INFO - 2025-10-29 10:42:12 --> Config Class Initialized
INFO - 2025-10-29 10:42:12 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:42:12 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:42:12 --> Utf8 Class Initialized
INFO - 2025-10-29 10:42:12 --> URI Class Initialized
INFO - 2025-10-29 10:42:12 --> Router Class Initialized
INFO - 2025-10-29 10:42:12 --> Output Class Initialized
INFO - 2025-10-29 10:42:12 --> Security Class Initialized
DEBUG - 2025-10-29 10:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:42:12 --> Input Class Initialized
INFO - 2025-10-29 10:42:12 --> Language Class Initialized
INFO - 2025-10-29 10:42:12 --> Loader Class Initialized
INFO - 2025-10-29 10:42:12 --> Helper loaded: url_helper
INFO - 2025-10-29 10:42:12 --> Database Driver Class Initialized
INFO - 2025-10-29 10:42:12 --> Controller Class Initialized
INFO - 2025-10-29 10:42:12 --> Model "Student_model" initialized
INFO - 2025-10-29 10:42:12 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:42:12 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:42:12 --> Helper loaded: form_helper
INFO - 2025-10-29 10:42:12 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:42:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:42:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 10:42:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:42:12 --> Final output sent to browser
DEBUG - 2025-10-29 10:42:12 --> Total execution time: 0.1024
INFO - 2025-10-29 10:43:31 --> Config Class Initialized
INFO - 2025-10-29 10:43:31 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:43:31 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:43:31 --> Utf8 Class Initialized
INFO - 2025-10-29 10:50:23 --> Config Class Initialized
INFO - 2025-10-29 10:50:23 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:50:23 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:50:23 --> Utf8 Class Initialized
INFO - 2025-10-29 10:50:23 --> URI Class Initialized
INFO - 2025-10-29 10:50:23 --> Router Class Initialized
INFO - 2025-10-29 10:50:23 --> Output Class Initialized
INFO - 2025-10-29 10:50:23 --> Security Class Initialized
DEBUG - 2025-10-29 10:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:50:23 --> Input Class Initialized
INFO - 2025-10-29 10:50:23 --> Language Class Initialized
INFO - 2025-10-29 10:50:23 --> Loader Class Initialized
INFO - 2025-10-29 10:50:23 --> Helper loaded: url_helper
INFO - 2025-10-29 10:50:23 --> Database Driver Class Initialized
INFO - 2025-10-29 10:50:23 --> Controller Class Initialized
INFO - 2025-10-29 10:50:23 --> Model "Student_model" initialized
INFO - 2025-10-29 10:50:23 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:50:23 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:50:23 --> Helper loaded: form_helper
INFO - 2025-10-29 10:50:23 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:50:23 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 10:50:23 --> Query error: Unknown column 'fm.name' in 'field list' - Invalid query: SELECT `sf`.*, `s`.`name`, `s`.`reg_no`, `s`.`phone`, `s`.`address`, `fm`.`name` as `fee_name`
FROM `student_fees` `sf`
JOIN `student` `s` ON `sf`.`student_id` = `s`.`id`
JOIN `fees_master` `fm` ON `sf`.`fee_id` = `fm`.`id`
WHERE `sf`.`status` = '1'
ORDER BY `sf`.`created` DESC
 LIMIT 50
INFO - 2025-10-29 10:50:23 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 10:50:49 --> Config Class Initialized
INFO - 2025-10-29 10:50:49 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:50:49 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:50:49 --> Utf8 Class Initialized
INFO - 2025-10-29 10:50:49 --> URI Class Initialized
INFO - 2025-10-29 10:50:49 --> Router Class Initialized
INFO - 2025-10-29 10:50:49 --> Output Class Initialized
INFO - 2025-10-29 10:50:49 --> Security Class Initialized
DEBUG - 2025-10-29 10:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:50:49 --> Input Class Initialized
INFO - 2025-10-29 10:50:49 --> Language Class Initialized
INFO - 2025-10-29 10:50:49 --> Loader Class Initialized
INFO - 2025-10-29 10:50:49 --> Helper loaded: url_helper
INFO - 2025-10-29 10:50:50 --> Database Driver Class Initialized
INFO - 2025-10-29 10:50:50 --> Controller Class Initialized
INFO - 2025-10-29 10:50:50 --> Model "Student_model" initialized
INFO - 2025-10-29 10:50:50 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:50:50 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:50:50 --> Helper loaded: form_helper
INFO - 2025-10-29 10:50:50 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:50:50 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 10:50:50 --> Query error: Unknown column 'fm.name' in 'field list' - Invalid query: SELECT `sf`.*, `s`.`name`, `s`.`reg_no`, `s`.`phone`, `s`.`address`, `fm`.`name` as `fee_name`
FROM `student_fees` `sf`
JOIN `student` `s` ON `sf`.`student_id` = `s`.`id`
JOIN `fees_master` `fm` ON `sf`.`fee_id` = `fm`.`id`
WHERE `sf`.`status` = '1'
ORDER BY `sf`.`created` DESC
 LIMIT 50
INFO - 2025-10-29 10:50:50 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 10:50:57 --> Config Class Initialized
INFO - 2025-10-29 10:50:57 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:50:57 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:50:57 --> Utf8 Class Initialized
INFO - 2025-10-29 10:50:57 --> URI Class Initialized
INFO - 2025-10-29 10:50:57 --> Router Class Initialized
INFO - 2025-10-29 10:50:57 --> Output Class Initialized
INFO - 2025-10-29 10:50:57 --> Security Class Initialized
DEBUG - 2025-10-29 10:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:50:57 --> Input Class Initialized
INFO - 2025-10-29 10:50:57 --> Language Class Initialized
INFO - 2025-10-29 10:50:57 --> Loader Class Initialized
INFO - 2025-10-29 10:50:57 --> Helper loaded: url_helper
INFO - 2025-10-29 10:50:57 --> Database Driver Class Initialized
INFO - 2025-10-29 10:50:57 --> Controller Class Initialized
INFO - 2025-10-29 10:50:57 --> Model "Student_model" initialized
INFO - 2025-10-29 10:50:57 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:50:57 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:50:57 --> Helper loaded: form_helper
INFO - 2025-10-29 10:50:57 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:50:57 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 10:50:57 --> Query error: Unknown column 'fm.name' in 'field list' - Invalid query: SELECT `sf`.*, `s`.`name`, `s`.`reg_no`, `s`.`phone`, `s`.`address`, `fm`.`name` as `fee_name`
FROM `student_fees` `sf`
JOIN `student` `s` ON `sf`.`student_id` = `s`.`id`
JOIN `fees_master` `fm` ON `sf`.`fee_id` = `fm`.`id`
WHERE `sf`.`status` = '1'
ORDER BY `sf`.`created` DESC
 LIMIT 50
INFO - 2025-10-29 10:50:57 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 10:51:31 --> Config Class Initialized
INFO - 2025-10-29 10:51:31 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:51:31 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:51:31 --> Utf8 Class Initialized
INFO - 2025-10-29 10:51:34 --> Config Class Initialized
INFO - 2025-10-29 10:51:34 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:51:34 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:51:34 --> Utf8 Class Initialized
INFO - 2025-10-29 10:51:34 --> URI Class Initialized
INFO - 2025-10-29 10:51:34 --> Router Class Initialized
INFO - 2025-10-29 10:51:34 --> Output Class Initialized
INFO - 2025-10-29 10:51:34 --> Security Class Initialized
DEBUG - 2025-10-29 10:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:51:34 --> Input Class Initialized
INFO - 2025-10-29 10:51:34 --> Language Class Initialized
INFO - 2025-10-29 10:51:34 --> Loader Class Initialized
INFO - 2025-10-29 10:51:34 --> Helper loaded: url_helper
INFO - 2025-10-29 10:51:34 --> Database Driver Class Initialized
INFO - 2025-10-29 10:51:34 --> Controller Class Initialized
INFO - 2025-10-29 10:51:34 --> Model "Student_model" initialized
INFO - 2025-10-29 10:51:34 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:51:34 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:51:34 --> Helper loaded: form_helper
INFO - 2025-10-29 10:51:34 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:51:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:51:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 10:51:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:51:34 --> Final output sent to browser
DEBUG - 2025-10-29 10:51:34 --> Total execution time: 0.1237
INFO - 2025-10-29 10:51:39 --> Config Class Initialized
INFO - 2025-10-29 10:51:39 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:51:39 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:51:39 --> Utf8 Class Initialized
INFO - 2025-10-29 10:51:39 --> URI Class Initialized
INFO - 2025-10-29 10:51:39 --> Router Class Initialized
INFO - 2025-10-29 10:51:39 --> Output Class Initialized
INFO - 2025-10-29 10:51:39 --> Security Class Initialized
DEBUG - 2025-10-29 10:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:51:39 --> Input Class Initialized
INFO - 2025-10-29 10:51:39 --> Language Class Initialized
ERROR - 2025-10-29 10:51:39 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 10:51:42 --> Config Class Initialized
INFO - 2025-10-29 10:51:42 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:51:42 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:51:42 --> Utf8 Class Initialized
INFO - 2025-10-29 10:51:42 --> URI Class Initialized
INFO - 2025-10-29 10:51:42 --> Router Class Initialized
INFO - 2025-10-29 10:51:42 --> Output Class Initialized
INFO - 2025-10-29 10:51:42 --> Security Class Initialized
DEBUG - 2025-10-29 10:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:51:42 --> Input Class Initialized
INFO - 2025-10-29 10:51:42 --> Language Class Initialized
ERROR - 2025-10-29 10:51:42 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 10:51:54 --> Config Class Initialized
INFO - 2025-10-29 10:51:54 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:51:54 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:51:54 --> Utf8 Class Initialized
INFO - 2025-10-29 10:51:54 --> URI Class Initialized
INFO - 2025-10-29 10:51:54 --> Router Class Initialized
INFO - 2025-10-29 10:51:54 --> Output Class Initialized
INFO - 2025-10-29 10:51:54 --> Security Class Initialized
DEBUG - 2025-10-29 10:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:51:54 --> Input Class Initialized
INFO - 2025-10-29 10:51:54 --> Language Class Initialized
INFO - 2025-10-29 10:51:54 --> Loader Class Initialized
INFO - 2025-10-29 10:51:54 --> Helper loaded: url_helper
INFO - 2025-10-29 10:51:54 --> Database Driver Class Initialized
INFO - 2025-10-29 10:51:54 --> Controller Class Initialized
INFO - 2025-10-29 10:51:54 --> Model "Student_model" initialized
INFO - 2025-10-29 10:51:54 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:51:54 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:51:54 --> Helper loaded: form_helper
INFO - 2025-10-29 10:51:54 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:51:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:51:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 10:51:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:51:54 --> Final output sent to browser
DEBUG - 2025-10-29 10:51:54 --> Total execution time: 0.0928
INFO - 2025-10-29 10:52:11 --> Config Class Initialized
INFO - 2025-10-29 10:52:11 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:52:11 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:52:11 --> Utf8 Class Initialized
INFO - 2025-10-29 10:52:11 --> URI Class Initialized
INFO - 2025-10-29 10:52:11 --> Router Class Initialized
INFO - 2025-10-29 10:52:11 --> Output Class Initialized
INFO - 2025-10-29 10:52:11 --> Security Class Initialized
DEBUG - 2025-10-29 10:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:52:11 --> Input Class Initialized
INFO - 2025-10-29 10:52:11 --> Language Class Initialized
INFO - 2025-10-29 10:52:11 --> Loader Class Initialized
INFO - 2025-10-29 10:52:11 --> Helper loaded: url_helper
INFO - 2025-10-29 10:52:11 --> Database Driver Class Initialized
INFO - 2025-10-29 10:52:11 --> Controller Class Initialized
INFO - 2025-10-29 10:52:11 --> Model "Student_model" initialized
INFO - 2025-10-29 10:52:11 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:52:11 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:52:11 --> Helper loaded: form_helper
INFO - 2025-10-29 10:52:11 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:52:11 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:52:11 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 10:52:11 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:52:11 --> Final output sent to browser
DEBUG - 2025-10-29 10:52:11 --> Total execution time: 0.1036
INFO - 2025-10-29 10:52:16 --> Config Class Initialized
INFO - 2025-10-29 10:52:16 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:52:16 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:52:16 --> Utf8 Class Initialized
INFO - 2025-10-29 10:52:16 --> URI Class Initialized
INFO - 2025-10-29 10:52:16 --> Router Class Initialized
INFO - 2025-10-29 10:52:16 --> Output Class Initialized
INFO - 2025-10-29 10:52:16 --> Security Class Initialized
DEBUG - 2025-10-29 10:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:52:16 --> Input Class Initialized
INFO - 2025-10-29 10:52:16 --> Language Class Initialized
ERROR - 2025-10-29 10:52:16 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 10:52:59 --> Config Class Initialized
INFO - 2025-10-29 10:52:59 --> Hooks Class Initialized
DEBUG - 2025-10-29 10:52:59 --> UTF-8 Support Enabled
INFO - 2025-10-29 10:52:59 --> Utf8 Class Initialized
INFO - 2025-10-29 10:52:59 --> URI Class Initialized
INFO - 2025-10-29 10:52:59 --> Router Class Initialized
INFO - 2025-10-29 10:52:59 --> Output Class Initialized
INFO - 2025-10-29 10:52:59 --> Security Class Initialized
DEBUG - 2025-10-29 10:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 10:52:59 --> Input Class Initialized
INFO - 2025-10-29 10:52:59 --> Language Class Initialized
INFO - 2025-10-29 10:52:59 --> Loader Class Initialized
INFO - 2025-10-29 10:52:59 --> Helper loaded: url_helper
INFO - 2025-10-29 10:52:59 --> Database Driver Class Initialized
INFO - 2025-10-29 10:52:59 --> Controller Class Initialized
INFO - 2025-10-29 10:52:59 --> Model "Student_model" initialized
INFO - 2025-10-29 10:52:59 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 10:52:59 --> Model "Payment_model" initialized
INFO - 2025-10-29 10:52:59 --> Helper loaded: form_helper
INFO - 2025-10-29 10:52:59 --> Form Validation Class Initialized
DEBUG - 2025-10-29 10:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 10:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 10:52:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 10:52:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 10:52:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 10:52:59 --> Final output sent to browser
DEBUG - 2025-10-29 10:52:59 --> Total execution time: 0.0896
INFO - 2025-10-29 11:04:46 --> Config Class Initialized
INFO - 2025-10-29 11:04:46 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:04:46 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:04:46 --> Utf8 Class Initialized
INFO - 2025-10-29 11:04:46 --> URI Class Initialized
INFO - 2025-10-29 11:04:46 --> Router Class Initialized
INFO - 2025-10-29 11:04:46 --> Output Class Initialized
INFO - 2025-10-29 11:04:46 --> Security Class Initialized
DEBUG - 2025-10-29 11:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:04:46 --> Input Class Initialized
INFO - 2025-10-29 11:04:46 --> Language Class Initialized
INFO - 2025-10-29 11:04:46 --> Loader Class Initialized
INFO - 2025-10-29 11:04:46 --> Helper loaded: url_helper
INFO - 2025-10-29 11:04:46 --> Database Driver Class Initialized
INFO - 2025-10-29 11:04:46 --> Controller Class Initialized
INFO - 2025-10-29 11:04:46 --> Model "Student_model" initialized
INFO - 2025-10-29 11:04:46 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:04:46 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:04:46 --> Helper loaded: form_helper
INFO - 2025-10-29 11:04:46 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:04:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:04:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 11:04:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:04:46 --> Final output sent to browser
DEBUG - 2025-10-29 11:04:46 --> Total execution time: 0.0928
INFO - 2025-10-29 11:04:50 --> Config Class Initialized
INFO - 2025-10-29 11:04:50 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:04:50 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:04:50 --> Utf8 Class Initialized
INFO - 2025-10-29 11:04:50 --> URI Class Initialized
INFO - 2025-10-29 11:04:50 --> Router Class Initialized
INFO - 2025-10-29 11:04:50 --> Output Class Initialized
INFO - 2025-10-29 11:04:50 --> Security Class Initialized
DEBUG - 2025-10-29 11:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:04:50 --> Input Class Initialized
INFO - 2025-10-29 11:04:50 --> Language Class Initialized
INFO - 2025-10-29 11:04:50 --> Loader Class Initialized
INFO - 2025-10-29 11:04:50 --> Helper loaded: url_helper
INFO - 2025-10-29 11:04:50 --> Database Driver Class Initialized
INFO - 2025-10-29 11:04:50 --> Controller Class Initialized
INFO - 2025-10-29 11:04:50 --> Model "Student_model" initialized
INFO - 2025-10-29 11:04:50 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:04:50 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:04:50 --> Helper loaded: form_helper
INFO - 2025-10-29 11:04:50 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:04:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:04:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:04:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:04:50 --> Final output sent to browser
DEBUG - 2025-10-29 11:04:50 --> Total execution time: 0.0949
INFO - 2025-10-29 11:04:54 --> Config Class Initialized
INFO - 2025-10-29 11:04:54 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:04:54 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:04:54 --> Utf8 Class Initialized
INFO - 2025-10-29 11:04:54 --> URI Class Initialized
INFO - 2025-10-29 11:04:54 --> Router Class Initialized
INFO - 2025-10-29 11:04:54 --> Output Class Initialized
INFO - 2025-10-29 11:04:54 --> Security Class Initialized
DEBUG - 2025-10-29 11:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:04:54 --> Input Class Initialized
INFO - 2025-10-29 11:04:54 --> Language Class Initialized
INFO - 2025-10-29 11:04:54 --> Loader Class Initialized
INFO - 2025-10-29 11:04:54 --> Helper loaded: url_helper
INFO - 2025-10-29 11:04:54 --> Database Driver Class Initialized
INFO - 2025-10-29 11:04:54 --> Controller Class Initialized
INFO - 2025-10-29 11:04:54 --> Model "Student_model" initialized
INFO - 2025-10-29 11:04:54 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:04:54 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:04:54 --> Helper loaded: form_helper
INFO - 2025-10-29 11:04:54 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:04:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:04:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 11:04:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:04:54 --> Final output sent to browser
DEBUG - 2025-10-29 11:04:54 --> Total execution time: 0.1572
INFO - 2025-10-29 11:04:56 --> Config Class Initialized
INFO - 2025-10-29 11:04:56 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:04:56 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:04:56 --> Utf8 Class Initialized
INFO - 2025-10-29 11:04:56 --> URI Class Initialized
INFO - 2025-10-29 11:04:56 --> Router Class Initialized
INFO - 2025-10-29 11:04:56 --> Output Class Initialized
INFO - 2025-10-29 11:04:56 --> Security Class Initialized
DEBUG - 2025-10-29 11:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:04:56 --> Input Class Initialized
INFO - 2025-10-29 11:04:56 --> Language Class Initialized
INFO - 2025-10-29 11:04:56 --> Loader Class Initialized
INFO - 2025-10-29 11:04:56 --> Helper loaded: url_helper
INFO - 2025-10-29 11:04:56 --> Database Driver Class Initialized
INFO - 2025-10-29 11:04:56 --> Controller Class Initialized
INFO - 2025-10-29 11:04:56 --> Model "Student_model" initialized
INFO - 2025-10-29 11:04:56 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:04:56 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:04:56 --> Helper loaded: form_helper
INFO - 2025-10-29 11:04:56 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:04:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:04:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:04:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:04:56 --> Final output sent to browser
DEBUG - 2025-10-29 11:04:56 --> Total execution time: 0.1186
INFO - 2025-10-29 11:04:58 --> Config Class Initialized
INFO - 2025-10-29 11:04:58 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:04:58 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:04:58 --> Utf8 Class Initialized
INFO - 2025-10-29 11:04:58 --> URI Class Initialized
INFO - 2025-10-29 11:04:58 --> Router Class Initialized
INFO - 2025-10-29 11:04:58 --> Output Class Initialized
INFO - 2025-10-29 11:04:58 --> Security Class Initialized
DEBUG - 2025-10-29 11:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:04:58 --> Input Class Initialized
INFO - 2025-10-29 11:04:58 --> Language Class Initialized
ERROR - 2025-10-29 11:04:58 --> 404 Page Not Found: Student-fees/search_student
INFO - 2025-10-29 11:04:59 --> Config Class Initialized
INFO - 2025-10-29 11:04:59 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:04:59 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:04:59 --> Utf8 Class Initialized
INFO - 2025-10-29 11:04:59 --> URI Class Initialized
INFO - 2025-10-29 11:04:59 --> Router Class Initialized
INFO - 2025-10-29 11:04:59 --> Output Class Initialized
INFO - 2025-10-29 11:04:59 --> Security Class Initialized
DEBUG - 2025-10-29 11:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:04:59 --> Input Class Initialized
INFO - 2025-10-29 11:04:59 --> Language Class Initialized
ERROR - 2025-10-29 11:04:59 --> 404 Page Not Found: Student-fees/search_student
INFO - 2025-10-29 11:05:01 --> Config Class Initialized
INFO - 2025-10-29 11:05:01 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:05:01 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:05:01 --> Utf8 Class Initialized
INFO - 2025-10-29 11:05:01 --> URI Class Initialized
INFO - 2025-10-29 11:05:01 --> Router Class Initialized
INFO - 2025-10-29 11:05:01 --> Output Class Initialized
INFO - 2025-10-29 11:05:01 --> Security Class Initialized
DEBUG - 2025-10-29 11:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:05:01 --> Input Class Initialized
INFO - 2025-10-29 11:05:01 --> Language Class Initialized
ERROR - 2025-10-29 11:05:01 --> 404 Page Not Found: Student-fees/search_student
INFO - 2025-10-29 11:08:10 --> Config Class Initialized
INFO - 2025-10-29 11:08:10 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:08:10 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:08:10 --> Utf8 Class Initialized
INFO - 2025-10-29 11:08:10 --> URI Class Initialized
INFO - 2025-10-29 11:08:10 --> Router Class Initialized
INFO - 2025-10-29 11:08:10 --> Output Class Initialized
INFO - 2025-10-29 11:08:10 --> Security Class Initialized
DEBUG - 2025-10-29 11:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:08:10 --> Input Class Initialized
INFO - 2025-10-29 11:08:10 --> Language Class Initialized
INFO - 2025-10-29 11:08:10 --> Loader Class Initialized
INFO - 2025-10-29 11:08:10 --> Helper loaded: url_helper
INFO - 2025-10-29 11:08:10 --> Database Driver Class Initialized
INFO - 2025-10-29 11:08:10 --> Controller Class Initialized
INFO - 2025-10-29 11:08:10 --> Model "Student_model" initialized
INFO - 2025-10-29 11:08:10 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:08:10 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:08:10 --> Helper loaded: form_helper
INFO - 2025-10-29 11:08:10 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:08:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:08:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:08:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:08:10 --> Final output sent to browser
DEBUG - 2025-10-29 11:08:10 --> Total execution time: 0.0806
INFO - 2025-10-29 11:08:13 --> Config Class Initialized
INFO - 2025-10-29 11:08:13 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:08:13 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:08:13 --> Utf8 Class Initialized
INFO - 2025-10-29 11:08:13 --> URI Class Initialized
INFO - 2025-10-29 11:08:13 --> Router Class Initialized
INFO - 2025-10-29 11:08:13 --> Output Class Initialized
INFO - 2025-10-29 11:08:13 --> Security Class Initialized
DEBUG - 2025-10-29 11:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:08:13 --> Input Class Initialized
INFO - 2025-10-29 11:08:13 --> Language Class Initialized
INFO - 2025-10-29 11:08:13 --> Loader Class Initialized
INFO - 2025-10-29 11:08:13 --> Helper loaded: url_helper
INFO - 2025-10-29 11:08:13 --> Database Driver Class Initialized
INFO - 2025-10-29 11:08:13 --> Controller Class Initialized
INFO - 2025-10-29 11:08:13 --> Model "Student_model" initialized
INFO - 2025-10-29 11:08:13 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:08:13 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:08:13 --> Helper loaded: form_helper
INFO - 2025-10-29 11:08:13 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:08:13 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 11:08:13 --> Query error: Table 'pioneer_dental_db.students' doesn't exist - Invalid query: SELECT *
FROM `students`
WHERE `name` LIKE '%22%' ESCAPE '!'
OR  `reg_no` LIKE '%22%' ESCAPE '!'
 LIMIT 10
INFO - 2025-10-29 11:08:13 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 11:08:14 --> Config Class Initialized
INFO - 2025-10-29 11:08:14 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:08:14 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:08:14 --> Utf8 Class Initialized
INFO - 2025-10-29 11:08:14 --> URI Class Initialized
INFO - 2025-10-29 11:08:14 --> Router Class Initialized
INFO - 2025-10-29 11:08:14 --> Output Class Initialized
INFO - 2025-10-29 11:08:14 --> Security Class Initialized
DEBUG - 2025-10-29 11:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:08:14 --> Input Class Initialized
INFO - 2025-10-29 11:08:14 --> Language Class Initialized
INFO - 2025-10-29 11:08:14 --> Loader Class Initialized
INFO - 2025-10-29 11:08:14 --> Helper loaded: url_helper
INFO - 2025-10-29 11:08:14 --> Database Driver Class Initialized
INFO - 2025-10-29 11:08:14 --> Controller Class Initialized
INFO - 2025-10-29 11:08:14 --> Model "Student_model" initialized
INFO - 2025-10-29 11:08:14 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:08:14 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:08:14 --> Helper loaded: form_helper
INFO - 2025-10-29 11:08:14 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:08:14 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 11:08:14 --> Query error: Table 'pioneer_dental_db.students' doesn't exist - Invalid query: SELECT *
FROM `students`
WHERE `name` LIKE '%222%' ESCAPE '!'
OR  `reg_no` LIKE '%222%' ESCAPE '!'
 LIMIT 10
INFO - 2025-10-29 11:08:14 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 11:08:15 --> Config Class Initialized
INFO - 2025-10-29 11:08:15 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:08:15 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:08:15 --> Utf8 Class Initialized
INFO - 2025-10-29 11:08:15 --> URI Class Initialized
INFO - 2025-10-29 11:08:15 --> Router Class Initialized
INFO - 2025-10-29 11:08:15 --> Output Class Initialized
INFO - 2025-10-29 11:08:15 --> Security Class Initialized
DEBUG - 2025-10-29 11:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:08:15 --> Input Class Initialized
INFO - 2025-10-29 11:08:15 --> Language Class Initialized
INFO - 2025-10-29 11:08:15 --> Loader Class Initialized
INFO - 2025-10-29 11:08:15 --> Helper loaded: url_helper
INFO - 2025-10-29 11:08:15 --> Database Driver Class Initialized
INFO - 2025-10-29 11:08:15 --> Controller Class Initialized
INFO - 2025-10-29 11:08:15 --> Model "Student_model" initialized
INFO - 2025-10-29 11:08:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:08:15 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:08:15 --> Helper loaded: form_helper
INFO - 2025-10-29 11:08:15 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:08:15 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 11:08:15 --> Query error: Table 'pioneer_dental_db.students' doesn't exist - Invalid query: SELECT *
FROM `students`
WHERE `name` LIKE '%2228%' ESCAPE '!'
OR  `reg_no` LIKE '%2228%' ESCAPE '!'
 LIMIT 10
INFO - 2025-10-29 11:08:15 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 11:11:00 --> Config Class Initialized
INFO - 2025-10-29 11:11:00 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:11:00 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:11:00 --> Utf8 Class Initialized
INFO - 2025-10-29 11:11:00 --> URI Class Initialized
INFO - 2025-10-29 11:11:00 --> Router Class Initialized
INFO - 2025-10-29 11:11:00 --> Output Class Initialized
INFO - 2025-10-29 11:11:00 --> Security Class Initialized
DEBUG - 2025-10-29 11:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:11:00 --> Input Class Initialized
INFO - 2025-10-29 11:11:00 --> Language Class Initialized
INFO - 2025-10-29 11:11:00 --> Loader Class Initialized
INFO - 2025-10-29 11:11:00 --> Helper loaded: url_helper
INFO - 2025-10-29 11:11:00 --> Database Driver Class Initialized
INFO - 2025-10-29 11:11:00 --> Controller Class Initialized
INFO - 2025-10-29 11:11:00 --> Model "Student_model" initialized
INFO - 2025-10-29 11:11:00 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:11:00 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:11:00 --> Helper loaded: form_helper
INFO - 2025-10-29 11:11:00 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:11:00 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:11:00 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:11:00 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:11:00 --> Final output sent to browser
DEBUG - 2025-10-29 11:11:00 --> Total execution time: 0.1500
INFO - 2025-10-29 11:11:04 --> Config Class Initialized
INFO - 2025-10-29 11:11:04 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:11:04 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:11:04 --> Utf8 Class Initialized
INFO - 2025-10-29 11:11:04 --> URI Class Initialized
INFO - 2025-10-29 11:11:04 --> Router Class Initialized
INFO - 2025-10-29 11:11:04 --> Output Class Initialized
INFO - 2025-10-29 11:11:04 --> Security Class Initialized
DEBUG - 2025-10-29 11:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:11:04 --> Input Class Initialized
INFO - 2025-10-29 11:11:04 --> Language Class Initialized
INFO - 2025-10-29 11:11:04 --> Loader Class Initialized
INFO - 2025-10-29 11:11:04 --> Helper loaded: url_helper
INFO - 2025-10-29 11:11:04 --> Database Driver Class Initialized
INFO - 2025-10-29 11:11:04 --> Controller Class Initialized
INFO - 2025-10-29 11:11:04 --> Model "Student_model" initialized
INFO - 2025-10-29 11:11:04 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:11:04 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:11:04 --> Helper loaded: form_helper
INFO - 2025-10-29 11:11:04 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:11:04 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 11:11:04 --> Query error: Table 'pioneer_dental_db.students' doesn't exist - Invalid query: SELECT *
FROM `students`
WHERE `name` LIKE '%222%' ESCAPE '!'
OR  `reg_no` LIKE '%222%' ESCAPE '!'
 LIMIT 10
INFO - 2025-10-29 11:11:04 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 11:11:05 --> Config Class Initialized
INFO - 2025-10-29 11:11:05 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:11:05 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:11:05 --> Utf8 Class Initialized
INFO - 2025-10-29 11:11:05 --> URI Class Initialized
INFO - 2025-10-29 11:11:05 --> Router Class Initialized
INFO - 2025-10-29 11:11:05 --> Output Class Initialized
INFO - 2025-10-29 11:11:05 --> Security Class Initialized
DEBUG - 2025-10-29 11:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:11:05 --> Input Class Initialized
INFO - 2025-10-29 11:11:05 --> Language Class Initialized
INFO - 2025-10-29 11:11:05 --> Loader Class Initialized
INFO - 2025-10-29 11:11:05 --> Helper loaded: url_helper
INFO - 2025-10-29 11:11:05 --> Database Driver Class Initialized
INFO - 2025-10-29 11:11:05 --> Controller Class Initialized
INFO - 2025-10-29 11:11:05 --> Model "Student_model" initialized
INFO - 2025-10-29 11:11:05 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:11:05 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:11:05 --> Helper loaded: form_helper
INFO - 2025-10-29 11:11:05 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:11:05 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 11:11:05 --> Query error: Table 'pioneer_dental_db.students' doesn't exist - Invalid query: SELECT *
FROM `students`
WHERE `name` LIKE '%2224%' ESCAPE '!'
OR  `reg_no` LIKE '%2224%' ESCAPE '!'
 LIMIT 10
INFO - 2025-10-29 11:11:05 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 11:11:07 --> Config Class Initialized
INFO - 2025-10-29 11:11:07 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:11:07 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:11:07 --> Utf8 Class Initialized
INFO - 2025-10-29 11:11:07 --> URI Class Initialized
INFO - 2025-10-29 11:11:07 --> Router Class Initialized
INFO - 2025-10-29 11:11:07 --> Output Class Initialized
INFO - 2025-10-29 11:11:07 --> Security Class Initialized
DEBUG - 2025-10-29 11:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:11:07 --> Input Class Initialized
INFO - 2025-10-29 11:11:07 --> Language Class Initialized
INFO - 2025-10-29 11:11:07 --> Loader Class Initialized
INFO - 2025-10-29 11:11:07 --> Helper loaded: url_helper
INFO - 2025-10-29 11:11:07 --> Database Driver Class Initialized
INFO - 2025-10-29 11:11:07 --> Controller Class Initialized
INFO - 2025-10-29 11:11:07 --> Model "Student_model" initialized
INFO - 2025-10-29 11:11:07 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:11:07 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:11:07 --> Helper loaded: form_helper
INFO - 2025-10-29 11:11:07 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:11:07 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 11:11:07 --> Query error: Table 'pioneer_dental_db.students' doesn't exist - Invalid query: SELECT *
FROM `students`
WHERE `name` LIKE '%2225%' ESCAPE '!'
OR  `reg_no` LIKE '%2225%' ESCAPE '!'
 LIMIT 10
INFO - 2025-10-29 11:11:07 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 11:11:09 --> Config Class Initialized
INFO - 2025-10-29 11:11:09 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:11:09 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:11:09 --> Utf8 Class Initialized
INFO - 2025-10-29 11:11:09 --> URI Class Initialized
INFO - 2025-10-29 11:11:09 --> Router Class Initialized
INFO - 2025-10-29 11:11:09 --> Output Class Initialized
INFO - 2025-10-29 11:11:09 --> Security Class Initialized
DEBUG - 2025-10-29 11:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:11:09 --> Input Class Initialized
INFO - 2025-10-29 11:11:09 --> Language Class Initialized
INFO - 2025-10-29 11:11:09 --> Loader Class Initialized
INFO - 2025-10-29 11:11:09 --> Helper loaded: url_helper
INFO - 2025-10-29 11:11:09 --> Database Driver Class Initialized
INFO - 2025-10-29 11:11:09 --> Controller Class Initialized
INFO - 2025-10-29 11:11:09 --> Model "Student_model" initialized
INFO - 2025-10-29 11:11:09 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:11:09 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:11:09 --> Helper loaded: form_helper
INFO - 2025-10-29 11:11:09 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:11:09 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 11:11:09 --> Query error: Table 'pioneer_dental_db.students' doesn't exist - Invalid query: SELECT *
FROM `students`
WHERE `name` LIKE '%2228%' ESCAPE '!'
OR  `reg_no` LIKE '%2228%' ESCAPE '!'
 LIMIT 10
INFO - 2025-10-29 11:11:09 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 11:13:22 --> Config Class Initialized
INFO - 2025-10-29 11:13:22 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:13:22 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:13:22 --> Utf8 Class Initialized
INFO - 2025-10-29 11:13:22 --> URI Class Initialized
INFO - 2025-10-29 11:13:22 --> Router Class Initialized
INFO - 2025-10-29 11:13:22 --> Output Class Initialized
INFO - 2025-10-29 11:13:22 --> Security Class Initialized
DEBUG - 2025-10-29 11:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:13:22 --> Input Class Initialized
INFO - 2025-10-29 11:13:22 --> Language Class Initialized
INFO - 2025-10-29 11:13:22 --> Loader Class Initialized
INFO - 2025-10-29 11:13:22 --> Helper loaded: url_helper
INFO - 2025-10-29 11:13:22 --> Database Driver Class Initialized
INFO - 2025-10-29 11:13:22 --> Controller Class Initialized
INFO - 2025-10-29 11:13:22 --> Model "Student_model" initialized
INFO - 2025-10-29 11:13:22 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:13:22 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:13:22 --> Helper loaded: form_helper
INFO - 2025-10-29 11:13:22 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:13:22 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 11:13:22 --> Query error: Table 'pioneer_dental_db.students' doesn't exist - Invalid query: SELECT *
FROM `students`
WHERE `name` LIKE '%22%' ESCAPE '!'
OR  `reg_no` LIKE '%22%' ESCAPE '!'
 LIMIT 10
INFO - 2025-10-29 11:13:22 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 11:15:12 --> Config Class Initialized
INFO - 2025-10-29 11:15:12 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:15:12 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:15:12 --> Utf8 Class Initialized
INFO - 2025-10-29 11:15:12 --> URI Class Initialized
INFO - 2025-10-29 11:15:12 --> Router Class Initialized
INFO - 2025-10-29 11:15:12 --> Output Class Initialized
INFO - 2025-10-29 11:15:12 --> Security Class Initialized
DEBUG - 2025-10-29 11:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:15:12 --> Input Class Initialized
INFO - 2025-10-29 11:15:12 --> Language Class Initialized
INFO - 2025-10-29 11:15:12 --> Loader Class Initialized
INFO - 2025-10-29 11:15:12 --> Helper loaded: url_helper
INFO - 2025-10-29 11:15:12 --> Database Driver Class Initialized
INFO - 2025-10-29 11:15:12 --> Controller Class Initialized
INFO - 2025-10-29 11:15:12 --> Model "Student_model" initialized
INFO - 2025-10-29 11:15:12 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:15:12 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:15:12 --> Helper loaded: form_helper
INFO - 2025-10-29 11:15:12 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:15:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:15:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:15:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:15:12 --> Final output sent to browser
DEBUG - 2025-10-29 11:15:12 --> Total execution time: 0.1221
INFO - 2025-10-29 11:15:15 --> Config Class Initialized
INFO - 2025-10-29 11:15:15 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:15:15 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:15:15 --> Utf8 Class Initialized
INFO - 2025-10-29 11:15:15 --> URI Class Initialized
INFO - 2025-10-29 11:15:15 --> Router Class Initialized
INFO - 2025-10-29 11:15:15 --> Output Class Initialized
INFO - 2025-10-29 11:15:15 --> Security Class Initialized
DEBUG - 2025-10-29 11:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:15:15 --> Input Class Initialized
INFO - 2025-10-29 11:15:15 --> Language Class Initialized
INFO - 2025-10-29 11:15:15 --> Loader Class Initialized
INFO - 2025-10-29 11:15:15 --> Helper loaded: url_helper
INFO - 2025-10-29 11:15:15 --> Database Driver Class Initialized
INFO - 2025-10-29 11:15:15 --> Controller Class Initialized
INFO - 2025-10-29 11:15:15 --> Model "Student_model" initialized
INFO - 2025-10-29 11:15:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:15:15 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:15:15 --> Helper loaded: form_helper
INFO - 2025-10-29 11:15:15 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:15:15 --> Final output sent to browser
DEBUG - 2025-10-29 11:15:15 --> Total execution time: 0.0993
INFO - 2025-10-29 11:15:17 --> Config Class Initialized
INFO - 2025-10-29 11:15:17 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:15:17 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:15:17 --> Utf8 Class Initialized
INFO - 2025-10-29 11:15:17 --> URI Class Initialized
INFO - 2025-10-29 11:15:17 --> Router Class Initialized
INFO - 2025-10-29 11:15:17 --> Output Class Initialized
INFO - 2025-10-29 11:15:17 --> Security Class Initialized
DEBUG - 2025-10-29 11:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:15:17 --> Input Class Initialized
INFO - 2025-10-29 11:15:17 --> Language Class Initialized
INFO - 2025-10-29 11:15:17 --> Loader Class Initialized
INFO - 2025-10-29 11:15:17 --> Helper loaded: url_helper
INFO - 2025-10-29 11:15:17 --> Database Driver Class Initialized
INFO - 2025-10-29 11:15:17 --> Controller Class Initialized
INFO - 2025-10-29 11:15:17 --> Model "Student_model" initialized
INFO - 2025-10-29 11:15:17 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:15:17 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:15:17 --> Helper loaded: form_helper
INFO - 2025-10-29 11:15:17 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:15:17 --> Final output sent to browser
DEBUG - 2025-10-29 11:15:17 --> Total execution time: 0.0839
INFO - 2025-10-29 11:15:18 --> Config Class Initialized
INFO - 2025-10-29 11:15:18 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:15:18 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:15:18 --> Utf8 Class Initialized
INFO - 2025-10-29 11:15:18 --> URI Class Initialized
INFO - 2025-10-29 11:15:18 --> Router Class Initialized
INFO - 2025-10-29 11:15:18 --> Output Class Initialized
INFO - 2025-10-29 11:15:18 --> Security Class Initialized
DEBUG - 2025-10-29 11:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:15:18 --> Input Class Initialized
INFO - 2025-10-29 11:15:18 --> Language Class Initialized
INFO - 2025-10-29 11:15:18 --> Loader Class Initialized
INFO - 2025-10-29 11:15:18 --> Helper loaded: url_helper
INFO - 2025-10-29 11:15:18 --> Database Driver Class Initialized
INFO - 2025-10-29 11:15:18 --> Controller Class Initialized
INFO - 2025-10-29 11:15:18 --> Model "Student_model" initialized
INFO - 2025-10-29 11:15:18 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:15:18 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:15:18 --> Helper loaded: form_helper
INFO - 2025-10-29 11:15:18 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:15:18 --> Final output sent to browser
DEBUG - 2025-10-29 11:15:18 --> Total execution time: 0.1044
INFO - 2025-10-29 11:16:26 --> Config Class Initialized
INFO - 2025-10-29 11:16:26 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:16:26 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:16:26 --> Utf8 Class Initialized
INFO - 2025-10-29 11:16:26 --> URI Class Initialized
INFO - 2025-10-29 11:16:26 --> Router Class Initialized
INFO - 2025-10-29 11:16:26 --> Output Class Initialized
INFO - 2025-10-29 11:16:26 --> Security Class Initialized
DEBUG - 2025-10-29 11:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:16:26 --> Input Class Initialized
INFO - 2025-10-29 11:16:26 --> Language Class Initialized
INFO - 2025-10-29 11:16:26 --> Loader Class Initialized
INFO - 2025-10-29 11:16:26 --> Helper loaded: url_helper
INFO - 2025-10-29 11:16:26 --> Database Driver Class Initialized
INFO - 2025-10-29 11:16:26 --> Controller Class Initialized
INFO - 2025-10-29 11:16:26 --> Model "Student_model" initialized
INFO - 2025-10-29 11:16:26 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:16:26 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:16:26 --> Helper loaded: form_helper
INFO - 2025-10-29 11:16:26 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:16:26 --> Final output sent to browser
DEBUG - 2025-10-29 11:16:26 --> Total execution time: 0.0945
INFO - 2025-10-29 11:16:28 --> Config Class Initialized
INFO - 2025-10-29 11:16:28 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:16:28 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:16:28 --> Utf8 Class Initialized
INFO - 2025-10-29 11:16:28 --> URI Class Initialized
INFO - 2025-10-29 11:16:28 --> Router Class Initialized
INFO - 2025-10-29 11:16:28 --> Output Class Initialized
INFO - 2025-10-29 11:16:28 --> Security Class Initialized
DEBUG - 2025-10-29 11:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:16:28 --> Input Class Initialized
INFO - 2025-10-29 11:16:28 --> Language Class Initialized
INFO - 2025-10-29 11:16:28 --> Loader Class Initialized
INFO - 2025-10-29 11:16:28 --> Helper loaded: url_helper
INFO - 2025-10-29 11:16:28 --> Database Driver Class Initialized
INFO - 2025-10-29 11:16:28 --> Controller Class Initialized
INFO - 2025-10-29 11:16:28 --> Model "Student_model" initialized
INFO - 2025-10-29 11:16:28 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:16:28 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:16:28 --> Helper loaded: form_helper
INFO - 2025-10-29 11:16:28 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:16:28 --> Final output sent to browser
DEBUG - 2025-10-29 11:16:28 --> Total execution time: 0.1078
INFO - 2025-10-29 11:16:29 --> Config Class Initialized
INFO - 2025-10-29 11:16:29 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:16:29 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:16:29 --> Utf8 Class Initialized
INFO - 2025-10-29 11:16:29 --> URI Class Initialized
INFO - 2025-10-29 11:16:29 --> Router Class Initialized
INFO - 2025-10-29 11:16:29 --> Output Class Initialized
INFO - 2025-10-29 11:16:29 --> Security Class Initialized
DEBUG - 2025-10-29 11:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:16:29 --> Input Class Initialized
INFO - 2025-10-29 11:16:29 --> Language Class Initialized
INFO - 2025-10-29 11:16:29 --> Loader Class Initialized
INFO - 2025-10-29 11:16:29 --> Helper loaded: url_helper
INFO - 2025-10-29 11:16:29 --> Database Driver Class Initialized
INFO - 2025-10-29 11:16:29 --> Controller Class Initialized
INFO - 2025-10-29 11:16:29 --> Model "Student_model" initialized
INFO - 2025-10-29 11:16:29 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:16:29 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:16:29 --> Helper loaded: form_helper
INFO - 2025-10-29 11:16:29 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:16:29 --> Final output sent to browser
DEBUG - 2025-10-29 11:16:29 --> Total execution time: 0.1026
INFO - 2025-10-29 11:22:27 --> Config Class Initialized
INFO - 2025-10-29 11:22:27 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:22:27 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:22:27 --> Utf8 Class Initialized
INFO - 2025-10-29 11:22:27 --> URI Class Initialized
INFO - 2025-10-29 11:22:27 --> Router Class Initialized
INFO - 2025-10-29 11:22:27 --> Output Class Initialized
INFO - 2025-10-29 11:22:27 --> Security Class Initialized
DEBUG - 2025-10-29 11:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:22:27 --> Input Class Initialized
INFO - 2025-10-29 11:22:27 --> Language Class Initialized
INFO - 2025-10-29 11:22:27 --> Loader Class Initialized
INFO - 2025-10-29 11:22:27 --> Helper loaded: url_helper
INFO - 2025-10-29 11:22:27 --> Database Driver Class Initialized
INFO - 2025-10-29 11:22:27 --> Controller Class Initialized
INFO - 2025-10-29 11:22:27 --> Model "Student_model" initialized
INFO - 2025-10-29 11:22:27 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:22:27 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:22:27 --> Helper loaded: form_helper
INFO - 2025-10-29 11:22:27 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:22:27 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:22:27 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:22:27 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:22:27 --> Final output sent to browser
DEBUG - 2025-10-29 11:22:27 --> Total execution time: 0.1032
INFO - 2025-10-29 11:24:16 --> Config Class Initialized
INFO - 2025-10-29 11:24:16 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:24:16 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:24:16 --> Utf8 Class Initialized
INFO - 2025-10-29 11:24:16 --> URI Class Initialized
INFO - 2025-10-29 11:24:16 --> Router Class Initialized
INFO - 2025-10-29 11:24:16 --> Output Class Initialized
INFO - 2025-10-29 11:24:16 --> Security Class Initialized
DEBUG - 2025-10-29 11:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:24:16 --> Input Class Initialized
INFO - 2025-10-29 11:24:16 --> Language Class Initialized
INFO - 2025-10-29 11:24:16 --> Loader Class Initialized
INFO - 2025-10-29 11:24:16 --> Helper loaded: url_helper
INFO - 2025-10-29 11:24:16 --> Database Driver Class Initialized
INFO - 2025-10-29 11:24:16 --> Controller Class Initialized
INFO - 2025-10-29 11:24:16 --> Model "Student_model" initialized
INFO - 2025-10-29 11:24:16 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:24:16 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:24:16 --> Helper loaded: form_helper
INFO - 2025-10-29 11:24:16 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:24:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:24:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:24:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:24:16 --> Final output sent to browser
DEBUG - 2025-10-29 11:24:16 --> Total execution time: 0.1474
INFO - 2025-10-29 11:25:49 --> Config Class Initialized
INFO - 2025-10-29 11:25:49 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:25:49 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:25:49 --> Utf8 Class Initialized
INFO - 2025-10-29 11:25:49 --> URI Class Initialized
INFO - 2025-10-29 11:25:49 --> Router Class Initialized
INFO - 2025-10-29 11:25:49 --> Output Class Initialized
INFO - 2025-10-29 11:25:49 --> Security Class Initialized
DEBUG - 2025-10-29 11:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:25:49 --> Input Class Initialized
INFO - 2025-10-29 11:25:49 --> Language Class Initialized
INFO - 2025-10-29 11:25:49 --> Loader Class Initialized
INFO - 2025-10-29 11:25:49 --> Helper loaded: url_helper
INFO - 2025-10-29 11:25:49 --> Database Driver Class Initialized
INFO - 2025-10-29 11:25:49 --> Controller Class Initialized
INFO - 2025-10-29 11:25:49 --> Model "Student_model" initialized
INFO - 2025-10-29 11:25:49 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:25:49 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:25:49 --> Helper loaded: form_helper
INFO - 2025-10-29 11:25:49 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:25:49 --> Final output sent to browser
DEBUG - 2025-10-29 11:25:49 --> Total execution time: 0.0773
INFO - 2025-10-29 11:26:43 --> Config Class Initialized
INFO - 2025-10-29 11:26:43 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:26:43 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:26:43 --> Utf8 Class Initialized
INFO - 2025-10-29 11:26:43 --> URI Class Initialized
INFO - 2025-10-29 11:26:43 --> Router Class Initialized
INFO - 2025-10-29 11:26:43 --> Output Class Initialized
INFO - 2025-10-29 11:26:43 --> Security Class Initialized
DEBUG - 2025-10-29 11:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:26:43 --> Input Class Initialized
INFO - 2025-10-29 11:26:43 --> Language Class Initialized
INFO - 2025-10-29 11:26:43 --> Loader Class Initialized
INFO - 2025-10-29 11:26:43 --> Helper loaded: url_helper
INFO - 2025-10-29 11:26:43 --> Database Driver Class Initialized
INFO - 2025-10-29 11:26:43 --> Controller Class Initialized
INFO - 2025-10-29 11:26:43 --> Model "Student_model" initialized
INFO - 2025-10-29 11:26:43 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:26:43 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:26:43 --> Helper loaded: form_helper
INFO - 2025-10-29 11:26:43 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:26:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:26:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:26:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:26:43 --> Final output sent to browser
DEBUG - 2025-10-29 11:26:43 --> Total execution time: 0.0960
INFO - 2025-10-29 11:26:55 --> Config Class Initialized
INFO - 2025-10-29 11:26:55 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:26:55 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:26:55 --> Utf8 Class Initialized
INFO - 2025-10-29 11:26:55 --> URI Class Initialized
INFO - 2025-10-29 11:26:55 --> Router Class Initialized
INFO - 2025-10-29 11:26:55 --> Output Class Initialized
INFO - 2025-10-29 11:26:55 --> Security Class Initialized
DEBUG - 2025-10-29 11:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:26:55 --> Input Class Initialized
INFO - 2025-10-29 11:26:55 --> Language Class Initialized
INFO - 2025-10-29 11:26:55 --> Loader Class Initialized
INFO - 2025-10-29 11:26:55 --> Helper loaded: url_helper
INFO - 2025-10-29 11:26:55 --> Database Driver Class Initialized
INFO - 2025-10-29 11:26:55 --> Controller Class Initialized
INFO - 2025-10-29 11:26:55 --> Model "Student_model" initialized
INFO - 2025-10-29 11:26:55 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:26:55 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:26:55 --> Helper loaded: form_helper
INFO - 2025-10-29 11:26:55 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:26:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:26:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 11:26:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:26:55 --> Final output sent to browser
DEBUG - 2025-10-29 11:26:55 --> Total execution time: 0.1250
INFO - 2025-10-29 11:26:59 --> Config Class Initialized
INFO - 2025-10-29 11:26:59 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:26:59 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:26:59 --> Utf8 Class Initialized
INFO - 2025-10-29 11:26:59 --> URI Class Initialized
INFO - 2025-10-29 11:26:59 --> Router Class Initialized
INFO - 2025-10-29 11:26:59 --> Output Class Initialized
INFO - 2025-10-29 11:26:59 --> Security Class Initialized
DEBUG - 2025-10-29 11:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:26:59 --> Input Class Initialized
INFO - 2025-10-29 11:26:59 --> Language Class Initialized
INFO - 2025-10-29 11:26:59 --> Loader Class Initialized
INFO - 2025-10-29 11:26:59 --> Helper loaded: url_helper
INFO - 2025-10-29 11:26:59 --> Database Driver Class Initialized
INFO - 2025-10-29 11:26:59 --> Controller Class Initialized
INFO - 2025-10-29 11:26:59 --> Model "Student_model" initialized
INFO - 2025-10-29 11:26:59 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:26:59 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:26:59 --> Helper loaded: form_helper
INFO - 2025-10-29 11:26:59 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:26:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:26:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:26:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:26:59 --> Final output sent to browser
DEBUG - 2025-10-29 11:26:59 --> Total execution time: 0.1061
INFO - 2025-10-29 11:27:47 --> Config Class Initialized
INFO - 2025-10-29 11:27:47 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:27:47 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:27:47 --> Utf8 Class Initialized
INFO - 2025-10-29 11:27:47 --> URI Class Initialized
INFO - 2025-10-29 11:27:47 --> Router Class Initialized
INFO - 2025-10-29 11:27:47 --> Output Class Initialized
INFO - 2025-10-29 11:27:47 --> Security Class Initialized
DEBUG - 2025-10-29 11:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:27:47 --> Input Class Initialized
INFO - 2025-10-29 11:27:47 --> Language Class Initialized
INFO - 2025-10-29 11:27:47 --> Loader Class Initialized
INFO - 2025-10-29 11:27:47 --> Helper loaded: url_helper
INFO - 2025-10-29 11:27:47 --> Database Driver Class Initialized
INFO - 2025-10-29 11:27:47 --> Controller Class Initialized
INFO - 2025-10-29 11:27:47 --> Model "Student_model" initialized
INFO - 2025-10-29 11:27:47 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:27:47 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:27:47 --> Helper loaded: form_helper
INFO - 2025-10-29 11:27:47 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:27:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:27:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:27:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:27:47 --> Final output sent to browser
DEBUG - 2025-10-29 11:27:47 --> Total execution time: 0.1252
INFO - 2025-10-29 11:29:44 --> Config Class Initialized
INFO - 2025-10-29 11:29:44 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:29:44 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:29:44 --> Utf8 Class Initialized
INFO - 2025-10-29 11:29:44 --> URI Class Initialized
INFO - 2025-10-29 11:29:44 --> Router Class Initialized
INFO - 2025-10-29 11:29:44 --> Output Class Initialized
INFO - 2025-10-29 11:29:44 --> Security Class Initialized
DEBUG - 2025-10-29 11:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:29:44 --> Input Class Initialized
INFO - 2025-10-29 11:29:44 --> Language Class Initialized
INFO - 2025-10-29 11:29:44 --> Loader Class Initialized
INFO - 2025-10-29 11:29:44 --> Helper loaded: url_helper
INFO - 2025-10-29 11:29:44 --> Database Driver Class Initialized
INFO - 2025-10-29 11:29:44 --> Controller Class Initialized
INFO - 2025-10-29 11:29:44 --> Model "Student_model" initialized
INFO - 2025-10-29 11:29:44 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:29:44 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:29:44 --> Helper loaded: form_helper
INFO - 2025-10-29 11:29:44 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:29:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:29:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:29:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:29:44 --> Final output sent to browser
DEBUG - 2025-10-29 11:29:44 --> Total execution time: 0.1019
INFO - 2025-10-29 11:33:13 --> Config Class Initialized
INFO - 2025-10-29 11:33:13 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:33:13 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:33:13 --> Utf8 Class Initialized
INFO - 2025-10-29 11:33:13 --> URI Class Initialized
INFO - 2025-10-29 11:33:13 --> Router Class Initialized
INFO - 2025-10-29 11:33:13 --> Output Class Initialized
INFO - 2025-10-29 11:33:13 --> Security Class Initialized
DEBUG - 2025-10-29 11:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:33:13 --> Input Class Initialized
INFO - 2025-10-29 11:33:13 --> Language Class Initialized
INFO - 2025-10-29 11:33:13 --> Loader Class Initialized
INFO - 2025-10-29 11:33:13 --> Helper loaded: url_helper
INFO - 2025-10-29 11:33:13 --> Database Driver Class Initialized
INFO - 2025-10-29 11:33:13 --> Controller Class Initialized
INFO - 2025-10-29 11:33:13 --> Model "Student_model" initialized
INFO - 2025-10-29 11:33:13 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:33:13 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:33:13 --> Helper loaded: form_helper
INFO - 2025-10-29 11:33:13 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:33:13 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:33:13 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:33:13 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:33:13 --> Final output sent to browser
DEBUG - 2025-10-29 11:33:13 --> Total execution time: 0.1167
INFO - 2025-10-29 11:33:32 --> Config Class Initialized
INFO - 2025-10-29 11:33:32 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:33:32 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:33:32 --> Utf8 Class Initialized
INFO - 2025-10-29 11:33:32 --> URI Class Initialized
INFO - 2025-10-29 11:33:32 --> Router Class Initialized
INFO - 2025-10-29 11:33:32 --> Output Class Initialized
INFO - 2025-10-29 11:33:32 --> Security Class Initialized
DEBUG - 2025-10-29 11:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:33:32 --> Input Class Initialized
INFO - 2025-10-29 11:33:32 --> Language Class Initialized
INFO - 2025-10-29 11:33:32 --> Loader Class Initialized
INFO - 2025-10-29 11:33:32 --> Helper loaded: url_helper
INFO - 2025-10-29 11:33:32 --> Database Driver Class Initialized
INFO - 2025-10-29 11:33:32 --> Controller Class Initialized
INFO - 2025-10-29 11:33:32 --> Model "Student_model" initialized
INFO - 2025-10-29 11:33:32 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:33:32 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:33:32 --> Helper loaded: form_helper
INFO - 2025-10-29 11:33:32 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:33:32 --> Final output sent to browser
DEBUG - 2025-10-29 11:33:32 --> Total execution time: 0.1109
INFO - 2025-10-29 11:33:34 --> Config Class Initialized
INFO - 2025-10-29 11:33:34 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:33:34 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:33:34 --> Utf8 Class Initialized
INFO - 2025-10-29 11:33:34 --> URI Class Initialized
INFO - 2025-10-29 11:33:34 --> Router Class Initialized
INFO - 2025-10-29 11:33:34 --> Output Class Initialized
INFO - 2025-10-29 11:33:34 --> Security Class Initialized
DEBUG - 2025-10-29 11:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:33:34 --> Input Class Initialized
INFO - 2025-10-29 11:33:34 --> Language Class Initialized
INFO - 2025-10-29 11:33:34 --> Loader Class Initialized
INFO - 2025-10-29 11:33:34 --> Helper loaded: url_helper
INFO - 2025-10-29 11:33:34 --> Database Driver Class Initialized
INFO - 2025-10-29 11:33:34 --> Controller Class Initialized
INFO - 2025-10-29 11:33:34 --> Model "Student_model" initialized
INFO - 2025-10-29 11:33:34 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:33:34 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:33:34 --> Helper loaded: form_helper
INFO - 2025-10-29 11:33:34 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:33:34 --> Final output sent to browser
DEBUG - 2025-10-29 11:33:34 --> Total execution time: 0.0898
INFO - 2025-10-29 11:33:34 --> Config Class Initialized
INFO - 2025-10-29 11:33:34 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:33:34 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:33:34 --> Utf8 Class Initialized
INFO - 2025-10-29 11:33:34 --> URI Class Initialized
INFO - 2025-10-29 11:33:34 --> Router Class Initialized
INFO - 2025-10-29 11:33:34 --> Output Class Initialized
INFO - 2025-10-29 11:33:34 --> Security Class Initialized
DEBUG - 2025-10-29 11:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:33:34 --> Input Class Initialized
INFO - 2025-10-29 11:33:34 --> Language Class Initialized
INFO - 2025-10-29 11:33:34 --> Loader Class Initialized
INFO - 2025-10-29 11:33:34 --> Helper loaded: url_helper
INFO - 2025-10-29 11:33:34 --> Database Driver Class Initialized
INFO - 2025-10-29 11:33:34 --> Controller Class Initialized
INFO - 2025-10-29 11:33:34 --> Model "Student_model" initialized
INFO - 2025-10-29 11:33:34 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:33:34 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:33:34 --> Helper loaded: form_helper
INFO - 2025-10-29 11:33:34 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:33:34 --> Final output sent to browser
DEBUG - 2025-10-29 11:33:34 --> Total execution time: 0.0798
INFO - 2025-10-29 11:33:34 --> Config Class Initialized
INFO - 2025-10-29 11:33:34 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:33:34 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:33:34 --> Utf8 Class Initialized
INFO - 2025-10-29 11:33:34 --> URI Class Initialized
INFO - 2025-10-29 11:33:34 --> Router Class Initialized
INFO - 2025-10-29 11:33:34 --> Output Class Initialized
INFO - 2025-10-29 11:33:34 --> Security Class Initialized
DEBUG - 2025-10-29 11:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:33:34 --> Input Class Initialized
INFO - 2025-10-29 11:33:34 --> Language Class Initialized
INFO - 2025-10-29 11:33:34 --> Loader Class Initialized
INFO - 2025-10-29 11:33:34 --> Helper loaded: url_helper
INFO - 2025-10-29 11:33:34 --> Database Driver Class Initialized
INFO - 2025-10-29 11:33:34 --> Controller Class Initialized
INFO - 2025-10-29 11:33:34 --> Model "Student_model" initialized
INFO - 2025-10-29 11:33:34 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:33:34 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:33:34 --> Helper loaded: form_helper
INFO - 2025-10-29 11:33:34 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:33:34 --> Final output sent to browser
DEBUG - 2025-10-29 11:33:34 --> Total execution time: 0.1065
INFO - 2025-10-29 11:35:03 --> Config Class Initialized
INFO - 2025-10-29 11:35:03 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:35:03 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:35:03 --> Utf8 Class Initialized
INFO - 2025-10-29 11:35:03 --> URI Class Initialized
INFO - 2025-10-29 11:35:03 --> Router Class Initialized
INFO - 2025-10-29 11:35:03 --> Output Class Initialized
INFO - 2025-10-29 11:35:03 --> Security Class Initialized
DEBUG - 2025-10-29 11:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:35:03 --> Input Class Initialized
INFO - 2025-10-29 11:35:03 --> Language Class Initialized
INFO - 2025-10-29 11:35:03 --> Loader Class Initialized
INFO - 2025-10-29 11:35:03 --> Helper loaded: url_helper
INFO - 2025-10-29 11:35:03 --> Database Driver Class Initialized
INFO - 2025-10-29 11:35:03 --> Controller Class Initialized
INFO - 2025-10-29 11:35:03 --> Model "Student_model" initialized
INFO - 2025-10-29 11:35:03 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:35:03 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:35:03 --> Helper loaded: form_helper
INFO - 2025-10-29 11:35:03 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:35:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:35:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:35:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:35:03 --> Final output sent to browser
DEBUG - 2025-10-29 11:35:03 --> Total execution time: 0.1146
INFO - 2025-10-29 11:35:47 --> Config Class Initialized
INFO - 2025-10-29 11:35:47 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:35:47 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:35:47 --> Utf8 Class Initialized
INFO - 2025-10-29 11:35:47 --> URI Class Initialized
INFO - 2025-10-29 11:35:47 --> Router Class Initialized
INFO - 2025-10-29 11:35:47 --> Output Class Initialized
INFO - 2025-10-29 11:35:47 --> Security Class Initialized
DEBUG - 2025-10-29 11:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:35:47 --> Input Class Initialized
INFO - 2025-10-29 11:35:47 --> Language Class Initialized
INFO - 2025-10-29 11:35:47 --> Loader Class Initialized
INFO - 2025-10-29 11:35:47 --> Helper loaded: url_helper
INFO - 2025-10-29 11:35:47 --> Database Driver Class Initialized
INFO - 2025-10-29 11:35:47 --> Controller Class Initialized
INFO - 2025-10-29 11:35:47 --> Model "Student_model" initialized
INFO - 2025-10-29 11:35:47 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:35:47 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:35:47 --> Helper loaded: form_helper
INFO - 2025-10-29 11:35:47 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:35:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:35:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:35:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:35:47 --> Final output sent to browser
DEBUG - 2025-10-29 11:35:47 --> Total execution time: 0.1310
INFO - 2025-10-29 11:35:58 --> Config Class Initialized
INFO - 2025-10-29 11:35:58 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:35:58 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:35:58 --> Utf8 Class Initialized
INFO - 2025-10-29 11:35:58 --> URI Class Initialized
DEBUG - 2025-10-29 11:35:58 --> No URI present. Default controller set.
INFO - 2025-10-29 11:35:58 --> Router Class Initialized
INFO - 2025-10-29 11:35:58 --> Output Class Initialized
INFO - 2025-10-29 11:35:58 --> Security Class Initialized
DEBUG - 2025-10-29 11:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:35:58 --> Input Class Initialized
INFO - 2025-10-29 11:35:58 --> Language Class Initialized
INFO - 2025-10-29 11:35:58 --> Loader Class Initialized
INFO - 2025-10-29 11:35:58 --> Helper loaded: url_helper
INFO - 2025-10-29 11:35:58 --> Database Driver Class Initialized
INFO - 2025-10-29 11:35:58 --> Controller Class Initialized
INFO - 2025-10-29 11:35:58 --> Model "Student_model" initialized
INFO - 2025-10-29 11:35:58 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:35:58 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 11:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:35:58 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 11:35:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''2025-05'
AND `status` = '1'' at line 3 - Invalid query: SELECT SUM(`amount_paid`) AS `amount_paid`
FROM `payments`
WHERE DATE_FORMAT(payment_date, "%Y-%m") '2025-05'
AND `status` = '1'
INFO - 2025-10-29 11:35:58 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 11:36:06 --> Config Class Initialized
INFO - 2025-10-29 11:36:06 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:36:06 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:36:06 --> Utf8 Class Initialized
INFO - 2025-10-29 11:36:06 --> URI Class Initialized
DEBUG - 2025-10-29 11:36:06 --> No URI present. Default controller set.
INFO - 2025-10-29 11:36:06 --> Router Class Initialized
INFO - 2025-10-29 11:36:06 --> Output Class Initialized
INFO - 2025-10-29 11:36:06 --> Security Class Initialized
DEBUG - 2025-10-29 11:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:36:06 --> Input Class Initialized
INFO - 2025-10-29 11:36:06 --> Language Class Initialized
INFO - 2025-10-29 11:36:06 --> Loader Class Initialized
INFO - 2025-10-29 11:36:06 --> Helper loaded: url_helper
INFO - 2025-10-29 11:36:06 --> Database Driver Class Initialized
INFO - 2025-10-29 11:36:06 --> Controller Class Initialized
INFO - 2025-10-29 11:36:06 --> Model "Student_model" initialized
INFO - 2025-10-29 11:36:06 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:36:06 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 11:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:36:06 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 11:36:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''2025-05'
AND `status` = '1'' at line 3 - Invalid query: SELECT SUM(`amount_paid`) AS `amount_paid`
FROM `payments`
WHERE DATE_FORMAT(payment_date, "%Y-%m") '2025-05'
AND `status` = '1'
INFO - 2025-10-29 11:36:06 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 11:37:45 --> Config Class Initialized
INFO - 2025-10-29 11:37:45 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:37:45 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:37:45 --> Utf8 Class Initialized
INFO - 2025-10-29 11:37:45 --> URI Class Initialized
DEBUG - 2025-10-29 11:37:45 --> No URI present. Default controller set.
INFO - 2025-10-29 11:37:45 --> Router Class Initialized
INFO - 2025-10-29 11:37:45 --> Output Class Initialized
INFO - 2025-10-29 11:37:45 --> Security Class Initialized
DEBUG - 2025-10-29 11:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:37:45 --> Input Class Initialized
INFO - 2025-10-29 11:37:45 --> Language Class Initialized
INFO - 2025-10-29 11:37:45 --> Loader Class Initialized
INFO - 2025-10-29 11:37:45 --> Helper loaded: url_helper
INFO - 2025-10-29 11:37:45 --> Database Driver Class Initialized
INFO - 2025-10-29 11:37:45 --> Controller Class Initialized
INFO - 2025-10-29 11:37:45 --> Model "Student_model" initialized
INFO - 2025-10-29 11:37:45 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:37:45 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 11:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:37:45 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 11:37:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''2025-05'
AND `status` = '1'' at line 3 - Invalid query: SELECT SUM(`amount_paid`) AS `amount_paid`
FROM `payments`
WHERE DATE_FORMAT(payment_date, "%Y-%m") '2025-05'
AND `status` = '1'
INFO - 2025-10-29 11:37:45 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 11:37:46 --> Config Class Initialized
INFO - 2025-10-29 11:37:46 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:37:46 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:37:46 --> Utf8 Class Initialized
INFO - 2025-10-29 11:37:46 --> URI Class Initialized
DEBUG - 2025-10-29 11:37:46 --> No URI present. Default controller set.
INFO - 2025-10-29 11:37:46 --> Router Class Initialized
INFO - 2025-10-29 11:37:46 --> Output Class Initialized
INFO - 2025-10-29 11:37:46 --> Security Class Initialized
DEBUG - 2025-10-29 11:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:37:46 --> Input Class Initialized
INFO - 2025-10-29 11:37:46 --> Language Class Initialized
INFO - 2025-10-29 11:37:46 --> Loader Class Initialized
INFO - 2025-10-29 11:37:46 --> Helper loaded: url_helper
INFO - 2025-10-29 11:37:46 --> Database Driver Class Initialized
INFO - 2025-10-29 11:37:46 --> Controller Class Initialized
INFO - 2025-10-29 11:37:46 --> Model "Student_model" initialized
INFO - 2025-10-29 11:37:46 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:37:46 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 11:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:37:46 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 11:37:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''2025-05'
AND `status` = '1'' at line 3 - Invalid query: SELECT SUM(`amount_paid`) AS `amount_paid`
FROM `payments`
WHERE DATE_FORMAT(payment_date, "%Y-%m") '2025-05'
AND `status` = '1'
INFO - 2025-10-29 11:37:46 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 11:37:47 --> Config Class Initialized
INFO - 2025-10-29 11:37:47 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:37:47 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:37:47 --> Utf8 Class Initialized
INFO - 2025-10-29 11:37:47 --> URI Class Initialized
DEBUG - 2025-10-29 11:37:47 --> No URI present. Default controller set.
INFO - 2025-10-29 11:37:47 --> Router Class Initialized
INFO - 2025-10-29 11:37:47 --> Output Class Initialized
INFO - 2025-10-29 11:37:47 --> Security Class Initialized
DEBUG - 2025-10-29 11:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:37:47 --> Input Class Initialized
INFO - 2025-10-29 11:37:47 --> Language Class Initialized
INFO - 2025-10-29 11:37:47 --> Loader Class Initialized
INFO - 2025-10-29 11:37:47 --> Helper loaded: url_helper
INFO - 2025-10-29 11:37:47 --> Database Driver Class Initialized
INFO - 2025-10-29 11:37:47 --> Controller Class Initialized
INFO - 2025-10-29 11:37:47 --> Model "Student_model" initialized
INFO - 2025-10-29 11:37:47 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:37:47 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 11:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:37:47 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 11:37:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''2025-05'
AND `status` = '1'' at line 3 - Invalid query: SELECT SUM(`amount_paid`) AS `amount_paid`
FROM `payments`
WHERE DATE_FORMAT(payment_date, "%Y-%m") '2025-05'
AND `status` = '1'
INFO - 2025-10-29 11:37:47 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 11:37:47 --> Config Class Initialized
INFO - 2025-10-29 11:37:47 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:37:47 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:37:47 --> Utf8 Class Initialized
INFO - 2025-10-29 11:37:47 --> URI Class Initialized
INFO - 2025-10-29 11:37:47 --> Router Class Initialized
INFO - 2025-10-29 11:37:47 --> Output Class Initialized
INFO - 2025-10-29 11:37:47 --> Security Class Initialized
DEBUG - 2025-10-29 11:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:37:47 --> Input Class Initialized
INFO - 2025-10-29 11:37:47 --> Language Class Initialized
INFO - 2025-10-29 11:37:47 --> Loader Class Initialized
INFO - 2025-10-29 11:37:47 --> Helper loaded: url_helper
INFO - 2025-10-29 11:37:47 --> Database Driver Class Initialized
INFO - 2025-10-29 11:37:47 --> Controller Class Initialized
INFO - 2025-10-29 11:37:47 --> Model "Student_model" initialized
INFO - 2025-10-29 11:37:47 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:37:47 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:37:47 --> Helper loaded: form_helper
INFO - 2025-10-29 11:37:47 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:37:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:37:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:37:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:37:47 --> Final output sent to browser
DEBUG - 2025-10-29 11:37:47 --> Total execution time: 0.1061
INFO - 2025-10-29 11:37:50 --> Config Class Initialized
INFO - 2025-10-29 11:37:50 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:37:50 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:37:50 --> Utf8 Class Initialized
INFO - 2025-10-29 11:37:50 --> URI Class Initialized
DEBUG - 2025-10-29 11:37:50 --> No URI present. Default controller set.
INFO - 2025-10-29 11:37:50 --> Router Class Initialized
INFO - 2025-10-29 11:37:50 --> Output Class Initialized
INFO - 2025-10-29 11:37:50 --> Security Class Initialized
DEBUG - 2025-10-29 11:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:37:50 --> Input Class Initialized
INFO - 2025-10-29 11:37:50 --> Language Class Initialized
INFO - 2025-10-29 11:37:50 --> Loader Class Initialized
INFO - 2025-10-29 11:37:50 --> Helper loaded: url_helper
INFO - 2025-10-29 11:37:50 --> Database Driver Class Initialized
INFO - 2025-10-29 11:37:50 --> Controller Class Initialized
INFO - 2025-10-29 11:37:50 --> Model "Student_model" initialized
INFO - 2025-10-29 11:37:50 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:37:50 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 11:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:37:50 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 11:37:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''2025-05'
AND `status` = '1'' at line 3 - Invalid query: SELECT SUM(`amount_paid`) AS `amount_paid`
FROM `payments`
WHERE DATE_FORMAT(payment_date, "%Y-%m") '2025-05'
AND `status` = '1'
INFO - 2025-10-29 11:37:50 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 11:37:51 --> Config Class Initialized
INFO - 2025-10-29 11:37:51 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:37:51 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:37:51 --> Utf8 Class Initialized
INFO - 2025-10-29 11:37:51 --> URI Class Initialized
INFO - 2025-10-29 11:37:51 --> Router Class Initialized
INFO - 2025-10-29 11:37:51 --> Output Class Initialized
INFO - 2025-10-29 11:37:51 --> Security Class Initialized
DEBUG - 2025-10-29 11:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:37:51 --> Input Class Initialized
INFO - 2025-10-29 11:37:51 --> Language Class Initialized
INFO - 2025-10-29 11:37:51 --> Loader Class Initialized
INFO - 2025-10-29 11:37:51 --> Helper loaded: url_helper
INFO - 2025-10-29 11:37:51 --> Database Driver Class Initialized
INFO - 2025-10-29 11:37:51 --> Controller Class Initialized
INFO - 2025-10-29 11:37:51 --> Model "Student_model" initialized
INFO - 2025-10-29 11:37:51 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:37:51 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:37:51 --> Helper loaded: form_helper
INFO - 2025-10-29 11:37:51 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:37:51 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:37:51 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:37:51 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:37:51 --> Final output sent to browser
DEBUG - 2025-10-29 11:37:51 --> Total execution time: 0.1155
INFO - 2025-10-29 11:37:53 --> Config Class Initialized
INFO - 2025-10-29 11:37:53 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:37:53 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:37:53 --> Utf8 Class Initialized
INFO - 2025-10-29 11:37:53 --> URI Class Initialized
INFO - 2025-10-29 11:37:53 --> Router Class Initialized
INFO - 2025-10-29 11:37:53 --> Output Class Initialized
INFO - 2025-10-29 11:37:53 --> Security Class Initialized
DEBUG - 2025-10-29 11:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:37:53 --> Input Class Initialized
INFO - 2025-10-29 11:37:53 --> Language Class Initialized
INFO - 2025-10-29 11:37:53 --> Loader Class Initialized
INFO - 2025-10-29 11:37:53 --> Helper loaded: url_helper
INFO - 2025-10-29 11:37:53 --> Database Driver Class Initialized
INFO - 2025-10-29 11:37:53 --> Controller Class Initialized
INFO - 2025-10-29 11:37:53 --> Model "Student_model" initialized
INFO - 2025-10-29 11:37:53 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:37:53 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:37:53 --> Helper loaded: form_helper
INFO - 2025-10-29 11:37:53 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:37:53 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:37:53 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 11:37:53 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:37:53 --> Final output sent to browser
DEBUG - 2025-10-29 11:37:53 --> Total execution time: 0.0865
INFO - 2025-10-29 11:37:56 --> Config Class Initialized
INFO - 2025-10-29 11:37:56 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:37:56 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:37:56 --> Utf8 Class Initialized
INFO - 2025-10-29 11:37:56 --> URI Class Initialized
DEBUG - 2025-10-29 11:37:56 --> No URI present. Default controller set.
INFO - 2025-10-29 11:37:56 --> Router Class Initialized
INFO - 2025-10-29 11:37:56 --> Output Class Initialized
INFO - 2025-10-29 11:37:56 --> Security Class Initialized
DEBUG - 2025-10-29 11:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:37:56 --> Input Class Initialized
INFO - 2025-10-29 11:37:56 --> Language Class Initialized
INFO - 2025-10-29 11:37:56 --> Loader Class Initialized
INFO - 2025-10-29 11:37:56 --> Helper loaded: url_helper
INFO - 2025-10-29 11:37:56 --> Database Driver Class Initialized
INFO - 2025-10-29 11:37:56 --> Controller Class Initialized
INFO - 2025-10-29 11:37:56 --> Model "Student_model" initialized
INFO - 2025-10-29 11:37:56 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:37:56 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 11:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:37:56 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 11:37:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''2025-05'
AND `status` = '1'' at line 3 - Invalid query: SELECT SUM(`amount_paid`) AS `amount_paid`
FROM `payments`
WHERE DATE_FORMAT(payment_date, "%Y-%m") '2025-05'
AND `status` = '1'
INFO - 2025-10-29 11:37:56 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 11:37:59 --> Config Class Initialized
INFO - 2025-10-29 11:37:59 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:37:59 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:37:59 --> Utf8 Class Initialized
INFO - 2025-10-29 11:37:59 --> URI Class Initialized
INFO - 2025-10-29 11:37:59 --> Router Class Initialized
INFO - 2025-10-29 11:37:59 --> Output Class Initialized
INFO - 2025-10-29 11:37:59 --> Security Class Initialized
DEBUG - 2025-10-29 11:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:37:59 --> Input Class Initialized
INFO - 2025-10-29 11:37:59 --> Language Class Initialized
INFO - 2025-10-29 11:37:59 --> Loader Class Initialized
INFO - 2025-10-29 11:37:59 --> Helper loaded: url_helper
INFO - 2025-10-29 11:37:59 --> Database Driver Class Initialized
INFO - 2025-10-29 11:37:59 --> Controller Class Initialized
INFO - 2025-10-29 11:37:59 --> Model "Student_model" initialized
INFO - 2025-10-29 11:37:59 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:37:59 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:37:59 --> Helper loaded: form_helper
INFO - 2025-10-29 11:37:59 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:37:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:37:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 11:37:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:37:59 --> Final output sent to browser
DEBUG - 2025-10-29 11:37:59 --> Total execution time: 0.1026
INFO - 2025-10-29 11:38:03 --> Config Class Initialized
INFO - 2025-10-29 11:38:03 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:38:03 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:38:03 --> Utf8 Class Initialized
INFO - 2025-10-29 11:38:03 --> URI Class Initialized
INFO - 2025-10-29 11:38:03 --> Router Class Initialized
INFO - 2025-10-29 11:38:03 --> Output Class Initialized
INFO - 2025-10-29 11:38:03 --> Security Class Initialized
DEBUG - 2025-10-29 11:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:38:03 --> Input Class Initialized
INFO - 2025-10-29 11:38:03 --> Language Class Initialized
ERROR - 2025-10-29 11:38:03 --> 404 Page Not Found: Payments/index
INFO - 2025-10-29 11:38:05 --> Config Class Initialized
INFO - 2025-10-29 11:38:05 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:38:05 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:38:05 --> Utf8 Class Initialized
INFO - 2025-10-29 11:38:05 --> URI Class Initialized
INFO - 2025-10-29 11:38:05 --> Router Class Initialized
INFO - 2025-10-29 11:38:05 --> Output Class Initialized
INFO - 2025-10-29 11:38:05 --> Security Class Initialized
DEBUG - 2025-10-29 11:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:38:05 --> Input Class Initialized
INFO - 2025-10-29 11:38:05 --> Language Class Initialized
INFO - 2025-10-29 11:38:05 --> Loader Class Initialized
INFO - 2025-10-29 11:38:05 --> Helper loaded: url_helper
INFO - 2025-10-29 11:38:05 --> Database Driver Class Initialized
INFO - 2025-10-29 11:38:05 --> Controller Class Initialized
INFO - 2025-10-29 11:38:05 --> Model "Student_model" initialized
INFO - 2025-10-29 11:38:05 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:38:05 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:38:05 --> Helper loaded: form_helper
INFO - 2025-10-29 11:38:05 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:38:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:38:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 11:38:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:38:05 --> Final output sent to browser
DEBUG - 2025-10-29 11:38:05 --> Total execution time: 0.1193
INFO - 2025-10-29 11:38:15 --> Config Class Initialized
INFO - 2025-10-29 11:38:15 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:38:15 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:38:15 --> Utf8 Class Initialized
INFO - 2025-10-29 11:38:15 --> URI Class Initialized
INFO - 2025-10-29 11:38:15 --> Router Class Initialized
INFO - 2025-10-29 11:38:15 --> Output Class Initialized
INFO - 2025-10-29 11:38:15 --> Security Class Initialized
DEBUG - 2025-10-29 11:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:38:15 --> Input Class Initialized
INFO - 2025-10-29 11:38:15 --> Language Class Initialized
INFO - 2025-10-29 11:38:15 --> Loader Class Initialized
INFO - 2025-10-29 11:38:15 --> Helper loaded: url_helper
INFO - 2025-10-29 11:38:15 --> Database Driver Class Initialized
INFO - 2025-10-29 11:38:15 --> Controller Class Initialized
INFO - 2025-10-29 11:38:15 --> Model "Student_model" initialized
INFO - 2025-10-29 11:38:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:38:15 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:38:15 --> Helper loaded: form_helper
INFO - 2025-10-29 11:38:15 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:38:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:38:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/edit.php
INFO - 2025-10-29 11:38:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:38:15 --> Final output sent to browser
DEBUG - 2025-10-29 11:38:15 --> Total execution time: 0.1032
INFO - 2025-10-29 11:38:19 --> Config Class Initialized
INFO - 2025-10-29 11:38:19 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:38:19 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:38:19 --> Utf8 Class Initialized
INFO - 2025-10-29 11:38:19 --> URI Class Initialized
INFO - 2025-10-29 11:38:19 --> Router Class Initialized
INFO - 2025-10-29 11:38:19 --> Output Class Initialized
INFO - 2025-10-29 11:38:19 --> Security Class Initialized
DEBUG - 2025-10-29 11:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:38:19 --> Input Class Initialized
INFO - 2025-10-29 11:38:19 --> Language Class Initialized
INFO - 2025-10-29 11:38:19 --> Loader Class Initialized
INFO - 2025-10-29 11:38:19 --> Helper loaded: url_helper
INFO - 2025-10-29 11:38:19 --> Database Driver Class Initialized
INFO - 2025-10-29 11:38:19 --> Controller Class Initialized
INFO - 2025-10-29 11:38:19 --> Model "Student_model" initialized
INFO - 2025-10-29 11:38:19 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:38:19 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:38:19 --> Helper loaded: form_helper
INFO - 2025-10-29 11:38:19 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:38:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:38:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-29 11:38:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:38:19 --> Final output sent to browser
DEBUG - 2025-10-29 11:38:19 --> Total execution time: 0.0798
INFO - 2025-10-29 11:38:24 --> Config Class Initialized
INFO - 2025-10-29 11:38:24 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:38:24 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:38:24 --> Utf8 Class Initialized
INFO - 2025-10-29 11:38:24 --> URI Class Initialized
INFO - 2025-10-29 11:38:24 --> Router Class Initialized
INFO - 2025-10-29 11:38:24 --> Output Class Initialized
INFO - 2025-10-29 11:38:24 --> Security Class Initialized
DEBUG - 2025-10-29 11:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:38:24 --> Input Class Initialized
INFO - 2025-10-29 11:38:24 --> Language Class Initialized
INFO - 2025-10-29 11:38:24 --> Loader Class Initialized
INFO - 2025-10-29 11:38:24 --> Helper loaded: url_helper
INFO - 2025-10-29 11:38:24 --> Database Driver Class Initialized
INFO - 2025-10-29 11:38:24 --> Controller Class Initialized
INFO - 2025-10-29 11:38:24 --> Model "Student_model" initialized
INFO - 2025-10-29 11:38:24 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:38:24 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:38:24 --> Helper loaded: form_helper
INFO - 2025-10-29 11:38:24 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:38:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:38:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 11:38:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:38:24 --> Final output sent to browser
DEBUG - 2025-10-29 11:38:24 --> Total execution time: 0.1105
INFO - 2025-10-29 11:38:26 --> Config Class Initialized
INFO - 2025-10-29 11:38:26 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:38:26 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:38:26 --> Utf8 Class Initialized
INFO - 2025-10-29 11:38:26 --> URI Class Initialized
INFO - 2025-10-29 11:38:26 --> Router Class Initialized
INFO - 2025-10-29 11:38:26 --> Output Class Initialized
INFO - 2025-10-29 11:38:26 --> Security Class Initialized
DEBUG - 2025-10-29 11:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:38:26 --> Input Class Initialized
INFO - 2025-10-29 11:38:26 --> Language Class Initialized
INFO - 2025-10-29 11:38:26 --> Loader Class Initialized
INFO - 2025-10-29 11:38:26 --> Helper loaded: url_helper
INFO - 2025-10-29 11:38:26 --> Database Driver Class Initialized
INFO - 2025-10-29 11:38:26 --> Controller Class Initialized
INFO - 2025-10-29 11:38:26 --> Model "Student_model" initialized
INFO - 2025-10-29 11:38:26 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:38:26 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:38:26 --> Helper loaded: form_helper
INFO - 2025-10-29 11:38:26 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:38:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:38:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:38:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:38:26 --> Final output sent to browser
DEBUG - 2025-10-29 11:38:26 --> Total execution time: 0.0848
INFO - 2025-10-29 11:39:10 --> Config Class Initialized
INFO - 2025-10-29 11:39:10 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:39:10 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:39:10 --> Utf8 Class Initialized
INFO - 2025-10-29 11:39:10 --> URI Class Initialized
INFO - 2025-10-29 11:39:10 --> Router Class Initialized
INFO - 2025-10-29 11:39:10 --> Output Class Initialized
INFO - 2025-10-29 11:39:10 --> Security Class Initialized
DEBUG - 2025-10-29 11:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:39:10 --> Input Class Initialized
INFO - 2025-10-29 11:39:10 --> Language Class Initialized
INFO - 2025-10-29 11:39:10 --> Loader Class Initialized
INFO - 2025-10-29 11:39:10 --> Helper loaded: url_helper
INFO - 2025-10-29 11:39:10 --> Database Driver Class Initialized
INFO - 2025-10-29 11:39:10 --> Controller Class Initialized
INFO - 2025-10-29 11:39:10 --> Model "Student_model" initialized
INFO - 2025-10-29 11:39:10 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:39:10 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:39:10 --> Helper loaded: form_helper
INFO - 2025-10-29 11:39:10 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:39:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:39:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:39:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:39:10 --> Final output sent to browser
DEBUG - 2025-10-29 11:39:10 --> Total execution time: 0.0876
INFO - 2025-10-29 11:39:26 --> Config Class Initialized
INFO - 2025-10-29 11:39:26 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:39:26 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:39:26 --> Utf8 Class Initialized
INFO - 2025-10-29 11:39:26 --> URI Class Initialized
INFO - 2025-10-29 11:39:26 --> Router Class Initialized
INFO - 2025-10-29 11:39:26 --> Output Class Initialized
INFO - 2025-10-29 11:39:26 --> Security Class Initialized
DEBUG - 2025-10-29 11:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:39:26 --> Input Class Initialized
INFO - 2025-10-29 11:39:26 --> Language Class Initialized
INFO - 2025-10-29 11:39:26 --> Loader Class Initialized
INFO - 2025-10-29 11:39:26 --> Helper loaded: url_helper
INFO - 2025-10-29 11:39:26 --> Database Driver Class Initialized
INFO - 2025-10-29 11:39:26 --> Controller Class Initialized
INFO - 2025-10-29 11:39:26 --> Model "Student_model" initialized
INFO - 2025-10-29 11:39:26 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:39:26 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:39:26 --> Helper loaded: form_helper
INFO - 2025-10-29 11:39:26 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:39:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:39:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:39:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:39:26 --> Final output sent to browser
DEBUG - 2025-10-29 11:39:26 --> Total execution time: 0.1488
INFO - 2025-10-29 11:39:34 --> Config Class Initialized
INFO - 2025-10-29 11:39:34 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:39:34 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:39:34 --> Utf8 Class Initialized
INFO - 2025-10-29 11:39:34 --> URI Class Initialized
INFO - 2025-10-29 11:39:34 --> Router Class Initialized
INFO - 2025-10-29 11:39:34 --> Output Class Initialized
INFO - 2025-10-29 11:39:34 --> Security Class Initialized
DEBUG - 2025-10-29 11:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:39:34 --> Input Class Initialized
INFO - 2025-10-29 11:39:34 --> Language Class Initialized
INFO - 2025-10-29 11:39:34 --> Loader Class Initialized
INFO - 2025-10-29 11:39:34 --> Helper loaded: url_helper
INFO - 2025-10-29 11:39:34 --> Database Driver Class Initialized
INFO - 2025-10-29 11:39:34 --> Controller Class Initialized
INFO - 2025-10-29 11:39:34 --> Model "Student_model" initialized
INFO - 2025-10-29 11:39:34 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:39:34 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:39:34 --> Helper loaded: form_helper
INFO - 2025-10-29 11:39:34 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:39:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:39:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:39:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:39:34 --> Final output sent to browser
DEBUG - 2025-10-29 11:39:34 --> Total execution time: 0.1209
INFO - 2025-10-29 11:39:35 --> Config Class Initialized
INFO - 2025-10-29 11:39:35 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:39:35 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:39:35 --> Utf8 Class Initialized
INFO - 2025-10-29 11:39:35 --> URI Class Initialized
INFO - 2025-10-29 11:39:35 --> Router Class Initialized
INFO - 2025-10-29 11:39:35 --> Output Class Initialized
INFO - 2025-10-29 11:39:35 --> Security Class Initialized
DEBUG - 2025-10-29 11:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:39:35 --> Input Class Initialized
INFO - 2025-10-29 11:39:35 --> Language Class Initialized
INFO - 2025-10-29 11:39:35 --> Loader Class Initialized
INFO - 2025-10-29 11:39:35 --> Helper loaded: url_helper
INFO - 2025-10-29 11:39:35 --> Database Driver Class Initialized
INFO - 2025-10-29 11:39:35 --> Controller Class Initialized
INFO - 2025-10-29 11:39:35 --> Model "Student_model" initialized
INFO - 2025-10-29 11:39:35 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:39:35 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:39:35 --> Helper loaded: form_helper
INFO - 2025-10-29 11:39:35 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:39:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:39:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:39:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:39:35 --> Final output sent to browser
DEBUG - 2025-10-29 11:39:35 --> Total execution time: 0.1391
INFO - 2025-10-29 11:39:35 --> Config Class Initialized
INFO - 2025-10-29 11:39:35 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:39:35 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:39:35 --> Utf8 Class Initialized
INFO - 2025-10-29 11:39:35 --> URI Class Initialized
INFO - 2025-10-29 11:39:35 --> Router Class Initialized
INFO - 2025-10-29 11:39:35 --> Output Class Initialized
INFO - 2025-10-29 11:39:35 --> Security Class Initialized
DEBUG - 2025-10-29 11:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:39:35 --> Input Class Initialized
INFO - 2025-10-29 11:39:35 --> Language Class Initialized
INFO - 2025-10-29 11:39:35 --> Loader Class Initialized
INFO - 2025-10-29 11:39:35 --> Helper loaded: url_helper
INFO - 2025-10-29 11:39:35 --> Database Driver Class Initialized
INFO - 2025-10-29 11:39:35 --> Controller Class Initialized
INFO - 2025-10-29 11:39:35 --> Model "Student_model" initialized
INFO - 2025-10-29 11:39:35 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:39:35 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:39:35 --> Helper loaded: form_helper
INFO - 2025-10-29 11:39:35 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:39:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:39:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:39:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:39:35 --> Final output sent to browser
DEBUG - 2025-10-29 11:39:35 --> Total execution time: 0.1491
INFO - 2025-10-29 11:39:35 --> Config Class Initialized
INFO - 2025-10-29 11:39:36 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:39:36 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:39:36 --> Utf8 Class Initialized
INFO - 2025-10-29 11:39:36 --> URI Class Initialized
INFO - 2025-10-29 11:39:36 --> Router Class Initialized
INFO - 2025-10-29 11:39:36 --> Output Class Initialized
INFO - 2025-10-29 11:39:36 --> Security Class Initialized
DEBUG - 2025-10-29 11:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:39:36 --> Input Class Initialized
INFO - 2025-10-29 11:39:36 --> Language Class Initialized
INFO - 2025-10-29 11:39:36 --> Loader Class Initialized
INFO - 2025-10-29 11:39:36 --> Helper loaded: url_helper
INFO - 2025-10-29 11:39:36 --> Database Driver Class Initialized
INFO - 2025-10-29 11:39:36 --> Controller Class Initialized
INFO - 2025-10-29 11:39:36 --> Model "Student_model" initialized
INFO - 2025-10-29 11:39:36 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:39:36 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:39:36 --> Helper loaded: form_helper
INFO - 2025-10-29 11:39:36 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:39:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:39:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:39:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:39:36 --> Final output sent to browser
DEBUG - 2025-10-29 11:39:36 --> Total execution time: 0.1092
INFO - 2025-10-29 11:40:35 --> Config Class Initialized
INFO - 2025-10-29 11:40:35 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:40:35 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:40:35 --> Utf8 Class Initialized
INFO - 2025-10-29 11:40:35 --> URI Class Initialized
INFO - 2025-10-29 11:40:35 --> Router Class Initialized
INFO - 2025-10-29 11:40:35 --> Output Class Initialized
INFO - 2025-10-29 11:40:35 --> Security Class Initialized
DEBUG - 2025-10-29 11:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:40:35 --> Input Class Initialized
INFO - 2025-10-29 11:40:35 --> Language Class Initialized
INFO - 2025-10-29 11:40:35 --> Loader Class Initialized
INFO - 2025-10-29 11:40:35 --> Helper loaded: url_helper
INFO - 2025-10-29 11:40:35 --> Database Driver Class Initialized
INFO - 2025-10-29 11:40:35 --> Controller Class Initialized
INFO - 2025-10-29 11:40:35 --> Model "Student_model" initialized
INFO - 2025-10-29 11:40:35 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:40:35 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:40:35 --> Helper loaded: form_helper
INFO - 2025-10-29 11:40:35 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:40:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:40:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:40:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:40:36 --> Final output sent to browser
DEBUG - 2025-10-29 11:40:36 --> Total execution time: 0.1411
INFO - 2025-10-29 11:40:46 --> Config Class Initialized
INFO - 2025-10-29 11:40:46 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:40:46 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:40:46 --> Utf8 Class Initialized
INFO - 2025-10-29 11:40:46 --> URI Class Initialized
INFO - 2025-10-29 11:40:46 --> Router Class Initialized
INFO - 2025-10-29 11:40:46 --> Output Class Initialized
INFO - 2025-10-29 11:40:46 --> Security Class Initialized
DEBUG - 2025-10-29 11:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:40:46 --> Input Class Initialized
INFO - 2025-10-29 11:40:46 --> Language Class Initialized
INFO - 2025-10-29 11:40:46 --> Loader Class Initialized
INFO - 2025-10-29 11:40:46 --> Helper loaded: url_helper
INFO - 2025-10-29 11:40:46 --> Database Driver Class Initialized
INFO - 2025-10-29 11:40:46 --> Controller Class Initialized
INFO - 2025-10-29 11:40:46 --> Model "Student_model" initialized
INFO - 2025-10-29 11:40:46 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:40:46 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:40:46 --> Helper loaded: form_helper
INFO - 2025-10-29 11:40:46 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:40:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:40:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 11:40:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:40:46 --> Final output sent to browser
DEBUG - 2025-10-29 11:40:46 --> Total execution time: 0.1344
INFO - 2025-10-29 11:40:48 --> Config Class Initialized
INFO - 2025-10-29 11:40:48 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:40:48 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:40:48 --> Utf8 Class Initialized
INFO - 2025-10-29 11:40:48 --> URI Class Initialized
INFO - 2025-10-29 11:40:48 --> Router Class Initialized
INFO - 2025-10-29 11:40:48 --> Output Class Initialized
INFO - 2025-10-29 11:40:48 --> Security Class Initialized
DEBUG - 2025-10-29 11:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:40:48 --> Input Class Initialized
INFO - 2025-10-29 11:40:48 --> Language Class Initialized
INFO - 2025-10-29 11:40:48 --> Loader Class Initialized
INFO - 2025-10-29 11:40:48 --> Helper loaded: url_helper
INFO - 2025-10-29 11:40:48 --> Database Driver Class Initialized
INFO - 2025-10-29 11:40:48 --> Controller Class Initialized
INFO - 2025-10-29 11:40:48 --> Model "Student_model" initialized
INFO - 2025-10-29 11:40:48 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:40:48 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:40:48 --> Helper loaded: form_helper
INFO - 2025-10-29 11:40:48 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:40:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:40:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:40:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:40:48 --> Final output sent to browser
DEBUG - 2025-10-29 11:40:48 --> Total execution time: 0.1297
INFO - 2025-10-29 11:41:02 --> Config Class Initialized
INFO - 2025-10-29 11:41:02 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:41:02 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:41:02 --> Utf8 Class Initialized
INFO - 2025-10-29 11:41:02 --> URI Class Initialized
INFO - 2025-10-29 11:41:02 --> Router Class Initialized
INFO - 2025-10-29 11:41:02 --> Output Class Initialized
INFO - 2025-10-29 11:41:02 --> Security Class Initialized
DEBUG - 2025-10-29 11:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:41:02 --> Input Class Initialized
INFO - 2025-10-29 11:41:02 --> Language Class Initialized
INFO - 2025-10-29 11:41:02 --> Loader Class Initialized
INFO - 2025-10-29 11:41:02 --> Helper loaded: url_helper
INFO - 2025-10-29 11:41:02 --> Database Driver Class Initialized
INFO - 2025-10-29 11:41:02 --> Controller Class Initialized
INFO - 2025-10-29 11:41:02 --> Model "Student_model" initialized
INFO - 2025-10-29 11:41:02 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:41:02 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:41:02 --> Helper loaded: form_helper
INFO - 2025-10-29 11:41:02 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:41:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:41:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:41:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:41:02 --> Final output sent to browser
DEBUG - 2025-10-29 11:41:02 --> Total execution time: 0.1048
INFO - 2025-10-29 11:41:47 --> Config Class Initialized
INFO - 2025-10-29 11:41:47 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:41:47 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:41:47 --> Utf8 Class Initialized
INFO - 2025-10-29 11:41:47 --> URI Class Initialized
INFO - 2025-10-29 11:41:47 --> Router Class Initialized
INFO - 2025-10-29 11:41:47 --> Output Class Initialized
INFO - 2025-10-29 11:41:47 --> Security Class Initialized
DEBUG - 2025-10-29 11:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:41:47 --> Input Class Initialized
INFO - 2025-10-29 11:41:47 --> Language Class Initialized
INFO - 2025-10-29 11:41:47 --> Loader Class Initialized
INFO - 2025-10-29 11:41:47 --> Helper loaded: url_helper
INFO - 2025-10-29 11:41:47 --> Database Driver Class Initialized
INFO - 2025-10-29 11:41:47 --> Controller Class Initialized
INFO - 2025-10-29 11:41:47 --> Model "Student_model" initialized
INFO - 2025-10-29 11:41:47 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:41:47 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:41:47 --> Helper loaded: form_helper
INFO - 2025-10-29 11:41:47 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:41:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:41:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:41:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:41:47 --> Final output sent to browser
DEBUG - 2025-10-29 11:41:47 --> Total execution time: 0.1078
INFO - 2025-10-29 11:41:48 --> Config Class Initialized
INFO - 2025-10-29 11:41:48 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:41:48 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:41:48 --> Utf8 Class Initialized
INFO - 2025-10-29 11:41:48 --> URI Class Initialized
INFO - 2025-10-29 11:41:48 --> Router Class Initialized
INFO - 2025-10-29 11:41:48 --> Output Class Initialized
INFO - 2025-10-29 11:41:48 --> Security Class Initialized
DEBUG - 2025-10-29 11:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:41:48 --> Input Class Initialized
INFO - 2025-10-29 11:41:48 --> Language Class Initialized
INFO - 2025-10-29 11:41:48 --> Loader Class Initialized
INFO - 2025-10-29 11:41:48 --> Helper loaded: url_helper
INFO - 2025-10-29 11:41:48 --> Database Driver Class Initialized
INFO - 2025-10-29 11:41:48 --> Controller Class Initialized
INFO - 2025-10-29 11:41:48 --> Model "Student_model" initialized
INFO - 2025-10-29 11:41:48 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:41:48 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:41:48 --> Helper loaded: form_helper
INFO - 2025-10-29 11:41:48 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:41:48 --> Final output sent to browser
DEBUG - 2025-10-29 11:41:48 --> Total execution time: 0.0812
INFO - 2025-10-29 11:41:53 --> Config Class Initialized
INFO - 2025-10-29 11:41:53 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:41:53 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:41:53 --> Utf8 Class Initialized
INFO - 2025-10-29 11:41:53 --> URI Class Initialized
INFO - 2025-10-29 11:41:53 --> Router Class Initialized
INFO - 2025-10-29 11:41:53 --> Output Class Initialized
INFO - 2025-10-29 11:41:53 --> Security Class Initialized
DEBUG - 2025-10-29 11:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:41:53 --> Input Class Initialized
INFO - 2025-10-29 11:41:53 --> Language Class Initialized
INFO - 2025-10-29 11:41:53 --> Loader Class Initialized
INFO - 2025-10-29 11:41:53 --> Helper loaded: url_helper
INFO - 2025-10-29 11:41:53 --> Database Driver Class Initialized
INFO - 2025-10-29 11:41:53 --> Controller Class Initialized
INFO - 2025-10-29 11:41:53 --> Model "Student_model" initialized
INFO - 2025-10-29 11:41:53 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:41:53 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:41:53 --> Helper loaded: form_helper
INFO - 2025-10-29 11:41:53 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:41:53 --> Final output sent to browser
DEBUG - 2025-10-29 11:41:53 --> Total execution time: 0.0823
INFO - 2025-10-29 11:41:55 --> Config Class Initialized
INFO - 2025-10-29 11:41:55 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:41:55 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:41:55 --> Utf8 Class Initialized
INFO - 2025-10-29 11:41:55 --> URI Class Initialized
INFO - 2025-10-29 11:41:55 --> Router Class Initialized
INFO - 2025-10-29 11:41:55 --> Output Class Initialized
INFO - 2025-10-29 11:41:55 --> Security Class Initialized
DEBUG - 2025-10-29 11:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:41:55 --> Input Class Initialized
INFO - 2025-10-29 11:41:55 --> Language Class Initialized
INFO - 2025-10-29 11:41:55 --> Loader Class Initialized
INFO - 2025-10-29 11:41:55 --> Helper loaded: url_helper
INFO - 2025-10-29 11:41:55 --> Database Driver Class Initialized
INFO - 2025-10-29 11:41:55 --> Controller Class Initialized
INFO - 2025-10-29 11:41:55 --> Model "Student_model" initialized
INFO - 2025-10-29 11:41:55 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:41:55 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:41:55 --> Helper loaded: form_helper
INFO - 2025-10-29 11:41:55 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:41:55 --> Final output sent to browser
DEBUG - 2025-10-29 11:41:55 --> Total execution time: 0.0969
INFO - 2025-10-29 11:41:56 --> Config Class Initialized
INFO - 2025-10-29 11:41:56 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:41:56 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:41:56 --> Utf8 Class Initialized
INFO - 2025-10-29 11:41:56 --> URI Class Initialized
INFO - 2025-10-29 11:41:56 --> Router Class Initialized
INFO - 2025-10-29 11:41:56 --> Output Class Initialized
INFO - 2025-10-29 11:41:56 --> Security Class Initialized
DEBUG - 2025-10-29 11:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:41:56 --> Input Class Initialized
INFO - 2025-10-29 11:41:56 --> Language Class Initialized
INFO - 2025-10-29 11:41:56 --> Loader Class Initialized
INFO - 2025-10-29 11:41:56 --> Helper loaded: url_helper
INFO - 2025-10-29 11:41:56 --> Database Driver Class Initialized
INFO - 2025-10-29 11:41:56 --> Controller Class Initialized
INFO - 2025-10-29 11:41:56 --> Model "Student_model" initialized
INFO - 2025-10-29 11:41:56 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:41:56 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:41:56 --> Helper loaded: form_helper
INFO - 2025-10-29 11:41:56 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:41:56 --> Final output sent to browser
DEBUG - 2025-10-29 11:41:56 --> Total execution time: 0.1112
INFO - 2025-10-29 11:42:00 --> Config Class Initialized
INFO - 2025-10-29 11:42:00 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:42:00 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:42:00 --> Utf8 Class Initialized
INFO - 2025-10-29 11:42:00 --> URI Class Initialized
INFO - 2025-10-29 11:42:00 --> Router Class Initialized
INFO - 2025-10-29 11:42:00 --> Output Class Initialized
INFO - 2025-10-29 11:42:00 --> Security Class Initialized
DEBUG - 2025-10-29 11:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:42:00 --> Input Class Initialized
INFO - 2025-10-29 11:42:00 --> Language Class Initialized
INFO - 2025-10-29 11:42:00 --> Loader Class Initialized
INFO - 2025-10-29 11:42:00 --> Helper loaded: url_helper
INFO - 2025-10-29 11:42:00 --> Database Driver Class Initialized
INFO - 2025-10-29 11:42:00 --> Controller Class Initialized
INFO - 2025-10-29 11:42:00 --> Model "Student_model" initialized
INFO - 2025-10-29 11:42:00 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:42:00 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:42:00 --> Helper loaded: form_helper
INFO - 2025-10-29 11:42:00 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:42:00 --> Final output sent to browser
DEBUG - 2025-10-29 11:42:00 --> Total execution time: 0.0927
INFO - 2025-10-29 11:42:02 --> Config Class Initialized
INFO - 2025-10-29 11:42:02 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:42:02 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:42:02 --> Utf8 Class Initialized
INFO - 2025-10-29 11:42:02 --> URI Class Initialized
INFO - 2025-10-29 11:42:02 --> Router Class Initialized
INFO - 2025-10-29 11:42:02 --> Output Class Initialized
INFO - 2025-10-29 11:42:02 --> Security Class Initialized
DEBUG - 2025-10-29 11:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:42:02 --> Input Class Initialized
INFO - 2025-10-29 11:42:02 --> Language Class Initialized
INFO - 2025-10-29 11:42:02 --> Loader Class Initialized
INFO - 2025-10-29 11:42:02 --> Helper loaded: url_helper
INFO - 2025-10-29 11:42:02 --> Database Driver Class Initialized
INFO - 2025-10-29 11:42:02 --> Controller Class Initialized
INFO - 2025-10-29 11:42:02 --> Model "Student_model" initialized
INFO - 2025-10-29 11:42:02 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:42:02 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:42:02 --> Helper loaded: form_helper
INFO - 2025-10-29 11:42:02 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:42:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:42:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:42:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:42:02 --> Final output sent to browser
DEBUG - 2025-10-29 11:42:02 --> Total execution time: 0.0975
INFO - 2025-10-29 11:42:04 --> Config Class Initialized
INFO - 2025-10-29 11:42:04 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:42:04 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:42:04 --> Utf8 Class Initialized
INFO - 2025-10-29 11:42:04 --> URI Class Initialized
INFO - 2025-10-29 11:42:04 --> Router Class Initialized
INFO - 2025-10-29 11:42:04 --> Output Class Initialized
INFO - 2025-10-29 11:42:04 --> Security Class Initialized
DEBUG - 2025-10-29 11:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:42:04 --> Input Class Initialized
INFO - 2025-10-29 11:42:04 --> Language Class Initialized
INFO - 2025-10-29 11:42:04 --> Loader Class Initialized
INFO - 2025-10-29 11:42:04 --> Helper loaded: url_helper
INFO - 2025-10-29 11:42:04 --> Database Driver Class Initialized
INFO - 2025-10-29 11:42:04 --> Controller Class Initialized
INFO - 2025-10-29 11:42:04 --> Model "Student_model" initialized
INFO - 2025-10-29 11:42:04 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:42:04 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:42:04 --> Helper loaded: form_helper
INFO - 2025-10-29 11:42:04 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:42:04 --> Final output sent to browser
DEBUG - 2025-10-29 11:42:04 --> Total execution time: 0.0787
INFO - 2025-10-29 11:42:05 --> Config Class Initialized
INFO - 2025-10-29 11:42:05 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:42:05 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:42:05 --> Utf8 Class Initialized
INFO - 2025-10-29 11:42:05 --> URI Class Initialized
INFO - 2025-10-29 11:42:05 --> Router Class Initialized
INFO - 2025-10-29 11:42:05 --> Output Class Initialized
INFO - 2025-10-29 11:42:05 --> Security Class Initialized
DEBUG - 2025-10-29 11:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:42:05 --> Input Class Initialized
INFO - 2025-10-29 11:42:05 --> Language Class Initialized
INFO - 2025-10-29 11:42:05 --> Loader Class Initialized
INFO - 2025-10-29 11:42:05 --> Helper loaded: url_helper
INFO - 2025-10-29 11:42:05 --> Database Driver Class Initialized
INFO - 2025-10-29 11:42:05 --> Controller Class Initialized
INFO - 2025-10-29 11:42:05 --> Model "Student_model" initialized
INFO - 2025-10-29 11:42:05 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:42:05 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:42:05 --> Helper loaded: form_helper
INFO - 2025-10-29 11:42:05 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:42:05 --> Final output sent to browser
DEBUG - 2025-10-29 11:42:05 --> Total execution time: 0.1140
INFO - 2025-10-29 11:42:06 --> Config Class Initialized
INFO - 2025-10-29 11:42:06 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:42:06 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:42:06 --> Utf8 Class Initialized
INFO - 2025-10-29 11:42:06 --> URI Class Initialized
INFO - 2025-10-29 11:42:06 --> Router Class Initialized
INFO - 2025-10-29 11:42:06 --> Output Class Initialized
INFO - 2025-10-29 11:42:06 --> Security Class Initialized
DEBUG - 2025-10-29 11:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:42:06 --> Input Class Initialized
INFO - 2025-10-29 11:42:06 --> Language Class Initialized
INFO - 2025-10-29 11:42:06 --> Loader Class Initialized
INFO - 2025-10-29 11:42:06 --> Helper loaded: url_helper
INFO - 2025-10-29 11:42:06 --> Database Driver Class Initialized
INFO - 2025-10-29 11:42:06 --> Controller Class Initialized
INFO - 2025-10-29 11:42:06 --> Model "Student_model" initialized
INFO - 2025-10-29 11:42:06 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:42:06 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:42:06 --> Helper loaded: form_helper
INFO - 2025-10-29 11:42:06 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:42:06 --> Final output sent to browser
DEBUG - 2025-10-29 11:42:06 --> Total execution time: 0.1020
INFO - 2025-10-29 11:42:08 --> Config Class Initialized
INFO - 2025-10-29 11:42:08 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:42:08 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:42:08 --> Utf8 Class Initialized
INFO - 2025-10-29 11:42:08 --> URI Class Initialized
INFO - 2025-10-29 11:42:08 --> Router Class Initialized
INFO - 2025-10-29 11:42:08 --> Output Class Initialized
INFO - 2025-10-29 11:42:08 --> Security Class Initialized
DEBUG - 2025-10-29 11:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:42:08 --> Input Class Initialized
INFO - 2025-10-29 11:42:08 --> Language Class Initialized
INFO - 2025-10-29 11:42:08 --> Loader Class Initialized
INFO - 2025-10-29 11:42:08 --> Helper loaded: url_helper
INFO - 2025-10-29 11:42:08 --> Database Driver Class Initialized
INFO - 2025-10-29 11:42:08 --> Controller Class Initialized
INFO - 2025-10-29 11:42:08 --> Model "Student_model" initialized
INFO - 2025-10-29 11:42:08 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:42:08 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:42:08 --> Helper loaded: form_helper
INFO - 2025-10-29 11:42:08 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:42:08 --> Final output sent to browser
DEBUG - 2025-10-29 11:42:08 --> Total execution time: 0.1033
INFO - 2025-10-29 11:42:09 --> Config Class Initialized
INFO - 2025-10-29 11:42:09 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:42:09 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:42:09 --> Utf8 Class Initialized
INFO - 2025-10-29 11:42:09 --> URI Class Initialized
INFO - 2025-10-29 11:42:09 --> Router Class Initialized
INFO - 2025-10-29 11:42:09 --> Output Class Initialized
INFO - 2025-10-29 11:42:09 --> Security Class Initialized
DEBUG - 2025-10-29 11:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:42:09 --> Input Class Initialized
INFO - 2025-10-29 11:42:09 --> Language Class Initialized
INFO - 2025-10-29 11:42:09 --> Loader Class Initialized
INFO - 2025-10-29 11:42:09 --> Helper loaded: url_helper
INFO - 2025-10-29 11:42:09 --> Database Driver Class Initialized
INFO - 2025-10-29 11:42:09 --> Controller Class Initialized
INFO - 2025-10-29 11:42:09 --> Model "Student_model" initialized
INFO - 2025-10-29 11:42:09 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:42:09 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:42:09 --> Helper loaded: form_helper
INFO - 2025-10-29 11:42:09 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:42:09 --> Final output sent to browser
DEBUG - 2025-10-29 11:42:09 --> Total execution time: 0.0862
INFO - 2025-10-29 11:42:10 --> Config Class Initialized
INFO - 2025-10-29 11:42:10 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:42:10 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:42:10 --> Utf8 Class Initialized
INFO - 2025-10-29 11:42:10 --> URI Class Initialized
INFO - 2025-10-29 11:42:10 --> Router Class Initialized
INFO - 2025-10-29 11:42:10 --> Output Class Initialized
INFO - 2025-10-29 11:42:10 --> Security Class Initialized
DEBUG - 2025-10-29 11:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:42:10 --> Input Class Initialized
INFO - 2025-10-29 11:42:10 --> Language Class Initialized
INFO - 2025-10-29 11:42:10 --> Loader Class Initialized
INFO - 2025-10-29 11:42:10 --> Helper loaded: url_helper
INFO - 2025-10-29 11:42:10 --> Database Driver Class Initialized
INFO - 2025-10-29 11:42:10 --> Controller Class Initialized
INFO - 2025-10-29 11:42:10 --> Model "Student_model" initialized
INFO - 2025-10-29 11:42:10 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:42:10 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:42:10 --> Helper loaded: form_helper
INFO - 2025-10-29 11:42:10 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:42:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:42:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 11:42:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:42:10 --> Final output sent to browser
DEBUG - 2025-10-29 11:42:10 --> Total execution time: 0.0865
INFO - 2025-10-29 11:42:12 --> Config Class Initialized
INFO - 2025-10-29 11:42:12 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:42:12 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:42:12 --> Utf8 Class Initialized
INFO - 2025-10-29 11:42:12 --> URI Class Initialized
INFO - 2025-10-29 11:42:12 --> Router Class Initialized
INFO - 2025-10-29 11:42:12 --> Output Class Initialized
INFO - 2025-10-29 11:42:12 --> Security Class Initialized
DEBUG - 2025-10-29 11:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:42:12 --> Input Class Initialized
INFO - 2025-10-29 11:42:12 --> Language Class Initialized
INFO - 2025-10-29 11:42:12 --> Loader Class Initialized
INFO - 2025-10-29 11:42:12 --> Helper loaded: url_helper
INFO - 2025-10-29 11:42:12 --> Database Driver Class Initialized
INFO - 2025-10-29 11:42:12 --> Controller Class Initialized
INFO - 2025-10-29 11:42:12 --> Model "Student_model" initialized
INFO - 2025-10-29 11:42:12 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:42:12 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:42:12 --> Helper loaded: form_helper
INFO - 2025-10-29 11:42:12 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:42:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:42:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:42:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:42:12 --> Final output sent to browser
DEBUG - 2025-10-29 11:42:12 --> Total execution time: 0.0877
INFO - 2025-10-29 11:42:13 --> Config Class Initialized
INFO - 2025-10-29 11:42:13 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:42:13 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:42:13 --> Utf8 Class Initialized
INFO - 2025-10-29 11:42:13 --> URI Class Initialized
INFO - 2025-10-29 11:42:13 --> Router Class Initialized
INFO - 2025-10-29 11:42:13 --> Output Class Initialized
INFO - 2025-10-29 11:42:13 --> Security Class Initialized
DEBUG - 2025-10-29 11:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:42:13 --> Input Class Initialized
INFO - 2025-10-29 11:42:13 --> Language Class Initialized
INFO - 2025-10-29 11:42:13 --> Loader Class Initialized
INFO - 2025-10-29 11:42:13 --> Helper loaded: url_helper
INFO - 2025-10-29 11:42:13 --> Database Driver Class Initialized
INFO - 2025-10-29 11:42:13 --> Controller Class Initialized
INFO - 2025-10-29 11:42:13 --> Model "Student_model" initialized
INFO - 2025-10-29 11:42:13 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:42:13 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:42:13 --> Helper loaded: form_helper
INFO - 2025-10-29 11:42:13 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:42:13 --> Final output sent to browser
DEBUG - 2025-10-29 11:42:13 --> Total execution time: 0.1252
INFO - 2025-10-29 11:42:15 --> Config Class Initialized
INFO - 2025-10-29 11:42:15 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:42:15 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:42:15 --> Utf8 Class Initialized
INFO - 2025-10-29 11:42:15 --> URI Class Initialized
INFO - 2025-10-29 11:42:15 --> Router Class Initialized
INFO - 2025-10-29 11:42:15 --> Output Class Initialized
INFO - 2025-10-29 11:42:15 --> Security Class Initialized
DEBUG - 2025-10-29 11:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:42:15 --> Input Class Initialized
INFO - 2025-10-29 11:42:15 --> Language Class Initialized
INFO - 2025-10-29 11:42:15 --> Loader Class Initialized
INFO - 2025-10-29 11:42:15 --> Helper loaded: url_helper
INFO - 2025-10-29 11:42:15 --> Database Driver Class Initialized
INFO - 2025-10-29 11:42:15 --> Controller Class Initialized
INFO - 2025-10-29 11:42:15 --> Model "Student_model" initialized
INFO - 2025-10-29 11:42:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:42:15 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:42:15 --> Helper loaded: form_helper
INFO - 2025-10-29 11:42:15 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:42:15 --> Final output sent to browser
DEBUG - 2025-10-29 11:42:15 --> Total execution time: 0.1216
INFO - 2025-10-29 11:42:16 --> Config Class Initialized
INFO - 2025-10-29 11:42:16 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:42:16 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:42:16 --> Utf8 Class Initialized
INFO - 2025-10-29 11:42:16 --> URI Class Initialized
INFO - 2025-10-29 11:42:16 --> Router Class Initialized
INFO - 2025-10-29 11:42:16 --> Output Class Initialized
INFO - 2025-10-29 11:42:16 --> Security Class Initialized
DEBUG - 2025-10-29 11:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:42:16 --> Input Class Initialized
INFO - 2025-10-29 11:42:16 --> Language Class Initialized
INFO - 2025-10-29 11:42:16 --> Loader Class Initialized
INFO - 2025-10-29 11:42:16 --> Helper loaded: url_helper
INFO - 2025-10-29 11:42:16 --> Database Driver Class Initialized
INFO - 2025-10-29 11:42:16 --> Controller Class Initialized
INFO - 2025-10-29 11:42:16 --> Model "Student_model" initialized
INFO - 2025-10-29 11:42:16 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:42:16 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:42:16 --> Helper loaded: form_helper
INFO - 2025-10-29 11:42:16 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:42:16 --> Final output sent to browser
DEBUG - 2025-10-29 11:42:16 --> Total execution time: 0.1239
INFO - 2025-10-29 11:42:18 --> Config Class Initialized
INFO - 2025-10-29 11:42:18 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:42:18 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:42:18 --> Utf8 Class Initialized
INFO - 2025-10-29 11:42:18 --> URI Class Initialized
INFO - 2025-10-29 11:42:18 --> Router Class Initialized
INFO - 2025-10-29 11:42:18 --> Output Class Initialized
INFO - 2025-10-29 11:42:18 --> Security Class Initialized
DEBUG - 2025-10-29 11:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:42:18 --> Input Class Initialized
INFO - 2025-10-29 11:42:18 --> Language Class Initialized
INFO - 2025-10-29 11:42:18 --> Loader Class Initialized
INFO - 2025-10-29 11:42:18 --> Helper loaded: url_helper
INFO - 2025-10-29 11:42:18 --> Database Driver Class Initialized
INFO - 2025-10-29 11:42:18 --> Controller Class Initialized
INFO - 2025-10-29 11:42:18 --> Model "Student_model" initialized
INFO - 2025-10-29 11:42:18 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:42:18 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:42:18 --> Helper loaded: form_helper
INFO - 2025-10-29 11:42:19 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:42:19 --> Final output sent to browser
DEBUG - 2025-10-29 11:42:19 --> Total execution time: 0.0797
INFO - 2025-10-29 11:42:20 --> Config Class Initialized
INFO - 2025-10-29 11:42:20 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:42:20 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:42:20 --> Utf8 Class Initialized
INFO - 2025-10-29 11:42:20 --> URI Class Initialized
INFO - 2025-10-29 11:42:20 --> Router Class Initialized
INFO - 2025-10-29 11:42:20 --> Output Class Initialized
INFO - 2025-10-29 11:42:20 --> Security Class Initialized
DEBUG - 2025-10-29 11:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:42:20 --> Input Class Initialized
INFO - 2025-10-29 11:42:20 --> Language Class Initialized
INFO - 2025-10-29 11:42:20 --> Loader Class Initialized
INFO - 2025-10-29 11:42:20 --> Helper loaded: url_helper
INFO - 2025-10-29 11:42:20 --> Database Driver Class Initialized
INFO - 2025-10-29 11:42:20 --> Controller Class Initialized
INFO - 2025-10-29 11:42:20 --> Model "Student_model" initialized
INFO - 2025-10-29 11:42:20 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:42:20 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:42:20 --> Helper loaded: form_helper
INFO - 2025-10-29 11:42:20 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:42:20 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:42:20 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 11:42:20 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:42:20 --> Final output sent to browser
DEBUG - 2025-10-29 11:42:20 --> Total execution time: 0.0941
INFO - 2025-10-29 11:42:52 --> Config Class Initialized
INFO - 2025-10-29 11:42:52 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:42:52 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:42:52 --> Utf8 Class Initialized
INFO - 2025-10-29 11:42:52 --> URI Class Initialized
INFO - 2025-10-29 11:42:52 --> Router Class Initialized
INFO - 2025-10-29 11:42:52 --> Output Class Initialized
INFO - 2025-10-29 11:42:52 --> Security Class Initialized
DEBUG - 2025-10-29 11:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:42:52 --> Input Class Initialized
INFO - 2025-10-29 11:42:52 --> Language Class Initialized
INFO - 2025-10-29 11:42:52 --> Loader Class Initialized
INFO - 2025-10-29 11:42:52 --> Helper loaded: url_helper
INFO - 2025-10-29 11:42:52 --> Database Driver Class Initialized
INFO - 2025-10-29 11:42:52 --> Controller Class Initialized
INFO - 2025-10-29 11:42:52 --> Model "Student_model" initialized
INFO - 2025-10-29 11:42:52 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:42:52 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:42:52 --> Helper loaded: form_helper
INFO - 2025-10-29 11:42:52 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:42:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:42:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 11:42:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:42:52 --> Final output sent to browser
DEBUG - 2025-10-29 11:42:52 --> Total execution time: 0.0887
INFO - 2025-10-29 11:42:54 --> Config Class Initialized
INFO - 2025-10-29 11:42:54 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:42:54 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:42:54 --> Utf8 Class Initialized
INFO - 2025-10-29 11:42:54 --> URI Class Initialized
INFO - 2025-10-29 11:42:54 --> Router Class Initialized
INFO - 2025-10-29 11:42:54 --> Output Class Initialized
INFO - 2025-10-29 11:42:54 --> Security Class Initialized
DEBUG - 2025-10-29 11:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:42:54 --> Input Class Initialized
INFO - 2025-10-29 11:42:54 --> Language Class Initialized
INFO - 2025-10-29 11:42:54 --> Loader Class Initialized
INFO - 2025-10-29 11:42:54 --> Helper loaded: url_helper
INFO - 2025-10-29 11:42:54 --> Database Driver Class Initialized
INFO - 2025-10-29 11:42:54 --> Controller Class Initialized
INFO - 2025-10-29 11:42:54 --> Model "Student_model" initialized
INFO - 2025-10-29 11:42:54 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:42:54 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:42:54 --> Helper loaded: form_helper
INFO - 2025-10-29 11:42:54 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:42:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:42:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:42:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:42:54 --> Final output sent to browser
DEBUG - 2025-10-29 11:42:54 --> Total execution time: 0.0944
INFO - 2025-10-29 11:43:15 --> Config Class Initialized
INFO - 2025-10-29 11:43:15 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:43:15 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:43:15 --> Utf8 Class Initialized
INFO - 2025-10-29 11:43:15 --> URI Class Initialized
INFO - 2025-10-29 11:43:15 --> Router Class Initialized
INFO - 2025-10-29 11:43:15 --> Output Class Initialized
INFO - 2025-10-29 11:43:15 --> Security Class Initialized
DEBUG - 2025-10-29 11:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:43:15 --> Input Class Initialized
INFO - 2025-10-29 11:43:15 --> Language Class Initialized
INFO - 2025-10-29 11:43:15 --> Loader Class Initialized
INFO - 2025-10-29 11:43:15 --> Helper loaded: url_helper
INFO - 2025-10-29 11:43:15 --> Database Driver Class Initialized
INFO - 2025-10-29 11:43:15 --> Controller Class Initialized
INFO - 2025-10-29 11:43:15 --> Model "Student_model" initialized
INFO - 2025-10-29 11:43:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:43:15 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:43:15 --> Helper loaded: form_helper
INFO - 2025-10-29 11:43:15 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:43:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:43:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 11:43:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:43:15 --> Final output sent to browser
DEBUG - 2025-10-29 11:43:15 --> Total execution time: 0.1588
INFO - 2025-10-29 11:43:18 --> Config Class Initialized
INFO - 2025-10-29 11:43:18 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:43:18 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:43:18 --> Utf8 Class Initialized
INFO - 2025-10-29 11:43:18 --> URI Class Initialized
INFO - 2025-10-29 11:43:18 --> Router Class Initialized
INFO - 2025-10-29 11:43:18 --> Output Class Initialized
INFO - 2025-10-29 11:43:18 --> Security Class Initialized
DEBUG - 2025-10-29 11:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:43:18 --> Input Class Initialized
INFO - 2025-10-29 11:43:18 --> Language Class Initialized
INFO - 2025-10-29 11:43:18 --> Loader Class Initialized
INFO - 2025-10-29 11:43:18 --> Helper loaded: url_helper
INFO - 2025-10-29 11:43:18 --> Database Driver Class Initialized
INFO - 2025-10-29 11:43:18 --> Controller Class Initialized
INFO - 2025-10-29 11:43:18 --> Model "Student_model" initialized
INFO - 2025-10-29 11:43:18 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:43:18 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:43:18 --> Helper loaded: form_helper
INFO - 2025-10-29 11:43:18 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:43:18 --> Final output sent to browser
DEBUG - 2025-10-29 11:43:18 --> Total execution time: 0.1299
INFO - 2025-10-29 11:43:26 --> Config Class Initialized
INFO - 2025-10-29 11:43:26 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:43:26 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:43:26 --> Utf8 Class Initialized
INFO - 2025-10-29 11:43:26 --> URI Class Initialized
INFO - 2025-10-29 11:43:26 --> Router Class Initialized
INFO - 2025-10-29 11:43:26 --> Output Class Initialized
INFO - 2025-10-29 11:43:26 --> Security Class Initialized
DEBUG - 2025-10-29 11:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:43:26 --> Input Class Initialized
INFO - 2025-10-29 11:43:26 --> Language Class Initialized
INFO - 2025-10-29 11:43:26 --> Loader Class Initialized
INFO - 2025-10-29 11:43:26 --> Helper loaded: url_helper
INFO - 2025-10-29 11:43:26 --> Database Driver Class Initialized
INFO - 2025-10-29 11:43:26 --> Controller Class Initialized
INFO - 2025-10-29 11:43:26 --> Model "Student_model" initialized
INFO - 2025-10-29 11:43:26 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:43:26 --> Model "Payment_model" initialized
INFO - 2025-10-29 11:43:26 --> Helper loaded: form_helper
INFO - 2025-10-29 11:43:26 --> Form Validation Class Initialized
DEBUG - 2025-10-29 11:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 11:43:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 11:43:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 11:43:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 11:43:26 --> Final output sent to browser
DEBUG - 2025-10-29 11:43:26 --> Total execution time: 0.0945
INFO - 2025-10-29 11:43:28 --> Config Class Initialized
INFO - 2025-10-29 11:43:28 --> Hooks Class Initialized
DEBUG - 2025-10-29 11:43:28 --> UTF-8 Support Enabled
INFO - 2025-10-29 11:43:28 --> Utf8 Class Initialized
INFO - 2025-10-29 11:43:28 --> URI Class Initialized
DEBUG - 2025-10-29 11:43:28 --> No URI present. Default controller set.
INFO - 2025-10-29 11:43:28 --> Router Class Initialized
INFO - 2025-10-29 11:43:28 --> Output Class Initialized
INFO - 2025-10-29 11:43:28 --> Security Class Initialized
DEBUG - 2025-10-29 11:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 11:43:28 --> Input Class Initialized
INFO - 2025-10-29 11:43:28 --> Language Class Initialized
INFO - 2025-10-29 11:43:28 --> Loader Class Initialized
INFO - 2025-10-29 11:43:28 --> Helper loaded: url_helper
INFO - 2025-10-29 11:43:28 --> Database Driver Class Initialized
INFO - 2025-10-29 11:43:28 --> Controller Class Initialized
INFO - 2025-10-29 11:43:28 --> Model "Student_model" initialized
INFO - 2025-10-29 11:43:28 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 11:43:28 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 11:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 11:43:28 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 11:43:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''2025-05'
AND `status` = '1'' at line 3 - Invalid query: SELECT SUM(`amount_paid`) AS `amount_paid`
FROM `payments`
WHERE DATE_FORMAT(payment_date, "%Y-%m") '2025-05'
AND `status` = '1'
INFO - 2025-10-29 11:43:28 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 12:26:16 --> Config Class Initialized
INFO - 2025-10-29 12:26:16 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:26:16 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:26:16 --> Utf8 Class Initialized
INFO - 2025-10-29 12:26:16 --> URI Class Initialized
DEBUG - 2025-10-29 12:26:16 --> No URI present. Default controller set.
INFO - 2025-10-29 12:26:16 --> Router Class Initialized
INFO - 2025-10-29 12:26:16 --> Output Class Initialized
INFO - 2025-10-29 12:26:16 --> Security Class Initialized
DEBUG - 2025-10-29 12:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:26:16 --> Input Class Initialized
INFO - 2025-10-29 12:26:16 --> Language Class Initialized
INFO - 2025-10-29 12:26:16 --> Loader Class Initialized
INFO - 2025-10-29 12:26:16 --> Helper loaded: url_helper
INFO - 2025-10-29 12:26:16 --> Database Driver Class Initialized
INFO - 2025-10-29 12:26:16 --> Controller Class Initialized
INFO - 2025-10-29 12:26:16 --> Model "Student_model" initialized
INFO - 2025-10-29 12:26:16 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:26:16 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:26:16 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 12:26:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2025-05
AND `status` = '1'' at line 3 - Invalid query: SELECT SUM(`amount_paid`) AS `amount_paid`
FROM `payments`
WHERE DATE_FORMAT(payment_date, "%Y-%m") 2025-05
AND `status` = '1'
INFO - 2025-10-29 12:26:16 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 12:26:18 --> Config Class Initialized
INFO - 2025-10-29 12:26:18 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:26:18 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:26:18 --> Utf8 Class Initialized
INFO - 2025-10-29 12:26:18 --> URI Class Initialized
DEBUG - 2025-10-29 12:26:18 --> No URI present. Default controller set.
INFO - 2025-10-29 12:26:18 --> Router Class Initialized
INFO - 2025-10-29 12:26:18 --> Output Class Initialized
INFO - 2025-10-29 12:26:18 --> Security Class Initialized
DEBUG - 2025-10-29 12:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:26:18 --> Input Class Initialized
INFO - 2025-10-29 12:26:18 --> Language Class Initialized
INFO - 2025-10-29 12:26:18 --> Loader Class Initialized
INFO - 2025-10-29 12:26:18 --> Helper loaded: url_helper
INFO - 2025-10-29 12:26:18 --> Database Driver Class Initialized
INFO - 2025-10-29 12:26:18 --> Controller Class Initialized
INFO - 2025-10-29 12:26:18 --> Model "Student_model" initialized
INFO - 2025-10-29 12:26:18 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:26:18 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:26:18 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 12:26:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2025-05
AND `status` = '1'' at line 3 - Invalid query: SELECT SUM(`amount_paid`) AS `amount_paid`
FROM `payments`
WHERE DATE_FORMAT(payment_date, "%Y-%m") 2025-05
AND `status` = '1'
INFO - 2025-10-29 12:26:18 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 12:26:18 --> Config Class Initialized
INFO - 2025-10-29 12:26:18 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:26:18 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:26:18 --> Utf8 Class Initialized
INFO - 2025-10-29 12:26:18 --> URI Class Initialized
DEBUG - 2025-10-29 12:26:18 --> No URI present. Default controller set.
INFO - 2025-10-29 12:26:18 --> Router Class Initialized
INFO - 2025-10-29 12:26:18 --> Output Class Initialized
INFO - 2025-10-29 12:26:18 --> Security Class Initialized
DEBUG - 2025-10-29 12:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:26:18 --> Input Class Initialized
INFO - 2025-10-29 12:26:18 --> Language Class Initialized
INFO - 2025-10-29 12:26:18 --> Loader Class Initialized
INFO - 2025-10-29 12:26:18 --> Helper loaded: url_helper
INFO - 2025-10-29 12:26:18 --> Database Driver Class Initialized
INFO - 2025-10-29 12:26:18 --> Controller Class Initialized
INFO - 2025-10-29 12:26:18 --> Model "Student_model" initialized
INFO - 2025-10-29 12:26:18 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:26:18 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:26:18 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 12:26:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2025-05
AND `status` = '1'' at line 3 - Invalid query: SELECT SUM(`amount_paid`) AS `amount_paid`
FROM `payments`
WHERE DATE_FORMAT(payment_date, "%Y-%m") 2025-05
AND `status` = '1'
INFO - 2025-10-29 12:26:18 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 12:26:18 --> Config Class Initialized
INFO - 2025-10-29 12:26:18 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:26:18 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:26:18 --> Utf8 Class Initialized
INFO - 2025-10-29 12:26:18 --> URI Class Initialized
DEBUG - 2025-10-29 12:26:18 --> No URI present. Default controller set.
INFO - 2025-10-29 12:26:18 --> Router Class Initialized
INFO - 2025-10-29 12:26:18 --> Output Class Initialized
INFO - 2025-10-29 12:26:18 --> Security Class Initialized
DEBUG - 2025-10-29 12:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:26:19 --> Input Class Initialized
INFO - 2025-10-29 12:26:19 --> Language Class Initialized
INFO - 2025-10-29 12:26:19 --> Loader Class Initialized
INFO - 2025-10-29 12:26:19 --> Helper loaded: url_helper
INFO - 2025-10-29 12:26:19 --> Database Driver Class Initialized
INFO - 2025-10-29 12:26:19 --> Controller Class Initialized
INFO - 2025-10-29 12:26:19 --> Model "Student_model" initialized
INFO - 2025-10-29 12:26:19 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:26:19 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:26:19 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 12:26:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2025-05
AND `status` = '1'' at line 3 - Invalid query: SELECT SUM(`amount_paid`) AS `amount_paid`
FROM `payments`
WHERE DATE_FORMAT(payment_date, "%Y-%m") 2025-05
AND `status` = '1'
INFO - 2025-10-29 12:26:19 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 12:26:19 --> Config Class Initialized
INFO - 2025-10-29 12:26:19 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:26:19 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:26:19 --> Utf8 Class Initialized
INFO - 2025-10-29 12:26:19 --> URI Class Initialized
DEBUG - 2025-10-29 12:26:19 --> No URI present. Default controller set.
INFO - 2025-10-29 12:26:19 --> Router Class Initialized
INFO - 2025-10-29 12:26:19 --> Output Class Initialized
INFO - 2025-10-29 12:26:19 --> Security Class Initialized
DEBUG - 2025-10-29 12:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:26:19 --> Input Class Initialized
INFO - 2025-10-29 12:26:19 --> Language Class Initialized
INFO - 2025-10-29 12:26:19 --> Loader Class Initialized
INFO - 2025-10-29 12:26:19 --> Helper loaded: url_helper
INFO - 2025-10-29 12:26:19 --> Database Driver Class Initialized
INFO - 2025-10-29 12:26:19 --> Controller Class Initialized
INFO - 2025-10-29 12:26:19 --> Model "Student_model" initialized
INFO - 2025-10-29 12:26:19 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:26:19 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:26:19 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 12:26:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2025-05
AND `status` = '1'' at line 3 - Invalid query: SELECT SUM(`amount_paid`) AS `amount_paid`
FROM `payments`
WHERE DATE_FORMAT(payment_date, "%Y-%m") 2025-05
AND `status` = '1'
INFO - 2025-10-29 12:26:19 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 12:26:19 --> Config Class Initialized
INFO - 2025-10-29 12:26:19 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:26:19 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:26:19 --> Utf8 Class Initialized
INFO - 2025-10-29 12:26:19 --> URI Class Initialized
DEBUG - 2025-10-29 12:26:19 --> No URI present. Default controller set.
INFO - 2025-10-29 12:26:19 --> Router Class Initialized
INFO - 2025-10-29 12:26:19 --> Output Class Initialized
INFO - 2025-10-29 12:26:19 --> Security Class Initialized
DEBUG - 2025-10-29 12:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:26:19 --> Input Class Initialized
INFO - 2025-10-29 12:26:19 --> Language Class Initialized
INFO - 2025-10-29 12:26:19 --> Loader Class Initialized
INFO - 2025-10-29 12:26:19 --> Helper loaded: url_helper
INFO - 2025-10-29 12:26:19 --> Database Driver Class Initialized
INFO - 2025-10-29 12:26:19 --> Controller Class Initialized
INFO - 2025-10-29 12:26:19 --> Model "Student_model" initialized
INFO - 2025-10-29 12:26:19 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:26:19 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:26:19 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 12:26:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2025-05
AND `status` = '1'' at line 3 - Invalid query: SELECT SUM(`amount_paid`) AS `amount_paid`
FROM `payments`
WHERE DATE_FORMAT(payment_date, "%Y-%m") 2025-05
AND `status` = '1'
INFO - 2025-10-29 12:26:19 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 12:26:35 --> Config Class Initialized
INFO - 2025-10-29 12:26:35 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:26:35 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:26:35 --> Utf8 Class Initialized
INFO - 2025-10-29 12:26:35 --> URI Class Initialized
DEBUG - 2025-10-29 12:26:35 --> No URI present. Default controller set.
INFO - 2025-10-29 12:26:35 --> Router Class Initialized
INFO - 2025-10-29 12:26:35 --> Output Class Initialized
INFO - 2025-10-29 12:26:35 --> Security Class Initialized
DEBUG - 2025-10-29 12:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:26:35 --> Input Class Initialized
INFO - 2025-10-29 12:26:35 --> Language Class Initialized
INFO - 2025-10-29 12:26:35 --> Loader Class Initialized
INFO - 2025-10-29 12:26:35 --> Helper loaded: url_helper
INFO - 2025-10-29 12:26:35 --> Database Driver Class Initialized
INFO - 2025-10-29 12:26:35 --> Controller Class Initialized
INFO - 2025-10-29 12:26:35 --> Model "Student_model" initialized
INFO - 2025-10-29 12:26:35 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:26:35 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:26:35 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 12:26:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''2025-05'
AND `status` = '1'' at line 3 - Invalid query: SELECT SUM(`amount_paid`) AS `amount_paid`
FROM `payments`
WHERE DATE_FORMAT(payment_date, "%Y-%m") '2025-05'
AND `status` = '1'
INFO - 2025-10-29 12:26:35 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 12:26:36 --> Config Class Initialized
INFO - 2025-10-29 12:26:36 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:26:36 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:26:36 --> Utf8 Class Initialized
INFO - 2025-10-29 12:26:36 --> URI Class Initialized
DEBUG - 2025-10-29 12:26:36 --> No URI present. Default controller set.
INFO - 2025-10-29 12:26:36 --> Router Class Initialized
INFO - 2025-10-29 12:26:36 --> Output Class Initialized
INFO - 2025-10-29 12:26:36 --> Security Class Initialized
DEBUG - 2025-10-29 12:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:26:36 --> Input Class Initialized
INFO - 2025-10-29 12:26:36 --> Language Class Initialized
INFO - 2025-10-29 12:26:36 --> Loader Class Initialized
INFO - 2025-10-29 12:26:36 --> Helper loaded: url_helper
INFO - 2025-10-29 12:26:36 --> Database Driver Class Initialized
INFO - 2025-10-29 12:26:36 --> Controller Class Initialized
INFO - 2025-10-29 12:26:36 --> Model "Student_model" initialized
INFO - 2025-10-29 12:26:36 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:26:36 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:26:36 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 12:26:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''2025-05'
AND `status` = '1'' at line 3 - Invalid query: SELECT SUM(`amount_paid`) AS `amount_paid`
FROM `payments`
WHERE DATE_FORMAT(payment_date, "%Y-%m") '2025-05'
AND `status` = '1'
INFO - 2025-10-29 12:26:36 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 12:26:37 --> Config Class Initialized
INFO - 2025-10-29 12:26:37 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:26:37 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:26:37 --> Utf8 Class Initialized
INFO - 2025-10-29 12:26:37 --> URI Class Initialized
DEBUG - 2025-10-29 12:26:37 --> No URI present. Default controller set.
INFO - 2025-10-29 12:26:37 --> Router Class Initialized
INFO - 2025-10-29 12:26:37 --> Output Class Initialized
INFO - 2025-10-29 12:26:37 --> Security Class Initialized
DEBUG - 2025-10-29 12:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:26:37 --> Input Class Initialized
INFO - 2025-10-29 12:26:37 --> Language Class Initialized
INFO - 2025-10-29 12:26:37 --> Loader Class Initialized
INFO - 2025-10-29 12:26:37 --> Helper loaded: url_helper
INFO - 2025-10-29 12:26:37 --> Database Driver Class Initialized
INFO - 2025-10-29 12:26:37 --> Controller Class Initialized
INFO - 2025-10-29 12:26:37 --> Model "Student_model" initialized
INFO - 2025-10-29 12:26:37 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:26:37 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:26:37 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-29 12:26:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''2025-05'
AND `status` = '1'' at line 3 - Invalid query: SELECT SUM(`amount_paid`) AS `amount_paid`
FROM `payments`
WHERE DATE_FORMAT(payment_date, "%Y-%m") '2025-05'
AND `status` = '1'
INFO - 2025-10-29 12:26:37 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-29 12:27:43 --> Config Class Initialized
INFO - 2025-10-29 12:27:43 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:27:43 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:27:43 --> Utf8 Class Initialized
INFO - 2025-10-29 12:27:43 --> URI Class Initialized
DEBUG - 2025-10-29 12:27:43 --> No URI present. Default controller set.
INFO - 2025-10-29 12:27:43 --> Router Class Initialized
INFO - 2025-10-29 12:27:43 --> Output Class Initialized
INFO - 2025-10-29 12:27:43 --> Security Class Initialized
DEBUG - 2025-10-29 12:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:27:43 --> Input Class Initialized
INFO - 2025-10-29 12:27:43 --> Language Class Initialized
INFO - 2025-10-29 12:27:43 --> Loader Class Initialized
INFO - 2025-10-29 12:27:43 --> Helper loaded: url_helper
INFO - 2025-10-29 12:27:43 --> Database Driver Class Initialized
INFO - 2025-10-29 12:27:43 --> Controller Class Initialized
INFO - 2025-10-29 12:27:43 --> Model "Student_model" initialized
INFO - 2025-10-29 12:27:43 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:27:43 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 12:27:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 12:28:46 --> Config Class Initialized
INFO - 2025-10-29 12:28:46 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:28:46 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:28:46 --> Utf8 Class Initialized
INFO - 2025-10-29 12:28:46 --> URI Class Initialized
DEBUG - 2025-10-29 12:28:46 --> No URI present. Default controller set.
INFO - 2025-10-29 12:28:46 --> Router Class Initialized
INFO - 2025-10-29 12:28:46 --> Output Class Initialized
INFO - 2025-10-29 12:28:46 --> Security Class Initialized
DEBUG - 2025-10-29 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:28:46 --> Input Class Initialized
INFO - 2025-10-29 12:28:46 --> Language Class Initialized
INFO - 2025-10-29 12:28:46 --> Loader Class Initialized
INFO - 2025-10-29 12:28:46 --> Helper loaded: url_helper
INFO - 2025-10-29 12:28:46 --> Database Driver Class Initialized
INFO - 2025-10-29 12:28:46 --> Controller Class Initialized
INFO - 2025-10-29 12:28:46 --> Model "Student_model" initialized
INFO - 2025-10-29 12:28:46 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:28:46 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 12:28:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 12:28:47 --> Config Class Initialized
INFO - 2025-10-29 12:28:47 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:28:47 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:28:47 --> Utf8 Class Initialized
INFO - 2025-10-29 12:28:47 --> URI Class Initialized
DEBUG - 2025-10-29 12:28:47 --> No URI present. Default controller set.
INFO - 2025-10-29 12:28:47 --> Router Class Initialized
INFO - 2025-10-29 12:28:47 --> Output Class Initialized
INFO - 2025-10-29 12:28:47 --> Security Class Initialized
DEBUG - 2025-10-29 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:28:47 --> Input Class Initialized
INFO - 2025-10-29 12:28:47 --> Language Class Initialized
INFO - 2025-10-29 12:28:47 --> Loader Class Initialized
INFO - 2025-10-29 12:28:47 --> Helper loaded: url_helper
INFO - 2025-10-29 12:28:47 --> Database Driver Class Initialized
INFO - 2025-10-29 12:28:47 --> Controller Class Initialized
INFO - 2025-10-29 12:28:47 --> Model "Student_model" initialized
INFO - 2025-10-29 12:28:47 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:28:47 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 12:28:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 12:28:47 --> Config Class Initialized
INFO - 2025-10-29 12:28:47 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:28:47 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:28:47 --> Utf8 Class Initialized
INFO - 2025-10-29 12:28:47 --> URI Class Initialized
DEBUG - 2025-10-29 12:28:47 --> No URI present. Default controller set.
INFO - 2025-10-29 12:28:47 --> Router Class Initialized
INFO - 2025-10-29 12:28:47 --> Output Class Initialized
INFO - 2025-10-29 12:28:47 --> Security Class Initialized
DEBUG - 2025-10-29 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:28:47 --> Input Class Initialized
INFO - 2025-10-29 12:28:47 --> Language Class Initialized
INFO - 2025-10-29 12:28:47 --> Loader Class Initialized
INFO - 2025-10-29 12:28:47 --> Helper loaded: url_helper
INFO - 2025-10-29 12:28:47 --> Database Driver Class Initialized
INFO - 2025-10-29 12:28:47 --> Controller Class Initialized
INFO - 2025-10-29 12:28:47 --> Model "Student_model" initialized
INFO - 2025-10-29 12:28:47 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:28:47 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 12:28:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 12:28:47 --> Config Class Initialized
INFO - 2025-10-29 12:28:47 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:28:47 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:28:47 --> Utf8 Class Initialized
INFO - 2025-10-29 12:28:47 --> URI Class Initialized
DEBUG - 2025-10-29 12:28:47 --> No URI present. Default controller set.
INFO - 2025-10-29 12:28:47 --> Router Class Initialized
INFO - 2025-10-29 12:28:47 --> Output Class Initialized
INFO - 2025-10-29 12:28:47 --> Security Class Initialized
DEBUG - 2025-10-29 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:28:47 --> Input Class Initialized
INFO - 2025-10-29 12:28:47 --> Language Class Initialized
INFO - 2025-10-29 12:28:47 --> Loader Class Initialized
INFO - 2025-10-29 12:28:47 --> Helper loaded: url_helper
INFO - 2025-10-29 12:28:47 --> Database Driver Class Initialized
INFO - 2025-10-29 12:28:47 --> Controller Class Initialized
INFO - 2025-10-29 12:28:47 --> Model "Student_model" initialized
INFO - 2025-10-29 12:28:47 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:28:47 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 12:28:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 12:28:47 --> Config Class Initialized
INFO - 2025-10-29 12:28:47 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:28:47 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:28:47 --> Utf8 Class Initialized
INFO - 2025-10-29 12:28:47 --> URI Class Initialized
DEBUG - 2025-10-29 12:28:47 --> No URI present. Default controller set.
INFO - 2025-10-29 12:28:47 --> Router Class Initialized
INFO - 2025-10-29 12:28:47 --> Output Class Initialized
INFO - 2025-10-29 12:28:47 --> Security Class Initialized
DEBUG - 2025-10-29 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:28:47 --> Input Class Initialized
INFO - 2025-10-29 12:28:47 --> Language Class Initialized
INFO - 2025-10-29 12:28:47 --> Loader Class Initialized
INFO - 2025-10-29 12:28:47 --> Helper loaded: url_helper
INFO - 2025-10-29 12:28:47 --> Database Driver Class Initialized
INFO - 2025-10-29 12:28:47 --> Controller Class Initialized
INFO - 2025-10-29 12:28:47 --> Model "Student_model" initialized
INFO - 2025-10-29 12:28:47 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:28:47 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 12:28:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 12:28:47 --> Config Class Initialized
INFO - 2025-10-29 12:28:47 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:28:47 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:28:47 --> Utf8 Class Initialized
INFO - 2025-10-29 12:28:47 --> URI Class Initialized
DEBUG - 2025-10-29 12:28:47 --> No URI present. Default controller set.
INFO - 2025-10-29 12:28:47 --> Router Class Initialized
INFO - 2025-10-29 12:28:47 --> Output Class Initialized
INFO - 2025-10-29 12:28:47 --> Security Class Initialized
DEBUG - 2025-10-29 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:28:47 --> Input Class Initialized
INFO - 2025-10-29 12:28:47 --> Language Class Initialized
INFO - 2025-10-29 12:28:47 --> Loader Class Initialized
INFO - 2025-10-29 12:28:47 --> Helper loaded: url_helper
INFO - 2025-10-29 12:28:47 --> Database Driver Class Initialized
INFO - 2025-10-29 12:28:47 --> Controller Class Initialized
INFO - 2025-10-29 12:28:47 --> Model "Student_model" initialized
INFO - 2025-10-29 12:28:47 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:28:47 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 12:28:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 12:28:48 --> Config Class Initialized
INFO - 2025-10-29 12:28:48 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:28:48 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:28:48 --> Utf8 Class Initialized
INFO - 2025-10-29 12:28:48 --> URI Class Initialized
DEBUG - 2025-10-29 12:28:48 --> No URI present. Default controller set.
INFO - 2025-10-29 12:28:48 --> Router Class Initialized
INFO - 2025-10-29 12:28:48 --> Output Class Initialized
INFO - 2025-10-29 12:28:48 --> Security Class Initialized
DEBUG - 2025-10-29 12:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:28:48 --> Input Class Initialized
INFO - 2025-10-29 12:28:48 --> Language Class Initialized
INFO - 2025-10-29 12:28:48 --> Loader Class Initialized
INFO - 2025-10-29 12:28:48 --> Helper loaded: url_helper
INFO - 2025-10-29 12:28:48 --> Database Driver Class Initialized
INFO - 2025-10-29 12:28:48 --> Controller Class Initialized
INFO - 2025-10-29 12:28:48 --> Model "Student_model" initialized
INFO - 2025-10-29 12:28:48 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:28:48 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 12:28:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 12:28:48 --> Config Class Initialized
INFO - 2025-10-29 12:28:48 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:28:48 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:28:48 --> Utf8 Class Initialized
INFO - 2025-10-29 12:28:48 --> URI Class Initialized
DEBUG - 2025-10-29 12:28:48 --> No URI present. Default controller set.
INFO - 2025-10-29 12:28:48 --> Router Class Initialized
INFO - 2025-10-29 12:28:48 --> Output Class Initialized
INFO - 2025-10-29 12:28:48 --> Security Class Initialized
DEBUG - 2025-10-29 12:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:28:48 --> Input Class Initialized
INFO - 2025-10-29 12:28:48 --> Language Class Initialized
INFO - 2025-10-29 12:28:48 --> Loader Class Initialized
INFO - 2025-10-29 12:28:48 --> Helper loaded: url_helper
INFO - 2025-10-29 12:28:48 --> Database Driver Class Initialized
INFO - 2025-10-29 12:28:48 --> Controller Class Initialized
INFO - 2025-10-29 12:28:48 --> Model "Student_model" initialized
INFO - 2025-10-29 12:28:48 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:28:48 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 12:28:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 12:28:48 --> Config Class Initialized
INFO - 2025-10-29 12:28:48 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:28:48 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:28:48 --> Utf8 Class Initialized
INFO - 2025-10-29 12:28:48 --> URI Class Initialized
DEBUG - 2025-10-29 12:28:48 --> No URI present. Default controller set.
INFO - 2025-10-29 12:28:48 --> Router Class Initialized
INFO - 2025-10-29 12:28:48 --> Output Class Initialized
INFO - 2025-10-29 12:28:48 --> Security Class Initialized
DEBUG - 2025-10-29 12:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:28:48 --> Input Class Initialized
INFO - 2025-10-29 12:28:48 --> Language Class Initialized
INFO - 2025-10-29 12:28:48 --> Loader Class Initialized
INFO - 2025-10-29 12:28:48 --> Helper loaded: url_helper
INFO - 2025-10-29 12:28:48 --> Database Driver Class Initialized
INFO - 2025-10-29 12:28:48 --> Controller Class Initialized
INFO - 2025-10-29 12:28:48 --> Model "Student_model" initialized
INFO - 2025-10-29 12:28:48 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:28:48 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 12:28:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 12:34:29 --> Config Class Initialized
INFO - 2025-10-29 12:34:29 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:34:29 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:34:29 --> Utf8 Class Initialized
INFO - 2025-10-29 12:34:29 --> URI Class Initialized
DEBUG - 2025-10-29 12:34:29 --> No URI present. Default controller set.
INFO - 2025-10-29 12:34:29 --> Router Class Initialized
INFO - 2025-10-29 12:34:29 --> Output Class Initialized
INFO - 2025-10-29 12:34:29 --> Security Class Initialized
DEBUG - 2025-10-29 12:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:34:29 --> Input Class Initialized
INFO - 2025-10-29 12:34:29 --> Language Class Initialized
INFO - 2025-10-29 12:34:29 --> Loader Class Initialized
INFO - 2025-10-29 12:34:29 --> Helper loaded: url_helper
INFO - 2025-10-29 12:34:29 --> Database Driver Class Initialized
INFO - 2025-10-29 12:34:29 --> Controller Class Initialized
INFO - 2025-10-29 12:34:29 --> Model "Student_model" initialized
INFO - 2025-10-29 12:34:29 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:34:29 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 12:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 12:34:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 12:34:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-29 12:34:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 12:34:29 --> Final output sent to browser
DEBUG - 2025-10-29 12:34:29 --> Total execution time: 0.0967
INFO - 2025-10-29 12:35:18 --> Config Class Initialized
INFO - 2025-10-29 12:35:18 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:35:18 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:35:18 --> Utf8 Class Initialized
INFO - 2025-10-29 12:35:18 --> URI Class Initialized
INFO - 2025-10-29 12:35:18 --> Router Class Initialized
INFO - 2025-10-29 12:35:18 --> Output Class Initialized
INFO - 2025-10-29 12:35:18 --> Security Class Initialized
DEBUG - 2025-10-29 12:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:35:18 --> Input Class Initialized
INFO - 2025-10-29 12:35:18 --> Language Class Initialized
INFO - 2025-10-29 12:35:18 --> Loader Class Initialized
INFO - 2025-10-29 12:35:18 --> Helper loaded: url_helper
INFO - 2025-10-29 12:35:18 --> Database Driver Class Initialized
INFO - 2025-10-29 12:35:18 --> Controller Class Initialized
INFO - 2025-10-29 12:35:18 --> Model "Student_model" initialized
INFO - 2025-10-29 12:35:18 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:35:18 --> Model "Payment_model" initialized
INFO - 2025-10-29 12:35:18 --> Helper loaded: form_helper
INFO - 2025-10-29 12:35:18 --> Form Validation Class Initialized
DEBUG - 2025-10-29 12:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 12:35:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 12:35:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 12:35:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 12:35:18 --> Final output sent to browser
DEBUG - 2025-10-29 12:35:18 --> Total execution time: 0.0828
INFO - 2025-10-29 12:35:20 --> Config Class Initialized
INFO - 2025-10-29 12:35:20 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:35:20 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:35:20 --> Utf8 Class Initialized
INFO - 2025-10-29 12:35:20 --> URI Class Initialized
INFO - 2025-10-29 12:35:20 --> Router Class Initialized
INFO - 2025-10-29 12:35:20 --> Output Class Initialized
INFO - 2025-10-29 12:35:20 --> Security Class Initialized
DEBUG - 2025-10-29 12:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:35:20 --> Input Class Initialized
INFO - 2025-10-29 12:35:20 --> Language Class Initialized
INFO - 2025-10-29 12:35:20 --> Loader Class Initialized
INFO - 2025-10-29 12:35:20 --> Helper loaded: url_helper
INFO - 2025-10-29 12:35:20 --> Database Driver Class Initialized
INFO - 2025-10-29 12:35:20 --> Controller Class Initialized
INFO - 2025-10-29 12:35:20 --> Model "Student_model" initialized
INFO - 2025-10-29 12:35:20 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:35:20 --> Model "Payment_model" initialized
INFO - 2025-10-29 12:35:20 --> Helper loaded: form_helper
INFO - 2025-10-29 12:35:20 --> Form Validation Class Initialized
DEBUG - 2025-10-29 12:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 12:35:20 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 12:35:20 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/edit.php
INFO - 2025-10-29 12:35:20 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 12:35:20 --> Final output sent to browser
DEBUG - 2025-10-29 12:35:20 --> Total execution time: 0.1285
INFO - 2025-10-29 12:35:25 --> Config Class Initialized
INFO - 2025-10-29 12:35:25 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:35:25 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:35:25 --> Utf8 Class Initialized
INFO - 2025-10-29 12:35:25 --> URI Class Initialized
INFO - 2025-10-29 12:35:25 --> Router Class Initialized
INFO - 2025-10-29 12:35:25 --> Output Class Initialized
INFO - 2025-10-29 12:35:25 --> Security Class Initialized
DEBUG - 2025-10-29 12:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:35:25 --> Input Class Initialized
INFO - 2025-10-29 12:35:25 --> Language Class Initialized
INFO - 2025-10-29 12:35:25 --> Loader Class Initialized
INFO - 2025-10-29 12:35:25 --> Helper loaded: url_helper
INFO - 2025-10-29 12:35:25 --> Database Driver Class Initialized
INFO - 2025-10-29 12:35:25 --> Controller Class Initialized
INFO - 2025-10-29 12:35:25 --> Model "Student_model" initialized
INFO - 2025-10-29 12:35:25 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:35:25 --> Model "Payment_model" initialized
INFO - 2025-10-29 12:35:25 --> Helper loaded: form_helper
INFO - 2025-10-29 12:35:25 --> Form Validation Class Initialized
DEBUG - 2025-10-29 12:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 12:35:25 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 12:35:25 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 12:35:25 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 12:35:25 --> Final output sent to browser
DEBUG - 2025-10-29 12:35:25 --> Total execution time: 0.1207
INFO - 2025-10-29 12:35:27 --> Config Class Initialized
INFO - 2025-10-29 12:35:27 --> Hooks Class Initialized
DEBUG - 2025-10-29 12:35:27 --> UTF-8 Support Enabled
INFO - 2025-10-29 12:35:27 --> Utf8 Class Initialized
INFO - 2025-10-29 12:35:27 --> URI Class Initialized
INFO - 2025-10-29 12:35:27 --> Router Class Initialized
INFO - 2025-10-29 12:35:27 --> Output Class Initialized
INFO - 2025-10-29 12:35:27 --> Security Class Initialized
DEBUG - 2025-10-29 12:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 12:35:27 --> Input Class Initialized
INFO - 2025-10-29 12:35:27 --> Language Class Initialized
INFO - 2025-10-29 12:35:27 --> Loader Class Initialized
INFO - 2025-10-29 12:35:27 --> Helper loaded: url_helper
INFO - 2025-10-29 12:35:27 --> Database Driver Class Initialized
INFO - 2025-10-29 12:35:27 --> Controller Class Initialized
INFO - 2025-10-29 12:35:27 --> Model "Student_model" initialized
INFO - 2025-10-29 12:35:27 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 12:35:27 --> Model "Payment_model" initialized
INFO - 2025-10-29 12:35:27 --> Helper loaded: form_helper
INFO - 2025-10-29 12:35:27 --> Form Validation Class Initialized
DEBUG - 2025-10-29 12:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 12:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 12:35:27 --> Final output sent to browser
DEBUG - 2025-10-29 12:35:27 --> Total execution time: 0.0873
INFO - 2025-10-29 13:00:19 --> Config Class Initialized
INFO - 2025-10-29 13:00:19 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:00:19 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:00:19 --> Utf8 Class Initialized
INFO - 2025-10-29 13:00:19 --> URI Class Initialized
INFO - 2025-10-29 13:00:19 --> Router Class Initialized
INFO - 2025-10-29 13:00:19 --> Output Class Initialized
INFO - 2025-10-29 13:00:19 --> Security Class Initialized
DEBUG - 2025-10-29 13:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:00:19 --> Input Class Initialized
INFO - 2025-10-29 13:00:19 --> Language Class Initialized
INFO - 2025-10-29 13:00:19 --> Loader Class Initialized
INFO - 2025-10-29 13:00:19 --> Helper loaded: url_helper
INFO - 2025-10-29 13:00:19 --> Database Driver Class Initialized
INFO - 2025-10-29 13:00:19 --> Controller Class Initialized
INFO - 2025-10-29 13:00:19 --> Model "Student_model" initialized
INFO - 2025-10-29 13:00:19 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:00:19 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:00:19 --> Helper loaded: form_helper
INFO - 2025-10-29 13:00:19 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:00:19 --> Final output sent to browser
DEBUG - 2025-10-29 13:00:19 --> Total execution time: 0.0950
INFO - 2025-10-29 13:00:22 --> Config Class Initialized
INFO - 2025-10-29 13:00:22 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:00:22 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:00:22 --> Utf8 Class Initialized
INFO - 2025-10-29 13:00:22 --> URI Class Initialized
INFO - 2025-10-29 13:00:22 --> Router Class Initialized
INFO - 2025-10-29 13:00:22 --> Output Class Initialized
INFO - 2025-10-29 13:00:22 --> Security Class Initialized
DEBUG - 2025-10-29 13:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:00:22 --> Input Class Initialized
INFO - 2025-10-29 13:00:22 --> Language Class Initialized
INFO - 2025-10-29 13:00:22 --> Loader Class Initialized
INFO - 2025-10-29 13:00:22 --> Helper loaded: url_helper
INFO - 2025-10-29 13:00:22 --> Database Driver Class Initialized
INFO - 2025-10-29 13:00:22 --> Controller Class Initialized
INFO - 2025-10-29 13:00:22 --> Model "Student_model" initialized
INFO - 2025-10-29 13:00:22 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:00:22 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:00:22 --> Helper loaded: form_helper
INFO - 2025-10-29 13:00:22 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:00:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:00:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:00:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:00:22 --> Final output sent to browser
DEBUG - 2025-10-29 13:00:22 --> Total execution time: 0.0788
INFO - 2025-10-29 13:00:24 --> Config Class Initialized
INFO - 2025-10-29 13:00:24 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:00:24 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:00:24 --> Utf8 Class Initialized
INFO - 2025-10-29 13:00:24 --> URI Class Initialized
DEBUG - 2025-10-29 13:00:24 --> No URI present. Default controller set.
INFO - 2025-10-29 13:00:24 --> Router Class Initialized
INFO - 2025-10-29 13:00:24 --> Output Class Initialized
INFO - 2025-10-29 13:00:24 --> Security Class Initialized
DEBUG - 2025-10-29 13:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:00:24 --> Input Class Initialized
INFO - 2025-10-29 13:00:24 --> Language Class Initialized
INFO - 2025-10-29 13:00:24 --> Loader Class Initialized
INFO - 2025-10-29 13:00:24 --> Helper loaded: url_helper
INFO - 2025-10-29 13:00:24 --> Database Driver Class Initialized
INFO - 2025-10-29 13:00:24 --> Controller Class Initialized
INFO - 2025-10-29 13:00:24 --> Model "Student_model" initialized
INFO - 2025-10-29 13:00:24 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:00:24 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 13:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:00:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:00:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-29 13:00:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:00:24 --> Final output sent to browser
DEBUG - 2025-10-29 13:00:24 --> Total execution time: 0.1217
INFO - 2025-10-29 13:00:40 --> Config Class Initialized
INFO - 2025-10-29 13:00:40 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:00:40 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:00:40 --> Utf8 Class Initialized
INFO - 2025-10-29 13:00:40 --> URI Class Initialized
INFO - 2025-10-29 13:00:40 --> Router Class Initialized
INFO - 2025-10-29 13:00:40 --> Output Class Initialized
INFO - 2025-10-29 13:00:40 --> Security Class Initialized
DEBUG - 2025-10-29 13:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:00:40 --> Input Class Initialized
INFO - 2025-10-29 13:00:40 --> Language Class Initialized
ERROR - 2025-10-29 13:00:40 --> 404 Page Not Found: Api_testinghtml/index
INFO - 2025-10-29 13:00:52 --> Config Class Initialized
INFO - 2025-10-29 13:00:52 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:00:52 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:00:52 --> Utf8 Class Initialized
INFO - 2025-10-29 13:00:52 --> URI Class Initialized
INFO - 2025-10-29 13:00:52 --> Router Class Initialized
INFO - 2025-10-29 13:00:52 --> Output Class Initialized
INFO - 2025-10-29 13:00:52 --> Security Class Initialized
DEBUG - 2025-10-29 13:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:00:52 --> Input Class Initialized
INFO - 2025-10-29 13:00:52 --> Language Class Initialized
INFO - 2025-10-29 13:00:52 --> Loader Class Initialized
INFO - 2025-10-29 13:00:52 --> Helper loaded: url_helper
INFO - 2025-10-29 13:00:52 --> Database Driver Class Initialized
INFO - 2025-10-29 13:00:52 --> Controller Class Initialized
INFO - 2025-10-29 13:00:52 --> Model "Student_model" initialized
INFO - 2025-10-29 13:00:52 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:00:52 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:00:52 --> Helper loaded: form_helper
INFO - 2025-10-29 13:00:52 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:00:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:00:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:00:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:00:52 --> Final output sent to browser
DEBUG - 2025-10-29 13:00:52 --> Total execution time: 0.0965
INFO - 2025-10-29 13:00:57 --> Config Class Initialized
INFO - 2025-10-29 13:00:57 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:00:57 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:00:57 --> Utf8 Class Initialized
INFO - 2025-10-29 13:00:57 --> URI Class Initialized
INFO - 2025-10-29 13:00:57 --> Router Class Initialized
INFO - 2025-10-29 13:00:57 --> Output Class Initialized
INFO - 2025-10-29 13:00:57 --> Security Class Initialized
DEBUG - 2025-10-29 13:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:00:57 --> Input Class Initialized
INFO - 2025-10-29 13:00:57 --> Language Class Initialized
INFO - 2025-10-29 13:00:57 --> Loader Class Initialized
INFO - 2025-10-29 13:00:57 --> Helper loaded: url_helper
INFO - 2025-10-29 13:00:57 --> Database Driver Class Initialized
INFO - 2025-10-29 13:00:57 --> Controller Class Initialized
INFO - 2025-10-29 13:00:57 --> Model "Student_model" initialized
INFO - 2025-10-29 13:00:57 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:00:57 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:00:57 --> Helper loaded: form_helper
INFO - 2025-10-29 13:00:57 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:00:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:00:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:00:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:00:57 --> Final output sent to browser
DEBUG - 2025-10-29 13:00:57 --> Total execution time: 0.1082
INFO - 2025-10-29 13:01:02 --> Config Class Initialized
INFO - 2025-10-29 13:01:02 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:01:02 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:01:02 --> Utf8 Class Initialized
INFO - 2025-10-29 13:01:02 --> URI Class Initialized
INFO - 2025-10-29 13:01:02 --> Router Class Initialized
INFO - 2025-10-29 13:01:02 --> Output Class Initialized
INFO - 2025-10-29 13:01:02 --> Security Class Initialized
DEBUG - 2025-10-29 13:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:01:02 --> Input Class Initialized
INFO - 2025-10-29 13:01:02 --> Language Class Initialized
INFO - 2025-10-29 13:01:02 --> Loader Class Initialized
INFO - 2025-10-29 13:01:02 --> Helper loaded: url_helper
INFO - 2025-10-29 13:01:02 --> Database Driver Class Initialized
INFO - 2025-10-29 13:01:02 --> Controller Class Initialized
INFO - 2025-10-29 13:01:02 --> Model "Student_model" initialized
INFO - 2025-10-29 13:01:02 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:01:02 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:01:02 --> Helper loaded: form_helper
INFO - 2025-10-29 13:01:02 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:01:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:01:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:01:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:01:02 --> Final output sent to browser
DEBUG - 2025-10-29 13:01:02 --> Total execution time: 0.1223
INFO - 2025-10-29 13:01:04 --> Config Class Initialized
INFO - 2025-10-29 13:01:04 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:01:04 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:01:04 --> Utf8 Class Initialized
INFO - 2025-10-29 13:01:04 --> URI Class Initialized
INFO - 2025-10-29 13:01:04 --> Router Class Initialized
INFO - 2025-10-29 13:01:04 --> Output Class Initialized
INFO - 2025-10-29 13:01:04 --> Security Class Initialized
DEBUG - 2025-10-29 13:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:01:04 --> Input Class Initialized
INFO - 2025-10-29 13:01:04 --> Language Class Initialized
INFO - 2025-10-29 13:01:04 --> Loader Class Initialized
INFO - 2025-10-29 13:01:04 --> Helper loaded: url_helper
INFO - 2025-10-29 13:01:04 --> Database Driver Class Initialized
INFO - 2025-10-29 13:01:04 --> Controller Class Initialized
INFO - 2025-10-29 13:01:04 --> Model "Student_model" initialized
INFO - 2025-10-29 13:01:04 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:01:04 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:01:04 --> Helper loaded: form_helper
INFO - 2025-10-29 13:01:04 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:01:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:01:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:01:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:01:04 --> Final output sent to browser
DEBUG - 2025-10-29 13:01:04 --> Total execution time: 0.1256
INFO - 2025-10-29 13:01:05 --> Config Class Initialized
INFO - 2025-10-29 13:01:05 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:01:05 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:01:05 --> Utf8 Class Initialized
INFO - 2025-10-29 13:01:05 --> URI Class Initialized
INFO - 2025-10-29 13:01:05 --> Router Class Initialized
INFO - 2025-10-29 13:01:05 --> Output Class Initialized
INFO - 2025-10-29 13:01:05 --> Security Class Initialized
DEBUG - 2025-10-29 13:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:01:05 --> Input Class Initialized
INFO - 2025-10-29 13:01:05 --> Language Class Initialized
INFO - 2025-10-29 13:01:05 --> Loader Class Initialized
INFO - 2025-10-29 13:01:05 --> Helper loaded: url_helper
INFO - 2025-10-29 13:01:05 --> Database Driver Class Initialized
INFO - 2025-10-29 13:01:05 --> Controller Class Initialized
INFO - 2025-10-29 13:01:05 --> Model "Student_model" initialized
INFO - 2025-10-29 13:01:05 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:01:05 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:01:05 --> Helper loaded: form_helper
INFO - 2025-10-29 13:01:05 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:01:05 --> Final output sent to browser
DEBUG - 2025-10-29 13:01:05 --> Total execution time: 0.0803
INFO - 2025-10-29 13:01:57 --> Config Class Initialized
INFO - 2025-10-29 13:01:57 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:01:57 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:01:57 --> Utf8 Class Initialized
INFO - 2025-10-29 13:01:57 --> URI Class Initialized
INFO - 2025-10-29 13:01:57 --> Router Class Initialized
INFO - 2025-10-29 13:01:57 --> Output Class Initialized
INFO - 2025-10-29 13:01:57 --> Security Class Initialized
DEBUG - 2025-10-29 13:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:01:57 --> Input Class Initialized
INFO - 2025-10-29 13:01:57 --> Language Class Initialized
INFO - 2025-10-29 13:01:57 --> Loader Class Initialized
INFO - 2025-10-29 13:01:57 --> Helper loaded: url_helper
INFO - 2025-10-29 13:01:57 --> Database Driver Class Initialized
INFO - 2025-10-29 13:01:57 --> Controller Class Initialized
INFO - 2025-10-29 13:01:57 --> Model "Student_model" initialized
INFO - 2025-10-29 13:01:57 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:01:57 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:01:57 --> Helper loaded: form_helper
INFO - 2025-10-29 13:01:57 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:01:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:01:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:01:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:01:57 --> Final output sent to browser
DEBUG - 2025-10-29 13:01:57 --> Total execution time: 0.0783
INFO - 2025-10-29 13:01:58 --> Config Class Initialized
INFO - 2025-10-29 13:01:58 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:01:58 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:01:58 --> Utf8 Class Initialized
INFO - 2025-10-29 13:01:58 --> URI Class Initialized
INFO - 2025-10-29 13:01:58 --> Router Class Initialized
INFO - 2025-10-29 13:01:58 --> Output Class Initialized
INFO - 2025-10-29 13:01:58 --> Security Class Initialized
DEBUG - 2025-10-29 13:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:01:58 --> Input Class Initialized
INFO - 2025-10-29 13:01:58 --> Language Class Initialized
ERROR - 2025-10-29 13:01:58 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:02:49 --> Config Class Initialized
INFO - 2025-10-29 13:02:49 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:02:49 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:02:49 --> Utf8 Class Initialized
INFO - 2025-10-29 13:02:49 --> URI Class Initialized
INFO - 2025-10-29 13:02:49 --> Router Class Initialized
INFO - 2025-10-29 13:02:49 --> Output Class Initialized
INFO - 2025-10-29 13:02:49 --> Security Class Initialized
DEBUG - 2025-10-29 13:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:02:49 --> Input Class Initialized
INFO - 2025-10-29 13:02:49 --> Language Class Initialized
ERROR - 2025-10-29 13:02:49 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:13:11 --> Config Class Initialized
INFO - 2025-10-29 13:13:11 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:13:11 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:13:11 --> Utf8 Class Initialized
INFO - 2025-10-29 13:13:11 --> URI Class Initialized
INFO - 2025-10-29 13:13:11 --> Router Class Initialized
INFO - 2025-10-29 13:13:11 --> Output Class Initialized
INFO - 2025-10-29 13:13:11 --> Security Class Initialized
DEBUG - 2025-10-29 13:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:13:11 --> Input Class Initialized
INFO - 2025-10-29 13:13:11 --> Language Class Initialized
ERROR - 2025-10-29 13:13:11 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:13:13 --> Config Class Initialized
INFO - 2025-10-29 13:13:13 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:13:13 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:13:13 --> Utf8 Class Initialized
INFO - 2025-10-29 13:13:13 --> URI Class Initialized
INFO - 2025-10-29 13:13:13 --> Router Class Initialized
INFO - 2025-10-29 13:13:13 --> Output Class Initialized
INFO - 2025-10-29 13:13:13 --> Security Class Initialized
DEBUG - 2025-10-29 13:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:13:13 --> Input Class Initialized
INFO - 2025-10-29 13:13:13 --> Language Class Initialized
INFO - 2025-10-29 13:13:13 --> Loader Class Initialized
INFO - 2025-10-29 13:13:13 --> Helper loaded: url_helper
INFO - 2025-10-29 13:13:13 --> Database Driver Class Initialized
INFO - 2025-10-29 13:13:13 --> Controller Class Initialized
INFO - 2025-10-29 13:13:13 --> Model "Student_model" initialized
INFO - 2025-10-29 13:13:13 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:13:13 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:13:13 --> Helper loaded: form_helper
INFO - 2025-10-29 13:13:13 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:13:13 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:13:13 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:13:13 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:13:13 --> Final output sent to browser
DEBUG - 2025-10-29 13:13:13 --> Total execution time: 0.1140
INFO - 2025-10-29 13:13:15 --> Config Class Initialized
INFO - 2025-10-29 13:13:15 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:13:15 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:13:15 --> Utf8 Class Initialized
INFO - 2025-10-29 13:13:15 --> URI Class Initialized
INFO - 2025-10-29 13:13:15 --> Router Class Initialized
INFO - 2025-10-29 13:13:15 --> Output Class Initialized
INFO - 2025-10-29 13:13:15 --> Security Class Initialized
DEBUG - 2025-10-29 13:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:13:15 --> Input Class Initialized
INFO - 2025-10-29 13:13:15 --> Language Class Initialized
ERROR - 2025-10-29 13:13:15 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:13:22 --> Config Class Initialized
INFO - 2025-10-29 13:13:22 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:13:22 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:13:22 --> Utf8 Class Initialized
INFO - 2025-10-29 13:13:22 --> URI Class Initialized
INFO - 2025-10-29 13:13:22 --> Router Class Initialized
INFO - 2025-10-29 13:13:22 --> Output Class Initialized
INFO - 2025-10-29 13:13:22 --> Security Class Initialized
DEBUG - 2025-10-29 13:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:13:22 --> Input Class Initialized
INFO - 2025-10-29 13:13:22 --> Language Class Initialized
INFO - 2025-10-29 13:13:22 --> Loader Class Initialized
INFO - 2025-10-29 13:13:22 --> Helper loaded: url_helper
INFO - 2025-10-29 13:13:22 --> Database Driver Class Initialized
INFO - 2025-10-29 13:13:22 --> Controller Class Initialized
INFO - 2025-10-29 13:13:22 --> Model "Student_model" initialized
INFO - 2025-10-29 13:13:22 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:13:22 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:13:22 --> Helper loaded: form_helper
INFO - 2025-10-29 13:13:22 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:13:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:13:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:13:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:13:22 --> Final output sent to browser
DEBUG - 2025-10-29 13:13:22 --> Total execution time: 0.1379
INFO - 2025-10-29 13:13:24 --> Config Class Initialized
INFO - 2025-10-29 13:13:24 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:13:24 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:13:24 --> Utf8 Class Initialized
INFO - 2025-10-29 13:13:24 --> URI Class Initialized
INFO - 2025-10-29 13:13:24 --> Router Class Initialized
INFO - 2025-10-29 13:13:24 --> Output Class Initialized
INFO - 2025-10-29 13:13:24 --> Security Class Initialized
DEBUG - 2025-10-29 13:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:13:24 --> Input Class Initialized
INFO - 2025-10-29 13:13:24 --> Language Class Initialized
INFO - 2025-10-29 13:13:24 --> Loader Class Initialized
INFO - 2025-10-29 13:13:24 --> Helper loaded: url_helper
INFO - 2025-10-29 13:13:24 --> Database Driver Class Initialized
INFO - 2025-10-29 13:13:24 --> Controller Class Initialized
INFO - 2025-10-29 13:13:24 --> Model "Student_model" initialized
INFO - 2025-10-29 13:13:24 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:13:24 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:13:24 --> Helper loaded: form_helper
INFO - 2025-10-29 13:13:24 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:13:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:13:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/edit.php
INFO - 2025-10-29 13:13:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:13:24 --> Final output sent to browser
DEBUG - 2025-10-29 13:13:24 --> Total execution time: 0.1074
INFO - 2025-10-29 13:13:27 --> Config Class Initialized
INFO - 2025-10-29 13:13:27 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:13:27 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:13:27 --> Utf8 Class Initialized
INFO - 2025-10-29 13:13:27 --> URI Class Initialized
INFO - 2025-10-29 13:13:27 --> Router Class Initialized
INFO - 2025-10-29 13:13:28 --> Output Class Initialized
INFO - 2025-10-29 13:13:28 --> Security Class Initialized
DEBUG - 2025-10-29 13:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:13:28 --> Input Class Initialized
INFO - 2025-10-29 13:13:28 --> Language Class Initialized
INFO - 2025-10-29 13:13:28 --> Loader Class Initialized
INFO - 2025-10-29 13:13:28 --> Helper loaded: url_helper
INFO - 2025-10-29 13:13:28 --> Database Driver Class Initialized
INFO - 2025-10-29 13:13:28 --> Controller Class Initialized
INFO - 2025-10-29 13:13:28 --> Model "Student_model" initialized
INFO - 2025-10-29 13:13:28 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:13:28 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:13:28 --> Helper loaded: form_helper
INFO - 2025-10-29 13:13:28 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:13:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:13:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:13:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:13:28 --> Final output sent to browser
DEBUG - 2025-10-29 13:13:28 --> Total execution time: 0.0985
INFO - 2025-10-29 13:13:29 --> Config Class Initialized
INFO - 2025-10-29 13:13:29 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:13:29 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:13:29 --> Utf8 Class Initialized
INFO - 2025-10-29 13:13:29 --> URI Class Initialized
INFO - 2025-10-29 13:13:29 --> Router Class Initialized
INFO - 2025-10-29 13:13:29 --> Output Class Initialized
INFO - 2025-10-29 13:13:29 --> Security Class Initialized
DEBUG - 2025-10-29 13:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:13:29 --> Input Class Initialized
INFO - 2025-10-29 13:13:29 --> Language Class Initialized
ERROR - 2025-10-29 13:13:29 --> 404 Page Not Found: Student-fees/search_student
INFO - 2025-10-29 13:13:30 --> Config Class Initialized
INFO - 2025-10-29 13:13:30 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:13:30 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:13:30 --> Utf8 Class Initialized
INFO - 2025-10-29 13:13:30 --> URI Class Initialized
INFO - 2025-10-29 13:13:30 --> Router Class Initialized
INFO - 2025-10-29 13:13:30 --> Output Class Initialized
INFO - 2025-10-29 13:13:30 --> Security Class Initialized
DEBUG - 2025-10-29 13:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:13:30 --> Input Class Initialized
INFO - 2025-10-29 13:13:30 --> Language Class Initialized
ERROR - 2025-10-29 13:13:30 --> 404 Page Not Found: Student-fees/search_student
INFO - 2025-10-29 13:13:32 --> Config Class Initialized
INFO - 2025-10-29 13:13:32 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:13:32 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:13:32 --> Utf8 Class Initialized
INFO - 2025-10-29 13:13:32 --> URI Class Initialized
INFO - 2025-10-29 13:13:32 --> Router Class Initialized
INFO - 2025-10-29 13:13:32 --> Output Class Initialized
INFO - 2025-10-29 13:13:32 --> Security Class Initialized
DEBUG - 2025-10-29 13:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:13:32 --> Input Class Initialized
INFO - 2025-10-29 13:13:32 --> Language Class Initialized
ERROR - 2025-10-29 13:13:32 --> 404 Page Not Found: Student-fees/search_student
INFO - 2025-10-29 13:13:34 --> Config Class Initialized
INFO - 2025-10-29 13:13:34 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:13:34 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:13:34 --> Utf8 Class Initialized
INFO - 2025-10-29 13:13:34 --> URI Class Initialized
INFO - 2025-10-29 13:13:34 --> Router Class Initialized
INFO - 2025-10-29 13:13:34 --> Output Class Initialized
INFO - 2025-10-29 13:13:34 --> Security Class Initialized
DEBUG - 2025-10-29 13:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:13:34 --> Input Class Initialized
INFO - 2025-10-29 13:13:34 --> Language Class Initialized
ERROR - 2025-10-29 13:13:34 --> 404 Page Not Found: Student-fees/search_student
INFO - 2025-10-29 13:13:34 --> Config Class Initialized
INFO - 2025-10-29 13:13:34 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:13:34 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:13:34 --> Utf8 Class Initialized
INFO - 2025-10-29 13:13:34 --> URI Class Initialized
INFO - 2025-10-29 13:13:34 --> Router Class Initialized
INFO - 2025-10-29 13:13:34 --> Output Class Initialized
INFO - 2025-10-29 13:13:34 --> Security Class Initialized
DEBUG - 2025-10-29 13:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:13:34 --> Input Class Initialized
INFO - 2025-10-29 13:13:34 --> Language Class Initialized
ERROR - 2025-10-29 13:13:34 --> 404 Page Not Found: Student-fees/search_student
INFO - 2025-10-29 13:13:35 --> Config Class Initialized
INFO - 2025-10-29 13:13:35 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:13:35 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:13:35 --> Utf8 Class Initialized
INFO - 2025-10-29 13:13:35 --> URI Class Initialized
INFO - 2025-10-29 13:13:35 --> Router Class Initialized
INFO - 2025-10-29 13:13:35 --> Output Class Initialized
INFO - 2025-10-29 13:13:35 --> Security Class Initialized
DEBUG - 2025-10-29 13:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:13:35 --> Input Class Initialized
INFO - 2025-10-29 13:13:35 --> Language Class Initialized
ERROR - 2025-10-29 13:13:35 --> 404 Page Not Found: Student-fees/search_student
INFO - 2025-10-29 13:13:35 --> Config Class Initialized
INFO - 2025-10-29 13:13:35 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:13:35 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:13:35 --> Utf8 Class Initialized
INFO - 2025-10-29 13:13:35 --> URI Class Initialized
INFO - 2025-10-29 13:13:35 --> Router Class Initialized
INFO - 2025-10-29 13:13:35 --> Output Class Initialized
INFO - 2025-10-29 13:13:35 --> Security Class Initialized
DEBUG - 2025-10-29 13:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:13:35 --> Input Class Initialized
INFO - 2025-10-29 13:13:35 --> Language Class Initialized
ERROR - 2025-10-29 13:13:35 --> 404 Page Not Found: Student-fees/search_student
INFO - 2025-10-29 13:13:36 --> Config Class Initialized
INFO - 2025-10-29 13:13:36 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:13:36 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:13:36 --> Utf8 Class Initialized
INFO - 2025-10-29 13:13:36 --> URI Class Initialized
INFO - 2025-10-29 13:13:36 --> Router Class Initialized
INFO - 2025-10-29 13:13:36 --> Output Class Initialized
INFO - 2025-10-29 13:13:36 --> Security Class Initialized
DEBUG - 2025-10-29 13:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:13:36 --> Input Class Initialized
INFO - 2025-10-29 13:13:36 --> Language Class Initialized
ERROR - 2025-10-29 13:13:36 --> 404 Page Not Found: Student-fees/search_student
INFO - 2025-10-29 13:13:37 --> Config Class Initialized
INFO - 2025-10-29 13:13:37 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:13:37 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:13:37 --> Utf8 Class Initialized
INFO - 2025-10-29 13:13:37 --> URI Class Initialized
INFO - 2025-10-29 13:13:37 --> Router Class Initialized
INFO - 2025-10-29 13:13:37 --> Output Class Initialized
INFO - 2025-10-29 13:13:37 --> Security Class Initialized
DEBUG - 2025-10-29 13:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:13:37 --> Input Class Initialized
INFO - 2025-10-29 13:13:37 --> Language Class Initialized
ERROR - 2025-10-29 13:13:37 --> 404 Page Not Found: Student-fees/search_student
INFO - 2025-10-29 13:13:38 --> Config Class Initialized
INFO - 2025-10-29 13:13:38 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:13:38 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:13:38 --> Utf8 Class Initialized
INFO - 2025-10-29 13:13:38 --> URI Class Initialized
INFO - 2025-10-29 13:13:38 --> Router Class Initialized
INFO - 2025-10-29 13:13:38 --> Output Class Initialized
INFO - 2025-10-29 13:13:38 --> Security Class Initialized
DEBUG - 2025-10-29 13:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:13:38 --> Input Class Initialized
INFO - 2025-10-29 13:13:38 --> Language Class Initialized
ERROR - 2025-10-29 13:13:38 --> 404 Page Not Found: Student-fees/search_student
INFO - 2025-10-29 13:13:52 --> Config Class Initialized
INFO - 2025-10-29 13:13:52 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:13:52 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:13:52 --> Utf8 Class Initialized
INFO - 2025-10-29 13:13:52 --> URI Class Initialized
INFO - 2025-10-29 13:13:52 --> Router Class Initialized
INFO - 2025-10-29 13:13:52 --> Output Class Initialized
INFO - 2025-10-29 13:13:52 --> Security Class Initialized
DEBUG - 2025-10-29 13:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:13:52 --> Input Class Initialized
INFO - 2025-10-29 13:13:52 --> Language Class Initialized
INFO - 2025-10-29 13:13:52 --> Loader Class Initialized
INFO - 2025-10-29 13:13:52 --> Helper loaded: url_helper
INFO - 2025-10-29 13:13:52 --> Database Driver Class Initialized
INFO - 2025-10-29 13:13:52 --> Controller Class Initialized
INFO - 2025-10-29 13:13:52 --> Model "Student_model" initialized
INFO - 2025-10-29 13:13:52 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:13:52 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:13:52 --> Helper loaded: form_helper
INFO - 2025-10-29 13:13:52 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:13:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:13:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:13:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:13:52 --> Final output sent to browser
DEBUG - 2025-10-29 13:13:52 --> Total execution time: 0.0958
INFO - 2025-10-29 13:14:15 --> Config Class Initialized
INFO - 2025-10-29 13:14:15 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:14:15 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:14:15 --> Utf8 Class Initialized
INFO - 2025-10-29 13:14:15 --> URI Class Initialized
INFO - 2025-10-29 13:14:15 --> Router Class Initialized
INFO - 2025-10-29 13:14:15 --> Output Class Initialized
INFO - 2025-10-29 13:14:15 --> Security Class Initialized
DEBUG - 2025-10-29 13:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:14:15 --> Input Class Initialized
INFO - 2025-10-29 13:14:15 --> Language Class Initialized
INFO - 2025-10-29 13:14:15 --> Loader Class Initialized
INFO - 2025-10-29 13:14:15 --> Helper loaded: url_helper
INFO - 2025-10-29 13:14:15 --> Database Driver Class Initialized
INFO - 2025-10-29 13:14:15 --> Controller Class Initialized
INFO - 2025-10-29 13:14:15 --> Model "Student_model" initialized
INFO - 2025-10-29 13:14:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:14:15 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:14:15 --> Helper loaded: form_helper
INFO - 2025-10-29 13:14:15 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:14:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:14:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:14:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:14:15 --> Final output sent to browser
DEBUG - 2025-10-29 13:14:15 --> Total execution time: 0.1352
INFO - 2025-10-29 13:14:31 --> Config Class Initialized
INFO - 2025-10-29 13:14:31 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:14:31 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:14:31 --> Utf8 Class Initialized
INFO - 2025-10-29 13:14:31 --> URI Class Initialized
INFO - 2025-10-29 13:14:31 --> Router Class Initialized
INFO - 2025-10-29 13:14:31 --> Output Class Initialized
INFO - 2025-10-29 13:14:31 --> Security Class Initialized
DEBUG - 2025-10-29 13:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:14:31 --> Input Class Initialized
INFO - 2025-10-29 13:14:31 --> Language Class Initialized
INFO - 2025-10-29 13:14:31 --> Loader Class Initialized
INFO - 2025-10-29 13:14:31 --> Helper loaded: url_helper
INFO - 2025-10-29 13:14:31 --> Database Driver Class Initialized
INFO - 2025-10-29 13:14:31 --> Controller Class Initialized
INFO - 2025-10-29 13:14:31 --> Model "Student_model" initialized
INFO - 2025-10-29 13:14:31 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:14:31 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:14:31 --> Helper loaded: form_helper
INFO - 2025-10-29 13:14:31 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:14:31 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:14:31 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:14:31 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:14:31 --> Final output sent to browser
DEBUG - 2025-10-29 13:14:31 --> Total execution time: 0.1198
INFO - 2025-10-29 13:14:32 --> Config Class Initialized
INFO - 2025-10-29 13:14:32 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:14:32 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:14:32 --> Utf8 Class Initialized
INFO - 2025-10-29 13:14:32 --> URI Class Initialized
INFO - 2025-10-29 13:14:32 --> Router Class Initialized
INFO - 2025-10-29 13:14:32 --> Output Class Initialized
INFO - 2025-10-29 13:14:32 --> Security Class Initialized
DEBUG - 2025-10-29 13:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:14:32 --> Input Class Initialized
INFO - 2025-10-29 13:14:32 --> Language Class Initialized
INFO - 2025-10-29 13:14:32 --> Loader Class Initialized
INFO - 2025-10-29 13:14:32 --> Helper loaded: url_helper
INFO - 2025-10-29 13:14:32 --> Database Driver Class Initialized
INFO - 2025-10-29 13:14:32 --> Controller Class Initialized
INFO - 2025-10-29 13:14:32 --> Model "Student_model" initialized
INFO - 2025-10-29 13:14:32 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:14:32 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:14:32 --> Helper loaded: form_helper
INFO - 2025-10-29 13:14:32 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:14:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:14:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:14:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:14:32 --> Final output sent to browser
DEBUG - 2025-10-29 13:14:32 --> Total execution time: 0.1259
INFO - 2025-10-29 13:14:34 --> Config Class Initialized
INFO - 2025-10-29 13:14:34 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:14:34 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:14:34 --> Utf8 Class Initialized
INFO - 2025-10-29 13:14:34 --> URI Class Initialized
INFO - 2025-10-29 13:14:34 --> Router Class Initialized
INFO - 2025-10-29 13:14:34 --> Output Class Initialized
INFO - 2025-10-29 13:14:34 --> Security Class Initialized
DEBUG - 2025-10-29 13:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:14:34 --> Input Class Initialized
INFO - 2025-10-29 13:14:34 --> Language Class Initialized
INFO - 2025-10-29 13:14:34 --> Loader Class Initialized
INFO - 2025-10-29 13:14:34 --> Helper loaded: url_helper
INFO - 2025-10-29 13:14:34 --> Database Driver Class Initialized
INFO - 2025-10-29 13:14:34 --> Controller Class Initialized
INFO - 2025-10-29 13:14:34 --> Model "Student_model" initialized
INFO - 2025-10-29 13:14:34 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:14:34 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:14:34 --> Helper loaded: form_helper
INFO - 2025-10-29 13:14:34 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:14:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:14:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:14:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:14:34 --> Final output sent to browser
DEBUG - 2025-10-29 13:14:34 --> Total execution time: 0.1459
INFO - 2025-10-29 13:14:35 --> Config Class Initialized
INFO - 2025-10-29 13:14:35 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:14:35 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:14:35 --> Utf8 Class Initialized
INFO - 2025-10-29 13:14:35 --> URI Class Initialized
INFO - 2025-10-29 13:14:35 --> Router Class Initialized
INFO - 2025-10-29 13:14:35 --> Output Class Initialized
INFO - 2025-10-29 13:14:35 --> Security Class Initialized
DEBUG - 2025-10-29 13:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:14:35 --> Input Class Initialized
INFO - 2025-10-29 13:14:35 --> Language Class Initialized
INFO - 2025-10-29 13:14:35 --> Loader Class Initialized
INFO - 2025-10-29 13:14:35 --> Helper loaded: url_helper
INFO - 2025-10-29 13:14:35 --> Database Driver Class Initialized
INFO - 2025-10-29 13:14:35 --> Controller Class Initialized
INFO - 2025-10-29 13:14:35 --> Model "Student_model" initialized
INFO - 2025-10-29 13:14:35 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:14:35 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:14:35 --> Helper loaded: form_helper
INFO - 2025-10-29 13:14:35 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:14:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:14:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:14:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:14:35 --> Final output sent to browser
DEBUG - 2025-10-29 13:14:35 --> Total execution time: 0.1112
INFO - 2025-10-29 13:14:37 --> Config Class Initialized
INFO - 2025-10-29 13:14:37 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:14:37 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:14:37 --> Utf8 Class Initialized
INFO - 2025-10-29 13:14:37 --> URI Class Initialized
DEBUG - 2025-10-29 13:14:37 --> No URI present. Default controller set.
INFO - 2025-10-29 13:14:37 --> Router Class Initialized
INFO - 2025-10-29 13:14:37 --> Output Class Initialized
INFO - 2025-10-29 13:14:37 --> Security Class Initialized
DEBUG - 2025-10-29 13:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:14:37 --> Input Class Initialized
INFO - 2025-10-29 13:14:37 --> Language Class Initialized
INFO - 2025-10-29 13:14:37 --> Loader Class Initialized
INFO - 2025-10-29 13:14:37 --> Helper loaded: url_helper
INFO - 2025-10-29 13:14:37 --> Database Driver Class Initialized
INFO - 2025-10-29 13:14:37 --> Controller Class Initialized
INFO - 2025-10-29 13:14:37 --> Model "Student_model" initialized
INFO - 2025-10-29 13:14:37 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:14:37 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 13:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:14:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:14:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-29 13:14:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:14:37 --> Final output sent to browser
DEBUG - 2025-10-29 13:14:37 --> Total execution time: 0.1162
INFO - 2025-10-29 13:14:39 --> Config Class Initialized
INFO - 2025-10-29 13:14:39 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:14:39 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:14:39 --> Utf8 Class Initialized
INFO - 2025-10-29 13:14:39 --> URI Class Initialized
INFO - 2025-10-29 13:14:39 --> Router Class Initialized
INFO - 2025-10-29 13:14:39 --> Output Class Initialized
INFO - 2025-10-29 13:14:39 --> Security Class Initialized
DEBUG - 2025-10-29 13:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:14:39 --> Input Class Initialized
INFO - 2025-10-29 13:14:39 --> Language Class Initialized
INFO - 2025-10-29 13:14:39 --> Loader Class Initialized
INFO - 2025-10-29 13:14:39 --> Helper loaded: url_helper
INFO - 2025-10-29 13:14:39 --> Database Driver Class Initialized
INFO - 2025-10-29 13:14:39 --> Controller Class Initialized
INFO - 2025-10-29 13:14:39 --> Model "Student_model" initialized
INFO - 2025-10-29 13:14:39 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:14:39 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:14:39 --> Helper loaded: form_helper
INFO - 2025-10-29 13:14:39 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:14:39 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:14:39 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:14:39 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:14:39 --> Final output sent to browser
DEBUG - 2025-10-29 13:14:39 --> Total execution time: 0.1358
INFO - 2025-10-29 13:14:41 --> Config Class Initialized
INFO - 2025-10-29 13:14:41 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:14:41 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:14:41 --> Utf8 Class Initialized
INFO - 2025-10-29 13:14:41 --> URI Class Initialized
INFO - 2025-10-29 13:14:41 --> Router Class Initialized
INFO - 2025-10-29 13:14:41 --> Output Class Initialized
INFO - 2025-10-29 13:14:41 --> Security Class Initialized
DEBUG - 2025-10-29 13:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:14:41 --> Input Class Initialized
INFO - 2025-10-29 13:14:41 --> Language Class Initialized
ERROR - 2025-10-29 13:14:41 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:14:44 --> Config Class Initialized
INFO - 2025-10-29 13:14:44 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:14:44 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:14:44 --> Utf8 Class Initialized
INFO - 2025-10-29 13:14:44 --> URI Class Initialized
INFO - 2025-10-29 13:14:44 --> Router Class Initialized
INFO - 2025-10-29 13:14:44 --> Output Class Initialized
INFO - 2025-10-29 13:14:44 --> Security Class Initialized
DEBUG - 2025-10-29 13:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:14:44 --> Input Class Initialized
INFO - 2025-10-29 13:14:44 --> Language Class Initialized
INFO - 2025-10-29 13:14:44 --> Loader Class Initialized
INFO - 2025-10-29 13:14:44 --> Helper loaded: url_helper
INFO - 2025-10-29 13:14:44 --> Database Driver Class Initialized
INFO - 2025-10-29 13:14:44 --> Controller Class Initialized
INFO - 2025-10-29 13:14:44 --> Model "Student_model" initialized
INFO - 2025-10-29 13:14:44 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:14:44 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:14:44 --> Helper loaded: form_helper
INFO - 2025-10-29 13:14:44 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:14:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:14:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/edit.php
INFO - 2025-10-29 13:14:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:14:44 --> Final output sent to browser
DEBUG - 2025-10-29 13:14:44 --> Total execution time: 0.0862
INFO - 2025-10-29 13:14:46 --> Config Class Initialized
INFO - 2025-10-29 13:14:46 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:14:46 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:14:46 --> Utf8 Class Initialized
INFO - 2025-10-29 13:14:46 --> URI Class Initialized
INFO - 2025-10-29 13:14:46 --> Router Class Initialized
INFO - 2025-10-29 13:14:46 --> Output Class Initialized
INFO - 2025-10-29 13:14:46 --> Security Class Initialized
DEBUG - 2025-10-29 13:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:14:46 --> Input Class Initialized
INFO - 2025-10-29 13:14:46 --> Language Class Initialized
INFO - 2025-10-29 13:14:46 --> Loader Class Initialized
INFO - 2025-10-29 13:14:46 --> Helper loaded: url_helper
INFO - 2025-10-29 13:14:46 --> Database Driver Class Initialized
INFO - 2025-10-29 13:14:46 --> Controller Class Initialized
INFO - 2025-10-29 13:14:46 --> Model "Student_model" initialized
INFO - 2025-10-29 13:14:46 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:14:46 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:14:46 --> Helper loaded: form_helper
INFO - 2025-10-29 13:14:46 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:14:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:14:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:14:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:14:47 --> Final output sent to browser
DEBUG - 2025-10-29 13:14:47 --> Total execution time: 0.1361
INFO - 2025-10-29 13:15:00 --> Config Class Initialized
INFO - 2025-10-29 13:15:00 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:15:00 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:15:00 --> Utf8 Class Initialized
INFO - 2025-10-29 13:15:00 --> URI Class Initialized
INFO - 2025-10-29 13:15:00 --> Router Class Initialized
INFO - 2025-10-29 13:15:00 --> Output Class Initialized
INFO - 2025-10-29 13:15:00 --> Security Class Initialized
DEBUG - 2025-10-29 13:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:15:00 --> Input Class Initialized
INFO - 2025-10-29 13:15:00 --> Language Class Initialized
INFO - 2025-10-29 13:15:01 --> Loader Class Initialized
INFO - 2025-10-29 13:15:01 --> Helper loaded: url_helper
INFO - 2025-10-29 13:15:01 --> Database Driver Class Initialized
INFO - 2025-10-29 13:15:01 --> Controller Class Initialized
INFO - 2025-10-29 13:15:01 --> Model "Student_model" initialized
INFO - 2025-10-29 13:15:01 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:15:01 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:15:01 --> Helper loaded: form_helper
INFO - 2025-10-29 13:15:01 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:15:01 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:15:01 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:15:01 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:15:01 --> Final output sent to browser
DEBUG - 2025-10-29 13:15:01 --> Total execution time: 0.0910
INFO - 2025-10-29 13:15:19 --> Config Class Initialized
INFO - 2025-10-29 13:15:19 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:15:19 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:15:19 --> Utf8 Class Initialized
INFO - 2025-10-29 13:15:19 --> URI Class Initialized
INFO - 2025-10-29 13:15:19 --> Router Class Initialized
INFO - 2025-10-29 13:15:19 --> Output Class Initialized
INFO - 2025-10-29 13:15:19 --> Security Class Initialized
DEBUG - 2025-10-29 13:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:15:19 --> Input Class Initialized
INFO - 2025-10-29 13:15:19 --> Language Class Initialized
INFO - 2025-10-29 13:15:19 --> Loader Class Initialized
INFO - 2025-10-29 13:15:19 --> Helper loaded: url_helper
INFO - 2025-10-29 13:15:19 --> Database Driver Class Initialized
INFO - 2025-10-29 13:15:19 --> Controller Class Initialized
INFO - 2025-10-29 13:15:19 --> Model "Student_model" initialized
INFO - 2025-10-29 13:15:19 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:15:19 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:15:19 --> Helper loaded: form_helper
INFO - 2025-10-29 13:15:19 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:15:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:15:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:15:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:15:19 --> Final output sent to browser
DEBUG - 2025-10-29 13:15:19 --> Total execution time: 0.1375
INFO - 2025-10-29 13:17:15 --> Config Class Initialized
INFO - 2025-10-29 13:17:15 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:17:15 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:17:15 --> Utf8 Class Initialized
INFO - 2025-10-29 13:17:15 --> URI Class Initialized
INFO - 2025-10-29 13:17:15 --> Router Class Initialized
INFO - 2025-10-29 13:17:15 --> Output Class Initialized
INFO - 2025-10-29 13:17:15 --> Security Class Initialized
DEBUG - 2025-10-29 13:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:17:15 --> Input Class Initialized
INFO - 2025-10-29 13:17:15 --> Language Class Initialized
INFO - 2025-10-29 13:17:15 --> Loader Class Initialized
INFO - 2025-10-29 13:17:15 --> Helper loaded: url_helper
INFO - 2025-10-29 13:17:15 --> Database Driver Class Initialized
INFO - 2025-10-29 13:17:15 --> Controller Class Initialized
INFO - 2025-10-29 13:17:15 --> Model "Student_model" initialized
INFO - 2025-10-29 13:17:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:17:15 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:17:15 --> Helper loaded: form_helper
INFO - 2025-10-29 13:17:15 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:17:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:17:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:17:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:17:15 --> Final output sent to browser
DEBUG - 2025-10-29 13:17:15 --> Total execution time: 0.1467
INFO - 2025-10-29 13:17:23 --> Config Class Initialized
INFO - 2025-10-29 13:17:23 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:17:23 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:17:23 --> Utf8 Class Initialized
INFO - 2025-10-29 13:17:23 --> URI Class Initialized
DEBUG - 2025-10-29 13:17:23 --> No URI present. Default controller set.
INFO - 2025-10-29 13:17:23 --> Router Class Initialized
INFO - 2025-10-29 13:17:23 --> Output Class Initialized
INFO - 2025-10-29 13:17:23 --> Security Class Initialized
DEBUG - 2025-10-29 13:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:17:23 --> Input Class Initialized
INFO - 2025-10-29 13:17:23 --> Language Class Initialized
INFO - 2025-10-29 13:17:23 --> Loader Class Initialized
INFO - 2025-10-29 13:17:23 --> Helper loaded: url_helper
INFO - 2025-10-29 13:17:23 --> Database Driver Class Initialized
INFO - 2025-10-29 13:17:23 --> Controller Class Initialized
INFO - 2025-10-29 13:17:23 --> Model "Student_model" initialized
INFO - 2025-10-29 13:17:23 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:17:23 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 13:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:17:23 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:17:23 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-29 13:17:23 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:17:23 --> Final output sent to browser
DEBUG - 2025-10-29 13:17:23 --> Total execution time: 0.1361
INFO - 2025-10-29 13:17:24 --> Config Class Initialized
INFO - 2025-10-29 13:17:24 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:17:24 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:17:24 --> Utf8 Class Initialized
INFO - 2025-10-29 13:17:24 --> URI Class Initialized
INFO - 2025-10-29 13:17:24 --> Router Class Initialized
INFO - 2025-10-29 13:17:24 --> Output Class Initialized
INFO - 2025-10-29 13:17:24 --> Security Class Initialized
DEBUG - 2025-10-29 13:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:17:24 --> Input Class Initialized
INFO - 2025-10-29 13:17:24 --> Language Class Initialized
INFO - 2025-10-29 13:17:24 --> Loader Class Initialized
INFO - 2025-10-29 13:17:24 --> Helper loaded: url_helper
INFO - 2025-10-29 13:17:24 --> Database Driver Class Initialized
INFO - 2025-10-29 13:17:24 --> Controller Class Initialized
INFO - 2025-10-29 13:17:24 --> Model "Student_model" initialized
INFO - 2025-10-29 13:17:24 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:17:24 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:17:24 --> Helper loaded: form_helper
INFO - 2025-10-29 13:17:24 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:17:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:17:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:17:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:17:24 --> Final output sent to browser
DEBUG - 2025-10-29 13:17:24 --> Total execution time: 0.1097
INFO - 2025-10-29 13:17:26 --> Config Class Initialized
INFO - 2025-10-29 13:17:26 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:17:26 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:17:26 --> Utf8 Class Initialized
INFO - 2025-10-29 13:17:27 --> URI Class Initialized
INFO - 2025-10-29 13:17:27 --> Router Class Initialized
INFO - 2025-10-29 13:17:27 --> Output Class Initialized
INFO - 2025-10-29 13:17:27 --> Security Class Initialized
DEBUG - 2025-10-29 13:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:17:27 --> Input Class Initialized
INFO - 2025-10-29 13:17:27 --> Language Class Initialized
INFO - 2025-10-29 13:17:27 --> Loader Class Initialized
INFO - 2025-10-29 13:17:27 --> Helper loaded: url_helper
INFO - 2025-10-29 13:17:27 --> Database Driver Class Initialized
INFO - 2025-10-29 13:17:27 --> Controller Class Initialized
INFO - 2025-10-29 13:17:27 --> Model "Student_model" initialized
INFO - 2025-10-29 13:17:27 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:17:27 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:17:27 --> Helper loaded: form_helper
INFO - 2025-10-29 13:17:27 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:17:27 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:17:27 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:17:27 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:17:27 --> Final output sent to browser
DEBUG - 2025-10-29 13:17:27 --> Total execution time: 0.1662
INFO - 2025-10-29 13:17:50 --> Config Class Initialized
INFO - 2025-10-29 13:17:50 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:17:50 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:17:50 --> Utf8 Class Initialized
INFO - 2025-10-29 13:17:50 --> URI Class Initialized
INFO - 2025-10-29 13:17:50 --> Router Class Initialized
INFO - 2025-10-29 13:17:50 --> Output Class Initialized
INFO - 2025-10-29 13:17:50 --> Security Class Initialized
DEBUG - 2025-10-29 13:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:17:50 --> Input Class Initialized
INFO - 2025-10-29 13:17:50 --> Language Class Initialized
INFO - 2025-10-29 13:17:50 --> Loader Class Initialized
INFO - 2025-10-29 13:17:50 --> Helper loaded: url_helper
INFO - 2025-10-29 13:17:50 --> Database Driver Class Initialized
INFO - 2025-10-29 13:17:50 --> Controller Class Initialized
INFO - 2025-10-29 13:17:50 --> Model "Student_model" initialized
INFO - 2025-10-29 13:17:50 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:17:50 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:17:50 --> Helper loaded: form_helper
INFO - 2025-10-29 13:17:50 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:17:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:17:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:17:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:17:50 --> Final output sent to browser
DEBUG - 2025-10-29 13:17:50 --> Total execution time: 0.1199
INFO - 2025-10-29 13:18:43 --> Config Class Initialized
INFO - 2025-10-29 13:18:43 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:18:43 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:18:43 --> Utf8 Class Initialized
INFO - 2025-10-29 13:18:43 --> URI Class Initialized
INFO - 2025-10-29 13:18:43 --> Router Class Initialized
INFO - 2025-10-29 13:18:43 --> Output Class Initialized
INFO - 2025-10-29 13:18:43 --> Security Class Initialized
DEBUG - 2025-10-29 13:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:18:43 --> Input Class Initialized
INFO - 2025-10-29 13:18:43 --> Language Class Initialized
INFO - 2025-10-29 13:18:43 --> Loader Class Initialized
INFO - 2025-10-29 13:18:43 --> Helper loaded: url_helper
INFO - 2025-10-29 13:18:43 --> Database Driver Class Initialized
INFO - 2025-10-29 13:18:43 --> Controller Class Initialized
INFO - 2025-10-29 13:18:43 --> Model "Student_model" initialized
INFO - 2025-10-29 13:18:43 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:18:43 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:18:43 --> Helper loaded: form_helper
INFO - 2025-10-29 13:18:43 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:18:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:18:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:18:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:18:43 --> Final output sent to browser
DEBUG - 2025-10-29 13:18:43 --> Total execution time: 0.1259
INFO - 2025-10-29 13:18:48 --> Config Class Initialized
INFO - 2025-10-29 13:18:48 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:18:48 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:18:48 --> Utf8 Class Initialized
INFO - 2025-10-29 13:18:48 --> URI Class Initialized
INFO - 2025-10-29 13:18:48 --> Router Class Initialized
INFO - 2025-10-29 13:18:48 --> Output Class Initialized
INFO - 2025-10-29 13:18:48 --> Security Class Initialized
DEBUG - 2025-10-29 13:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:18:48 --> Input Class Initialized
INFO - 2025-10-29 13:18:48 --> Language Class Initialized
INFO - 2025-10-29 13:18:48 --> Loader Class Initialized
INFO - 2025-10-29 13:18:48 --> Helper loaded: url_helper
INFO - 2025-10-29 13:18:48 --> Database Driver Class Initialized
INFO - 2025-10-29 13:18:48 --> Controller Class Initialized
INFO - 2025-10-29 13:18:48 --> Model "Student_model" initialized
INFO - 2025-10-29 13:18:48 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:18:48 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:18:48 --> Helper loaded: form_helper
INFO - 2025-10-29 13:18:48 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:18:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:18:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:18:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:18:48 --> Final output sent to browser
DEBUG - 2025-10-29 13:18:48 --> Total execution time: 0.1313
INFO - 2025-10-29 13:20:58 --> Config Class Initialized
INFO - 2025-10-29 13:20:58 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:20:58 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:20:58 --> Utf8 Class Initialized
INFO - 2025-10-29 13:20:58 --> URI Class Initialized
INFO - 2025-10-29 13:20:58 --> Router Class Initialized
INFO - 2025-10-29 13:20:58 --> Output Class Initialized
INFO - 2025-10-29 13:20:58 --> Security Class Initialized
DEBUG - 2025-10-29 13:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:20:58 --> Input Class Initialized
INFO - 2025-10-29 13:20:58 --> Language Class Initialized
ERROR - 2025-10-29 13:20:58 --> 404 Page Not Found: Api_testinghtml/index
INFO - 2025-10-29 13:21:00 --> Config Class Initialized
INFO - 2025-10-29 13:21:00 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:21:00 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:21:00 --> Utf8 Class Initialized
INFO - 2025-10-29 13:21:00 --> URI Class Initialized
INFO - 2025-10-29 13:21:00 --> Router Class Initialized
INFO - 2025-10-29 13:21:00 --> Output Class Initialized
INFO - 2025-10-29 13:21:00 --> Security Class Initialized
DEBUG - 2025-10-29 13:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:21:00 --> Input Class Initialized
INFO - 2025-10-29 13:21:00 --> Language Class Initialized
INFO - 2025-10-29 13:21:00 --> Loader Class Initialized
INFO - 2025-10-29 13:21:00 --> Helper loaded: url_helper
INFO - 2025-10-29 13:21:01 --> Database Driver Class Initialized
INFO - 2025-10-29 13:21:01 --> Controller Class Initialized
INFO - 2025-10-29 13:21:01 --> Model "Student_model" initialized
INFO - 2025-10-29 13:21:01 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:21:01 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:21:01 --> Helper loaded: form_helper
INFO - 2025-10-29 13:21:01 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:21:01 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:21:01 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:21:01 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:21:01 --> Final output sent to browser
DEBUG - 2025-10-29 13:21:01 --> Total execution time: 0.1599
INFO - 2025-10-29 13:21:02 --> Config Class Initialized
INFO - 2025-10-29 13:21:02 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:21:02 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:21:02 --> Utf8 Class Initialized
INFO - 2025-10-29 13:21:02 --> URI Class Initialized
INFO - 2025-10-29 13:21:02 --> Router Class Initialized
INFO - 2025-10-29 13:21:02 --> Output Class Initialized
INFO - 2025-10-29 13:21:02 --> Security Class Initialized
DEBUG - 2025-10-29 13:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:21:02 --> Input Class Initialized
INFO - 2025-10-29 13:21:02 --> Language Class Initialized
INFO - 2025-10-29 13:21:02 --> Loader Class Initialized
INFO - 2025-10-29 13:21:02 --> Helper loaded: url_helper
INFO - 2025-10-29 13:21:02 --> Database Driver Class Initialized
INFO - 2025-10-29 13:21:02 --> Controller Class Initialized
INFO - 2025-10-29 13:21:02 --> Model "Student_model" initialized
INFO - 2025-10-29 13:21:02 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:21:02 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:21:02 --> Helper loaded: form_helper
INFO - 2025-10-29 13:21:02 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:21:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:21:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:21:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:21:02 --> Final output sent to browser
DEBUG - 2025-10-29 13:21:02 --> Total execution time: 0.1245
INFO - 2025-10-29 13:26:33 --> Config Class Initialized
INFO - 2025-10-29 13:26:33 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:26:33 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:26:33 --> Utf8 Class Initialized
INFO - 2025-10-29 13:26:33 --> URI Class Initialized
INFO - 2025-10-29 13:26:33 --> Router Class Initialized
INFO - 2025-10-29 13:26:33 --> Output Class Initialized
INFO - 2025-10-29 13:26:33 --> Security Class Initialized
DEBUG - 2025-10-29 13:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:26:33 --> Input Class Initialized
INFO - 2025-10-29 13:26:33 --> Language Class Initialized
INFO - 2025-10-29 13:26:33 --> Loader Class Initialized
INFO - 2025-10-29 13:26:33 --> Helper loaded: url_helper
INFO - 2025-10-29 13:26:33 --> Database Driver Class Initialized
INFO - 2025-10-29 13:26:33 --> Controller Class Initialized
INFO - 2025-10-29 13:26:33 --> Model "Student_model" initialized
INFO - 2025-10-29 13:26:33 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:26:33 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:26:33 --> Helper loaded: form_helper
INFO - 2025-10-29 13:26:33 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:26:33 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:26:33 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:26:33 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:26:33 --> Final output sent to browser
DEBUG - 2025-10-29 13:26:33 --> Total execution time: 0.1072
INFO - 2025-10-29 13:26:33 --> Config Class Initialized
INFO - 2025-10-29 13:26:33 --> Config Class Initialized
INFO - 2025-10-29 13:26:33 --> Hooks Class Initialized
INFO - 2025-10-29 13:26:33 --> Hooks Class Initialized
INFO - 2025-10-29 13:26:33 --> Config Class Initialized
INFO - 2025-10-29 13:26:33 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:26:33 --> UTF-8 Support Enabled
DEBUG - 2025-10-29 13:26:33 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:26:33 --> Utf8 Class Initialized
INFO - 2025-10-29 13:26:33 --> Utf8 Class Initialized
INFO - 2025-10-29 13:26:33 --> URI Class Initialized
INFO - 2025-10-29 13:26:33 --> URI Class Initialized
DEBUG - 2025-10-29 13:26:33 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:26:33 --> Utf8 Class Initialized
INFO - 2025-10-29 13:26:33 --> Router Class Initialized
INFO - 2025-10-29 13:26:33 --> Router Class Initialized
INFO - 2025-10-29 13:26:33 --> URI Class Initialized
INFO - 2025-10-29 13:26:33 --> Output Class Initialized
INFO - 2025-10-29 13:26:33 --> Output Class Initialized
INFO - 2025-10-29 13:26:33 --> Router Class Initialized
INFO - 2025-10-29 13:26:33 --> Security Class Initialized
INFO - 2025-10-29 13:26:33 --> Security Class Initialized
INFO - 2025-10-29 13:26:33 --> Output Class Initialized
DEBUG - 2025-10-29 13:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-10-29 13:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:26:33 --> Input Class Initialized
INFO - 2025-10-29 13:26:33 --> Input Class Initialized
INFO - 2025-10-29 13:26:33 --> Language Class Initialized
INFO - 2025-10-29 13:26:33 --> Security Class Initialized
INFO - 2025-10-29 13:26:33 --> Language Class Initialized
ERROR - 2025-10-29 13:26:33 --> 404 Page Not Found: Assets/js
DEBUG - 2025-10-29 13:26:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2025-10-29 13:26:33 --> 404 Page Not Found: Assets/css
INFO - 2025-10-29 13:26:33 --> Input Class Initialized
INFO - 2025-10-29 13:26:33 --> Language Class Initialized
ERROR - 2025-10-29 13:26:33 --> 404 Page Not Found: Assets/js
INFO - 2025-10-29 13:27:16 --> Config Class Initialized
INFO - 2025-10-29 13:27:16 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:27:16 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:27:16 --> Utf8 Class Initialized
INFO - 2025-10-29 13:27:16 --> URI Class Initialized
INFO - 2025-10-29 13:27:16 --> Router Class Initialized
INFO - 2025-10-29 13:27:16 --> Output Class Initialized
INFO - 2025-10-29 13:27:16 --> Security Class Initialized
DEBUG - 2025-10-29 13:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:27:16 --> Input Class Initialized
INFO - 2025-10-29 13:27:16 --> Language Class Initialized
INFO - 2025-10-29 13:27:16 --> Loader Class Initialized
INFO - 2025-10-29 13:27:16 --> Helper loaded: url_helper
INFO - 2025-10-29 13:27:16 --> Database Driver Class Initialized
INFO - 2025-10-29 13:27:16 --> Controller Class Initialized
INFO - 2025-10-29 13:27:16 --> Model "Student_model" initialized
INFO - 2025-10-29 13:27:16 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:27:16 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:27:16 --> Helper loaded: form_helper
INFO - 2025-10-29 13:27:16 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:27:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:27:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:27:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:27:16 --> Final output sent to browser
DEBUG - 2025-10-29 13:27:16 --> Total execution time: 0.1646
INFO - 2025-10-29 13:27:18 --> Config Class Initialized
INFO - 2025-10-29 13:27:18 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:27:18 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:27:18 --> Utf8 Class Initialized
INFO - 2025-10-29 13:27:18 --> URI Class Initialized
INFO - 2025-10-29 13:27:18 --> Router Class Initialized
INFO - 2025-10-29 13:27:18 --> Output Class Initialized
INFO - 2025-10-29 13:27:18 --> Security Class Initialized
DEBUG - 2025-10-29 13:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:27:18 --> Input Class Initialized
INFO - 2025-10-29 13:27:18 --> Language Class Initialized
INFO - 2025-10-29 13:27:18 --> Loader Class Initialized
INFO - 2025-10-29 13:27:18 --> Helper loaded: url_helper
INFO - 2025-10-29 13:27:18 --> Database Driver Class Initialized
INFO - 2025-10-29 13:27:18 --> Controller Class Initialized
INFO - 2025-10-29 13:27:18 --> Model "Student_model" initialized
INFO - 2025-10-29 13:27:18 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:27:18 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:27:18 --> Helper loaded: form_helper
INFO - 2025-10-29 13:27:18 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:27:18 --> Final output sent to browser
DEBUG - 2025-10-29 13:27:18 --> Total execution time: 0.0829
INFO - 2025-10-29 13:27:25 --> Config Class Initialized
INFO - 2025-10-29 13:27:25 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:27:25 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:27:25 --> Utf8 Class Initialized
INFO - 2025-10-29 13:27:25 --> URI Class Initialized
INFO - 2025-10-29 13:27:25 --> Router Class Initialized
INFO - 2025-10-29 13:27:25 --> Output Class Initialized
INFO - 2025-10-29 13:27:25 --> Security Class Initialized
DEBUG - 2025-10-29 13:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:27:25 --> Input Class Initialized
INFO - 2025-10-29 13:27:25 --> Language Class Initialized
INFO - 2025-10-29 13:27:25 --> Loader Class Initialized
INFO - 2025-10-29 13:27:25 --> Helper loaded: url_helper
INFO - 2025-10-29 13:27:25 --> Database Driver Class Initialized
INFO - 2025-10-29 13:27:25 --> Controller Class Initialized
INFO - 2025-10-29 13:27:25 --> Model "Student_model" initialized
INFO - 2025-10-29 13:27:25 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:27:25 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:27:25 --> Helper loaded: form_helper
INFO - 2025-10-29 13:27:25 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:27:25 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:27:25 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:27:25 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:27:25 --> Final output sent to browser
DEBUG - 2025-10-29 13:27:25 --> Total execution time: 0.1130
INFO - 2025-10-29 13:27:27 --> Config Class Initialized
INFO - 2025-10-29 13:27:27 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:27:27 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:27:27 --> Utf8 Class Initialized
INFO - 2025-10-29 13:27:27 --> URI Class Initialized
INFO - 2025-10-29 13:27:27 --> Router Class Initialized
INFO - 2025-10-29 13:27:27 --> Output Class Initialized
INFO - 2025-10-29 13:27:27 --> Security Class Initialized
DEBUG - 2025-10-29 13:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:27:27 --> Input Class Initialized
INFO - 2025-10-29 13:27:27 --> Language Class Initialized
INFO - 2025-10-29 13:27:27 --> Loader Class Initialized
INFO - 2025-10-29 13:27:27 --> Helper loaded: url_helper
INFO - 2025-10-29 13:27:27 --> Database Driver Class Initialized
INFO - 2025-10-29 13:27:27 --> Controller Class Initialized
INFO - 2025-10-29 13:27:27 --> Model "Student_model" initialized
INFO - 2025-10-29 13:27:27 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:27:27 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:27:27 --> Helper loaded: form_helper
INFO - 2025-10-29 13:27:27 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:27:27 --> Final output sent to browser
DEBUG - 2025-10-29 13:27:27 --> Total execution time: 0.0801
INFO - 2025-10-29 13:27:29 --> Config Class Initialized
INFO - 2025-10-29 13:27:29 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:27:29 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:27:29 --> Utf8 Class Initialized
INFO - 2025-10-29 13:27:29 --> URI Class Initialized
INFO - 2025-10-29 13:27:29 --> Router Class Initialized
INFO - 2025-10-29 13:27:29 --> Output Class Initialized
INFO - 2025-10-29 13:27:29 --> Security Class Initialized
DEBUG - 2025-10-29 13:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:27:29 --> Input Class Initialized
INFO - 2025-10-29 13:27:29 --> Language Class Initialized
INFO - 2025-10-29 13:27:29 --> Loader Class Initialized
INFO - 2025-10-29 13:27:29 --> Helper loaded: url_helper
INFO - 2025-10-29 13:27:29 --> Database Driver Class Initialized
INFO - 2025-10-29 13:27:29 --> Controller Class Initialized
INFO - 2025-10-29 13:27:29 --> Model "Student_model" initialized
INFO - 2025-10-29 13:27:29 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:27:29 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:27:29 --> Helper loaded: form_helper
INFO - 2025-10-29 13:27:29 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:27:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:27:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:27:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:27:29 --> Final output sent to browser
DEBUG - 2025-10-29 13:27:29 --> Total execution time: 0.0877
INFO - 2025-10-29 13:27:31 --> Config Class Initialized
INFO - 2025-10-29 13:27:31 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:27:31 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:27:31 --> Utf8 Class Initialized
INFO - 2025-10-29 13:27:31 --> URI Class Initialized
DEBUG - 2025-10-29 13:27:31 --> No URI present. Default controller set.
INFO - 2025-10-29 13:27:31 --> Router Class Initialized
INFO - 2025-10-29 13:27:31 --> Output Class Initialized
INFO - 2025-10-29 13:27:31 --> Security Class Initialized
DEBUG - 2025-10-29 13:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:27:31 --> Input Class Initialized
INFO - 2025-10-29 13:27:31 --> Language Class Initialized
INFO - 2025-10-29 13:27:31 --> Loader Class Initialized
INFO - 2025-10-29 13:27:31 --> Helper loaded: url_helper
INFO - 2025-10-29 13:27:31 --> Database Driver Class Initialized
INFO - 2025-10-29 13:27:31 --> Controller Class Initialized
INFO - 2025-10-29 13:27:31 --> Model "Student_model" initialized
INFO - 2025-10-29 13:27:31 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:27:31 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 13:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:27:31 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:27:31 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-29 13:27:31 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:27:31 --> Final output sent to browser
DEBUG - 2025-10-29 13:27:31 --> Total execution time: 0.1289
INFO - 2025-10-29 13:27:35 --> Config Class Initialized
INFO - 2025-10-29 13:27:35 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:27:35 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:27:35 --> Utf8 Class Initialized
INFO - 2025-10-29 13:27:35 --> URI Class Initialized
INFO - 2025-10-29 13:27:35 --> Router Class Initialized
INFO - 2025-10-29 13:27:35 --> Output Class Initialized
INFO - 2025-10-29 13:27:35 --> Security Class Initialized
DEBUG - 2025-10-29 13:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:27:35 --> Input Class Initialized
INFO - 2025-10-29 13:27:35 --> Language Class Initialized
INFO - 2025-10-29 13:27:35 --> Loader Class Initialized
INFO - 2025-10-29 13:27:35 --> Helper loaded: url_helper
INFO - 2025-10-29 13:27:35 --> Database Driver Class Initialized
INFO - 2025-10-29 13:27:35 --> Controller Class Initialized
INFO - 2025-10-29 13:27:35 --> Model "Student_model" initialized
INFO - 2025-10-29 13:27:35 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:27:35 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:27:35 --> Helper loaded: form_helper
INFO - 2025-10-29 13:27:35 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:27:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:27:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:27:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:27:36 --> Final output sent to browser
DEBUG - 2025-10-29 13:27:36 --> Total execution time: 0.1202
INFO - 2025-10-29 13:27:37 --> Config Class Initialized
INFO - 2025-10-29 13:27:37 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:27:37 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:27:37 --> Utf8 Class Initialized
INFO - 2025-10-29 13:27:37 --> URI Class Initialized
INFO - 2025-10-29 13:27:37 --> Router Class Initialized
INFO - 2025-10-29 13:27:37 --> Output Class Initialized
INFO - 2025-10-29 13:27:37 --> Security Class Initialized
DEBUG - 2025-10-29 13:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:27:37 --> Input Class Initialized
INFO - 2025-10-29 13:27:37 --> Language Class Initialized
ERROR - 2025-10-29 13:27:37 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:27:51 --> Config Class Initialized
INFO - 2025-10-29 13:27:51 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:27:51 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:27:51 --> Utf8 Class Initialized
INFO - 2025-10-29 13:27:51 --> URI Class Initialized
INFO - 2025-10-29 13:27:51 --> Router Class Initialized
INFO - 2025-10-29 13:27:51 --> Output Class Initialized
INFO - 2025-10-29 13:27:51 --> Security Class Initialized
DEBUG - 2025-10-29 13:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:27:51 --> Input Class Initialized
INFO - 2025-10-29 13:27:51 --> Language Class Initialized
INFO - 2025-10-29 13:27:51 --> Loader Class Initialized
INFO - 2025-10-29 13:27:51 --> Helper loaded: url_helper
INFO - 2025-10-29 13:27:51 --> Database Driver Class Initialized
INFO - 2025-10-29 13:27:51 --> Controller Class Initialized
INFO - 2025-10-29 13:27:51 --> Model "Student_model" initialized
INFO - 2025-10-29 13:27:51 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:27:51 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:27:51 --> Helper loaded: form_helper
INFO - 2025-10-29 13:27:51 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:27:51 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:27:51 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/edit.php
INFO - 2025-10-29 13:27:51 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:27:51 --> Final output sent to browser
DEBUG - 2025-10-29 13:27:51 --> Total execution time: 0.1038
INFO - 2025-10-29 13:27:53 --> Config Class Initialized
INFO - 2025-10-29 13:27:53 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:27:53 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:27:53 --> Utf8 Class Initialized
INFO - 2025-10-29 13:27:53 --> URI Class Initialized
INFO - 2025-10-29 13:27:53 --> Router Class Initialized
INFO - 2025-10-29 13:27:53 --> Output Class Initialized
INFO - 2025-10-29 13:27:53 --> Security Class Initialized
DEBUG - 2025-10-29 13:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:27:53 --> Input Class Initialized
INFO - 2025-10-29 13:27:53 --> Language Class Initialized
INFO - 2025-10-29 13:27:53 --> Loader Class Initialized
INFO - 2025-10-29 13:27:53 --> Helper loaded: url_helper
INFO - 2025-10-29 13:27:53 --> Database Driver Class Initialized
INFO - 2025-10-29 13:27:53 --> Controller Class Initialized
INFO - 2025-10-29 13:27:53 --> Model "Student_model" initialized
INFO - 2025-10-29 13:27:53 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:27:53 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:27:53 --> Helper loaded: form_helper
INFO - 2025-10-29 13:27:53 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:27:53 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:27:53 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-29 13:27:53 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:27:53 --> Final output sent to browser
DEBUG - 2025-10-29 13:27:53 --> Total execution time: 0.1108
INFO - 2025-10-29 13:27:55 --> Config Class Initialized
INFO - 2025-10-29 13:27:55 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:27:55 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:27:55 --> Utf8 Class Initialized
INFO - 2025-10-29 13:27:55 --> URI Class Initialized
INFO - 2025-10-29 13:27:55 --> Router Class Initialized
INFO - 2025-10-29 13:27:55 --> Output Class Initialized
INFO - 2025-10-29 13:27:55 --> Security Class Initialized
DEBUG - 2025-10-29 13:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:27:55 --> Input Class Initialized
INFO - 2025-10-29 13:27:55 --> Language Class Initialized
INFO - 2025-10-29 13:27:55 --> Loader Class Initialized
INFO - 2025-10-29 13:27:55 --> Helper loaded: url_helper
INFO - 2025-10-29 13:27:55 --> Database Driver Class Initialized
INFO - 2025-10-29 13:27:55 --> Controller Class Initialized
INFO - 2025-10-29 13:27:55 --> Model "Student_model" initialized
INFO - 2025-10-29 13:27:55 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:27:55 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:27:55 --> Helper loaded: form_helper
INFO - 2025-10-29 13:27:55 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:27:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:27:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:27:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:27:55 --> Final output sent to browser
DEBUG - 2025-10-29 13:27:55 --> Total execution time: 0.0843
INFO - 2025-10-29 13:27:57 --> Config Class Initialized
INFO - 2025-10-29 13:27:57 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:27:57 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:27:57 --> Utf8 Class Initialized
INFO - 2025-10-29 13:27:57 --> URI Class Initialized
INFO - 2025-10-29 13:27:57 --> Router Class Initialized
INFO - 2025-10-29 13:27:57 --> Output Class Initialized
INFO - 2025-10-29 13:27:57 --> Security Class Initialized
DEBUG - 2025-10-29 13:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:27:57 --> Input Class Initialized
INFO - 2025-10-29 13:27:57 --> Language Class Initialized
INFO - 2025-10-29 13:27:57 --> Loader Class Initialized
INFO - 2025-10-29 13:27:57 --> Helper loaded: url_helper
INFO - 2025-10-29 13:27:58 --> Database Driver Class Initialized
INFO - 2025-10-29 13:27:58 --> Controller Class Initialized
INFO - 2025-10-29 13:27:58 --> Model "Student_model" initialized
INFO - 2025-10-29 13:27:58 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:27:58 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:27:58 --> Helper loaded: form_helper
INFO - 2025-10-29 13:27:58 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:27:58 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:27:58 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-29 13:27:58 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:27:58 --> Final output sent to browser
DEBUG - 2025-10-29 13:27:58 --> Total execution time: 0.0927
INFO - 2025-10-29 13:28:00 --> Config Class Initialized
INFO - 2025-10-29 13:28:00 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:28:00 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:28:00 --> Utf8 Class Initialized
INFO - 2025-10-29 13:28:00 --> URI Class Initialized
INFO - 2025-10-29 13:28:00 --> Router Class Initialized
INFO - 2025-10-29 13:28:00 --> Output Class Initialized
INFO - 2025-10-29 13:28:00 --> Security Class Initialized
DEBUG - 2025-10-29 13:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:28:00 --> Input Class Initialized
INFO - 2025-10-29 13:28:00 --> Language Class Initialized
ERROR - 2025-10-29 13:28:00 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:28:03 --> Config Class Initialized
INFO - 2025-10-29 13:28:03 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:28:03 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:28:03 --> Utf8 Class Initialized
INFO - 2025-10-29 13:28:03 --> URI Class Initialized
INFO - 2025-10-29 13:28:03 --> Router Class Initialized
INFO - 2025-10-29 13:28:03 --> Output Class Initialized
INFO - 2025-10-29 13:28:03 --> Security Class Initialized
DEBUG - 2025-10-29 13:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:28:03 --> Input Class Initialized
INFO - 2025-10-29 13:28:03 --> Language Class Initialized
ERROR - 2025-10-29 13:28:03 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:29:06 --> Config Class Initialized
INFO - 2025-10-29 13:29:06 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:29:06 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:29:06 --> Utf8 Class Initialized
INFO - 2025-10-29 13:29:06 --> URI Class Initialized
INFO - 2025-10-29 13:29:06 --> Router Class Initialized
INFO - 2025-10-29 13:29:06 --> Output Class Initialized
INFO - 2025-10-29 13:29:06 --> Security Class Initialized
DEBUG - 2025-10-29 13:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:29:06 --> Input Class Initialized
INFO - 2025-10-29 13:29:06 --> Language Class Initialized
INFO - 2025-10-29 13:29:06 --> Loader Class Initialized
INFO - 2025-10-29 13:29:06 --> Helper loaded: url_helper
INFO - 2025-10-29 13:29:06 --> Database Driver Class Initialized
INFO - 2025-10-29 13:29:06 --> Controller Class Initialized
INFO - 2025-10-29 13:29:06 --> Model "Student_model" initialized
INFO - 2025-10-29 13:29:06 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:29:06 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:29:06 --> Helper loaded: form_helper
INFO - 2025-10-29 13:29:06 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:29:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:29:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/edit.php
INFO - 2025-10-29 13:29:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:29:06 --> Final output sent to browser
DEBUG - 2025-10-29 13:29:06 --> Total execution time: 0.1089
INFO - 2025-10-29 13:29:10 --> Config Class Initialized
INFO - 2025-10-29 13:29:10 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:29:10 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:29:10 --> Utf8 Class Initialized
INFO - 2025-10-29 13:29:10 --> URI Class Initialized
INFO - 2025-10-29 13:29:10 --> Router Class Initialized
INFO - 2025-10-29 13:29:10 --> Output Class Initialized
INFO - 2025-10-29 13:29:10 --> Security Class Initialized
DEBUG - 2025-10-29 13:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:29:10 --> Input Class Initialized
INFO - 2025-10-29 13:29:10 --> Language Class Initialized
INFO - 2025-10-29 13:29:10 --> Loader Class Initialized
INFO - 2025-10-29 13:29:10 --> Helper loaded: url_helper
INFO - 2025-10-29 13:29:10 --> Database Driver Class Initialized
INFO - 2025-10-29 13:29:10 --> Controller Class Initialized
INFO - 2025-10-29 13:29:10 --> Model "Student_model" initialized
INFO - 2025-10-29 13:29:10 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:29:10 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:29:10 --> Helper loaded: form_helper
INFO - 2025-10-29 13:29:10 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:29:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:29:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-29 13:29:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:29:10 --> Final output sent to browser
DEBUG - 2025-10-29 13:29:10 --> Total execution time: 0.1100
INFO - 2025-10-29 13:29:12 --> Config Class Initialized
INFO - 2025-10-29 13:29:12 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:29:12 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:29:12 --> Utf8 Class Initialized
INFO - 2025-10-29 13:29:12 --> URI Class Initialized
INFO - 2025-10-29 13:29:12 --> Router Class Initialized
INFO - 2025-10-29 13:29:12 --> Output Class Initialized
INFO - 2025-10-29 13:29:12 --> Security Class Initialized
DEBUG - 2025-10-29 13:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:29:12 --> Input Class Initialized
INFO - 2025-10-29 13:29:12 --> Language Class Initialized
INFO - 2025-10-29 13:29:12 --> Loader Class Initialized
INFO - 2025-10-29 13:29:12 --> Helper loaded: url_helper
INFO - 2025-10-29 13:29:12 --> Database Driver Class Initialized
INFO - 2025-10-29 13:29:12 --> Controller Class Initialized
INFO - 2025-10-29 13:29:12 --> Model "Student_model" initialized
INFO - 2025-10-29 13:29:12 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:29:12 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:29:12 --> Helper loaded: form_helper
INFO - 2025-10-29 13:29:12 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:29:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:29:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:29:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:29:12 --> Final output sent to browser
DEBUG - 2025-10-29 13:29:12 --> Total execution time: 0.1464
INFO - 2025-10-29 13:29:16 --> Config Class Initialized
INFO - 2025-10-29 13:29:16 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:29:16 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:29:16 --> Utf8 Class Initialized
INFO - 2025-10-29 13:29:16 --> URI Class Initialized
INFO - 2025-10-29 13:29:16 --> Router Class Initialized
INFO - 2025-10-29 13:29:16 --> Output Class Initialized
INFO - 2025-10-29 13:29:16 --> Security Class Initialized
DEBUG - 2025-10-29 13:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:29:16 --> Input Class Initialized
INFO - 2025-10-29 13:29:16 --> Language Class Initialized
INFO - 2025-10-29 13:29:16 --> Loader Class Initialized
INFO - 2025-10-29 13:29:16 --> Helper loaded: url_helper
INFO - 2025-10-29 13:29:16 --> Database Driver Class Initialized
INFO - 2025-10-29 13:29:16 --> Controller Class Initialized
INFO - 2025-10-29 13:29:16 --> Model "Student_model" initialized
INFO - 2025-10-29 13:29:16 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:29:16 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:29:16 --> Helper loaded: form_helper
INFO - 2025-10-29 13:29:16 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:29:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:29:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/edit.php
INFO - 2025-10-29 13:29:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:29:16 --> Final output sent to browser
DEBUG - 2025-10-29 13:29:16 --> Total execution time: 0.1284
INFO - 2025-10-29 13:29:18 --> Config Class Initialized
INFO - 2025-10-29 13:29:18 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:29:18 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:29:18 --> Utf8 Class Initialized
INFO - 2025-10-29 13:29:18 --> URI Class Initialized
INFO - 2025-10-29 13:29:18 --> Router Class Initialized
INFO - 2025-10-29 13:29:18 --> Output Class Initialized
INFO - 2025-10-29 13:29:18 --> Security Class Initialized
DEBUG - 2025-10-29 13:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:29:18 --> Input Class Initialized
INFO - 2025-10-29 13:29:18 --> Language Class Initialized
INFO - 2025-10-29 13:29:18 --> Loader Class Initialized
INFO - 2025-10-29 13:29:18 --> Helper loaded: url_helper
INFO - 2025-10-29 13:29:18 --> Database Driver Class Initialized
INFO - 2025-10-29 13:29:18 --> Controller Class Initialized
INFO - 2025-10-29 13:29:18 --> Model "Student_model" initialized
INFO - 2025-10-29 13:29:18 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:29:18 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:29:18 --> Helper loaded: form_helper
INFO - 2025-10-29 13:29:18 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:29:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:29:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-29 13:29:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:29:18 --> Final output sent to browser
DEBUG - 2025-10-29 13:29:18 --> Total execution time: 0.0776
INFO - 2025-10-29 13:29:22 --> Config Class Initialized
INFO - 2025-10-29 13:29:22 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:29:22 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:29:22 --> Utf8 Class Initialized
INFO - 2025-10-29 13:29:22 --> URI Class Initialized
INFO - 2025-10-29 13:29:22 --> Router Class Initialized
INFO - 2025-10-29 13:29:22 --> Output Class Initialized
INFO - 2025-10-29 13:29:22 --> Security Class Initialized
DEBUG - 2025-10-29 13:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:29:22 --> Input Class Initialized
INFO - 2025-10-29 13:29:22 --> Language Class Initialized
INFO - 2025-10-29 13:29:22 --> Loader Class Initialized
INFO - 2025-10-29 13:29:22 --> Helper loaded: url_helper
INFO - 2025-10-29 13:29:22 --> Database Driver Class Initialized
INFO - 2025-10-29 13:29:22 --> Controller Class Initialized
INFO - 2025-10-29 13:29:22 --> Model "Student_model" initialized
INFO - 2025-10-29 13:29:22 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:29:22 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:29:22 --> Helper loaded: form_helper
INFO - 2025-10-29 13:29:22 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:29:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:29:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:29:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:29:22 --> Final output sent to browser
DEBUG - 2025-10-29 13:29:22 --> Total execution time: 0.1180
INFO - 2025-10-29 13:29:26 --> Config Class Initialized
INFO - 2025-10-29 13:29:26 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:29:26 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:29:26 --> Utf8 Class Initialized
INFO - 2025-10-29 13:29:26 --> URI Class Initialized
INFO - 2025-10-29 13:29:26 --> Router Class Initialized
INFO - 2025-10-29 13:29:26 --> Output Class Initialized
INFO - 2025-10-29 13:29:26 --> Security Class Initialized
DEBUG - 2025-10-29 13:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:29:26 --> Input Class Initialized
INFO - 2025-10-29 13:29:26 --> Language Class Initialized
INFO - 2025-10-29 13:29:26 --> Loader Class Initialized
INFO - 2025-10-29 13:29:26 --> Helper loaded: url_helper
INFO - 2025-10-29 13:29:26 --> Database Driver Class Initialized
INFO - 2025-10-29 13:29:26 --> Controller Class Initialized
INFO - 2025-10-29 13:29:26 --> Model "Student_model" initialized
INFO - 2025-10-29 13:29:26 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:29:26 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:29:26 --> Helper loaded: form_helper
INFO - 2025-10-29 13:29:26 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:29:27 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:29:27 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/edit.php
INFO - 2025-10-29 13:29:27 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:29:27 --> Final output sent to browser
DEBUG - 2025-10-29 13:29:27 --> Total execution time: 0.1484
INFO - 2025-10-29 13:29:36 --> Config Class Initialized
INFO - 2025-10-29 13:29:36 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:29:36 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:29:36 --> Utf8 Class Initialized
INFO - 2025-10-29 13:29:36 --> URI Class Initialized
INFO - 2025-10-29 13:29:36 --> Router Class Initialized
INFO - 2025-10-29 13:29:36 --> Output Class Initialized
INFO - 2025-10-29 13:29:36 --> Security Class Initialized
DEBUG - 2025-10-29 13:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:29:36 --> Input Class Initialized
INFO - 2025-10-29 13:29:36 --> Language Class Initialized
INFO - 2025-10-29 13:29:36 --> Loader Class Initialized
INFO - 2025-10-29 13:29:36 --> Helper loaded: url_helper
INFO - 2025-10-29 13:29:36 --> Database Driver Class Initialized
INFO - 2025-10-29 13:29:36 --> Controller Class Initialized
INFO - 2025-10-29 13:29:36 --> Model "Student_model" initialized
INFO - 2025-10-29 13:29:36 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:29:36 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:29:36 --> Helper loaded: form_helper
INFO - 2025-10-29 13:29:36 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:29:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:29:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-29 13:29:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:29:36 --> Final output sent to browser
DEBUG - 2025-10-29 13:29:36 --> Total execution time: 0.0840
INFO - 2025-10-29 13:29:37 --> Config Class Initialized
INFO - 2025-10-29 13:29:37 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:29:37 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:29:37 --> Utf8 Class Initialized
INFO - 2025-10-29 13:29:37 --> URI Class Initialized
INFO - 2025-10-29 13:29:37 --> Router Class Initialized
INFO - 2025-10-29 13:29:37 --> Output Class Initialized
INFO - 2025-10-29 13:29:37 --> Security Class Initialized
DEBUG - 2025-10-29 13:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:29:37 --> Input Class Initialized
INFO - 2025-10-29 13:29:37 --> Language Class Initialized
INFO - 2025-10-29 13:29:37 --> Loader Class Initialized
INFO - 2025-10-29 13:29:37 --> Helper loaded: url_helper
INFO - 2025-10-29 13:29:38 --> Database Driver Class Initialized
INFO - 2025-10-29 13:29:38 --> Controller Class Initialized
INFO - 2025-10-29 13:29:38 --> Model "Student_model" initialized
INFO - 2025-10-29 13:29:38 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:29:38 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:29:38 --> Helper loaded: form_helper
INFO - 2025-10-29 13:29:38 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:29:38 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:29:38 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:29:38 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:29:38 --> Final output sent to browser
DEBUG - 2025-10-29 13:29:38 --> Total execution time: 0.1038
INFO - 2025-10-29 13:29:41 --> Config Class Initialized
INFO - 2025-10-29 13:29:41 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:29:41 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:29:41 --> Utf8 Class Initialized
INFO - 2025-10-29 13:29:41 --> URI Class Initialized
INFO - 2025-10-29 13:29:41 --> Router Class Initialized
INFO - 2025-10-29 13:29:41 --> Output Class Initialized
INFO - 2025-10-29 13:29:41 --> Security Class Initialized
DEBUG - 2025-10-29 13:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:29:41 --> Input Class Initialized
INFO - 2025-10-29 13:29:41 --> Language Class Initialized
INFO - 2025-10-29 13:29:41 --> Loader Class Initialized
INFO - 2025-10-29 13:29:41 --> Helper loaded: url_helper
INFO - 2025-10-29 13:29:41 --> Database Driver Class Initialized
INFO - 2025-10-29 13:29:41 --> Controller Class Initialized
INFO - 2025-10-29 13:29:41 --> Model "Student_model" initialized
INFO - 2025-10-29 13:29:41 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:29:41 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:29:41 --> Helper loaded: form_helper
INFO - 2025-10-29 13:29:41 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:29:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:29:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/edit.php
INFO - 2025-10-29 13:29:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:29:41 --> Final output sent to browser
DEBUG - 2025-10-29 13:29:41 --> Total execution time: 0.1158
INFO - 2025-10-29 13:29:52 --> Config Class Initialized
INFO - 2025-10-29 13:29:52 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:29:52 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:29:52 --> Utf8 Class Initialized
INFO - 2025-10-29 13:29:52 --> URI Class Initialized
INFO - 2025-10-29 13:29:52 --> Router Class Initialized
INFO - 2025-10-29 13:29:52 --> Output Class Initialized
INFO - 2025-10-29 13:29:52 --> Security Class Initialized
DEBUG - 2025-10-29 13:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:29:52 --> Input Class Initialized
INFO - 2025-10-29 13:29:52 --> Language Class Initialized
INFO - 2025-10-29 13:29:52 --> Loader Class Initialized
INFO - 2025-10-29 13:29:52 --> Helper loaded: url_helper
INFO - 2025-10-29 13:29:52 --> Database Driver Class Initialized
INFO - 2025-10-29 13:29:52 --> Controller Class Initialized
INFO - 2025-10-29 13:29:52 --> Model "Student_model" initialized
INFO - 2025-10-29 13:29:52 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:29:52 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:29:52 --> Helper loaded: form_helper
INFO - 2025-10-29 13:29:52 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:29:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-29 13:29:52 --> Config Class Initialized
INFO - 2025-10-29 13:29:52 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:29:52 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:29:52 --> Utf8 Class Initialized
INFO - 2025-10-29 13:29:52 --> URI Class Initialized
INFO - 2025-10-29 13:29:52 --> Router Class Initialized
INFO - 2025-10-29 13:29:52 --> Output Class Initialized
INFO - 2025-10-29 13:29:52 --> Security Class Initialized
DEBUG - 2025-10-29 13:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:29:52 --> Input Class Initialized
INFO - 2025-10-29 13:29:52 --> Language Class Initialized
INFO - 2025-10-29 13:29:52 --> Loader Class Initialized
INFO - 2025-10-29 13:29:52 --> Helper loaded: url_helper
INFO - 2025-10-29 13:29:52 --> Database Driver Class Initialized
INFO - 2025-10-29 13:29:52 --> Controller Class Initialized
INFO - 2025-10-29 13:29:52 --> Model "Student_model" initialized
INFO - 2025-10-29 13:29:52 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:29:52 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:29:52 --> Helper loaded: form_helper
INFO - 2025-10-29 13:29:52 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:29:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:29:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-29 13:29:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:29:52 --> Final output sent to browser
DEBUG - 2025-10-29 13:29:52 --> Total execution time: 0.0761
INFO - 2025-10-29 13:29:56 --> Config Class Initialized
INFO - 2025-10-29 13:29:56 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:29:56 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:29:56 --> Utf8 Class Initialized
INFO - 2025-10-29 13:29:56 --> URI Class Initialized
INFO - 2025-10-29 13:29:56 --> Router Class Initialized
INFO - 2025-10-29 13:29:56 --> Output Class Initialized
INFO - 2025-10-29 13:29:56 --> Security Class Initialized
DEBUG - 2025-10-29 13:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:29:56 --> Input Class Initialized
INFO - 2025-10-29 13:29:56 --> Language Class Initialized
INFO - 2025-10-29 13:29:56 --> Loader Class Initialized
INFO - 2025-10-29 13:29:56 --> Helper loaded: url_helper
INFO - 2025-10-29 13:29:56 --> Database Driver Class Initialized
INFO - 2025-10-29 13:29:56 --> Controller Class Initialized
INFO - 2025-10-29 13:29:56 --> Model "Student_model" initialized
INFO - 2025-10-29 13:29:56 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:29:56 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:29:56 --> Helper loaded: form_helper
INFO - 2025-10-29 13:29:56 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:29:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:29:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:29:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:29:56 --> Final output sent to browser
DEBUG - 2025-10-29 13:29:56 --> Total execution time: 0.1276
INFO - 2025-10-29 13:30:02 --> Config Class Initialized
INFO - 2025-10-29 13:30:02 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:30:02 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:30:02 --> Utf8 Class Initialized
INFO - 2025-10-29 13:30:02 --> URI Class Initialized
INFO - 2025-10-29 13:30:02 --> Router Class Initialized
INFO - 2025-10-29 13:30:02 --> Output Class Initialized
INFO - 2025-10-29 13:30:02 --> Security Class Initialized
DEBUG - 2025-10-29 13:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:30:02 --> Input Class Initialized
INFO - 2025-10-29 13:30:02 --> Language Class Initialized
INFO - 2025-10-29 13:30:02 --> Loader Class Initialized
INFO - 2025-10-29 13:30:02 --> Helper loaded: url_helper
INFO - 2025-10-29 13:30:02 --> Database Driver Class Initialized
INFO - 2025-10-29 13:30:02 --> Controller Class Initialized
INFO - 2025-10-29 13:30:02 --> Model "Student_model" initialized
INFO - 2025-10-29 13:30:02 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:30:02 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:30:02 --> Helper loaded: form_helper
INFO - 2025-10-29 13:30:02 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:30:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:30:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:30:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:30:02 --> Final output sent to browser
DEBUG - 2025-10-29 13:30:02 --> Total execution time: 0.1543
INFO - 2025-10-29 13:30:04 --> Config Class Initialized
INFO - 2025-10-29 13:30:04 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:30:04 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:30:04 --> Utf8 Class Initialized
INFO - 2025-10-29 13:30:04 --> URI Class Initialized
INFO - 2025-10-29 13:30:04 --> Router Class Initialized
INFO - 2025-10-29 13:30:04 --> Output Class Initialized
INFO - 2025-10-29 13:30:04 --> Security Class Initialized
DEBUG - 2025-10-29 13:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:30:04 --> Input Class Initialized
INFO - 2025-10-29 13:30:04 --> Language Class Initialized
INFO - 2025-10-29 13:30:04 --> Loader Class Initialized
INFO - 2025-10-29 13:30:04 --> Helper loaded: url_helper
INFO - 2025-10-29 13:30:04 --> Database Driver Class Initialized
INFO - 2025-10-29 13:30:04 --> Controller Class Initialized
INFO - 2025-10-29 13:30:04 --> Model "Student_model" initialized
INFO - 2025-10-29 13:30:04 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:30:04 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:30:04 --> Helper loaded: form_helper
INFO - 2025-10-29 13:30:04 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:30:04 --> Final output sent to browser
DEBUG - 2025-10-29 13:30:04 --> Total execution time: 0.0994
INFO - 2025-10-29 13:30:06 --> Config Class Initialized
INFO - 2025-10-29 13:30:06 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:30:06 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:30:06 --> Utf8 Class Initialized
INFO - 2025-10-29 13:30:06 --> URI Class Initialized
INFO - 2025-10-29 13:30:06 --> Router Class Initialized
INFO - 2025-10-29 13:30:06 --> Output Class Initialized
INFO - 2025-10-29 13:30:06 --> Security Class Initialized
DEBUG - 2025-10-29 13:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:30:06 --> Input Class Initialized
INFO - 2025-10-29 13:30:06 --> Language Class Initialized
INFO - 2025-10-29 13:30:06 --> Loader Class Initialized
INFO - 2025-10-29 13:30:06 --> Helper loaded: url_helper
INFO - 2025-10-29 13:30:06 --> Database Driver Class Initialized
INFO - 2025-10-29 13:30:06 --> Controller Class Initialized
INFO - 2025-10-29 13:30:06 --> Model "Student_model" initialized
INFO - 2025-10-29 13:30:06 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:30:06 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:30:06 --> Helper loaded: form_helper
INFO - 2025-10-29 13:30:06 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:30:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:30:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:30:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:30:06 --> Final output sent to browser
DEBUG - 2025-10-29 13:30:06 --> Total execution time: 0.1128
INFO - 2025-10-29 13:30:07 --> Config Class Initialized
INFO - 2025-10-29 13:30:07 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:30:07 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:30:07 --> Utf8 Class Initialized
INFO - 2025-10-29 13:30:07 --> URI Class Initialized
INFO - 2025-10-29 13:30:07 --> Router Class Initialized
INFO - 2025-10-29 13:30:07 --> Output Class Initialized
INFO - 2025-10-29 13:30:07 --> Security Class Initialized
DEBUG - 2025-10-29 13:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:30:07 --> Input Class Initialized
INFO - 2025-10-29 13:30:07 --> Language Class Initialized
INFO - 2025-10-29 13:30:07 --> Loader Class Initialized
INFO - 2025-10-29 13:30:07 --> Helper loaded: url_helper
INFO - 2025-10-29 13:30:07 --> Database Driver Class Initialized
INFO - 2025-10-29 13:30:07 --> Controller Class Initialized
INFO - 2025-10-29 13:30:07 --> Model "Student_model" initialized
INFO - 2025-10-29 13:30:07 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:30:07 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:30:07 --> Helper loaded: form_helper
INFO - 2025-10-29 13:30:07 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:30:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:30:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:30:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:30:08 --> Final output sent to browser
DEBUG - 2025-10-29 13:30:08 --> Total execution time: 0.0836
INFO - 2025-10-29 13:30:08 --> Config Class Initialized
INFO - 2025-10-29 13:30:08 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:30:08 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:30:08 --> Utf8 Class Initialized
INFO - 2025-10-29 13:30:08 --> URI Class Initialized
DEBUG - 2025-10-29 13:30:08 --> No URI present. Default controller set.
INFO - 2025-10-29 13:30:08 --> Router Class Initialized
INFO - 2025-10-29 13:30:08 --> Output Class Initialized
INFO - 2025-10-29 13:30:08 --> Security Class Initialized
DEBUG - 2025-10-29 13:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:30:08 --> Input Class Initialized
INFO - 2025-10-29 13:30:08 --> Language Class Initialized
INFO - 2025-10-29 13:30:08 --> Loader Class Initialized
INFO - 2025-10-29 13:30:08 --> Helper loaded: url_helper
INFO - 2025-10-29 13:30:08 --> Database Driver Class Initialized
INFO - 2025-10-29 13:30:08 --> Controller Class Initialized
INFO - 2025-10-29 13:30:08 --> Model "Student_model" initialized
INFO - 2025-10-29 13:30:08 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:30:08 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 13:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:30:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:30:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-29 13:30:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:30:08 --> Final output sent to browser
DEBUG - 2025-10-29 13:30:08 --> Total execution time: 0.0882
INFO - 2025-10-29 13:32:56 --> Config Class Initialized
INFO - 2025-10-29 13:32:56 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:32:56 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:32:56 --> Utf8 Class Initialized
INFO - 2025-10-29 13:32:56 --> URI Class Initialized
DEBUG - 2025-10-29 13:32:56 --> No URI present. Default controller set.
INFO - 2025-10-29 13:32:56 --> Router Class Initialized
INFO - 2025-10-29 13:32:56 --> Output Class Initialized
INFO - 2025-10-29 13:32:56 --> Security Class Initialized
DEBUG - 2025-10-29 13:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:32:56 --> Input Class Initialized
INFO - 2025-10-29 13:32:56 --> Language Class Initialized
INFO - 2025-10-29 13:32:56 --> Loader Class Initialized
INFO - 2025-10-29 13:32:56 --> Helper loaded: url_helper
INFO - 2025-10-29 13:32:56 --> Database Driver Class Initialized
INFO - 2025-10-29 13:32:56 --> Controller Class Initialized
INFO - 2025-10-29 13:32:56 --> Model "Student_model" initialized
INFO - 2025-10-29 13:32:56 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:32:56 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 13:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:32:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:32:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-29 13:32:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:32:56 --> Final output sent to browser
DEBUG - 2025-10-29 13:32:56 --> Total execution time: 0.0925
INFO - 2025-10-29 13:33:03 --> Config Class Initialized
INFO - 2025-10-29 13:33:03 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:33:03 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:33:03 --> Utf8 Class Initialized
INFO - 2025-10-29 13:33:03 --> URI Class Initialized
INFO - 2025-10-29 13:33:03 --> Router Class Initialized
INFO - 2025-10-29 13:33:03 --> Output Class Initialized
INFO - 2025-10-29 13:33:04 --> Security Class Initialized
DEBUG - 2025-10-29 13:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:33:04 --> Input Class Initialized
INFO - 2025-10-29 13:33:04 --> Language Class Initialized
INFO - 2025-10-29 13:33:04 --> Loader Class Initialized
INFO - 2025-10-29 13:33:04 --> Helper loaded: url_helper
INFO - 2025-10-29 13:33:04 --> Database Driver Class Initialized
INFO - 2025-10-29 13:33:04 --> Controller Class Initialized
INFO - 2025-10-29 13:33:04 --> Model "Student_model" initialized
INFO - 2025-10-29 13:33:04 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:33:04 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:33:04 --> Helper loaded: form_helper
INFO - 2025-10-29 13:33:04 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:33:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:33:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:33:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:33:04 --> Final output sent to browser
DEBUG - 2025-10-29 13:33:04 --> Total execution time: 0.1092
INFO - 2025-10-29 13:33:08 --> Config Class Initialized
INFO - 2025-10-29 13:33:08 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:33:08 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:33:08 --> Utf8 Class Initialized
INFO - 2025-10-29 13:33:08 --> URI Class Initialized
INFO - 2025-10-29 13:33:08 --> Router Class Initialized
INFO - 2025-10-29 13:33:08 --> Output Class Initialized
INFO - 2025-10-29 13:33:08 --> Security Class Initialized
DEBUG - 2025-10-29 13:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:33:08 --> Input Class Initialized
INFO - 2025-10-29 13:33:08 --> Language Class Initialized
ERROR - 2025-10-29 13:33:08 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:35:07 --> Config Class Initialized
INFO - 2025-10-29 13:35:07 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:35:07 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:35:07 --> Utf8 Class Initialized
INFO - 2025-10-29 13:35:07 --> URI Class Initialized
INFO - 2025-10-29 13:35:07 --> Router Class Initialized
INFO - 2025-10-29 13:35:07 --> Output Class Initialized
INFO - 2025-10-29 13:35:07 --> Security Class Initialized
DEBUG - 2025-10-29 13:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:35:07 --> Input Class Initialized
INFO - 2025-10-29 13:35:07 --> Language Class Initialized
INFO - 2025-10-29 13:35:07 --> Loader Class Initialized
INFO - 2025-10-29 13:35:07 --> Helper loaded: url_helper
INFO - 2025-10-29 13:35:07 --> Database Driver Class Initialized
INFO - 2025-10-29 13:35:07 --> Controller Class Initialized
INFO - 2025-10-29 13:35:07 --> Model "Student_model" initialized
INFO - 2025-10-29 13:35:07 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:35:07 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:35:07 --> Helper loaded: form_helper
INFO - 2025-10-29 13:35:07 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:35:07 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:35:07 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:35:07 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:35:07 --> Final output sent to browser
DEBUG - 2025-10-29 13:35:07 --> Total execution time: 0.0853
INFO - 2025-10-29 13:35:07 --> Config Class Initialized
INFO - 2025-10-29 13:35:07 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:35:07 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:35:07 --> Utf8 Class Initialized
INFO - 2025-10-29 13:35:07 --> URI Class Initialized
DEBUG - 2025-10-29 13:35:07 --> No URI present. Default controller set.
INFO - 2025-10-29 13:35:07 --> Router Class Initialized
INFO - 2025-10-29 13:35:07 --> Output Class Initialized
INFO - 2025-10-29 13:35:07 --> Security Class Initialized
DEBUG - 2025-10-29 13:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:35:07 --> Input Class Initialized
INFO - 2025-10-29 13:35:07 --> Language Class Initialized
INFO - 2025-10-29 13:35:07 --> Loader Class Initialized
INFO - 2025-10-29 13:35:07 --> Helper loaded: url_helper
INFO - 2025-10-29 13:35:07 --> Database Driver Class Initialized
INFO - 2025-10-29 13:35:07 --> Controller Class Initialized
INFO - 2025-10-29 13:35:07 --> Model "Student_model" initialized
INFO - 2025-10-29 13:35:07 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:35:07 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 13:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:35:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:35:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-29 13:35:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:35:08 --> Final output sent to browser
DEBUG - 2025-10-29 13:35:08 --> Total execution time: 0.0781
INFO - 2025-10-29 13:35:08 --> Config Class Initialized
INFO - 2025-10-29 13:35:08 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:35:08 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:35:08 --> Utf8 Class Initialized
INFO - 2025-10-29 13:35:08 --> URI Class Initialized
INFO - 2025-10-29 13:35:08 --> Router Class Initialized
INFO - 2025-10-29 13:35:08 --> Output Class Initialized
INFO - 2025-10-29 13:35:08 --> Security Class Initialized
DEBUG - 2025-10-29 13:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:35:08 --> Input Class Initialized
INFO - 2025-10-29 13:35:08 --> Language Class Initialized
ERROR - 2025-10-29 13:35:08 --> 404 Page Not Found: Assets/js
INFO - 2025-10-29 13:35:19 --> Config Class Initialized
INFO - 2025-10-29 13:35:19 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:35:19 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:35:19 --> Utf8 Class Initialized
INFO - 2025-10-29 13:35:19 --> URI Class Initialized
DEBUG - 2025-10-29 13:35:19 --> No URI present. Default controller set.
INFO - 2025-10-29 13:35:19 --> Router Class Initialized
INFO - 2025-10-29 13:35:19 --> Output Class Initialized
INFO - 2025-10-29 13:35:19 --> Security Class Initialized
DEBUG - 2025-10-29 13:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:35:19 --> Input Class Initialized
INFO - 2025-10-29 13:35:19 --> Language Class Initialized
INFO - 2025-10-29 13:35:19 --> Loader Class Initialized
INFO - 2025-10-29 13:35:19 --> Helper loaded: url_helper
INFO - 2025-10-29 13:35:19 --> Database Driver Class Initialized
INFO - 2025-10-29 13:35:19 --> Controller Class Initialized
INFO - 2025-10-29 13:35:19 --> Model "Student_model" initialized
INFO - 2025-10-29 13:35:19 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:35:19 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 13:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:35:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:35:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-29 13:35:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:35:19 --> Final output sent to browser
DEBUG - 2025-10-29 13:35:19 --> Total execution time: 0.1224
INFO - 2025-10-29 13:35:31 --> Config Class Initialized
INFO - 2025-10-29 13:35:31 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:35:31 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:35:31 --> Utf8 Class Initialized
INFO - 2025-10-29 13:35:31 --> URI Class Initialized
INFO - 2025-10-29 13:35:31 --> Router Class Initialized
INFO - 2025-10-29 13:35:31 --> Output Class Initialized
INFO - 2025-10-29 13:35:31 --> Security Class Initialized
DEBUG - 2025-10-29 13:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:35:31 --> Input Class Initialized
INFO - 2025-10-29 13:35:31 --> Language Class Initialized
INFO - 2025-10-29 13:35:31 --> Loader Class Initialized
INFO - 2025-10-29 13:35:31 --> Helper loaded: url_helper
INFO - 2025-10-29 13:35:31 --> Database Driver Class Initialized
INFO - 2025-10-29 13:35:31 --> Controller Class Initialized
INFO - 2025-10-29 13:35:31 --> Model "Student_model" initialized
INFO - 2025-10-29 13:35:31 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:35:31 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:35:31 --> Helper loaded: form_helper
INFO - 2025-10-29 13:35:31 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:35:31 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:35:31 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:35:31 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:35:31 --> Final output sent to browser
DEBUG - 2025-10-29 13:35:31 --> Total execution time: 0.1070
INFO - 2025-10-29 13:35:33 --> Config Class Initialized
INFO - 2025-10-29 13:35:33 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:35:33 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:35:33 --> Utf8 Class Initialized
INFO - 2025-10-29 13:35:33 --> URI Class Initialized
INFO - 2025-10-29 13:35:33 --> Router Class Initialized
INFO - 2025-10-29 13:35:33 --> Output Class Initialized
INFO - 2025-10-29 13:35:33 --> Security Class Initialized
DEBUG - 2025-10-29 13:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:35:33 --> Input Class Initialized
INFO - 2025-10-29 13:35:33 --> Language Class Initialized
INFO - 2025-10-29 13:35:33 --> Loader Class Initialized
INFO - 2025-10-29 13:35:33 --> Helper loaded: url_helper
INFO - 2025-10-29 13:35:33 --> Database Driver Class Initialized
INFO - 2025-10-29 13:35:33 --> Controller Class Initialized
INFO - 2025-10-29 13:35:33 --> Model "Student_model" initialized
INFO - 2025-10-29 13:35:33 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:35:33 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:35:33 --> Helper loaded: form_helper
INFO - 2025-10-29 13:35:33 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:35:33 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:35:33 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-29 13:35:33 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:35:33 --> Final output sent to browser
DEBUG - 2025-10-29 13:35:33 --> Total execution time: 0.1374
INFO - 2025-10-29 13:35:35 --> Config Class Initialized
INFO - 2025-10-29 13:35:35 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:35:35 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:35:35 --> Utf8 Class Initialized
INFO - 2025-10-29 13:35:35 --> URI Class Initialized
INFO - 2025-10-29 13:35:35 --> Router Class Initialized
INFO - 2025-10-29 13:35:35 --> Output Class Initialized
INFO - 2025-10-29 13:35:35 --> Security Class Initialized
DEBUG - 2025-10-29 13:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:35:35 --> Input Class Initialized
INFO - 2025-10-29 13:35:35 --> Language Class Initialized
INFO - 2025-10-29 13:35:35 --> Loader Class Initialized
INFO - 2025-10-29 13:35:35 --> Helper loaded: url_helper
INFO - 2025-10-29 13:35:35 --> Database Driver Class Initialized
INFO - 2025-10-29 13:35:35 --> Controller Class Initialized
INFO - 2025-10-29 13:35:35 --> Model "Student_model" initialized
INFO - 2025-10-29 13:35:35 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:35:35 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:35:35 --> Helper loaded: form_helper
INFO - 2025-10-29 13:35:35 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:35:35 --> Final output sent to browser
DEBUG - 2025-10-29 13:35:35 --> Total execution time: 0.0802
INFO - 2025-10-29 13:35:37 --> Config Class Initialized
INFO - 2025-10-29 13:35:37 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:35:37 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:35:37 --> Utf8 Class Initialized
INFO - 2025-10-29 13:35:37 --> URI Class Initialized
INFO - 2025-10-29 13:35:37 --> Router Class Initialized
INFO - 2025-10-29 13:35:37 --> Output Class Initialized
INFO - 2025-10-29 13:35:37 --> Security Class Initialized
DEBUG - 2025-10-29 13:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:35:37 --> Input Class Initialized
INFO - 2025-10-29 13:35:37 --> Language Class Initialized
INFO - 2025-10-29 13:35:37 --> Loader Class Initialized
INFO - 2025-10-29 13:35:37 --> Helper loaded: url_helper
INFO - 2025-10-29 13:35:37 --> Database Driver Class Initialized
INFO - 2025-10-29 13:35:37 --> Controller Class Initialized
INFO - 2025-10-29 13:35:37 --> Model "Student_model" initialized
INFO - 2025-10-29 13:35:37 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:35:37 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:35:37 --> Helper loaded: form_helper
INFO - 2025-10-29 13:35:37 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:35:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:35:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:35:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:35:37 --> Final output sent to browser
DEBUG - 2025-10-29 13:35:37 --> Total execution time: 0.0832
INFO - 2025-10-29 13:35:38 --> Config Class Initialized
INFO - 2025-10-29 13:35:38 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:35:38 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:35:38 --> Utf8 Class Initialized
INFO - 2025-10-29 13:35:38 --> URI Class Initialized
INFO - 2025-10-29 13:35:38 --> Router Class Initialized
INFO - 2025-10-29 13:35:38 --> Output Class Initialized
INFO - 2025-10-29 13:35:38 --> Security Class Initialized
DEBUG - 2025-10-29 13:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:35:38 --> Input Class Initialized
INFO - 2025-10-29 13:35:38 --> Language Class Initialized
ERROR - 2025-10-29 13:35:38 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:36:31 --> Config Class Initialized
INFO - 2025-10-29 13:36:31 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:36:31 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:36:31 --> Utf8 Class Initialized
INFO - 2025-10-29 13:36:31 --> URI Class Initialized
INFO - 2025-10-29 13:36:31 --> Router Class Initialized
INFO - 2025-10-29 13:36:31 --> Output Class Initialized
INFO - 2025-10-29 13:36:31 --> Security Class Initialized
DEBUG - 2025-10-29 13:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:36:31 --> Input Class Initialized
INFO - 2025-10-29 13:36:31 --> Language Class Initialized
ERROR - 2025-10-29 13:36:31 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:37:54 --> Config Class Initialized
INFO - 2025-10-29 13:37:54 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:37:54 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:37:54 --> Utf8 Class Initialized
INFO - 2025-10-29 13:37:54 --> URI Class Initialized
INFO - 2025-10-29 13:37:54 --> Router Class Initialized
INFO - 2025-10-29 13:37:54 --> Output Class Initialized
INFO - 2025-10-29 13:37:54 --> Security Class Initialized
DEBUG - 2025-10-29 13:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:37:54 --> Input Class Initialized
INFO - 2025-10-29 13:37:54 --> Language Class Initialized
ERROR - 2025-10-29 13:37:54 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:43:40 --> Config Class Initialized
INFO - 2025-10-29 13:43:40 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:43:40 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:43:40 --> Utf8 Class Initialized
INFO - 2025-10-29 13:43:40 --> URI Class Initialized
INFO - 2025-10-29 13:43:40 --> Router Class Initialized
INFO - 2025-10-29 13:43:40 --> Output Class Initialized
INFO - 2025-10-29 13:43:40 --> Security Class Initialized
DEBUG - 2025-10-29 13:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:43:40 --> Input Class Initialized
INFO - 2025-10-29 13:43:40 --> Language Class Initialized
INFO - 2025-10-29 13:43:40 --> Loader Class Initialized
INFO - 2025-10-29 13:43:40 --> Helper loaded: url_helper
INFO - 2025-10-29 13:43:40 --> Database Driver Class Initialized
INFO - 2025-10-29 13:43:40 --> Controller Class Initialized
INFO - 2025-10-29 13:43:40 --> Model "Student_model" initialized
INFO - 2025-10-29 13:43:40 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:43:40 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:43:40 --> Helper loaded: form_helper
INFO - 2025-10-29 13:43:40 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:43:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:43:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:43:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:43:40 --> Final output sent to browser
DEBUG - 2025-10-29 13:43:40 --> Total execution time: 0.1056
INFO - 2025-10-29 13:43:41 --> Config Class Initialized
INFO - 2025-10-29 13:43:41 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:43:41 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:43:41 --> Utf8 Class Initialized
INFO - 2025-10-29 13:43:41 --> URI Class Initialized
INFO - 2025-10-29 13:43:41 --> Router Class Initialized
INFO - 2025-10-29 13:43:41 --> Output Class Initialized
INFO - 2025-10-29 13:43:41 --> Security Class Initialized
DEBUG - 2025-10-29 13:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:43:41 --> Input Class Initialized
INFO - 2025-10-29 13:43:41 --> Language Class Initialized
ERROR - 2025-10-29 13:43:41 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:44:08 --> Config Class Initialized
INFO - 2025-10-29 13:44:08 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:44:08 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:44:08 --> Utf8 Class Initialized
INFO - 2025-10-29 13:44:08 --> URI Class Initialized
INFO - 2025-10-29 13:44:08 --> Router Class Initialized
INFO - 2025-10-29 13:44:08 --> Output Class Initialized
INFO - 2025-10-29 13:44:08 --> Security Class Initialized
DEBUG - 2025-10-29 13:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:44:08 --> Input Class Initialized
INFO - 2025-10-29 13:44:08 --> Language Class Initialized
ERROR - 2025-10-29 13:44:08 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:44:08 --> Config Class Initialized
INFO - 2025-10-29 13:44:08 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:44:08 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:44:08 --> Utf8 Class Initialized
INFO - 2025-10-29 13:44:08 --> URI Class Initialized
INFO - 2025-10-29 13:44:08 --> Router Class Initialized
INFO - 2025-10-29 13:44:08 --> Output Class Initialized
INFO - 2025-10-29 13:44:08 --> Security Class Initialized
DEBUG - 2025-10-29 13:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:44:08 --> Input Class Initialized
INFO - 2025-10-29 13:44:08 --> Language Class Initialized
ERROR - 2025-10-29 13:44:08 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:44:09 --> Config Class Initialized
INFO - 2025-10-29 13:44:09 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:44:09 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:44:09 --> Utf8 Class Initialized
INFO - 2025-10-29 13:44:09 --> URI Class Initialized
INFO - 2025-10-29 13:44:09 --> Router Class Initialized
INFO - 2025-10-29 13:44:09 --> Output Class Initialized
INFO - 2025-10-29 13:44:09 --> Security Class Initialized
DEBUG - 2025-10-29 13:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:44:09 --> Input Class Initialized
INFO - 2025-10-29 13:44:09 --> Language Class Initialized
ERROR - 2025-10-29 13:44:09 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:44:09 --> Config Class Initialized
INFO - 2025-10-29 13:44:09 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:44:09 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:44:09 --> Utf8 Class Initialized
INFO - 2025-10-29 13:44:09 --> URI Class Initialized
INFO - 2025-10-29 13:44:09 --> Router Class Initialized
INFO - 2025-10-29 13:44:09 --> Output Class Initialized
INFO - 2025-10-29 13:44:09 --> Security Class Initialized
DEBUG - 2025-10-29 13:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:44:09 --> Input Class Initialized
INFO - 2025-10-29 13:44:09 --> Language Class Initialized
ERROR - 2025-10-29 13:44:09 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:44:09 --> Config Class Initialized
INFO - 2025-10-29 13:44:09 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:44:09 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:44:09 --> Utf8 Class Initialized
INFO - 2025-10-29 13:44:09 --> URI Class Initialized
INFO - 2025-10-29 13:44:09 --> Router Class Initialized
INFO - 2025-10-29 13:44:09 --> Output Class Initialized
INFO - 2025-10-29 13:44:09 --> Security Class Initialized
DEBUG - 2025-10-29 13:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:44:09 --> Input Class Initialized
INFO - 2025-10-29 13:44:09 --> Language Class Initialized
ERROR - 2025-10-29 13:44:09 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:45:33 --> Config Class Initialized
INFO - 2025-10-29 13:45:33 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:45:33 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:45:33 --> Utf8 Class Initialized
INFO - 2025-10-29 13:45:33 --> URI Class Initialized
INFO - 2025-10-29 13:45:33 --> Router Class Initialized
INFO - 2025-10-29 13:45:33 --> Output Class Initialized
INFO - 2025-10-29 13:45:33 --> Security Class Initialized
DEBUG - 2025-10-29 13:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:45:33 --> Input Class Initialized
INFO - 2025-10-29 13:45:33 --> Language Class Initialized
INFO - 2025-10-29 13:45:33 --> Loader Class Initialized
INFO - 2025-10-29 13:45:33 --> Helper loaded: url_helper
INFO - 2025-10-29 13:45:33 --> Database Driver Class Initialized
INFO - 2025-10-29 13:45:33 --> Controller Class Initialized
INFO - 2025-10-29 13:45:33 --> Model "Student_model" initialized
INFO - 2025-10-29 13:45:33 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:45:33 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:45:33 --> Helper loaded: form_helper
INFO - 2025-10-29 13:45:33 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:45:33 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:45:33 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:45:33 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:45:33 --> Final output sent to browser
DEBUG - 2025-10-29 13:45:33 --> Total execution time: 0.0954
INFO - 2025-10-29 13:45:35 --> Config Class Initialized
INFO - 2025-10-29 13:45:35 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:45:35 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:45:35 --> Utf8 Class Initialized
INFO - 2025-10-29 13:45:35 --> URI Class Initialized
INFO - 2025-10-29 13:45:35 --> Router Class Initialized
INFO - 2025-10-29 13:45:35 --> Output Class Initialized
INFO - 2025-10-29 13:45:35 --> Security Class Initialized
DEBUG - 2025-10-29 13:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:45:35 --> Input Class Initialized
INFO - 2025-10-29 13:45:35 --> Language Class Initialized
INFO - 2025-10-29 13:45:35 --> Loader Class Initialized
INFO - 2025-10-29 13:45:35 --> Helper loaded: url_helper
INFO - 2025-10-29 13:45:35 --> Database Driver Class Initialized
INFO - 2025-10-29 13:45:35 --> Controller Class Initialized
INFO - 2025-10-29 13:45:35 --> Model "Student_model" initialized
INFO - 2025-10-29 13:45:35 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:45:35 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:45:35 --> Helper loaded: form_helper
INFO - 2025-10-29 13:45:35 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:45:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:45:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:45:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:45:35 --> Final output sent to browser
DEBUG - 2025-10-29 13:45:35 --> Total execution time: 0.0908
INFO - 2025-10-29 13:45:35 --> Config Class Initialized
INFO - 2025-10-29 13:45:35 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:45:35 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:45:35 --> Utf8 Class Initialized
INFO - 2025-10-29 13:45:35 --> URI Class Initialized
INFO - 2025-10-29 13:45:35 --> Router Class Initialized
INFO - 2025-10-29 13:45:35 --> Output Class Initialized
INFO - 2025-10-29 13:45:35 --> Security Class Initialized
DEBUG - 2025-10-29 13:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:45:35 --> Input Class Initialized
INFO - 2025-10-29 13:45:35 --> Language Class Initialized
INFO - 2025-10-29 13:45:35 --> Loader Class Initialized
INFO - 2025-10-29 13:45:35 --> Helper loaded: url_helper
INFO - 2025-10-29 13:45:35 --> Database Driver Class Initialized
INFO - 2025-10-29 13:45:35 --> Controller Class Initialized
INFO - 2025-10-29 13:45:35 --> Model "Student_model" initialized
INFO - 2025-10-29 13:45:35 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:45:35 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:45:35 --> Helper loaded: form_helper
INFO - 2025-10-29 13:45:35 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:45:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:45:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:45:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:45:35 --> Final output sent to browser
DEBUG - 2025-10-29 13:45:35 --> Total execution time: 0.0857
INFO - 2025-10-29 13:45:36 --> Config Class Initialized
INFO - 2025-10-29 13:45:36 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:45:36 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:45:36 --> Utf8 Class Initialized
INFO - 2025-10-29 13:45:36 --> URI Class Initialized
INFO - 2025-10-29 13:45:36 --> Router Class Initialized
INFO - 2025-10-29 13:45:36 --> Output Class Initialized
INFO - 2025-10-29 13:45:36 --> Security Class Initialized
DEBUG - 2025-10-29 13:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:45:36 --> Input Class Initialized
INFO - 2025-10-29 13:45:36 --> Language Class Initialized
INFO - 2025-10-29 13:45:36 --> Loader Class Initialized
INFO - 2025-10-29 13:45:36 --> Helper loaded: url_helper
INFO - 2025-10-29 13:45:36 --> Database Driver Class Initialized
INFO - 2025-10-29 13:45:36 --> Controller Class Initialized
INFO - 2025-10-29 13:45:36 --> Model "Student_model" initialized
INFO - 2025-10-29 13:45:36 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:45:36 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:45:36 --> Helper loaded: form_helper
INFO - 2025-10-29 13:45:36 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:45:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:45:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:45:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:45:36 --> Final output sent to browser
DEBUG - 2025-10-29 13:45:36 --> Total execution time: 0.1082
INFO - 2025-10-29 13:45:36 --> Config Class Initialized
INFO - 2025-10-29 13:45:36 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:45:36 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:45:36 --> Utf8 Class Initialized
INFO - 2025-10-29 13:45:36 --> URI Class Initialized
INFO - 2025-10-29 13:45:36 --> Router Class Initialized
INFO - 2025-10-29 13:45:36 --> Output Class Initialized
INFO - 2025-10-29 13:45:36 --> Security Class Initialized
DEBUG - 2025-10-29 13:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:45:36 --> Input Class Initialized
INFO - 2025-10-29 13:45:36 --> Language Class Initialized
INFO - 2025-10-29 13:45:36 --> Loader Class Initialized
INFO - 2025-10-29 13:45:36 --> Helper loaded: url_helper
INFO - 2025-10-29 13:45:36 --> Database Driver Class Initialized
INFO - 2025-10-29 13:45:36 --> Controller Class Initialized
INFO - 2025-10-29 13:45:36 --> Model "Student_model" initialized
INFO - 2025-10-29 13:45:36 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:45:36 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:45:36 --> Helper loaded: form_helper
INFO - 2025-10-29 13:45:36 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:45:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:45:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:45:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:45:36 --> Final output sent to browser
DEBUG - 2025-10-29 13:45:36 --> Total execution time: 0.0961
INFO - 2025-10-29 13:45:36 --> Config Class Initialized
INFO - 2025-10-29 13:45:36 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:45:36 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:45:36 --> Utf8 Class Initialized
INFO - 2025-10-29 13:45:36 --> URI Class Initialized
INFO - 2025-10-29 13:45:36 --> Router Class Initialized
INFO - 2025-10-29 13:45:36 --> Output Class Initialized
INFO - 2025-10-29 13:45:36 --> Security Class Initialized
DEBUG - 2025-10-29 13:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:45:36 --> Input Class Initialized
INFO - 2025-10-29 13:45:36 --> Language Class Initialized
INFO - 2025-10-29 13:45:36 --> Loader Class Initialized
INFO - 2025-10-29 13:45:36 --> Helper loaded: url_helper
INFO - 2025-10-29 13:45:36 --> Database Driver Class Initialized
INFO - 2025-10-29 13:45:36 --> Controller Class Initialized
INFO - 2025-10-29 13:45:36 --> Model "Student_model" initialized
INFO - 2025-10-29 13:45:36 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:45:36 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:45:36 --> Helper loaded: form_helper
INFO - 2025-10-29 13:45:36 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:45:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:45:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:45:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:45:36 --> Final output sent to browser
DEBUG - 2025-10-29 13:45:36 --> Total execution time: 0.0751
INFO - 2025-10-29 13:45:36 --> Config Class Initialized
INFO - 2025-10-29 13:45:36 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:45:36 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:45:36 --> Utf8 Class Initialized
INFO - 2025-10-29 13:45:36 --> URI Class Initialized
INFO - 2025-10-29 13:45:36 --> Router Class Initialized
INFO - 2025-10-29 13:45:36 --> Output Class Initialized
INFO - 2025-10-29 13:45:36 --> Security Class Initialized
DEBUG - 2025-10-29 13:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:45:36 --> Input Class Initialized
INFO - 2025-10-29 13:45:36 --> Language Class Initialized
INFO - 2025-10-29 13:45:36 --> Loader Class Initialized
INFO - 2025-10-29 13:45:36 --> Helper loaded: url_helper
INFO - 2025-10-29 13:45:36 --> Database Driver Class Initialized
INFO - 2025-10-29 13:45:36 --> Controller Class Initialized
INFO - 2025-10-29 13:45:36 --> Model "Student_model" initialized
INFO - 2025-10-29 13:45:36 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:45:36 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:45:36 --> Helper loaded: form_helper
INFO - 2025-10-29 13:45:36 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:45:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:45:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:45:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:45:36 --> Final output sent to browser
DEBUG - 2025-10-29 13:45:36 --> Total execution time: 0.0849
INFO - 2025-10-29 13:45:36 --> Config Class Initialized
INFO - 2025-10-29 13:45:36 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:45:36 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:45:36 --> Utf8 Class Initialized
INFO - 2025-10-29 13:45:36 --> URI Class Initialized
INFO - 2025-10-29 13:45:36 --> Router Class Initialized
INFO - 2025-10-29 13:45:36 --> Output Class Initialized
INFO - 2025-10-29 13:45:36 --> Security Class Initialized
DEBUG - 2025-10-29 13:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:45:37 --> Input Class Initialized
INFO - 2025-10-29 13:45:37 --> Language Class Initialized
INFO - 2025-10-29 13:45:37 --> Loader Class Initialized
INFO - 2025-10-29 13:45:37 --> Helper loaded: url_helper
INFO - 2025-10-29 13:45:37 --> Database Driver Class Initialized
INFO - 2025-10-29 13:45:37 --> Controller Class Initialized
INFO - 2025-10-29 13:45:37 --> Model "Student_model" initialized
INFO - 2025-10-29 13:45:37 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:45:37 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:45:37 --> Helper loaded: form_helper
INFO - 2025-10-29 13:45:37 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:45:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:45:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:45:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:45:37 --> Final output sent to browser
DEBUG - 2025-10-29 13:45:37 --> Total execution time: 0.0962
INFO - 2025-10-29 13:45:37 --> Config Class Initialized
INFO - 2025-10-29 13:45:37 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:45:37 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:45:37 --> Utf8 Class Initialized
INFO - 2025-10-29 13:45:37 --> URI Class Initialized
INFO - 2025-10-29 13:45:37 --> Router Class Initialized
INFO - 2025-10-29 13:45:37 --> Output Class Initialized
INFO - 2025-10-29 13:45:37 --> Security Class Initialized
DEBUG - 2025-10-29 13:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:45:37 --> Input Class Initialized
INFO - 2025-10-29 13:45:37 --> Language Class Initialized
INFO - 2025-10-29 13:45:37 --> Loader Class Initialized
INFO - 2025-10-29 13:45:37 --> Helper loaded: url_helper
INFO - 2025-10-29 13:45:37 --> Database Driver Class Initialized
INFO - 2025-10-29 13:45:37 --> Controller Class Initialized
INFO - 2025-10-29 13:45:37 --> Model "Student_model" initialized
INFO - 2025-10-29 13:45:37 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:45:37 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:45:37 --> Helper loaded: form_helper
INFO - 2025-10-29 13:45:37 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:45:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:45:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:45:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:45:37 --> Final output sent to browser
DEBUG - 2025-10-29 13:45:37 --> Total execution time: 0.0837
INFO - 2025-10-29 13:45:39 --> Config Class Initialized
INFO - 2025-10-29 13:45:39 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:45:39 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:45:39 --> Utf8 Class Initialized
INFO - 2025-10-29 13:45:39 --> URI Class Initialized
INFO - 2025-10-29 13:45:39 --> Router Class Initialized
INFO - 2025-10-29 13:45:39 --> Output Class Initialized
INFO - 2025-10-29 13:45:39 --> Security Class Initialized
DEBUG - 2025-10-29 13:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:45:39 --> Input Class Initialized
INFO - 2025-10-29 13:45:39 --> Language Class Initialized
ERROR - 2025-10-29 13:45:39 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:45:49 --> Config Class Initialized
INFO - 2025-10-29 13:45:49 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:45:49 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:45:49 --> Utf8 Class Initialized
INFO - 2025-10-29 13:45:49 --> URI Class Initialized
INFO - 2025-10-29 13:45:49 --> Router Class Initialized
INFO - 2025-10-29 13:45:49 --> Output Class Initialized
INFO - 2025-10-29 13:45:49 --> Security Class Initialized
DEBUG - 2025-10-29 13:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:45:49 --> Input Class Initialized
INFO - 2025-10-29 13:45:49 --> Language Class Initialized
INFO - 2025-10-29 13:45:49 --> Loader Class Initialized
INFO - 2025-10-29 13:45:49 --> Helper loaded: url_helper
INFO - 2025-10-29 13:45:49 --> Database Driver Class Initialized
INFO - 2025-10-29 13:45:49 --> Controller Class Initialized
INFO - 2025-10-29 13:45:49 --> Model "Student_model" initialized
INFO - 2025-10-29 13:45:49 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:45:49 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:45:49 --> Helper loaded: form_helper
INFO - 2025-10-29 13:45:49 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:45:49 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:45:49 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:45:49 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:45:49 --> Final output sent to browser
DEBUG - 2025-10-29 13:45:49 --> Total execution time: 0.1241
INFO - 2025-10-29 13:45:50 --> Config Class Initialized
INFO - 2025-10-29 13:45:50 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:45:50 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:45:50 --> Utf8 Class Initialized
INFO - 2025-10-29 13:45:50 --> URI Class Initialized
INFO - 2025-10-29 13:45:50 --> Router Class Initialized
INFO - 2025-10-29 13:45:50 --> Output Class Initialized
INFO - 2025-10-29 13:45:50 --> Security Class Initialized
DEBUG - 2025-10-29 13:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:45:50 --> Input Class Initialized
INFO - 2025-10-29 13:45:50 --> Language Class Initialized
INFO - 2025-10-29 13:45:50 --> Loader Class Initialized
INFO - 2025-10-29 13:45:50 --> Helper loaded: url_helper
INFO - 2025-10-29 13:45:50 --> Database Driver Class Initialized
INFO - 2025-10-29 13:45:50 --> Controller Class Initialized
INFO - 2025-10-29 13:45:50 --> Model "Student_model" initialized
INFO - 2025-10-29 13:45:50 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:45:50 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:45:50 --> Helper loaded: form_helper
INFO - 2025-10-29 13:45:50 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:45:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:45:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:45:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:45:50 --> Final output sent to browser
DEBUG - 2025-10-29 13:45:50 --> Total execution time: 0.1003
INFO - 2025-10-29 13:45:50 --> Config Class Initialized
INFO - 2025-10-29 13:45:50 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:45:50 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:45:50 --> Utf8 Class Initialized
INFO - 2025-10-29 13:45:50 --> URI Class Initialized
INFO - 2025-10-29 13:45:50 --> Router Class Initialized
INFO - 2025-10-29 13:45:50 --> Output Class Initialized
INFO - 2025-10-29 13:45:50 --> Security Class Initialized
DEBUG - 2025-10-29 13:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:45:50 --> Input Class Initialized
INFO - 2025-10-29 13:45:50 --> Language Class Initialized
INFO - 2025-10-29 13:45:50 --> Loader Class Initialized
INFO - 2025-10-29 13:45:50 --> Helper loaded: url_helper
INFO - 2025-10-29 13:45:50 --> Database Driver Class Initialized
INFO - 2025-10-29 13:45:50 --> Controller Class Initialized
INFO - 2025-10-29 13:45:50 --> Model "Student_model" initialized
INFO - 2025-10-29 13:45:50 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:45:50 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:45:50 --> Helper loaded: form_helper
INFO - 2025-10-29 13:45:50 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:45:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:45:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:45:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:45:50 --> Final output sent to browser
DEBUG - 2025-10-29 13:45:50 --> Total execution time: 0.1208
INFO - 2025-10-29 13:45:52 --> Config Class Initialized
INFO - 2025-10-29 13:45:52 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:45:52 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:45:52 --> Utf8 Class Initialized
INFO - 2025-10-29 13:45:52 --> URI Class Initialized
INFO - 2025-10-29 13:45:52 --> Router Class Initialized
INFO - 2025-10-29 13:45:52 --> Output Class Initialized
INFO - 2025-10-29 13:45:52 --> Security Class Initialized
DEBUG - 2025-10-29 13:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:45:52 --> Input Class Initialized
INFO - 2025-10-29 13:45:52 --> Language Class Initialized
ERROR - 2025-10-29 13:45:52 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:46:09 --> Config Class Initialized
INFO - 2025-10-29 13:46:09 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:46:09 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:46:09 --> Utf8 Class Initialized
INFO - 2025-10-29 13:46:09 --> URI Class Initialized
INFO - 2025-10-29 13:46:09 --> Router Class Initialized
INFO - 2025-10-29 13:46:09 --> Output Class Initialized
INFO - 2025-10-29 13:46:09 --> Security Class Initialized
DEBUG - 2025-10-29 13:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:46:09 --> Input Class Initialized
INFO - 2025-10-29 13:46:09 --> Language Class Initialized
ERROR - 2025-10-29 13:46:09 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 13:48:05 --> Config Class Initialized
INFO - 2025-10-29 13:48:05 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:48:05 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:48:05 --> Utf8 Class Initialized
INFO - 2025-10-29 13:48:05 --> URI Class Initialized
INFO - 2025-10-29 13:48:05 --> Router Class Initialized
INFO - 2025-10-29 13:48:05 --> Output Class Initialized
INFO - 2025-10-29 13:48:05 --> Security Class Initialized
DEBUG - 2025-10-29 13:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:48:05 --> Input Class Initialized
INFO - 2025-10-29 13:48:05 --> Language Class Initialized
INFO - 2025-10-29 13:48:05 --> Loader Class Initialized
INFO - 2025-10-29 13:48:05 --> Helper loaded: url_helper
INFO - 2025-10-29 13:48:05 --> Database Driver Class Initialized
INFO - 2025-10-29 13:48:05 --> Controller Class Initialized
INFO - 2025-10-29 13:48:05 --> Model "Student_model" initialized
INFO - 2025-10-29 13:48:05 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:48:05 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:48:05 --> Helper loaded: form_helper
INFO - 2025-10-29 13:48:05 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:48:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:48:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:48:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:48:05 --> Final output sent to browser
DEBUG - 2025-10-29 13:48:05 --> Total execution time: 0.1029
INFO - 2025-10-29 13:48:05 --> Config Class Initialized
INFO - 2025-10-29 13:48:05 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:48:05 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:48:05 --> Utf8 Class Initialized
INFO - 2025-10-29 13:48:05 --> URI Class Initialized
INFO - 2025-10-29 13:48:05 --> Router Class Initialized
INFO - 2025-10-29 13:48:05 --> Output Class Initialized
INFO - 2025-10-29 13:48:05 --> Security Class Initialized
DEBUG - 2025-10-29 13:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:48:05 --> Input Class Initialized
INFO - 2025-10-29 13:48:05 --> Language Class Initialized
INFO - 2025-10-29 13:48:05 --> Loader Class Initialized
INFO - 2025-10-29 13:48:05 --> Helper loaded: url_helper
INFO - 2025-10-29 13:48:05 --> Database Driver Class Initialized
INFO - 2025-10-29 13:48:05 --> Controller Class Initialized
INFO - 2025-10-29 13:48:05 --> Model "Student_model" initialized
INFO - 2025-10-29 13:48:05 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:48:05 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:48:05 --> Helper loaded: form_helper
INFO - 2025-10-29 13:48:05 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:48:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:48:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:48:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:48:05 --> Final output sent to browser
DEBUG - 2025-10-29 13:48:05 --> Total execution time: 0.1399
INFO - 2025-10-29 13:48:05 --> Config Class Initialized
INFO - 2025-10-29 13:48:05 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:48:05 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:48:05 --> Utf8 Class Initialized
INFO - 2025-10-29 13:48:05 --> URI Class Initialized
INFO - 2025-10-29 13:48:05 --> Router Class Initialized
INFO - 2025-10-29 13:48:05 --> Output Class Initialized
INFO - 2025-10-29 13:48:05 --> Security Class Initialized
DEBUG - 2025-10-29 13:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:48:05 --> Input Class Initialized
INFO - 2025-10-29 13:48:05 --> Language Class Initialized
INFO - 2025-10-29 13:48:05 --> Loader Class Initialized
INFO - 2025-10-29 13:48:06 --> Helper loaded: url_helper
INFO - 2025-10-29 13:48:06 --> Database Driver Class Initialized
INFO - 2025-10-29 13:48:06 --> Controller Class Initialized
INFO - 2025-10-29 13:48:06 --> Model "Student_model" initialized
INFO - 2025-10-29 13:48:06 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:48:06 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:48:06 --> Helper loaded: form_helper
INFO - 2025-10-29 13:48:06 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:48:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:48:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:48:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:48:06 --> Final output sent to browser
DEBUG - 2025-10-29 13:48:06 --> Total execution time: 0.0825
INFO - 2025-10-29 13:48:06 --> Config Class Initialized
INFO - 2025-10-29 13:48:06 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:48:06 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:48:06 --> Utf8 Class Initialized
INFO - 2025-10-29 13:48:06 --> URI Class Initialized
INFO - 2025-10-29 13:48:06 --> Router Class Initialized
INFO - 2025-10-29 13:48:06 --> Output Class Initialized
INFO - 2025-10-29 13:48:06 --> Security Class Initialized
DEBUG - 2025-10-29 13:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:48:06 --> Input Class Initialized
INFO - 2025-10-29 13:48:06 --> Language Class Initialized
INFO - 2025-10-29 13:48:06 --> Loader Class Initialized
INFO - 2025-10-29 13:48:06 --> Helper loaded: url_helper
INFO - 2025-10-29 13:48:06 --> Database Driver Class Initialized
INFO - 2025-10-29 13:48:06 --> Controller Class Initialized
INFO - 2025-10-29 13:48:06 --> Model "Student_model" initialized
INFO - 2025-10-29 13:48:06 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:48:06 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:48:06 --> Helper loaded: form_helper
INFO - 2025-10-29 13:48:06 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:48:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:48:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:48:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:48:06 --> Final output sent to browser
DEBUG - 2025-10-29 13:48:06 --> Total execution time: 0.1219
INFO - 2025-10-29 13:48:06 --> Config Class Initialized
INFO - 2025-10-29 13:48:06 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:48:06 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:48:06 --> Utf8 Class Initialized
INFO - 2025-10-29 13:48:06 --> URI Class Initialized
INFO - 2025-10-29 13:48:06 --> Router Class Initialized
INFO - 2025-10-29 13:48:06 --> Output Class Initialized
INFO - 2025-10-29 13:48:06 --> Security Class Initialized
DEBUG - 2025-10-29 13:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:48:06 --> Input Class Initialized
INFO - 2025-10-29 13:48:06 --> Language Class Initialized
INFO - 2025-10-29 13:48:06 --> Loader Class Initialized
INFO - 2025-10-29 13:48:06 --> Helper loaded: url_helper
INFO - 2025-10-29 13:48:06 --> Database Driver Class Initialized
INFO - 2025-10-29 13:48:06 --> Controller Class Initialized
INFO - 2025-10-29 13:48:06 --> Model "Student_model" initialized
INFO - 2025-10-29 13:48:06 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 13:48:06 --> Model "Payment_model" initialized
INFO - 2025-10-29 13:48:06 --> Helper loaded: form_helper
INFO - 2025-10-29 13:48:06 --> Form Validation Class Initialized
DEBUG - 2025-10-29 13:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 13:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 13:48:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 13:48:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 13:48:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 13:48:06 --> Final output sent to browser
DEBUG - 2025-10-29 13:48:06 --> Total execution time: 0.0920
INFO - 2025-10-29 13:48:08 --> Config Class Initialized
INFO - 2025-10-29 13:48:08 --> Hooks Class Initialized
DEBUG - 2025-10-29 13:48:08 --> UTF-8 Support Enabled
INFO - 2025-10-29 13:48:08 --> Utf8 Class Initialized
INFO - 2025-10-29 13:48:08 --> URI Class Initialized
INFO - 2025-10-29 13:48:08 --> Router Class Initialized
INFO - 2025-10-29 13:48:08 --> Output Class Initialized
INFO - 2025-10-29 13:48:08 --> Security Class Initialized
DEBUG - 2025-10-29 13:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 13:48:08 --> Input Class Initialized
INFO - 2025-10-29 13:48:08 --> Language Class Initialized
ERROR - 2025-10-29 13:48:08 --> 404 Page Not Found: Payments/create
INFO - 2025-10-29 14:15:17 --> Config Class Initialized
INFO - 2025-10-29 14:15:17 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:15:17 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:15:17 --> Utf8 Class Initialized
INFO - 2025-10-29 14:15:17 --> URI Class Initialized
INFO - 2025-10-29 14:15:17 --> Router Class Initialized
INFO - 2025-10-29 14:15:17 --> Output Class Initialized
INFO - 2025-10-29 14:15:17 --> Security Class Initialized
DEBUG - 2025-10-29 14:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:15:17 --> Input Class Initialized
INFO - 2025-10-29 14:15:17 --> Language Class Initialized
INFO - 2025-10-29 14:15:17 --> Loader Class Initialized
INFO - 2025-10-29 14:15:17 --> Helper loaded: url_helper
INFO - 2025-10-29 14:15:17 --> Database Driver Class Initialized
INFO - 2025-10-29 14:15:17 --> Controller Class Initialized
INFO - 2025-10-29 14:15:17 --> Model "Student_model" initialized
INFO - 2025-10-29 14:15:17 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:15:17 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:15:17 --> Helper loaded: form_helper
INFO - 2025-10-29 14:15:17 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:15:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:15:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 14:15:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:15:17 --> Final output sent to browser
DEBUG - 2025-10-29 14:15:17 --> Total execution time: 0.1241
INFO - 2025-10-29 14:15:18 --> Config Class Initialized
INFO - 2025-10-29 14:15:18 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:15:18 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:15:18 --> Utf8 Class Initialized
INFO - 2025-10-29 14:15:18 --> URI Class Initialized
INFO - 2025-10-29 14:15:18 --> Router Class Initialized
INFO - 2025-10-29 14:15:19 --> Output Class Initialized
INFO - 2025-10-29 14:15:19 --> Security Class Initialized
DEBUG - 2025-10-29 14:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:15:19 --> Input Class Initialized
INFO - 2025-10-29 14:15:19 --> Language Class Initialized
INFO - 2025-10-29 14:15:19 --> Loader Class Initialized
INFO - 2025-10-29 14:15:19 --> Helper loaded: url_helper
INFO - 2025-10-29 14:15:19 --> Database Driver Class Initialized
INFO - 2025-10-29 14:15:19 --> Controller Class Initialized
INFO - 2025-10-29 14:15:19 --> Model "Student_model" initialized
INFO - 2025-10-29 14:15:19 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:15:19 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:15:19 --> Helper loaded: form_helper
INFO - 2025-10-29 14:15:19 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:15:19 --> Payments Controller Loaded
INFO - 2025-10-29 14:15:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:15:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-29 14:15:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:15:19 --> Final output sent to browser
DEBUG - 2025-10-29 14:15:19 --> Total execution time: 0.0866
INFO - 2025-10-29 14:15:28 --> Config Class Initialized
INFO - 2025-10-29 14:15:28 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:15:28 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:15:28 --> Utf8 Class Initialized
INFO - 2025-10-29 14:15:28 --> URI Class Initialized
INFO - 2025-10-29 14:15:28 --> Router Class Initialized
INFO - 2025-10-29 14:15:28 --> Output Class Initialized
INFO - 2025-10-29 14:15:28 --> Security Class Initialized
DEBUG - 2025-10-29 14:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:15:28 --> Input Class Initialized
INFO - 2025-10-29 14:15:28 --> Language Class Initialized
INFO - 2025-10-29 14:15:28 --> Loader Class Initialized
INFO - 2025-10-29 14:15:28 --> Helper loaded: url_helper
INFO - 2025-10-29 14:15:28 --> Database Driver Class Initialized
INFO - 2025-10-29 14:15:28 --> Controller Class Initialized
INFO - 2025-10-29 14:15:28 --> Model "Student_model" initialized
INFO - 2025-10-29 14:15:28 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:15:28 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:15:28 --> Helper loaded: form_helper
INFO - 2025-10-29 14:15:28 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:15:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:15:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 14:15:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:15:28 --> Final output sent to browser
DEBUG - 2025-10-29 14:15:28 --> Total execution time: 0.1160
INFO - 2025-10-29 14:15:36 --> Config Class Initialized
INFO - 2025-10-29 14:15:36 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:15:36 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:15:36 --> Utf8 Class Initialized
INFO - 2025-10-29 14:15:36 --> URI Class Initialized
INFO - 2025-10-29 14:15:36 --> Router Class Initialized
INFO - 2025-10-29 14:15:36 --> Output Class Initialized
INFO - 2025-10-29 14:15:36 --> Security Class Initialized
DEBUG - 2025-10-29 14:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:15:36 --> Input Class Initialized
INFO - 2025-10-29 14:15:36 --> Language Class Initialized
INFO - 2025-10-29 14:15:36 --> Loader Class Initialized
INFO - 2025-10-29 14:15:36 --> Helper loaded: url_helper
INFO - 2025-10-29 14:15:36 --> Database Driver Class Initialized
INFO - 2025-10-29 14:15:36 --> Controller Class Initialized
INFO - 2025-10-29 14:15:36 --> Model "Student_model" initialized
INFO - 2025-10-29 14:15:36 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:15:36 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:15:36 --> Helper loaded: form_helper
INFO - 2025-10-29 14:15:36 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:15:36 --> Payments Controller Loaded
INFO - 2025-10-29 14:15:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:15:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-29 14:15:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:15:36 --> Final output sent to browser
DEBUG - 2025-10-29 14:15:36 --> Total execution time: 0.1251
INFO - 2025-10-29 14:15:40 --> Config Class Initialized
INFO - 2025-10-29 14:15:40 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:15:40 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:15:40 --> Utf8 Class Initialized
INFO - 2025-10-29 14:15:40 --> URI Class Initialized
INFO - 2025-10-29 14:15:40 --> Router Class Initialized
INFO - 2025-10-29 14:15:40 --> Output Class Initialized
INFO - 2025-10-29 14:15:40 --> Security Class Initialized
DEBUG - 2025-10-29 14:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:15:40 --> Input Class Initialized
INFO - 2025-10-29 14:15:40 --> Language Class Initialized
INFO - 2025-10-29 14:15:40 --> Loader Class Initialized
INFO - 2025-10-29 14:15:40 --> Helper loaded: url_helper
INFO - 2025-10-29 14:15:40 --> Database Driver Class Initialized
INFO - 2025-10-29 14:15:40 --> Controller Class Initialized
INFO - 2025-10-29 14:15:40 --> Model "Student_model" initialized
INFO - 2025-10-29 14:15:40 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:15:40 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:15:40 --> Helper loaded: form_helper
INFO - 2025-10-29 14:15:40 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:15:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:15:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-29 14:15:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:15:40 --> Final output sent to browser
DEBUG - 2025-10-29 14:15:40 --> Total execution time: 0.1007
INFO - 2025-10-29 14:15:42 --> Config Class Initialized
INFO - 2025-10-29 14:15:42 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:15:42 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:15:42 --> Utf8 Class Initialized
INFO - 2025-10-29 14:15:42 --> URI Class Initialized
INFO - 2025-10-29 14:15:42 --> Router Class Initialized
INFO - 2025-10-29 14:15:42 --> Output Class Initialized
INFO - 2025-10-29 14:15:42 --> Security Class Initialized
DEBUG - 2025-10-29 14:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:15:42 --> Input Class Initialized
INFO - 2025-10-29 14:15:42 --> Language Class Initialized
INFO - 2025-10-29 14:15:42 --> Loader Class Initialized
INFO - 2025-10-29 14:15:42 --> Helper loaded: url_helper
INFO - 2025-10-29 14:15:42 --> Database Driver Class Initialized
INFO - 2025-10-29 14:15:42 --> Controller Class Initialized
INFO - 2025-10-29 14:15:42 --> Model "Student_model" initialized
INFO - 2025-10-29 14:15:42 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:15:42 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:15:42 --> Helper loaded: form_helper
INFO - 2025-10-29 14:15:42 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:15:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:15:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 14:15:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:15:42 --> Final output sent to browser
DEBUG - 2025-10-29 14:15:42 --> Total execution time: 0.0989
INFO - 2025-10-29 14:15:48 --> Config Class Initialized
INFO - 2025-10-29 14:15:48 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:15:48 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:15:48 --> Utf8 Class Initialized
INFO - 2025-10-29 14:15:48 --> URI Class Initialized
DEBUG - 2025-10-29 14:15:48 --> No URI present. Default controller set.
INFO - 2025-10-29 14:15:48 --> Router Class Initialized
INFO - 2025-10-29 14:15:48 --> Output Class Initialized
INFO - 2025-10-29 14:15:48 --> Security Class Initialized
DEBUG - 2025-10-29 14:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:15:48 --> Input Class Initialized
INFO - 2025-10-29 14:15:48 --> Language Class Initialized
INFO - 2025-10-29 14:15:48 --> Loader Class Initialized
INFO - 2025-10-29 14:15:48 --> Helper loaded: url_helper
INFO - 2025-10-29 14:15:48 --> Database Driver Class Initialized
INFO - 2025-10-29 14:15:48 --> Controller Class Initialized
INFO - 2025-10-29 14:15:48 --> Model "Student_model" initialized
INFO - 2025-10-29 14:15:48 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:15:48 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 14:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:15:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:15:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-29 14:15:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:15:48 --> Final output sent to browser
DEBUG - 2025-10-29 14:15:48 --> Total execution time: 0.1063
INFO - 2025-10-29 14:15:51 --> Config Class Initialized
INFO - 2025-10-29 14:15:51 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:15:51 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:15:51 --> Utf8 Class Initialized
INFO - 2025-10-29 14:15:51 --> URI Class Initialized
INFO - 2025-10-29 14:15:51 --> Router Class Initialized
INFO - 2025-10-29 14:15:51 --> Output Class Initialized
INFO - 2025-10-29 14:15:51 --> Security Class Initialized
DEBUG - 2025-10-29 14:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:15:51 --> Input Class Initialized
INFO - 2025-10-29 14:15:51 --> Language Class Initialized
INFO - 2025-10-29 14:15:51 --> Loader Class Initialized
INFO - 2025-10-29 14:15:51 --> Helper loaded: url_helper
INFO - 2025-10-29 14:15:51 --> Database Driver Class Initialized
INFO - 2025-10-29 14:15:52 --> Controller Class Initialized
INFO - 2025-10-29 14:15:52 --> Model "Student_model" initialized
INFO - 2025-10-29 14:15:52 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:15:52 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:15:52 --> Helper loaded: form_helper
INFO - 2025-10-29 14:15:52 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:15:52 --> Payments Controller Loaded
INFO - 2025-10-29 14:15:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:15:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/index.php
INFO - 2025-10-29 14:15:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:15:52 --> Final output sent to browser
DEBUG - 2025-10-29 14:15:52 --> Total execution time: 0.0844
INFO - 2025-10-29 14:15:53 --> Config Class Initialized
INFO - 2025-10-29 14:15:53 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:15:53 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:15:53 --> Utf8 Class Initialized
INFO - 2025-10-29 14:15:53 --> URI Class Initialized
INFO - 2025-10-29 14:15:53 --> Router Class Initialized
INFO - 2025-10-29 14:15:53 --> Output Class Initialized
INFO - 2025-10-29 14:15:53 --> Security Class Initialized
DEBUG - 2025-10-29 14:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:15:53 --> Input Class Initialized
INFO - 2025-10-29 14:15:53 --> Language Class Initialized
INFO - 2025-10-29 14:15:53 --> Loader Class Initialized
INFO - 2025-10-29 14:15:53 --> Helper loaded: url_helper
INFO - 2025-10-29 14:15:54 --> Database Driver Class Initialized
INFO - 2025-10-29 14:15:54 --> Controller Class Initialized
INFO - 2025-10-29 14:15:54 --> Model "Student_model" initialized
INFO - 2025-10-29 14:15:54 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:15:54 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:15:54 --> Helper loaded: form_helper
INFO - 2025-10-29 14:15:54 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:15:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:15:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 14:15:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:15:54 --> Final output sent to browser
DEBUG - 2025-10-29 14:15:54 --> Total execution time: 0.0949
INFO - 2025-10-29 14:17:17 --> Config Class Initialized
INFO - 2025-10-29 14:17:17 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:17:17 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:17:17 --> Utf8 Class Initialized
INFO - 2025-10-29 14:17:17 --> URI Class Initialized
INFO - 2025-10-29 14:17:17 --> Router Class Initialized
INFO - 2025-10-29 14:17:17 --> Output Class Initialized
INFO - 2025-10-29 14:17:17 --> Security Class Initialized
DEBUG - 2025-10-29 14:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:17:17 --> Input Class Initialized
INFO - 2025-10-29 14:17:17 --> Language Class Initialized
INFO - 2025-10-29 14:17:17 --> Loader Class Initialized
INFO - 2025-10-29 14:17:17 --> Helper loaded: url_helper
INFO - 2025-10-29 14:17:17 --> Database Driver Class Initialized
INFO - 2025-10-29 14:17:17 --> Controller Class Initialized
INFO - 2025-10-29 14:17:17 --> Model "Student_model" initialized
INFO - 2025-10-29 14:17:17 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:17:17 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:17:17 --> Helper loaded: form_helper
INFO - 2025-10-29 14:17:18 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:17:18 --> Payments Controller Loaded
INFO - 2025-10-29 14:17:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:17:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-29 14:17:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:17:18 --> Final output sent to browser
DEBUG - 2025-10-29 14:17:18 --> Total execution time: 0.1186
INFO - 2025-10-29 14:19:18 --> Config Class Initialized
INFO - 2025-10-29 14:19:18 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:19:18 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:19:18 --> Utf8 Class Initialized
INFO - 2025-10-29 14:19:18 --> URI Class Initialized
INFO - 2025-10-29 14:19:18 --> Router Class Initialized
INFO - 2025-10-29 14:19:18 --> Output Class Initialized
INFO - 2025-10-29 14:19:18 --> Security Class Initialized
DEBUG - 2025-10-29 14:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:19:18 --> Input Class Initialized
INFO - 2025-10-29 14:19:18 --> Language Class Initialized
INFO - 2025-10-29 14:19:18 --> Loader Class Initialized
INFO - 2025-10-29 14:19:18 --> Helper loaded: url_helper
INFO - 2025-10-29 14:19:18 --> Database Driver Class Initialized
INFO - 2025-10-29 14:19:18 --> Controller Class Initialized
INFO - 2025-10-29 14:19:18 --> Model "Student_model" initialized
INFO - 2025-10-29 14:19:18 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:19:18 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:19:18 --> Helper loaded: form_helper
INFO - 2025-10-29 14:19:18 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:19:18 --> Payments Controller Loaded
INFO - 2025-10-29 14:19:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:19:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-29 14:19:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:19:18 --> Final output sent to browser
DEBUG - 2025-10-29 14:19:18 --> Total execution time: 0.0966
INFO - 2025-10-29 14:19:19 --> Config Class Initialized
INFO - 2025-10-29 14:19:19 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:19:19 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:19:19 --> Utf8 Class Initialized
INFO - 2025-10-29 14:19:19 --> URI Class Initialized
INFO - 2025-10-29 14:19:19 --> Router Class Initialized
INFO - 2025-10-29 14:19:19 --> Output Class Initialized
INFO - 2025-10-29 14:19:19 --> Security Class Initialized
DEBUG - 2025-10-29 14:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:19:19 --> Input Class Initialized
INFO - 2025-10-29 14:19:19 --> Language Class Initialized
INFO - 2025-10-29 14:19:19 --> Loader Class Initialized
INFO - 2025-10-29 14:19:19 --> Helper loaded: url_helper
INFO - 2025-10-29 14:19:19 --> Database Driver Class Initialized
INFO - 2025-10-29 14:19:19 --> Controller Class Initialized
INFO - 2025-10-29 14:19:19 --> Model "Student_model" initialized
INFO - 2025-10-29 14:19:19 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:19:19 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:19:19 --> Helper loaded: form_helper
INFO - 2025-10-29 14:19:19 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:19:20 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:19:20 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-29 14:19:20 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:19:20 --> Final output sent to browser
DEBUG - 2025-10-29 14:19:20 --> Total execution time: 0.0921
INFO - 2025-10-29 14:19:21 --> Config Class Initialized
INFO - 2025-10-29 14:19:21 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:19:21 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:19:21 --> Utf8 Class Initialized
INFO - 2025-10-29 14:19:21 --> URI Class Initialized
INFO - 2025-10-29 14:19:21 --> Router Class Initialized
INFO - 2025-10-29 14:19:21 --> Output Class Initialized
INFO - 2025-10-29 14:19:21 --> Security Class Initialized
DEBUG - 2025-10-29 14:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:19:21 --> Input Class Initialized
INFO - 2025-10-29 14:19:21 --> Language Class Initialized
INFO - 2025-10-29 14:19:21 --> Loader Class Initialized
INFO - 2025-10-29 14:19:21 --> Helper loaded: url_helper
INFO - 2025-10-29 14:19:21 --> Database Driver Class Initialized
INFO - 2025-10-29 14:19:21 --> Controller Class Initialized
INFO - 2025-10-29 14:19:21 --> Model "Student_model" initialized
INFO - 2025-10-29 14:19:21 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:19:21 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:19:21 --> Helper loaded: form_helper
INFO - 2025-10-29 14:19:21 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:19:21 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:19:21 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 14:19:21 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:19:21 --> Final output sent to browser
DEBUG - 2025-10-29 14:19:21 --> Total execution time: 0.0793
INFO - 2025-10-29 14:19:24 --> Config Class Initialized
INFO - 2025-10-29 14:19:24 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:19:24 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:19:24 --> Utf8 Class Initialized
INFO - 2025-10-29 14:19:24 --> URI Class Initialized
INFO - 2025-10-29 14:19:24 --> Router Class Initialized
INFO - 2025-10-29 14:19:24 --> Output Class Initialized
INFO - 2025-10-29 14:19:24 --> Security Class Initialized
DEBUG - 2025-10-29 14:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:19:24 --> Input Class Initialized
INFO - 2025-10-29 14:19:24 --> Language Class Initialized
INFO - 2025-10-29 14:19:24 --> Loader Class Initialized
INFO - 2025-10-29 14:19:24 --> Helper loaded: url_helper
INFO - 2025-10-29 14:19:24 --> Database Driver Class Initialized
INFO - 2025-10-29 14:19:24 --> Controller Class Initialized
INFO - 2025-10-29 14:19:24 --> Model "Student_model" initialized
INFO - 2025-10-29 14:19:24 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:19:24 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:19:24 --> Helper loaded: form_helper
INFO - 2025-10-29 14:19:24 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:19:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:19:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 14:19:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:19:24 --> Final output sent to browser
DEBUG - 2025-10-29 14:19:24 --> Total execution time: 0.1193
INFO - 2025-10-29 14:19:26 --> Config Class Initialized
INFO - 2025-10-29 14:19:26 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:19:26 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:19:26 --> Utf8 Class Initialized
INFO - 2025-10-29 14:19:26 --> URI Class Initialized
DEBUG - 2025-10-29 14:19:26 --> No URI present. Default controller set.
INFO - 2025-10-29 14:19:26 --> Router Class Initialized
INFO - 2025-10-29 14:19:26 --> Output Class Initialized
INFO - 2025-10-29 14:19:26 --> Security Class Initialized
DEBUG - 2025-10-29 14:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:19:26 --> Input Class Initialized
INFO - 2025-10-29 14:19:26 --> Language Class Initialized
INFO - 2025-10-29 14:19:26 --> Loader Class Initialized
INFO - 2025-10-29 14:19:26 --> Helper loaded: url_helper
INFO - 2025-10-29 14:19:26 --> Database Driver Class Initialized
INFO - 2025-10-29 14:19:26 --> Controller Class Initialized
INFO - 2025-10-29 14:19:26 --> Model "Student_model" initialized
INFO - 2025-10-29 14:19:26 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:19:26 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 14:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:19:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:19:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-29 14:19:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:19:26 --> Final output sent to browser
DEBUG - 2025-10-29 14:19:26 --> Total execution time: 0.0933
INFO - 2025-10-29 14:19:36 --> Config Class Initialized
INFO - 2025-10-29 14:19:36 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:19:37 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:19:37 --> Utf8 Class Initialized
INFO - 2025-10-29 14:19:37 --> URI Class Initialized
INFO - 2025-10-29 14:19:37 --> Router Class Initialized
INFO - 2025-10-29 14:19:37 --> Output Class Initialized
INFO - 2025-10-29 14:19:37 --> Security Class Initialized
DEBUG - 2025-10-29 14:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:19:37 --> Input Class Initialized
INFO - 2025-10-29 14:19:37 --> Language Class Initialized
INFO - 2025-10-29 14:19:37 --> Loader Class Initialized
INFO - 2025-10-29 14:19:37 --> Helper loaded: url_helper
INFO - 2025-10-29 14:19:37 --> Database Driver Class Initialized
INFO - 2025-10-29 14:19:37 --> Controller Class Initialized
INFO - 2025-10-29 14:19:37 --> Model "Student_model" initialized
INFO - 2025-10-29 14:19:37 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:19:37 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:19:37 --> Helper loaded: form_helper
INFO - 2025-10-29 14:19:37 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:19:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:19:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 14:19:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:19:37 --> Final output sent to browser
DEBUG - 2025-10-29 14:19:37 --> Total execution time: 0.1038
INFO - 2025-10-29 14:19:38 --> Config Class Initialized
INFO - 2025-10-29 14:19:38 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:19:38 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:19:38 --> Utf8 Class Initialized
INFO - 2025-10-29 14:19:38 --> URI Class Initialized
INFO - 2025-10-29 14:19:38 --> Router Class Initialized
INFO - 2025-10-29 14:19:38 --> Output Class Initialized
INFO - 2025-10-29 14:19:38 --> Security Class Initialized
DEBUG - 2025-10-29 14:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:19:38 --> Input Class Initialized
INFO - 2025-10-29 14:19:38 --> Language Class Initialized
INFO - 2025-10-29 14:19:38 --> Loader Class Initialized
INFO - 2025-10-29 14:19:38 --> Helper loaded: url_helper
INFO - 2025-10-29 14:19:38 --> Database Driver Class Initialized
INFO - 2025-10-29 14:19:38 --> Controller Class Initialized
INFO - 2025-10-29 14:19:38 --> Model "Student_model" initialized
INFO - 2025-10-29 14:19:38 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:19:38 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:19:38 --> Helper loaded: form_helper
INFO - 2025-10-29 14:19:38 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:19:38 --> Payments Controller Loaded
INFO - 2025-10-29 14:19:38 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:19:38 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-29 14:19:38 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:19:38 --> Final output sent to browser
DEBUG - 2025-10-29 14:19:38 --> Total execution time: 0.1297
INFO - 2025-10-29 14:19:42 --> Config Class Initialized
INFO - 2025-10-29 14:19:42 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:19:42 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:19:42 --> Utf8 Class Initialized
INFO - 2025-10-29 14:19:42 --> URI Class Initialized
DEBUG - 2025-10-29 14:19:42 --> No URI present. Default controller set.
INFO - 2025-10-29 14:19:42 --> Router Class Initialized
INFO - 2025-10-29 14:19:42 --> Output Class Initialized
INFO - 2025-10-29 14:19:42 --> Security Class Initialized
DEBUG - 2025-10-29 14:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:19:42 --> Input Class Initialized
INFO - 2025-10-29 14:19:42 --> Language Class Initialized
INFO - 2025-10-29 14:19:42 --> Loader Class Initialized
INFO - 2025-10-29 14:19:42 --> Helper loaded: url_helper
INFO - 2025-10-29 14:19:42 --> Database Driver Class Initialized
INFO - 2025-10-29 14:19:42 --> Controller Class Initialized
INFO - 2025-10-29 14:19:42 --> Model "Student_model" initialized
INFO - 2025-10-29 14:19:42 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:19:42 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 14:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:19:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:19:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-29 14:19:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:19:42 --> Final output sent to browser
DEBUG - 2025-10-29 14:19:42 --> Total execution time: 0.1202
INFO - 2025-10-29 14:19:59 --> Config Class Initialized
INFO - 2025-10-29 14:19:59 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:19:59 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:19:59 --> Utf8 Class Initialized
INFO - 2025-10-29 14:19:59 --> URI Class Initialized
DEBUG - 2025-10-29 14:19:59 --> No URI present. Default controller set.
INFO - 2025-10-29 14:19:59 --> Router Class Initialized
INFO - 2025-10-29 14:19:59 --> Output Class Initialized
INFO - 2025-10-29 14:19:59 --> Security Class Initialized
DEBUG - 2025-10-29 14:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:19:59 --> Input Class Initialized
INFO - 2025-10-29 14:19:59 --> Language Class Initialized
INFO - 2025-10-29 14:19:59 --> Loader Class Initialized
INFO - 2025-10-29 14:19:59 --> Helper loaded: url_helper
INFO - 2025-10-29 14:19:59 --> Database Driver Class Initialized
INFO - 2025-10-29 14:19:59 --> Controller Class Initialized
INFO - 2025-10-29 14:19:59 --> Model "Student_model" initialized
INFO - 2025-10-29 14:19:59 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:19:59 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 14:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:19:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:19:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-29 14:19:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:19:59 --> Final output sent to browser
DEBUG - 2025-10-29 14:19:59 --> Total execution time: 0.0928
INFO - 2025-10-29 14:20:03 --> Config Class Initialized
INFO - 2025-10-29 14:20:03 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:20:03 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:20:03 --> Utf8 Class Initialized
INFO - 2025-10-29 14:20:03 --> URI Class Initialized
INFO - 2025-10-29 14:20:03 --> Router Class Initialized
INFO - 2025-10-29 14:20:03 --> Output Class Initialized
INFO - 2025-10-29 14:20:03 --> Security Class Initialized
DEBUG - 2025-10-29 14:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:20:03 --> Input Class Initialized
INFO - 2025-10-29 14:20:03 --> Language Class Initialized
INFO - 2025-10-29 14:20:03 --> Loader Class Initialized
INFO - 2025-10-29 14:20:03 --> Helper loaded: url_helper
INFO - 2025-10-29 14:20:03 --> Database Driver Class Initialized
INFO - 2025-10-29 14:20:03 --> Controller Class Initialized
INFO - 2025-10-29 14:20:03 --> Model "Student_model" initialized
INFO - 2025-10-29 14:20:03 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:20:03 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:20:03 --> Helper loaded: form_helper
INFO - 2025-10-29 14:20:03 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:20:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:20:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 14:20:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:20:03 --> Final output sent to browser
DEBUG - 2025-10-29 14:20:03 --> Total execution time: 0.1266
INFO - 2025-10-29 14:20:09 --> Config Class Initialized
INFO - 2025-10-29 14:20:09 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:20:09 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:20:09 --> Utf8 Class Initialized
INFO - 2025-10-29 14:20:09 --> URI Class Initialized
INFO - 2025-10-29 14:20:09 --> Router Class Initialized
INFO - 2025-10-29 14:20:09 --> Output Class Initialized
INFO - 2025-10-29 14:20:09 --> Security Class Initialized
DEBUG - 2025-10-29 14:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:20:09 --> Input Class Initialized
INFO - 2025-10-29 14:20:09 --> Language Class Initialized
INFO - 2025-10-29 14:20:09 --> Loader Class Initialized
INFO - 2025-10-29 14:20:09 --> Helper loaded: url_helper
INFO - 2025-10-29 14:20:09 --> Database Driver Class Initialized
INFO - 2025-10-29 14:20:09 --> Controller Class Initialized
INFO - 2025-10-29 14:20:09 --> Model "Student_model" initialized
INFO - 2025-10-29 14:20:09 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:20:09 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:20:09 --> Helper loaded: form_helper
INFO - 2025-10-29 14:20:09 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:20:09 --> Payments Controller Loaded
INFO - 2025-10-29 14:20:09 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:20:09 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-29 14:20:09 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:20:09 --> Final output sent to browser
DEBUG - 2025-10-29 14:20:09 --> Total execution time: 0.1146
INFO - 2025-10-29 14:20:14 --> Config Class Initialized
INFO - 2025-10-29 14:20:14 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:20:14 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:20:14 --> Utf8 Class Initialized
INFO - 2025-10-29 14:20:14 --> URI Class Initialized
INFO - 2025-10-29 14:20:14 --> Router Class Initialized
INFO - 2025-10-29 14:20:14 --> Output Class Initialized
INFO - 2025-10-29 14:20:14 --> Security Class Initialized
DEBUG - 2025-10-29 14:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:20:14 --> Input Class Initialized
INFO - 2025-10-29 14:20:14 --> Language Class Initialized
INFO - 2025-10-29 14:20:14 --> Loader Class Initialized
INFO - 2025-10-29 14:20:14 --> Helper loaded: url_helper
INFO - 2025-10-29 14:20:14 --> Database Driver Class Initialized
INFO - 2025-10-29 14:20:14 --> Controller Class Initialized
INFO - 2025-10-29 14:20:14 --> Model "Student_model" initialized
INFO - 2025-10-29 14:20:14 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:20:14 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:20:14 --> Helper loaded: form_helper
INFO - 2025-10-29 14:20:14 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:20:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:20:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-29 14:20:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:20:14 --> Final output sent to browser
DEBUG - 2025-10-29 14:20:14 --> Total execution time: 0.1001
INFO - 2025-10-29 14:20:16 --> Config Class Initialized
INFO - 2025-10-29 14:20:16 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:20:16 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:20:16 --> Utf8 Class Initialized
INFO - 2025-10-29 14:20:16 --> URI Class Initialized
INFO - 2025-10-29 14:20:16 --> Router Class Initialized
INFO - 2025-10-29 14:20:16 --> Output Class Initialized
INFO - 2025-10-29 14:20:16 --> Security Class Initialized
DEBUG - 2025-10-29 14:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:20:16 --> Input Class Initialized
INFO - 2025-10-29 14:20:16 --> Language Class Initialized
INFO - 2025-10-29 14:20:16 --> Loader Class Initialized
INFO - 2025-10-29 14:20:16 --> Helper loaded: url_helper
INFO - 2025-10-29 14:20:16 --> Database Driver Class Initialized
INFO - 2025-10-29 14:20:16 --> Controller Class Initialized
INFO - 2025-10-29 14:20:16 --> Model "Student_model" initialized
INFO - 2025-10-29 14:20:16 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:20:16 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:20:16 --> Helper loaded: form_helper
INFO - 2025-10-29 14:20:16 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:20:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:20:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 14:20:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:20:16 --> Final output sent to browser
DEBUG - 2025-10-29 14:20:16 --> Total execution time: 0.1023
INFO - 2025-10-29 14:20:21 --> Config Class Initialized
INFO - 2025-10-29 14:20:21 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:20:21 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:20:21 --> Utf8 Class Initialized
INFO - 2025-10-29 14:20:21 --> URI Class Initialized
INFO - 2025-10-29 14:20:21 --> Router Class Initialized
INFO - 2025-10-29 14:20:21 --> Output Class Initialized
INFO - 2025-10-29 14:20:21 --> Security Class Initialized
DEBUG - 2025-10-29 14:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:20:21 --> Input Class Initialized
INFO - 2025-10-29 14:20:21 --> Language Class Initialized
INFO - 2025-10-29 14:20:21 --> Loader Class Initialized
INFO - 2025-10-29 14:20:21 --> Helper loaded: url_helper
INFO - 2025-10-29 14:20:21 --> Database Driver Class Initialized
INFO - 2025-10-29 14:20:21 --> Controller Class Initialized
INFO - 2025-10-29 14:20:21 --> Model "Student_model" initialized
INFO - 2025-10-29 14:20:21 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:20:21 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:20:21 --> Helper loaded: form_helper
INFO - 2025-10-29 14:20:21 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:20:21 --> Payments Controller Loaded
INFO - 2025-10-29 14:20:21 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:20:21 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-29 14:20:21 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:20:21 --> Final output sent to browser
DEBUG - 2025-10-29 14:20:21 --> Total execution time: 0.0841
INFO - 2025-10-29 14:20:33 --> Config Class Initialized
INFO - 2025-10-29 14:20:33 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:20:33 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:20:33 --> Utf8 Class Initialized
INFO - 2025-10-29 14:20:33 --> URI Class Initialized
INFO - 2025-10-29 14:20:33 --> Router Class Initialized
INFO - 2025-10-29 14:20:33 --> Output Class Initialized
INFO - 2025-10-29 14:20:33 --> Security Class Initialized
DEBUG - 2025-10-29 14:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:20:33 --> Input Class Initialized
INFO - 2025-10-29 14:20:33 --> Language Class Initialized
INFO - 2025-10-29 14:20:33 --> Loader Class Initialized
INFO - 2025-10-29 14:20:33 --> Helper loaded: url_helper
INFO - 2025-10-29 14:20:33 --> Database Driver Class Initialized
INFO - 2025-10-29 14:20:33 --> Controller Class Initialized
INFO - 2025-10-29 14:20:33 --> Model "Student_model" initialized
INFO - 2025-10-29 14:20:33 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:20:33 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:20:33 --> Helper loaded: form_helper
INFO - 2025-10-29 14:20:33 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:20:33 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:20:33 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 14:20:33 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:20:33 --> Final output sent to browser
DEBUG - 2025-10-29 14:20:33 --> Total execution time: 0.0855
INFO - 2025-10-29 14:20:52 --> Config Class Initialized
INFO - 2025-10-29 14:20:52 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:20:52 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:20:52 --> Utf8 Class Initialized
INFO - 2025-10-29 14:20:52 --> URI Class Initialized
DEBUG - 2025-10-29 14:20:52 --> No URI present. Default controller set.
INFO - 2025-10-29 14:20:52 --> Router Class Initialized
INFO - 2025-10-29 14:20:52 --> Output Class Initialized
INFO - 2025-10-29 14:20:52 --> Security Class Initialized
DEBUG - 2025-10-29 14:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:20:52 --> Input Class Initialized
INFO - 2025-10-29 14:20:52 --> Language Class Initialized
INFO - 2025-10-29 14:20:52 --> Loader Class Initialized
INFO - 2025-10-29 14:20:52 --> Helper loaded: url_helper
INFO - 2025-10-29 14:20:52 --> Database Driver Class Initialized
INFO - 2025-10-29 14:20:52 --> Controller Class Initialized
INFO - 2025-10-29 14:20:52 --> Model "Student_model" initialized
INFO - 2025-10-29 14:20:52 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:20:52 --> Model "Payment_model" initialized
DEBUG - 2025-10-29 14:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:20:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:20:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-29 14:20:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:20:52 --> Final output sent to browser
DEBUG - 2025-10-29 14:20:52 --> Total execution time: 0.1190
INFO - 2025-10-29 14:21:42 --> Config Class Initialized
INFO - 2025-10-29 14:21:42 --> Hooks Class Initialized
DEBUG - 2025-10-29 14:21:42 --> UTF-8 Support Enabled
INFO - 2025-10-29 14:21:42 --> Utf8 Class Initialized
INFO - 2025-10-29 14:21:42 --> URI Class Initialized
INFO - 2025-10-29 14:21:42 --> Router Class Initialized
INFO - 2025-10-29 14:21:42 --> Output Class Initialized
INFO - 2025-10-29 14:21:42 --> Security Class Initialized
DEBUG - 2025-10-29 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-29 14:21:42 --> Input Class Initialized
INFO - 2025-10-29 14:21:42 --> Language Class Initialized
INFO - 2025-10-29 14:21:42 --> Loader Class Initialized
INFO - 2025-10-29 14:21:42 --> Helper loaded: url_helper
INFO - 2025-10-29 14:21:42 --> Database Driver Class Initialized
INFO - 2025-10-29 14:21:42 --> Controller Class Initialized
INFO - 2025-10-29 14:21:42 --> Model "Student_model" initialized
INFO - 2025-10-29 14:21:42 --> Model "Student_fee_model" initialized
INFO - 2025-10-29 14:21:42 --> Model "Payment_model" initialized
INFO - 2025-10-29 14:21:42 --> Helper loaded: form_helper
INFO - 2025-10-29 14:21:42 --> Form Validation Class Initialized
DEBUG - 2025-10-29 14:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-29 14:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-29 14:21:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-29 14:21:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-29 14:21:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-29 14:21:42 --> Final output sent to browser
DEBUG - 2025-10-29 14:21:42 --> Total execution time: 0.0857
