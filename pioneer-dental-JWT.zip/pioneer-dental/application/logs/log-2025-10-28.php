<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-10-28 12:16:26 --> Config Class Initialized
INFO - 2025-10-28 12:16:26 --> Hooks Class Initialized
DEBUG - 2025-10-28 12:16:26 --> UTF-8 Support Enabled
INFO - 2025-10-28 12:16:26 --> Utf8 Class Initialized
INFO - 2025-10-28 12:16:26 --> URI Class Initialized
INFO - 2025-10-28 12:16:26 --> Router Class Initialized
INFO - 2025-10-28 12:16:26 --> Output Class Initialized
INFO - 2025-10-28 12:16:26 --> Security Class Initialized
DEBUG - 2025-10-28 12:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-28 12:16:26 --> Input Class Initialized
INFO - 2025-10-28 12:16:26 --> Language Class Initialized
INFO - 2025-10-28 12:16:26 --> Loader Class Initialized
INFO - 2025-10-28 12:16:26 --> Helper loaded: url_helper
INFO - 2025-10-28 12:16:26 --> Database Driver Class Initialized
INFO - 2025-10-28 12:16:26 --> Controller Class Initialized
INFO - 2025-10-28 12:16:26 --> Model "Student_model" initialized
INFO - 2025-10-28 12:16:26 --> Model "Student_fee_model" initialized
INFO - 2025-10-28 12:16:26 --> Model "Payment_model" initialized
INFO - 2025-10-28 12:16:26 --> Helper loaded: form_helper
INFO - 2025-10-28 12:16:26 --> Form Validation Class Initialized
DEBUG - 2025-10-28 12:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-28 12:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-28 12:52:27 --> Config Class Initialized
INFO - 2025-10-28 12:52:27 --> Hooks Class Initialized
DEBUG - 2025-10-28 12:52:27 --> UTF-8 Support Enabled
INFO - 2025-10-28 12:52:27 --> Utf8 Class Initialized
INFO - 2025-10-28 12:52:27 --> URI Class Initialized
INFO - 2025-10-28 12:52:27 --> Router Class Initialized
INFO - 2025-10-28 12:52:27 --> Output Class Initialized
INFO - 2025-10-28 12:52:27 --> Security Class Initialized
DEBUG - 2025-10-28 12:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-28 12:52:27 --> Input Class Initialized
INFO - 2025-10-28 12:52:27 --> Language Class Initialized
ERROR - 2025-10-28 12:52:27 --> 404 Page Not Found: /index
INFO - 2025-10-28 12:57:12 --> Config Class Initialized
INFO - 2025-10-28 12:57:12 --> Hooks Class Initialized
DEBUG - 2025-10-28 12:57:12 --> UTF-8 Support Enabled
INFO - 2025-10-28 12:57:12 --> Utf8 Class Initialized
INFO - 2025-10-28 12:57:12 --> URI Class Initialized
INFO - 2025-10-28 12:57:12 --> Router Class Initialized
INFO - 2025-10-28 12:57:12 --> Output Class Initialized
INFO - 2025-10-28 12:57:12 --> Security Class Initialized
DEBUG - 2025-10-28 12:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-28 12:57:12 --> Input Class Initialized
INFO - 2025-10-28 12:57:12 --> Language Class Initialized
INFO - 2025-10-28 12:57:12 --> Loader Class Initialized
INFO - 2025-10-28 12:57:12 --> Helper loaded: url_helper
INFO - 2025-10-28 12:57:12 --> Database Driver Class Initialized
INFO - 2025-10-28 12:57:12 --> Controller Class Initialized
INFO - 2025-10-28 12:57:12 --> Model "Student_model" initialized
INFO - 2025-10-28 12:57:12 --> Model "Student_fee_model" initialized
INFO - 2025-10-28 12:57:12 --> Model "Payment_model" initialized
INFO - 2025-10-28 12:57:12 --> Helper loaded: form_helper
INFO - 2025-10-28 12:57:12 --> Form Validation Class Initialized
DEBUG - 2025-10-28 12:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-28 12:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-28 12:57:12 --> Config Class Initialized
INFO - 2025-10-28 12:57:12 --> Hooks Class Initialized
DEBUG - 2025-10-28 12:57:12 --> UTF-8 Support Enabled
INFO - 2025-10-28 12:57:12 --> Utf8 Class Initialized
INFO - 2025-10-28 12:57:12 --> URI Class Initialized
INFO - 2025-10-28 12:57:13 --> Router Class Initialized
INFO - 2025-10-28 12:57:13 --> Output Class Initialized
INFO - 2025-10-28 12:57:13 --> Security Class Initialized
DEBUG - 2025-10-28 12:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-28 12:57:13 --> Input Class Initialized
INFO - 2025-10-28 12:57:13 --> Language Class Initialized
INFO - 2025-10-28 12:57:13 --> Loader Class Initialized
INFO - 2025-10-28 12:57:13 --> Helper loaded: url_helper
INFO - 2025-10-28 12:57:13 --> Database Driver Class Initialized
INFO - 2025-10-28 12:57:13 --> Controller Class Initialized
INFO - 2025-10-28 12:57:13 --> Model "Student_model" initialized
INFO - 2025-10-28 12:57:13 --> Model "Student_fee_model" initialized
INFO - 2025-10-28 12:57:13 --> Model "Payment_model" initialized
INFO - 2025-10-28 12:57:13 --> Helper loaded: form_helper
INFO - 2025-10-28 12:57:13 --> Form Validation Class Initialized
DEBUG - 2025-10-28 12:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-28 12:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-28 13:04:41 --> Config Class Initialized
INFO - 2025-10-28 13:04:41 --> Hooks Class Initialized
DEBUG - 2025-10-28 13:04:41 --> UTF-8 Support Enabled
INFO - 2025-10-28 13:04:41 --> Utf8 Class Initialized
INFO - 2025-10-28 13:04:41 --> URI Class Initialized
INFO - 2025-10-28 13:04:41 --> Router Class Initialized
INFO - 2025-10-28 13:04:41 --> Output Class Initialized
INFO - 2025-10-28 13:04:41 --> Security Class Initialized
DEBUG - 2025-10-28 13:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-28 13:04:41 --> Input Class Initialized
INFO - 2025-10-28 13:04:41 --> Language Class Initialized
INFO - 2025-10-28 13:04:41 --> Loader Class Initialized
INFO - 2025-10-28 13:04:41 --> Helper loaded: url_helper
INFO - 2025-10-28 13:04:41 --> Database Driver Class Initialized
INFO - 2025-10-28 13:04:41 --> Controller Class Initialized
INFO - 2025-10-28 13:04:41 --> Model "Student_model" initialized
INFO - 2025-10-28 13:04:41 --> Model "Student_fee_model" initialized
INFO - 2025-10-28 13:04:41 --> Model "Payment_model" initialized
INFO - 2025-10-28 13:04:41 --> Helper loaded: form_helper
INFO - 2025-10-28 13:04:41 --> Form Validation Class Initialized
DEBUG - 2025-10-28 13:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-28 13:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-28 13:04:41 --> Config Class Initialized
INFO - 2025-10-28 13:04:41 --> Hooks Class Initialized
DEBUG - 2025-10-28 13:04:41 --> UTF-8 Support Enabled
INFO - 2025-10-28 13:04:41 --> Utf8 Class Initialized
INFO - 2025-10-28 13:04:41 --> URI Class Initialized
INFO - 2025-10-28 13:04:41 --> Router Class Initialized
INFO - 2025-10-28 13:04:41 --> Output Class Initialized
INFO - 2025-10-28 13:04:41 --> Security Class Initialized
DEBUG - 2025-10-28 13:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-28 13:04:41 --> Input Class Initialized
INFO - 2025-10-28 13:04:41 --> Language Class Initialized
INFO - 2025-10-28 13:04:41 --> Loader Class Initialized
INFO - 2025-10-28 13:04:41 --> Helper loaded: url_helper
INFO - 2025-10-28 13:04:41 --> Database Driver Class Initialized
INFO - 2025-10-28 13:04:41 --> Controller Class Initialized
INFO - 2025-10-28 13:04:41 --> Model "Student_model" initialized
INFO - 2025-10-28 13:04:41 --> Model "Student_fee_model" initialized
INFO - 2025-10-28 13:04:41 --> Model "Payment_model" initialized
INFO - 2025-10-28 13:04:41 --> Helper loaded: form_helper
INFO - 2025-10-28 13:04:41 --> Form Validation Class Initialized
DEBUG - 2025-10-28 13:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-28 13:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-28 13:06:46 --> Config Class Initialized
INFO - 2025-10-28 13:06:46 --> Hooks Class Initialized
DEBUG - 2025-10-28 13:06:46 --> UTF-8 Support Enabled
INFO - 2025-10-28 13:06:46 --> Utf8 Class Initialized
INFO - 2025-10-28 13:06:46 --> URI Class Initialized
INFO - 2025-10-28 13:06:46 --> Router Class Initialized
INFO - 2025-10-28 13:06:46 --> Output Class Initialized
INFO - 2025-10-28 13:06:46 --> Security Class Initialized
DEBUG - 2025-10-28 13:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-28 13:06:46 --> Input Class Initialized
INFO - 2025-10-28 13:06:46 --> Language Class Initialized
INFO - 2025-10-28 13:06:46 --> Loader Class Initialized
INFO - 2025-10-28 13:06:46 --> Helper loaded: url_helper
INFO - 2025-10-28 13:06:46 --> Database Driver Class Initialized
INFO - 2025-10-28 13:06:46 --> Controller Class Initialized
INFO - 2025-10-28 13:06:46 --> Model "Student_model" initialized
INFO - 2025-10-28 13:06:46 --> Model "Student_fee_model" initialized
INFO - 2025-10-28 13:06:46 --> Model "Payment_model" initialized
INFO - 2025-10-28 13:06:46 --> Helper loaded: form_helper
INFO - 2025-10-28 13:06:46 --> Form Validation Class Initialized
DEBUG - 2025-10-28 13:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-28 13:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-28 13:14:28 --> Config Class Initialized
INFO - 2025-10-28 13:14:28 --> Hooks Class Initialized
DEBUG - 2025-10-28 13:14:28 --> UTF-8 Support Enabled
INFO - 2025-10-28 13:14:28 --> Utf8 Class Initialized
INFO - 2025-10-28 13:14:28 --> URI Class Initialized
INFO - 2025-10-28 13:14:28 --> Router Class Initialized
INFO - 2025-10-28 13:14:28 --> Output Class Initialized
INFO - 2025-10-28 13:14:28 --> Security Class Initialized
DEBUG - 2025-10-28 13:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-28 13:14:28 --> Input Class Initialized
INFO - 2025-10-28 13:14:28 --> Language Class Initialized
INFO - 2025-10-28 13:14:28 --> Loader Class Initialized
INFO - 2025-10-28 13:14:28 --> Helper loaded: url_helper
INFO - 2025-10-28 13:14:28 --> Database Driver Class Initialized
INFO - 2025-10-28 13:14:28 --> Controller Class Initialized
INFO - 2025-10-28 13:14:28 --> Model "Student_model" initialized
INFO - 2025-10-28 13:14:29 --> Model "Student_fee_model" initialized
INFO - 2025-10-28 13:14:29 --> Model "Payment_model" initialized
INFO - 2025-10-28 13:14:29 --> Helper loaded: form_helper
INFO - 2025-10-28 13:14:29 --> Form Validation Class Initialized
DEBUG - 2025-10-28 13:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-28 13:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-28 13:15:29 --> Config Class Initialized
INFO - 2025-10-28 13:15:29 --> Hooks Class Initialized
DEBUG - 2025-10-28 13:15:29 --> UTF-8 Support Enabled
INFO - 2025-10-28 13:15:29 --> Utf8 Class Initialized
INFO - 2025-10-28 13:15:29 --> URI Class Initialized
INFO - 2025-10-28 13:15:29 --> Router Class Initialized
INFO - 2025-10-28 13:15:29 --> Output Class Initialized
INFO - 2025-10-28 13:15:29 --> Security Class Initialized
DEBUG - 2025-10-28 13:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-28 13:15:29 --> Input Class Initialized
INFO - 2025-10-28 13:15:29 --> Language Class Initialized
INFO - 2025-10-28 13:15:29 --> Loader Class Initialized
INFO - 2025-10-28 13:15:29 --> Helper loaded: url_helper
INFO - 2025-10-28 13:15:29 --> Database Driver Class Initialized
INFO - 2025-10-28 13:15:29 --> Controller Class Initialized
INFO - 2025-10-28 13:15:29 --> Model "Student_model" initialized
INFO - 2025-10-28 13:15:29 --> Model "Student_fee_model" initialized
INFO - 2025-10-28 13:15:29 --> Model "Payment_model" initialized
INFO - 2025-10-28 13:15:29 --> Helper loaded: form_helper
INFO - 2025-10-28 13:15:29 --> Form Validation Class Initialized
DEBUG - 2025-10-28 13:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-28 13:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-28 13:15:30 --> Config Class Initialized
INFO - 2025-10-28 13:15:30 --> Hooks Class Initialized
DEBUG - 2025-10-28 13:15:30 --> UTF-8 Support Enabled
INFO - 2025-10-28 13:15:30 --> Utf8 Class Initialized
INFO - 2025-10-28 13:15:30 --> URI Class Initialized
INFO - 2025-10-28 13:15:30 --> Router Class Initialized
INFO - 2025-10-28 13:15:30 --> Output Class Initialized
INFO - 2025-10-28 13:15:30 --> Security Class Initialized
DEBUG - 2025-10-28 13:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-28 13:15:30 --> Input Class Initialized
INFO - 2025-10-28 13:15:30 --> Language Class Initialized
INFO - 2025-10-28 13:15:30 --> Loader Class Initialized
INFO - 2025-10-28 13:15:30 --> Helper loaded: url_helper
INFO - 2025-10-28 13:15:30 --> Database Driver Class Initialized
INFO - 2025-10-28 13:15:30 --> Controller Class Initialized
INFO - 2025-10-28 13:15:30 --> Model "Student_model" initialized
INFO - 2025-10-28 13:15:30 --> Model "Student_fee_model" initialized
INFO - 2025-10-28 13:15:30 --> Model "Payment_model" initialized
INFO - 2025-10-28 13:15:30 --> Helper loaded: form_helper
INFO - 2025-10-28 13:15:30 --> Form Validation Class Initialized
DEBUG - 2025-10-28 13:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-28 13:15:30 --> Session: Class initialized using 'files' driver.
