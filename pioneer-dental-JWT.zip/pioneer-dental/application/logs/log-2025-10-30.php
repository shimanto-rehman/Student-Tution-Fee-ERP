<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-10-30 04:33:04 --> Config Class Initialized
INFO - 2025-10-30 04:33:04 --> Hooks Class Initialized
DEBUG - 2025-10-30 04:33:05 --> UTF-8 Support Enabled
INFO - 2025-10-30 04:33:05 --> Utf8 Class Initialized
INFO - 2025-10-30 04:33:05 --> URI Class Initialized
INFO - 2025-10-30 04:33:05 --> Router Class Initialized
INFO - 2025-10-30 04:33:05 --> Output Class Initialized
INFO - 2025-10-30 04:33:05 --> Security Class Initialized
DEBUG - 2025-10-30 04:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 04:33:05 --> Input Class Initialized
INFO - 2025-10-30 04:33:05 --> Language Class Initialized
INFO - 2025-10-30 04:33:05 --> Loader Class Initialized
INFO - 2025-10-30 04:33:05 --> Helper loaded: url_helper
INFO - 2025-10-30 04:33:05 --> Database Driver Class Initialized
INFO - 2025-10-30 04:33:05 --> Controller Class Initialized
INFO - 2025-10-30 04:33:05 --> Model "Student_model" initialized
INFO - 2025-10-30 04:33:05 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 04:33:05 --> Model "Payment_model" initialized
INFO - 2025-10-30 04:33:05 --> Helper loaded: form_helper
INFO - 2025-10-30 04:33:05 --> Form Validation Class Initialized
DEBUG - 2025-10-30 04:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 04:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 04:33:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 04:33:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 04:33:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 04:33:05 --> Final output sent to browser
DEBUG - 2025-10-30 04:33:05 --> Total execution time: 0.3864
INFO - 2025-10-30 04:33:09 --> Config Class Initialized
INFO - 2025-10-30 04:33:09 --> Hooks Class Initialized
DEBUG - 2025-10-30 04:33:09 --> UTF-8 Support Enabled
INFO - 2025-10-30 04:33:09 --> Utf8 Class Initialized
INFO - 2025-10-30 04:33:09 --> URI Class Initialized
INFO - 2025-10-30 04:33:09 --> Router Class Initialized
INFO - 2025-10-30 04:33:09 --> Output Class Initialized
INFO - 2025-10-30 04:33:09 --> Security Class Initialized
DEBUG - 2025-10-30 04:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 04:33:09 --> Input Class Initialized
INFO - 2025-10-30 04:33:09 --> Language Class Initialized
INFO - 2025-10-30 04:33:09 --> Loader Class Initialized
INFO - 2025-10-30 04:33:09 --> Helper loaded: url_helper
INFO - 2025-10-30 04:33:09 --> Database Driver Class Initialized
INFO - 2025-10-30 04:33:09 --> Controller Class Initialized
INFO - 2025-10-30 04:33:09 --> Model "Student_model" initialized
INFO - 2025-10-30 04:33:09 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 04:33:09 --> Model "Payment_model" initialized
INFO - 2025-10-30 04:33:09 --> Helper loaded: form_helper
INFO - 2025-10-30 04:33:09 --> Form Validation Class Initialized
DEBUG - 2025-10-30 04:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 04:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 04:33:09 --> Payments Controller Loaded
INFO - 2025-10-30 04:33:09 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 04:33:09 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 04:33:09 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 04:33:09 --> Final output sent to browser
DEBUG - 2025-10-30 04:33:09 --> Total execution time: 0.0970
INFO - 2025-10-30 04:33:11 --> Config Class Initialized
INFO - 2025-10-30 04:33:11 --> Hooks Class Initialized
DEBUG - 2025-10-30 04:33:11 --> UTF-8 Support Enabled
INFO - 2025-10-30 04:33:11 --> Utf8 Class Initialized
INFO - 2025-10-30 04:33:11 --> URI Class Initialized
INFO - 2025-10-30 04:33:11 --> Router Class Initialized
INFO - 2025-10-30 04:33:11 --> Output Class Initialized
INFO - 2025-10-30 04:33:11 --> Security Class Initialized
DEBUG - 2025-10-30 04:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 04:33:11 --> Input Class Initialized
INFO - 2025-10-30 04:33:11 --> Language Class Initialized
INFO - 2025-10-30 04:33:11 --> Loader Class Initialized
INFO - 2025-10-30 04:33:11 --> Helper loaded: url_helper
INFO - 2025-10-30 04:33:11 --> Database Driver Class Initialized
INFO - 2025-10-30 04:33:11 --> Controller Class Initialized
INFO - 2025-10-30 04:33:11 --> Model "Student_model" initialized
INFO - 2025-10-30 04:33:11 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 04:33:11 --> Model "Payment_model" initialized
INFO - 2025-10-30 04:33:11 --> Helper loaded: form_helper
INFO - 2025-10-30 04:33:11 --> Form Validation Class Initialized
DEBUG - 2025-10-30 04:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 04:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 04:33:11 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 04:33:11 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 04:33:11 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 04:33:11 --> Final output sent to browser
DEBUG - 2025-10-30 04:33:11 --> Total execution time: 0.0869
INFO - 2025-10-30 04:56:12 --> Config Class Initialized
INFO - 2025-10-30 04:56:12 --> Hooks Class Initialized
DEBUG - 2025-10-30 04:56:12 --> UTF-8 Support Enabled
INFO - 2025-10-30 04:56:12 --> Utf8 Class Initialized
INFO - 2025-10-30 04:56:12 --> URI Class Initialized
INFO - 2025-10-30 04:56:12 --> Router Class Initialized
INFO - 2025-10-30 04:56:12 --> Output Class Initialized
INFO - 2025-10-30 04:56:12 --> Security Class Initialized
DEBUG - 2025-10-30 04:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 04:56:12 --> Input Class Initialized
INFO - 2025-10-30 04:56:12 --> Language Class Initialized
INFO - 2025-10-30 04:56:12 --> Loader Class Initialized
INFO - 2025-10-30 04:56:12 --> Helper loaded: url_helper
INFO - 2025-10-30 04:56:12 --> Database Driver Class Initialized
INFO - 2025-10-30 04:56:12 --> Controller Class Initialized
INFO - 2025-10-30 04:56:12 --> Model "Student_model" initialized
INFO - 2025-10-30 04:56:12 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 04:56:12 --> Model "Payment_model" initialized
INFO - 2025-10-30 04:56:12 --> Helper loaded: form_helper
INFO - 2025-10-30 04:56:12 --> Form Validation Class Initialized
DEBUG - 2025-10-30 04:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 04:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 04:56:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 04:56:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 04:56:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 04:56:12 --> Final output sent to browser
DEBUG - 2025-10-30 04:56:12 --> Total execution time: 0.1099
INFO - 2025-10-30 04:56:13 --> Config Class Initialized
INFO - 2025-10-30 04:56:13 --> Hooks Class Initialized
DEBUG - 2025-10-30 04:56:13 --> UTF-8 Support Enabled
INFO - 2025-10-30 04:56:13 --> Utf8 Class Initialized
INFO - 2025-10-30 04:56:13 --> URI Class Initialized
DEBUG - 2025-10-30 04:56:13 --> No URI present. Default controller set.
INFO - 2025-10-30 04:56:13 --> Router Class Initialized
INFO - 2025-10-30 04:56:13 --> Output Class Initialized
INFO - 2025-10-30 04:56:13 --> Security Class Initialized
DEBUG - 2025-10-30 04:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 04:56:13 --> Input Class Initialized
INFO - 2025-10-30 04:56:13 --> Language Class Initialized
INFO - 2025-10-30 04:56:14 --> Loader Class Initialized
INFO - 2025-10-30 04:56:14 --> Helper loaded: url_helper
INFO - 2025-10-30 04:56:14 --> Database Driver Class Initialized
INFO - 2025-10-30 04:56:14 --> Controller Class Initialized
INFO - 2025-10-30 04:56:14 --> Model "Student_model" initialized
INFO - 2025-10-30 04:56:14 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 04:56:14 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 04:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 04:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 04:56:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 04:56:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-30 04:56:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 04:56:14 --> Final output sent to browser
DEBUG - 2025-10-30 04:56:14 --> Total execution time: 0.0990
INFO - 2025-10-30 04:56:16 --> Config Class Initialized
INFO - 2025-10-30 04:56:16 --> Hooks Class Initialized
DEBUG - 2025-10-30 04:56:16 --> UTF-8 Support Enabled
INFO - 2025-10-30 04:56:16 --> Utf8 Class Initialized
INFO - 2025-10-30 04:56:16 --> URI Class Initialized
INFO - 2025-10-30 04:56:16 --> Router Class Initialized
INFO - 2025-10-30 04:56:16 --> Output Class Initialized
INFO - 2025-10-30 04:56:16 --> Security Class Initialized
DEBUG - 2025-10-30 04:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 04:56:16 --> Input Class Initialized
INFO - 2025-10-30 04:56:16 --> Language Class Initialized
INFO - 2025-10-30 04:56:16 --> Loader Class Initialized
INFO - 2025-10-30 04:56:16 --> Helper loaded: url_helper
INFO - 2025-10-30 04:56:16 --> Database Driver Class Initialized
INFO - 2025-10-30 04:56:16 --> Controller Class Initialized
INFO - 2025-10-30 04:56:16 --> Model "Student_model" initialized
INFO - 2025-10-30 04:56:16 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 04:56:16 --> Model "Payment_model" initialized
INFO - 2025-10-30 04:56:16 --> Helper loaded: form_helper
INFO - 2025-10-30 04:56:16 --> Form Validation Class Initialized
DEBUG - 2025-10-30 04:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 04:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 04:56:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 04:56:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 04:56:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 04:56:16 --> Final output sent to browser
DEBUG - 2025-10-30 04:56:16 --> Total execution time: 0.1071
INFO - 2025-10-30 04:56:18 --> Config Class Initialized
INFO - 2025-10-30 04:56:18 --> Hooks Class Initialized
DEBUG - 2025-10-30 04:56:18 --> UTF-8 Support Enabled
INFO - 2025-10-30 04:56:18 --> Utf8 Class Initialized
INFO - 2025-10-30 04:56:18 --> URI Class Initialized
INFO - 2025-10-30 04:56:18 --> Router Class Initialized
INFO - 2025-10-30 04:56:18 --> Output Class Initialized
INFO - 2025-10-30 04:56:18 --> Security Class Initialized
DEBUG - 2025-10-30 04:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 04:56:18 --> Input Class Initialized
INFO - 2025-10-30 04:56:18 --> Language Class Initialized
INFO - 2025-10-30 04:56:18 --> Loader Class Initialized
INFO - 2025-10-30 04:56:18 --> Helper loaded: url_helper
INFO - 2025-10-30 04:56:18 --> Database Driver Class Initialized
INFO - 2025-10-30 04:56:18 --> Controller Class Initialized
INFO - 2025-10-30 04:56:18 --> Model "Student_model" initialized
INFO - 2025-10-30 04:56:18 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 04:56:18 --> Model "Payment_model" initialized
INFO - 2025-10-30 04:56:18 --> Helper loaded: form_helper
INFO - 2025-10-30 04:56:18 --> Form Validation Class Initialized
DEBUG - 2025-10-30 04:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 04:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 04:56:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 04:56:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 04:56:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 04:56:18 --> Final output sent to browser
DEBUG - 2025-10-30 04:56:18 --> Total execution time: 0.1402
INFO - 2025-10-30 04:56:19 --> Config Class Initialized
INFO - 2025-10-30 04:56:19 --> Hooks Class Initialized
DEBUG - 2025-10-30 04:56:19 --> UTF-8 Support Enabled
INFO - 2025-10-30 04:56:19 --> Utf8 Class Initialized
INFO - 2025-10-30 04:56:19 --> URI Class Initialized
INFO - 2025-10-30 04:56:19 --> Router Class Initialized
INFO - 2025-10-30 04:56:19 --> Output Class Initialized
INFO - 2025-10-30 04:56:19 --> Security Class Initialized
DEBUG - 2025-10-30 04:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 04:56:19 --> Input Class Initialized
INFO - 2025-10-30 04:56:19 --> Language Class Initialized
INFO - 2025-10-30 04:56:19 --> Loader Class Initialized
INFO - 2025-10-30 04:56:19 --> Helper loaded: url_helper
INFO - 2025-10-30 04:56:19 --> Database Driver Class Initialized
INFO - 2025-10-30 04:56:19 --> Controller Class Initialized
INFO - 2025-10-30 04:56:19 --> Model "Student_model" initialized
INFO - 2025-10-30 04:56:19 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 04:56:19 --> Model "Payment_model" initialized
INFO - 2025-10-30 04:56:19 --> Helper loaded: form_helper
INFO - 2025-10-30 04:56:19 --> Form Validation Class Initialized
DEBUG - 2025-10-30 04:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 04:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 04:56:19 --> Final output sent to browser
DEBUG - 2025-10-30 04:56:19 --> Total execution time: 0.0793
INFO - 2025-10-30 04:56:20 --> Config Class Initialized
INFO - 2025-10-30 04:56:20 --> Hooks Class Initialized
DEBUG - 2025-10-30 04:56:21 --> UTF-8 Support Enabled
INFO - 2025-10-30 04:56:21 --> Utf8 Class Initialized
INFO - 2025-10-30 04:56:21 --> URI Class Initialized
INFO - 2025-10-30 04:56:21 --> Router Class Initialized
INFO - 2025-10-30 04:56:21 --> Output Class Initialized
INFO - 2025-10-30 04:56:21 --> Security Class Initialized
DEBUG - 2025-10-30 04:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 04:56:21 --> Input Class Initialized
INFO - 2025-10-30 04:56:21 --> Language Class Initialized
INFO - 2025-10-30 04:56:21 --> Loader Class Initialized
INFO - 2025-10-30 04:56:21 --> Helper loaded: url_helper
INFO - 2025-10-30 04:56:21 --> Database Driver Class Initialized
INFO - 2025-10-30 04:56:21 --> Controller Class Initialized
INFO - 2025-10-30 04:56:21 --> Model "Student_model" initialized
INFO - 2025-10-30 04:56:21 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 04:56:21 --> Model "Payment_model" initialized
INFO - 2025-10-30 04:56:21 --> Helper loaded: form_helper
INFO - 2025-10-30 04:56:21 --> Form Validation Class Initialized
DEBUG - 2025-10-30 04:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 04:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 04:56:21 --> Final output sent to browser
DEBUG - 2025-10-30 04:56:21 --> Total execution time: 0.1080
INFO - 2025-10-30 04:56:21 --> Config Class Initialized
INFO - 2025-10-30 04:56:21 --> Hooks Class Initialized
DEBUG - 2025-10-30 04:56:21 --> UTF-8 Support Enabled
INFO - 2025-10-30 04:56:21 --> Utf8 Class Initialized
INFO - 2025-10-30 04:56:21 --> URI Class Initialized
INFO - 2025-10-30 04:56:21 --> Router Class Initialized
INFO - 2025-10-30 04:56:21 --> Output Class Initialized
INFO - 2025-10-30 04:56:21 --> Security Class Initialized
DEBUG - 2025-10-30 04:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 04:56:21 --> Input Class Initialized
INFO - 2025-10-30 04:56:21 --> Language Class Initialized
INFO - 2025-10-30 04:56:21 --> Loader Class Initialized
INFO - 2025-10-30 04:56:21 --> Helper loaded: url_helper
INFO - 2025-10-30 04:56:22 --> Database Driver Class Initialized
INFO - 2025-10-30 04:56:22 --> Controller Class Initialized
INFO - 2025-10-30 04:56:22 --> Model "Student_model" initialized
INFO - 2025-10-30 04:56:22 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 04:56:22 --> Model "Payment_model" initialized
INFO - 2025-10-30 04:56:22 --> Helper loaded: form_helper
INFO - 2025-10-30 04:56:22 --> Form Validation Class Initialized
DEBUG - 2025-10-30 04:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 04:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 04:56:22 --> Final output sent to browser
DEBUG - 2025-10-30 04:56:22 --> Total execution time: 0.0937
INFO - 2025-10-30 04:56:34 --> Config Class Initialized
INFO - 2025-10-30 04:56:34 --> Hooks Class Initialized
DEBUG - 2025-10-30 04:56:34 --> UTF-8 Support Enabled
INFO - 2025-10-30 04:56:34 --> Utf8 Class Initialized
INFO - 2025-10-30 04:56:34 --> URI Class Initialized
INFO - 2025-10-30 04:56:34 --> Router Class Initialized
INFO - 2025-10-30 04:56:34 --> Output Class Initialized
INFO - 2025-10-30 04:56:34 --> Security Class Initialized
DEBUG - 2025-10-30 04:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 04:56:34 --> Input Class Initialized
INFO - 2025-10-30 04:56:34 --> Language Class Initialized
INFO - 2025-10-30 04:56:34 --> Loader Class Initialized
INFO - 2025-10-30 04:56:34 --> Helper loaded: url_helper
INFO - 2025-10-30 04:56:34 --> Database Driver Class Initialized
INFO - 2025-10-30 04:56:34 --> Controller Class Initialized
INFO - 2025-10-30 04:56:34 --> Model "Student_model" initialized
INFO - 2025-10-30 04:56:34 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 04:56:34 --> Model "Payment_model" initialized
INFO - 2025-10-30 04:56:34 --> Helper loaded: form_helper
INFO - 2025-10-30 04:56:34 --> Form Validation Class Initialized
DEBUG - 2025-10-30 04:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 04:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 04:56:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 04:56:34 --> Config Class Initialized
INFO - 2025-10-30 04:56:34 --> Hooks Class Initialized
DEBUG - 2025-10-30 04:56:34 --> UTF-8 Support Enabled
INFO - 2025-10-30 04:56:34 --> Utf8 Class Initialized
INFO - 2025-10-30 04:56:34 --> URI Class Initialized
INFO - 2025-10-30 04:56:34 --> Router Class Initialized
INFO - 2025-10-30 04:56:34 --> Output Class Initialized
INFO - 2025-10-30 04:56:34 --> Security Class Initialized
DEBUG - 2025-10-30 04:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 04:56:34 --> Input Class Initialized
INFO - 2025-10-30 04:56:34 --> Language Class Initialized
INFO - 2025-10-30 04:56:34 --> Loader Class Initialized
INFO - 2025-10-30 04:56:34 --> Helper loaded: url_helper
INFO - 2025-10-30 04:56:34 --> Database Driver Class Initialized
INFO - 2025-10-30 04:56:34 --> Controller Class Initialized
INFO - 2025-10-30 04:56:34 --> Model "Student_model" initialized
INFO - 2025-10-30 04:56:34 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 04:56:34 --> Model "Payment_model" initialized
INFO - 2025-10-30 04:56:34 --> Helper loaded: form_helper
INFO - 2025-10-30 04:56:34 --> Form Validation Class Initialized
DEBUG - 2025-10-30 04:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 04:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 04:56:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 04:56:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 04:56:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 04:56:34 --> Final output sent to browser
DEBUG - 2025-10-30 04:56:34 --> Total execution time: 0.1398
INFO - 2025-10-30 04:56:39 --> Config Class Initialized
INFO - 2025-10-30 04:56:39 --> Hooks Class Initialized
DEBUG - 2025-10-30 04:56:39 --> UTF-8 Support Enabled
INFO - 2025-10-30 04:56:39 --> Utf8 Class Initialized
INFO - 2025-10-30 04:56:39 --> URI Class Initialized
INFO - 2025-10-30 04:56:39 --> Router Class Initialized
INFO - 2025-10-30 04:56:39 --> Output Class Initialized
INFO - 2025-10-30 04:56:39 --> Security Class Initialized
DEBUG - 2025-10-30 04:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 04:56:39 --> Input Class Initialized
INFO - 2025-10-30 04:56:39 --> Language Class Initialized
INFO - 2025-10-30 04:56:39 --> Loader Class Initialized
INFO - 2025-10-30 04:56:39 --> Helper loaded: url_helper
INFO - 2025-10-30 04:56:39 --> Database Driver Class Initialized
INFO - 2025-10-30 04:56:39 --> Controller Class Initialized
INFO - 2025-10-30 04:56:39 --> Model "Student_model" initialized
INFO - 2025-10-30 04:56:39 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 04:56:39 --> Model "Payment_model" initialized
INFO - 2025-10-30 04:56:39 --> Helper loaded: form_helper
INFO - 2025-10-30 04:56:39 --> Form Validation Class Initialized
DEBUG - 2025-10-30 04:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 04:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 04:56:39 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 04:56:39 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 04:56:39 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 04:56:39 --> Final output sent to browser
DEBUG - 2025-10-30 04:56:39 --> Total execution time: 0.0906
INFO - 2025-10-30 04:56:52 --> Config Class Initialized
INFO - 2025-10-30 04:56:52 --> Hooks Class Initialized
DEBUG - 2025-10-30 04:56:52 --> UTF-8 Support Enabled
INFO - 2025-10-30 04:56:52 --> Utf8 Class Initialized
INFO - 2025-10-30 04:56:52 --> URI Class Initialized
INFO - 2025-10-30 04:56:52 --> Router Class Initialized
INFO - 2025-10-30 04:56:52 --> Output Class Initialized
INFO - 2025-10-30 04:56:52 --> Security Class Initialized
DEBUG - 2025-10-30 04:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 04:56:52 --> Input Class Initialized
INFO - 2025-10-30 04:56:52 --> Language Class Initialized
INFO - 2025-10-30 04:56:52 --> Loader Class Initialized
INFO - 2025-10-30 04:56:52 --> Helper loaded: url_helper
INFO - 2025-10-30 04:56:52 --> Database Driver Class Initialized
INFO - 2025-10-30 04:56:52 --> Controller Class Initialized
INFO - 2025-10-30 04:56:52 --> Model "Student_model" initialized
INFO - 2025-10-30 04:56:52 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 04:56:52 --> Model "Payment_model" initialized
INFO - 2025-10-30 04:56:52 --> Helper loaded: form_helper
INFO - 2025-10-30 04:56:52 --> Form Validation Class Initialized
DEBUG - 2025-10-30 04:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 04:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 04:56:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 04:56:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/edit.php
INFO - 2025-10-30 04:56:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 04:56:52 --> Final output sent to browser
DEBUG - 2025-10-30 04:56:52 --> Total execution time: 0.1138
INFO - 2025-10-30 04:57:00 --> Config Class Initialized
INFO - 2025-10-30 04:57:00 --> Hooks Class Initialized
DEBUG - 2025-10-30 04:57:00 --> UTF-8 Support Enabled
INFO - 2025-10-30 04:57:00 --> Utf8 Class Initialized
INFO - 2025-10-30 04:57:00 --> URI Class Initialized
INFO - 2025-10-30 04:57:00 --> Router Class Initialized
INFO - 2025-10-30 04:57:00 --> Output Class Initialized
INFO - 2025-10-30 04:57:00 --> Security Class Initialized
DEBUG - 2025-10-30 04:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 04:57:00 --> Input Class Initialized
INFO - 2025-10-30 04:57:00 --> Language Class Initialized
INFO - 2025-10-30 04:57:00 --> Loader Class Initialized
INFO - 2025-10-30 04:57:00 --> Helper loaded: url_helper
INFO - 2025-10-30 04:57:00 --> Database Driver Class Initialized
INFO - 2025-10-30 04:57:00 --> Controller Class Initialized
INFO - 2025-10-30 04:57:00 --> Model "Student_model" initialized
INFO - 2025-10-30 04:57:00 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 04:57:00 --> Model "Payment_model" initialized
INFO - 2025-10-30 04:57:00 --> Helper loaded: form_helper
INFO - 2025-10-30 04:57:00 --> Form Validation Class Initialized
DEBUG - 2025-10-30 04:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 04:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 04:57:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 04:57:01 --> Config Class Initialized
INFO - 2025-10-30 04:57:01 --> Hooks Class Initialized
DEBUG - 2025-10-30 04:57:01 --> UTF-8 Support Enabled
INFO - 2025-10-30 04:57:01 --> Utf8 Class Initialized
INFO - 2025-10-30 04:57:01 --> URI Class Initialized
INFO - 2025-10-30 04:57:01 --> Router Class Initialized
INFO - 2025-10-30 04:57:01 --> Output Class Initialized
INFO - 2025-10-30 04:57:01 --> Security Class Initialized
DEBUG - 2025-10-30 04:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 04:57:01 --> Input Class Initialized
INFO - 2025-10-30 04:57:01 --> Language Class Initialized
INFO - 2025-10-30 04:57:01 --> Loader Class Initialized
INFO - 2025-10-30 04:57:01 --> Helper loaded: url_helper
INFO - 2025-10-30 04:57:01 --> Database Driver Class Initialized
INFO - 2025-10-30 04:57:01 --> Controller Class Initialized
INFO - 2025-10-30 04:57:01 --> Model "Student_model" initialized
INFO - 2025-10-30 04:57:01 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 04:57:01 --> Model "Payment_model" initialized
INFO - 2025-10-30 04:57:01 --> Helper loaded: form_helper
INFO - 2025-10-30 04:57:01 --> Form Validation Class Initialized
DEBUG - 2025-10-30 04:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 04:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 04:57:01 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 04:57:01 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 04:57:01 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 04:57:01 --> Final output sent to browser
DEBUG - 2025-10-30 04:57:01 --> Total execution time: 0.0901
INFO - 2025-10-30 04:57:03 --> Config Class Initialized
INFO - 2025-10-30 04:57:03 --> Hooks Class Initialized
DEBUG - 2025-10-30 04:57:03 --> UTF-8 Support Enabled
INFO - 2025-10-30 04:57:03 --> Utf8 Class Initialized
INFO - 2025-10-30 04:57:03 --> URI Class Initialized
INFO - 2025-10-30 04:57:03 --> Router Class Initialized
INFO - 2025-10-30 04:57:03 --> Output Class Initialized
INFO - 2025-10-30 04:57:03 --> Security Class Initialized
DEBUG - 2025-10-30 04:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 04:57:03 --> Input Class Initialized
INFO - 2025-10-30 04:57:03 --> Language Class Initialized
INFO - 2025-10-30 04:57:03 --> Loader Class Initialized
INFO - 2025-10-30 04:57:03 --> Helper loaded: url_helper
INFO - 2025-10-30 04:57:03 --> Database Driver Class Initialized
INFO - 2025-10-30 04:57:03 --> Controller Class Initialized
INFO - 2025-10-30 04:57:03 --> Model "Student_model" initialized
INFO - 2025-10-30 04:57:03 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 04:57:03 --> Model "Payment_model" initialized
INFO - 2025-10-30 04:57:03 --> Helper loaded: form_helper
INFO - 2025-10-30 04:57:03 --> Form Validation Class Initialized
DEBUG - 2025-10-30 04:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 04:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 04:57:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 04:57:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 04:57:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 04:57:03 --> Final output sent to browser
DEBUG - 2025-10-30 04:57:03 --> Total execution time: 0.0989
INFO - 2025-10-30 05:34:40 --> Config Class Initialized
INFO - 2025-10-30 05:34:40 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:34:40 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:34:40 --> Utf8 Class Initialized
INFO - 2025-10-30 05:34:40 --> URI Class Initialized
INFO - 2025-10-30 05:34:40 --> Router Class Initialized
INFO - 2025-10-30 05:34:40 --> Output Class Initialized
INFO - 2025-10-30 05:34:40 --> Security Class Initialized
DEBUG - 2025-10-30 05:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:34:40 --> Input Class Initialized
INFO - 2025-10-30 05:34:40 --> Language Class Initialized
INFO - 2025-10-30 05:34:40 --> Loader Class Initialized
INFO - 2025-10-30 05:34:40 --> Helper loaded: url_helper
INFO - 2025-10-30 05:34:40 --> Database Driver Class Initialized
INFO - 2025-10-30 05:34:40 --> Controller Class Initialized
INFO - 2025-10-30 05:34:40 --> Model "Student_model" initialized
INFO - 2025-10-30 05:34:40 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:34:40 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:34:40 --> Helper loaded: form_helper
INFO - 2025-10-30 05:34:40 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:34:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:34:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 05:34:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:34:40 --> Final output sent to browser
DEBUG - 2025-10-30 05:34:40 --> Total execution time: 0.0635
INFO - 2025-10-30 05:38:29 --> Config Class Initialized
INFO - 2025-10-30 05:38:29 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:38:29 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:38:29 --> Utf8 Class Initialized
INFO - 2025-10-30 05:38:29 --> URI Class Initialized
DEBUG - 2025-10-30 05:38:29 --> No URI present. Default controller set.
INFO - 2025-10-30 05:38:29 --> Router Class Initialized
INFO - 2025-10-30 05:38:29 --> Output Class Initialized
INFO - 2025-10-30 05:38:29 --> Security Class Initialized
DEBUG - 2025-10-30 05:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:38:29 --> Input Class Initialized
INFO - 2025-10-30 05:38:29 --> Language Class Initialized
INFO - 2025-10-30 05:38:29 --> Loader Class Initialized
INFO - 2025-10-30 05:38:29 --> Helper loaded: url_helper
INFO - 2025-10-30 05:38:29 --> Database Driver Class Initialized
INFO - 2025-10-30 05:38:29 --> Controller Class Initialized
INFO - 2025-10-30 05:38:29 --> Model "Student_model" initialized
INFO - 2025-10-30 05:38:29 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:38:29 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 05:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:38:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:38:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-30 05:38:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:38:29 --> Final output sent to browser
DEBUG - 2025-10-30 05:38:29 --> Total execution time: 0.0684
INFO - 2025-10-30 05:38:34 --> Config Class Initialized
INFO - 2025-10-30 05:38:34 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:38:34 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:38:34 --> Utf8 Class Initialized
INFO - 2025-10-30 05:38:34 --> URI Class Initialized
DEBUG - 2025-10-30 05:38:34 --> No URI present. Default controller set.
INFO - 2025-10-30 05:38:34 --> Router Class Initialized
INFO - 2025-10-30 05:38:34 --> Output Class Initialized
INFO - 2025-10-30 05:38:34 --> Security Class Initialized
DEBUG - 2025-10-30 05:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:38:34 --> Input Class Initialized
INFO - 2025-10-30 05:38:34 --> Language Class Initialized
INFO - 2025-10-30 05:38:34 --> Loader Class Initialized
INFO - 2025-10-30 05:38:34 --> Helper loaded: url_helper
INFO - 2025-10-30 05:38:34 --> Database Driver Class Initialized
INFO - 2025-10-30 05:38:34 --> Controller Class Initialized
INFO - 2025-10-30 05:38:34 --> Model "Student_model" initialized
INFO - 2025-10-30 05:38:34 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:38:34 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 05:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:38:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:38:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-30 05:38:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:38:34 --> Final output sent to browser
DEBUG - 2025-10-30 05:38:34 --> Total execution time: 0.0719
INFO - 2025-10-30 05:38:35 --> Config Class Initialized
INFO - 2025-10-30 05:38:35 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:38:35 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:38:35 --> Utf8 Class Initialized
INFO - 2025-10-30 05:38:35 --> URI Class Initialized
INFO - 2025-10-30 05:38:35 --> Router Class Initialized
INFO - 2025-10-30 05:38:35 --> Output Class Initialized
INFO - 2025-10-30 05:38:35 --> Security Class Initialized
DEBUG - 2025-10-30 05:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:38:35 --> Input Class Initialized
INFO - 2025-10-30 05:38:35 --> Language Class Initialized
INFO - 2025-10-30 05:38:35 --> Loader Class Initialized
INFO - 2025-10-30 05:38:35 --> Helper loaded: url_helper
INFO - 2025-10-30 05:38:35 --> Database Driver Class Initialized
INFO - 2025-10-30 05:38:35 --> Controller Class Initialized
INFO - 2025-10-30 05:38:35 --> Model "Student_model" initialized
INFO - 2025-10-30 05:38:35 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:38:35 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:38:35 --> Helper loaded: form_helper
INFO - 2025-10-30 05:38:35 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:38:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:38:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 05:38:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:38:35 --> Final output sent to browser
DEBUG - 2025-10-30 05:38:35 --> Total execution time: 0.0813
INFO - 2025-10-30 05:38:37 --> Config Class Initialized
INFO - 2025-10-30 05:38:37 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:38:37 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:38:37 --> Utf8 Class Initialized
INFO - 2025-10-30 05:38:37 --> URI Class Initialized
DEBUG - 2025-10-30 05:38:37 --> No URI present. Default controller set.
INFO - 2025-10-30 05:38:37 --> Router Class Initialized
INFO - 2025-10-30 05:38:37 --> Output Class Initialized
INFO - 2025-10-30 05:38:37 --> Security Class Initialized
DEBUG - 2025-10-30 05:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:38:37 --> Input Class Initialized
INFO - 2025-10-30 05:38:37 --> Language Class Initialized
INFO - 2025-10-30 05:38:37 --> Loader Class Initialized
INFO - 2025-10-30 05:38:37 --> Helper loaded: url_helper
INFO - 2025-10-30 05:38:37 --> Database Driver Class Initialized
INFO - 2025-10-30 05:38:37 --> Controller Class Initialized
INFO - 2025-10-30 05:38:37 --> Model "Student_model" initialized
INFO - 2025-10-30 05:38:37 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:38:37 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 05:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:38:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:38:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-30 05:38:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:38:37 --> Final output sent to browser
DEBUG - 2025-10-30 05:38:37 --> Total execution time: 0.0633
INFO - 2025-10-30 05:38:41 --> Config Class Initialized
INFO - 2025-10-30 05:38:41 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:38:41 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:38:41 --> Utf8 Class Initialized
INFO - 2025-10-30 05:38:41 --> URI Class Initialized
INFO - 2025-10-30 05:38:41 --> Router Class Initialized
INFO - 2025-10-30 05:38:41 --> Output Class Initialized
INFO - 2025-10-30 05:38:41 --> Security Class Initialized
DEBUG - 2025-10-30 05:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:38:41 --> Input Class Initialized
INFO - 2025-10-30 05:38:41 --> Language Class Initialized
INFO - 2025-10-30 05:38:41 --> Loader Class Initialized
INFO - 2025-10-30 05:38:41 --> Helper loaded: url_helper
INFO - 2025-10-30 05:38:41 --> Database Driver Class Initialized
INFO - 2025-10-30 05:38:41 --> Controller Class Initialized
INFO - 2025-10-30 05:38:41 --> Model "Student_model" initialized
INFO - 2025-10-30 05:38:41 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:38:41 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:38:41 --> Helper loaded: form_helper
INFO - 2025-10-30 05:38:41 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:38:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:38:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 05:38:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:38:41 --> Final output sent to browser
DEBUG - 2025-10-30 05:38:41 --> Total execution time: 0.0680
INFO - 2025-10-30 05:38:46 --> Config Class Initialized
INFO - 2025-10-30 05:38:46 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:38:46 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:38:46 --> Utf8 Class Initialized
INFO - 2025-10-30 05:38:46 --> URI Class Initialized
INFO - 2025-10-30 05:38:46 --> Router Class Initialized
INFO - 2025-10-30 05:38:46 --> Output Class Initialized
INFO - 2025-10-30 05:38:46 --> Security Class Initialized
DEBUG - 2025-10-30 05:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:38:46 --> Input Class Initialized
INFO - 2025-10-30 05:38:46 --> Language Class Initialized
INFO - 2025-10-30 05:38:46 --> Loader Class Initialized
INFO - 2025-10-30 05:38:46 --> Helper loaded: url_helper
INFO - 2025-10-30 05:38:46 --> Database Driver Class Initialized
INFO - 2025-10-30 05:38:46 --> Controller Class Initialized
INFO - 2025-10-30 05:38:46 --> Model "Student_model" initialized
INFO - 2025-10-30 05:38:46 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:38:46 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:38:46 --> Helper loaded: form_helper
INFO - 2025-10-30 05:38:46 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:38:46 --> Payments Controller Loaded
INFO - 2025-10-30 05:38:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:38:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/index.php
INFO - 2025-10-30 05:38:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:38:46 --> Final output sent to browser
DEBUG - 2025-10-30 05:38:46 --> Total execution time: 0.0852
INFO - 2025-10-30 05:39:02 --> Config Class Initialized
INFO - 2025-10-30 05:39:02 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:39:02 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:39:02 --> Utf8 Class Initialized
INFO - 2025-10-30 05:39:02 --> URI Class Initialized
INFO - 2025-10-30 05:39:02 --> Router Class Initialized
INFO - 2025-10-30 05:39:02 --> Output Class Initialized
INFO - 2025-10-30 05:39:02 --> Security Class Initialized
DEBUG - 2025-10-30 05:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:39:02 --> Input Class Initialized
INFO - 2025-10-30 05:39:02 --> Language Class Initialized
INFO - 2025-10-30 05:39:02 --> Loader Class Initialized
INFO - 2025-10-30 05:39:02 --> Helper loaded: url_helper
INFO - 2025-10-30 05:39:02 --> Database Driver Class Initialized
INFO - 2025-10-30 05:39:02 --> Controller Class Initialized
INFO - 2025-10-30 05:39:02 --> Model "Student_model" initialized
INFO - 2025-10-30 05:39:02 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:39:02 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:39:02 --> Helper loaded: form_helper
INFO - 2025-10-30 05:39:02 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:39:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:39:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 05:39:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:39:02 --> Final output sent to browser
DEBUG - 2025-10-30 05:39:02 --> Total execution time: 0.0764
INFO - 2025-10-30 05:39:04 --> Config Class Initialized
INFO - 2025-10-30 05:39:04 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:39:04 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:39:04 --> Utf8 Class Initialized
INFO - 2025-10-30 05:39:04 --> URI Class Initialized
INFO - 2025-10-30 05:39:04 --> Router Class Initialized
INFO - 2025-10-30 05:39:04 --> Output Class Initialized
INFO - 2025-10-30 05:39:04 --> Security Class Initialized
DEBUG - 2025-10-30 05:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:39:04 --> Input Class Initialized
INFO - 2025-10-30 05:39:04 --> Language Class Initialized
INFO - 2025-10-30 05:39:04 --> Loader Class Initialized
INFO - 2025-10-30 05:39:04 --> Helper loaded: url_helper
INFO - 2025-10-30 05:39:04 --> Database Driver Class Initialized
INFO - 2025-10-30 05:39:04 --> Controller Class Initialized
INFO - 2025-10-30 05:39:04 --> Model "Student_model" initialized
INFO - 2025-10-30 05:39:04 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:39:04 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:39:04 --> Helper loaded: form_helper
INFO - 2025-10-30 05:39:04 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:39:04 --> Payments Controller Loaded
INFO - 2025-10-30 05:39:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:39:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 05:39:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:39:04 --> Final output sent to browser
DEBUG - 2025-10-30 05:39:04 --> Total execution time: 0.0697
INFO - 2025-10-30 05:39:07 --> Config Class Initialized
INFO - 2025-10-30 05:39:07 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:39:07 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:39:07 --> Utf8 Class Initialized
INFO - 2025-10-30 05:39:07 --> URI Class Initialized
INFO - 2025-10-30 05:39:07 --> Router Class Initialized
INFO - 2025-10-30 05:39:07 --> Output Class Initialized
INFO - 2025-10-30 05:39:07 --> Security Class Initialized
DEBUG - 2025-10-30 05:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:39:07 --> Input Class Initialized
INFO - 2025-10-30 05:39:07 --> Language Class Initialized
INFO - 2025-10-30 05:39:07 --> Loader Class Initialized
INFO - 2025-10-30 05:39:07 --> Helper loaded: url_helper
INFO - 2025-10-30 05:39:07 --> Database Driver Class Initialized
INFO - 2025-10-30 05:39:07 --> Controller Class Initialized
INFO - 2025-10-30 05:39:07 --> Model "Student_model" initialized
INFO - 2025-10-30 05:39:07 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:39:07 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:39:07 --> Helper loaded: form_helper
INFO - 2025-10-30 05:39:07 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:39:07 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:39:07 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 05:39:07 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:39:07 --> Final output sent to browser
DEBUG - 2025-10-30 05:39:07 --> Total execution time: 0.0599
INFO - 2025-10-30 05:39:11 --> Config Class Initialized
INFO - 2025-10-30 05:39:11 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:39:11 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:39:11 --> Utf8 Class Initialized
INFO - 2025-10-30 05:39:11 --> URI Class Initialized
INFO - 2025-10-30 05:39:11 --> Router Class Initialized
INFO - 2025-10-30 05:39:11 --> Output Class Initialized
INFO - 2025-10-30 05:39:11 --> Security Class Initialized
DEBUG - 2025-10-30 05:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:39:11 --> Input Class Initialized
INFO - 2025-10-30 05:39:11 --> Language Class Initialized
INFO - 2025-10-30 05:39:11 --> Loader Class Initialized
INFO - 2025-10-30 05:39:11 --> Helper loaded: url_helper
INFO - 2025-10-30 05:39:11 --> Database Driver Class Initialized
INFO - 2025-10-30 05:39:11 --> Controller Class Initialized
INFO - 2025-10-30 05:39:11 --> Model "Student_model" initialized
INFO - 2025-10-30 05:39:11 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:39:11 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:39:11 --> Helper loaded: form_helper
INFO - 2025-10-30 05:39:11 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:39:11 --> Payments Controller Loaded
INFO - 2025-10-30 05:39:11 --> Config Class Initialized
INFO - 2025-10-30 05:39:11 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:39:11 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:39:11 --> Utf8 Class Initialized
INFO - 2025-10-30 05:39:11 --> URI Class Initialized
INFO - 2025-10-30 05:39:11 --> Router Class Initialized
INFO - 2025-10-30 05:39:11 --> Output Class Initialized
INFO - 2025-10-30 05:39:11 --> Security Class Initialized
DEBUG - 2025-10-30 05:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:39:11 --> Input Class Initialized
INFO - 2025-10-30 05:39:11 --> Language Class Initialized
INFO - 2025-10-30 05:39:11 --> Loader Class Initialized
INFO - 2025-10-30 05:39:11 --> Helper loaded: url_helper
INFO - 2025-10-30 05:39:11 --> Database Driver Class Initialized
INFO - 2025-10-30 05:39:11 --> Controller Class Initialized
INFO - 2025-10-30 05:39:11 --> Model "Student_model" initialized
INFO - 2025-10-30 05:39:11 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:39:11 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:39:11 --> Final output sent to browser
DEBUG - 2025-10-30 05:39:11 --> Total execution time: 0.0916
INFO - 2025-10-30 05:39:11 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
ERROR - 2025-10-30 05:39:11 --> Severity: Warning --> Undefined variable $total_paid C:\xampp\htdocs\pioneer-dental\application\views\payments\process.php 56
ERROR - 2025-10-30 05:39:11 --> Severity: Warning --> Undefined variable $balance C:\xampp\htdocs\pioneer-dental\application\views\payments\process.php 64
ERROR - 2025-10-30 05:39:11 --> Severity: Warning --> Undefined variable $balance C:\xampp\htdocs\pioneer-dental\application\views\payments\process.php 76
ERROR - 2025-10-30 05:39:11 --> Severity: Warning --> Undefined variable $balance C:\xampp\htdocs\pioneer-dental\application\views\payments\process.php 148
INFO - 2025-10-30 05:39:11 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/process.php
INFO - 2025-10-30 05:39:11 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:39:11 --> Final output sent to browser
DEBUG - 2025-10-30 05:39:11 --> Total execution time: 0.2347
INFO - 2025-10-30 05:39:16 --> Config Class Initialized
INFO - 2025-10-30 05:39:16 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:39:16 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:39:16 --> Utf8 Class Initialized
INFO - 2025-10-30 05:39:16 --> URI Class Initialized
DEBUG - 2025-10-30 05:39:16 --> No URI present. Default controller set.
INFO - 2025-10-30 05:39:16 --> Router Class Initialized
INFO - 2025-10-30 05:39:16 --> Output Class Initialized
INFO - 2025-10-30 05:39:16 --> Security Class Initialized
DEBUG - 2025-10-30 05:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:39:16 --> Input Class Initialized
INFO - 2025-10-30 05:39:16 --> Language Class Initialized
INFO - 2025-10-30 05:39:16 --> Loader Class Initialized
INFO - 2025-10-30 05:39:16 --> Helper loaded: url_helper
INFO - 2025-10-30 05:39:16 --> Database Driver Class Initialized
INFO - 2025-10-30 05:39:16 --> Controller Class Initialized
INFO - 2025-10-30 05:39:16 --> Model "Student_model" initialized
INFO - 2025-10-30 05:39:16 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:39:16 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 05:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:39:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:39:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-30 05:39:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:39:16 --> Final output sent to browser
DEBUG - 2025-10-30 05:39:16 --> Total execution time: 0.0593
INFO - 2025-10-30 05:39:21 --> Config Class Initialized
INFO - 2025-10-30 05:39:21 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:39:21 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:39:21 --> Utf8 Class Initialized
INFO - 2025-10-30 05:39:21 --> URI Class Initialized
INFO - 2025-10-30 05:39:21 --> Router Class Initialized
INFO - 2025-10-30 05:39:21 --> Output Class Initialized
INFO - 2025-10-30 05:39:21 --> Security Class Initialized
DEBUG - 2025-10-30 05:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:39:21 --> Input Class Initialized
INFO - 2025-10-30 05:39:21 --> Language Class Initialized
INFO - 2025-10-30 05:39:21 --> Loader Class Initialized
INFO - 2025-10-30 05:39:21 --> Helper loaded: url_helper
INFO - 2025-10-30 05:39:21 --> Database Driver Class Initialized
INFO - 2025-10-30 05:39:21 --> Controller Class Initialized
INFO - 2025-10-30 05:39:21 --> Model "Student_model" initialized
INFO - 2025-10-30 05:39:21 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:39:22 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:39:22 --> Helper loaded: form_helper
INFO - 2025-10-30 05:39:22 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:39:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:39:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 05:39:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:39:22 --> Final output sent to browser
DEBUG - 2025-10-30 05:39:22 --> Total execution time: 0.0652
INFO - 2025-10-30 05:39:25 --> Config Class Initialized
INFO - 2025-10-30 05:39:25 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:39:25 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:39:25 --> Utf8 Class Initialized
INFO - 2025-10-30 05:39:25 --> URI Class Initialized
INFO - 2025-10-30 05:39:25 --> Router Class Initialized
INFO - 2025-10-30 05:39:25 --> Output Class Initialized
INFO - 2025-10-30 05:39:25 --> Security Class Initialized
DEBUG - 2025-10-30 05:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:39:25 --> Input Class Initialized
INFO - 2025-10-30 05:39:25 --> Language Class Initialized
INFO - 2025-10-30 05:39:25 --> Loader Class Initialized
INFO - 2025-10-30 05:39:25 --> Helper loaded: url_helper
INFO - 2025-10-30 05:39:25 --> Database Driver Class Initialized
INFO - 2025-10-30 05:39:25 --> Controller Class Initialized
INFO - 2025-10-30 05:39:25 --> Model "Student_model" initialized
INFO - 2025-10-30 05:39:25 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:39:25 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:39:25 --> Helper loaded: form_helper
INFO - 2025-10-30 05:39:25 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:39:25 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:39:25 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 05:39:25 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:39:25 --> Final output sent to browser
DEBUG - 2025-10-30 05:39:25 --> Total execution time: 0.0667
INFO - 2025-10-30 05:39:28 --> Config Class Initialized
INFO - 2025-10-30 05:39:28 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:39:28 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:39:28 --> Utf8 Class Initialized
INFO - 2025-10-30 05:39:28 --> URI Class Initialized
INFO - 2025-10-30 05:39:28 --> Router Class Initialized
INFO - 2025-10-30 05:39:28 --> Output Class Initialized
INFO - 2025-10-30 05:39:28 --> Security Class Initialized
DEBUG - 2025-10-30 05:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:39:28 --> Input Class Initialized
INFO - 2025-10-30 05:39:28 --> Language Class Initialized
INFO - 2025-10-30 05:39:28 --> Loader Class Initialized
INFO - 2025-10-30 05:39:28 --> Helper loaded: url_helper
INFO - 2025-10-30 05:39:28 --> Database Driver Class Initialized
INFO - 2025-10-30 05:39:28 --> Controller Class Initialized
INFO - 2025-10-30 05:39:28 --> Model "Student_model" initialized
INFO - 2025-10-30 05:39:28 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:39:28 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:39:28 --> Helper loaded: form_helper
INFO - 2025-10-30 05:39:28 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:39:28 --> Payments Controller Loaded
INFO - 2025-10-30 05:39:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:39:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/index.php
INFO - 2025-10-30 05:39:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:39:28 --> Final output sent to browser
DEBUG - 2025-10-30 05:39:28 --> Total execution time: 0.0551
INFO - 2025-10-30 05:39:31 --> Config Class Initialized
INFO - 2025-10-30 05:39:31 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:39:31 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:39:31 --> Utf8 Class Initialized
INFO - 2025-10-30 05:39:31 --> URI Class Initialized
INFO - 2025-10-30 05:39:31 --> Router Class Initialized
INFO - 2025-10-30 05:39:31 --> Output Class Initialized
INFO - 2025-10-30 05:39:31 --> Security Class Initialized
DEBUG - 2025-10-30 05:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:39:31 --> Input Class Initialized
INFO - 2025-10-30 05:39:31 --> Language Class Initialized
ERROR - 2025-10-30 05:39:31 --> 404 Page Not Found: Api_testinghtml/index
INFO - 2025-10-30 05:39:41 --> Config Class Initialized
INFO - 2025-10-30 05:39:41 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:39:41 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:39:41 --> Utf8 Class Initialized
INFO - 2025-10-30 05:39:41 --> URI Class Initialized
DEBUG - 2025-10-30 05:39:41 --> No URI present. Default controller set.
INFO - 2025-10-30 05:39:41 --> Router Class Initialized
INFO - 2025-10-30 05:39:41 --> Output Class Initialized
INFO - 2025-10-30 05:39:41 --> Security Class Initialized
DEBUG - 2025-10-30 05:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:39:41 --> Input Class Initialized
INFO - 2025-10-30 05:39:41 --> Language Class Initialized
INFO - 2025-10-30 05:39:41 --> Loader Class Initialized
INFO - 2025-10-30 05:39:41 --> Helper loaded: url_helper
INFO - 2025-10-30 05:39:41 --> Database Driver Class Initialized
INFO - 2025-10-30 05:39:41 --> Controller Class Initialized
INFO - 2025-10-30 05:39:41 --> Model "Student_model" initialized
INFO - 2025-10-30 05:39:41 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:39:41 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 05:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:39:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:39:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-30 05:39:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:39:41 --> Final output sent to browser
DEBUG - 2025-10-30 05:39:41 --> Total execution time: 0.0653
INFO - 2025-10-30 05:40:10 --> Config Class Initialized
INFO - 2025-10-30 05:40:10 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:40:10 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:40:10 --> Utf8 Class Initialized
INFO - 2025-10-30 05:40:10 --> URI Class Initialized
INFO - 2025-10-30 05:40:10 --> Router Class Initialized
INFO - 2025-10-30 05:40:10 --> Output Class Initialized
INFO - 2025-10-30 05:40:10 --> Security Class Initialized
DEBUG - 2025-10-30 05:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:40:10 --> Input Class Initialized
INFO - 2025-10-30 05:40:10 --> Language Class Initialized
INFO - 2025-10-30 05:40:10 --> Loader Class Initialized
INFO - 2025-10-30 05:40:10 --> Helper loaded: url_helper
INFO - 2025-10-30 05:40:10 --> Database Driver Class Initialized
INFO - 2025-10-30 05:40:10 --> Controller Class Initialized
INFO - 2025-10-30 05:40:10 --> Model "Student_model" initialized
INFO - 2025-10-30 05:40:10 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:40:10 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:40:10 --> Helper loaded: form_helper
INFO - 2025-10-30 05:40:10 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:40:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:40:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 05:40:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:40:10 --> Final output sent to browser
DEBUG - 2025-10-30 05:40:10 --> Total execution time: 0.0702
INFO - 2025-10-30 05:40:12 --> Config Class Initialized
INFO - 2025-10-30 05:40:12 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:40:12 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:40:12 --> Utf8 Class Initialized
INFO - 2025-10-30 05:40:12 --> URI Class Initialized
INFO - 2025-10-30 05:40:12 --> Router Class Initialized
INFO - 2025-10-30 05:40:12 --> Output Class Initialized
INFO - 2025-10-30 05:40:12 --> Security Class Initialized
DEBUG - 2025-10-30 05:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:40:12 --> Input Class Initialized
INFO - 2025-10-30 05:40:12 --> Language Class Initialized
INFO - 2025-10-30 05:40:12 --> Loader Class Initialized
INFO - 2025-10-30 05:40:12 --> Helper loaded: url_helper
INFO - 2025-10-30 05:40:12 --> Database Driver Class Initialized
INFO - 2025-10-30 05:40:12 --> Controller Class Initialized
INFO - 2025-10-30 05:40:12 --> Model "Student_model" initialized
INFO - 2025-10-30 05:40:12 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:40:12 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:40:12 --> Helper loaded: form_helper
INFO - 2025-10-30 05:40:12 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:40:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:40:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/edit.php
INFO - 2025-10-30 05:40:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:40:12 --> Final output sent to browser
DEBUG - 2025-10-30 05:40:12 --> Total execution time: 0.0674
INFO - 2025-10-30 05:40:17 --> Config Class Initialized
INFO - 2025-10-30 05:40:17 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:40:17 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:40:17 --> Utf8 Class Initialized
INFO - 2025-10-30 05:40:17 --> URI Class Initialized
INFO - 2025-10-30 05:40:17 --> Router Class Initialized
INFO - 2025-10-30 05:40:17 --> Output Class Initialized
INFO - 2025-10-30 05:40:17 --> Security Class Initialized
DEBUG - 2025-10-30 05:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:40:17 --> Input Class Initialized
INFO - 2025-10-30 05:40:17 --> Language Class Initialized
INFO - 2025-10-30 05:40:17 --> Loader Class Initialized
INFO - 2025-10-30 05:40:17 --> Helper loaded: url_helper
INFO - 2025-10-30 05:40:17 --> Database Driver Class Initialized
INFO - 2025-10-30 05:40:17 --> Controller Class Initialized
INFO - 2025-10-30 05:40:17 --> Model "Student_model" initialized
INFO - 2025-10-30 05:40:17 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:40:17 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:40:17 --> Helper loaded: form_helper
INFO - 2025-10-30 05:40:17 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:40:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:40:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 05:40:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:40:17 --> Final output sent to browser
DEBUG - 2025-10-30 05:40:17 --> Total execution time: 0.0873
INFO - 2025-10-30 05:40:19 --> Config Class Initialized
INFO - 2025-10-30 05:40:19 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:40:20 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:40:20 --> Utf8 Class Initialized
INFO - 2025-10-30 05:40:20 --> URI Class Initialized
INFO - 2025-10-30 05:40:20 --> Router Class Initialized
INFO - 2025-10-30 05:40:20 --> Output Class Initialized
INFO - 2025-10-30 05:40:20 --> Security Class Initialized
DEBUG - 2025-10-30 05:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:40:20 --> Input Class Initialized
INFO - 2025-10-30 05:40:20 --> Language Class Initialized
INFO - 2025-10-30 05:40:20 --> Loader Class Initialized
INFO - 2025-10-30 05:40:20 --> Helper loaded: url_helper
INFO - 2025-10-30 05:40:20 --> Database Driver Class Initialized
INFO - 2025-10-30 05:40:20 --> Controller Class Initialized
INFO - 2025-10-30 05:40:20 --> Model "Student_model" initialized
INFO - 2025-10-30 05:40:20 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:40:20 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:40:20 --> Helper loaded: form_helper
INFO - 2025-10-30 05:40:20 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:40:20 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:40:20 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 05:40:20 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:40:20 --> Final output sent to browser
DEBUG - 2025-10-30 05:40:20 --> Total execution time: 0.0647
INFO - 2025-10-30 05:41:05 --> Config Class Initialized
INFO - 2025-10-30 05:41:05 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:41:05 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:41:05 --> Utf8 Class Initialized
INFO - 2025-10-30 05:41:05 --> URI Class Initialized
INFO - 2025-10-30 05:41:05 --> Router Class Initialized
INFO - 2025-10-30 05:41:05 --> Output Class Initialized
INFO - 2025-10-30 05:41:05 --> Security Class Initialized
DEBUG - 2025-10-30 05:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:41:05 --> Input Class Initialized
INFO - 2025-10-30 05:41:05 --> Language Class Initialized
INFO - 2025-10-30 05:41:05 --> Loader Class Initialized
INFO - 2025-10-30 05:41:05 --> Helper loaded: url_helper
INFO - 2025-10-30 05:41:05 --> Database Driver Class Initialized
INFO - 2025-10-30 05:41:05 --> Controller Class Initialized
INFO - 2025-10-30 05:41:05 --> Model "Student_model" initialized
INFO - 2025-10-30 05:41:05 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:41:05 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:41:05 --> Helper loaded: form_helper
INFO - 2025-10-30 05:41:05 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:41:05 --> Payments Controller Loaded
INFO - 2025-10-30 05:41:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:41:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 05:41:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:41:05 --> Final output sent to browser
DEBUG - 2025-10-30 05:41:05 --> Total execution time: 0.0627
INFO - 2025-10-30 05:41:07 --> Config Class Initialized
INFO - 2025-10-30 05:41:07 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:41:07 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:41:07 --> Utf8 Class Initialized
INFO - 2025-10-30 05:41:07 --> URI Class Initialized
INFO - 2025-10-30 05:41:07 --> Router Class Initialized
INFO - 2025-10-30 05:41:07 --> Output Class Initialized
INFO - 2025-10-30 05:41:07 --> Security Class Initialized
DEBUG - 2025-10-30 05:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:41:07 --> Input Class Initialized
INFO - 2025-10-30 05:41:07 --> Language Class Initialized
INFO - 2025-10-30 05:41:07 --> Loader Class Initialized
INFO - 2025-10-30 05:41:07 --> Helper loaded: url_helper
INFO - 2025-10-30 05:41:07 --> Database Driver Class Initialized
INFO - 2025-10-30 05:41:07 --> Controller Class Initialized
INFO - 2025-10-30 05:41:07 --> Model "Student_model" initialized
INFO - 2025-10-30 05:41:07 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:41:07 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:41:07 --> Helper loaded: form_helper
INFO - 2025-10-30 05:41:07 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:41:07 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:41:07 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 05:41:07 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:41:07 --> Final output sent to browser
DEBUG - 2025-10-30 05:41:07 --> Total execution time: 0.0557
INFO - 2025-10-30 05:41:50 --> Config Class Initialized
INFO - 2025-10-30 05:41:50 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:41:50 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:41:50 --> Utf8 Class Initialized
INFO - 2025-10-30 05:41:50 --> URI Class Initialized
INFO - 2025-10-30 05:41:50 --> Router Class Initialized
INFO - 2025-10-30 05:41:50 --> Output Class Initialized
INFO - 2025-10-30 05:41:50 --> Security Class Initialized
DEBUG - 2025-10-30 05:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:41:50 --> Input Class Initialized
INFO - 2025-10-30 05:41:50 --> Language Class Initialized
INFO - 2025-10-30 05:41:50 --> Loader Class Initialized
INFO - 2025-10-30 05:41:50 --> Helper loaded: url_helper
INFO - 2025-10-30 05:41:50 --> Database Driver Class Initialized
INFO - 2025-10-30 05:41:50 --> Controller Class Initialized
INFO - 2025-10-30 05:41:50 --> Model "Student_model" initialized
INFO - 2025-10-30 05:41:50 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:41:50 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:41:50 --> Helper loaded: form_helper
INFO - 2025-10-30 05:41:50 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:41:50 --> Payments Controller Loaded
INFO - 2025-10-30 05:41:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 05:41:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:41:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 05:41:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:41:50 --> Final output sent to browser
DEBUG - 2025-10-30 05:41:50 --> Total execution time: 0.0869
INFO - 2025-10-30 05:41:57 --> Config Class Initialized
INFO - 2025-10-30 05:41:57 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:41:57 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:41:57 --> Utf8 Class Initialized
INFO - 2025-10-30 05:41:57 --> URI Class Initialized
INFO - 2025-10-30 05:41:57 --> Router Class Initialized
INFO - 2025-10-30 05:41:57 --> Output Class Initialized
INFO - 2025-10-30 05:41:57 --> Security Class Initialized
DEBUG - 2025-10-30 05:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:41:57 --> Input Class Initialized
INFO - 2025-10-30 05:41:57 --> Language Class Initialized
INFO - 2025-10-30 05:41:57 --> Loader Class Initialized
INFO - 2025-10-30 05:41:57 --> Helper loaded: url_helper
INFO - 2025-10-30 05:41:57 --> Database Driver Class Initialized
INFO - 2025-10-30 05:41:57 --> Controller Class Initialized
INFO - 2025-10-30 05:41:57 --> Model "Student_model" initialized
INFO - 2025-10-30 05:41:57 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:41:57 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:41:57 --> Helper loaded: form_helper
INFO - 2025-10-30 05:41:57 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:41:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:41:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 05:41:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:41:57 --> Final output sent to browser
DEBUG - 2025-10-30 05:41:57 --> Total execution time: 0.0811
INFO - 2025-10-30 05:42:03 --> Config Class Initialized
INFO - 2025-10-30 05:42:03 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:42:03 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:42:03 --> Utf8 Class Initialized
INFO - 2025-10-30 05:42:03 --> URI Class Initialized
INFO - 2025-10-30 05:42:03 --> Router Class Initialized
INFO - 2025-10-30 05:42:03 --> Output Class Initialized
INFO - 2025-10-30 05:42:03 --> Security Class Initialized
DEBUG - 2025-10-30 05:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:42:03 --> Input Class Initialized
INFO - 2025-10-30 05:42:03 --> Language Class Initialized
INFO - 2025-10-30 05:42:03 --> Loader Class Initialized
INFO - 2025-10-30 05:42:03 --> Helper loaded: url_helper
INFO - 2025-10-30 05:42:03 --> Database Driver Class Initialized
INFO - 2025-10-30 05:42:03 --> Controller Class Initialized
INFO - 2025-10-30 05:42:03 --> Model "Student_model" initialized
INFO - 2025-10-30 05:42:03 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:42:03 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:42:03 --> Helper loaded: form_helper
INFO - 2025-10-30 05:42:03 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:42:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:42:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/edit.php
INFO - 2025-10-30 05:42:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:42:03 --> Final output sent to browser
DEBUG - 2025-10-30 05:42:03 --> Total execution time: 0.0734
INFO - 2025-10-30 05:42:08 --> Config Class Initialized
INFO - 2025-10-30 05:42:08 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:42:08 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:42:08 --> Utf8 Class Initialized
INFO - 2025-10-30 05:42:08 --> URI Class Initialized
INFO - 2025-10-30 05:42:08 --> Router Class Initialized
INFO - 2025-10-30 05:42:08 --> Output Class Initialized
INFO - 2025-10-30 05:42:08 --> Security Class Initialized
DEBUG - 2025-10-30 05:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:42:08 --> Input Class Initialized
INFO - 2025-10-30 05:42:08 --> Language Class Initialized
INFO - 2025-10-30 05:42:08 --> Loader Class Initialized
INFO - 2025-10-30 05:42:08 --> Helper loaded: url_helper
INFO - 2025-10-30 05:42:08 --> Database Driver Class Initialized
INFO - 2025-10-30 05:42:08 --> Controller Class Initialized
INFO - 2025-10-30 05:42:08 --> Model "Student_model" initialized
INFO - 2025-10-30 05:42:08 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:42:08 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:42:08 --> Helper loaded: form_helper
INFO - 2025-10-30 05:42:08 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:42:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:42:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 05:42:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:42:08 --> Final output sent to browser
DEBUG - 2025-10-30 05:42:08 --> Total execution time: 0.1257
INFO - 2025-10-30 05:42:10 --> Config Class Initialized
INFO - 2025-10-30 05:42:10 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:42:10 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:42:10 --> Utf8 Class Initialized
INFO - 2025-10-30 05:42:10 --> URI Class Initialized
INFO - 2025-10-30 05:42:10 --> Router Class Initialized
INFO - 2025-10-30 05:42:10 --> Output Class Initialized
INFO - 2025-10-30 05:42:10 --> Security Class Initialized
DEBUG - 2025-10-30 05:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:42:10 --> Input Class Initialized
INFO - 2025-10-30 05:42:10 --> Language Class Initialized
INFO - 2025-10-30 05:42:10 --> Loader Class Initialized
INFO - 2025-10-30 05:42:10 --> Helper loaded: url_helper
INFO - 2025-10-30 05:42:10 --> Database Driver Class Initialized
INFO - 2025-10-30 05:42:10 --> Controller Class Initialized
INFO - 2025-10-30 05:42:10 --> Model "Student_model" initialized
INFO - 2025-10-30 05:42:10 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:42:10 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:42:10 --> Helper loaded: form_helper
INFO - 2025-10-30 05:42:10 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:42:10 --> Payments Controller Loaded
INFO - 2025-10-30 05:42:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:42:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 05:42:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:42:10 --> Final output sent to browser
DEBUG - 2025-10-30 05:42:10 --> Total execution time: 0.0714
INFO - 2025-10-30 05:42:18 --> Config Class Initialized
INFO - 2025-10-30 05:42:18 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:42:18 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:42:18 --> Utf8 Class Initialized
INFO - 2025-10-30 05:42:18 --> URI Class Initialized
INFO - 2025-10-30 05:42:18 --> Router Class Initialized
INFO - 2025-10-30 05:42:18 --> Output Class Initialized
INFO - 2025-10-30 05:42:18 --> Security Class Initialized
DEBUG - 2025-10-30 05:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:42:18 --> Input Class Initialized
INFO - 2025-10-30 05:42:18 --> Language Class Initialized
INFO - 2025-10-30 05:42:18 --> Loader Class Initialized
INFO - 2025-10-30 05:42:18 --> Helper loaded: url_helper
INFO - 2025-10-30 05:42:18 --> Database Driver Class Initialized
INFO - 2025-10-30 05:42:18 --> Controller Class Initialized
INFO - 2025-10-30 05:42:18 --> Model "Student_model" initialized
INFO - 2025-10-30 05:42:18 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:42:18 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:42:18 --> Helper loaded: form_helper
INFO - 2025-10-30 05:42:18 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:42:18 --> Payments Controller Loaded
INFO - 2025-10-30 05:42:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 05:42:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:42:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 05:42:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:42:18 --> Final output sent to browser
DEBUG - 2025-10-30 05:42:18 --> Total execution time: 0.0763
INFO - 2025-10-30 05:42:24 --> Config Class Initialized
INFO - 2025-10-30 05:42:24 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:42:24 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:42:24 --> Utf8 Class Initialized
INFO - 2025-10-30 05:42:24 --> URI Class Initialized
INFO - 2025-10-30 05:42:24 --> Router Class Initialized
INFO - 2025-10-30 05:42:24 --> Output Class Initialized
INFO - 2025-10-30 05:42:24 --> Security Class Initialized
DEBUG - 2025-10-30 05:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:42:24 --> Input Class Initialized
INFO - 2025-10-30 05:42:24 --> Language Class Initialized
INFO - 2025-10-30 05:42:24 --> Loader Class Initialized
INFO - 2025-10-30 05:42:24 --> Helper loaded: url_helper
INFO - 2025-10-30 05:42:24 --> Database Driver Class Initialized
INFO - 2025-10-30 05:42:24 --> Controller Class Initialized
INFO - 2025-10-30 05:42:24 --> Model "Student_model" initialized
INFO - 2025-10-30 05:42:24 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:42:24 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:42:24 --> Helper loaded: form_helper
INFO - 2025-10-30 05:42:24 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:42:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:42:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 05:42:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:42:24 --> Final output sent to browser
DEBUG - 2025-10-30 05:42:24 --> Total execution time: 0.0676
INFO - 2025-10-30 05:42:26 --> Config Class Initialized
INFO - 2025-10-30 05:42:26 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:42:26 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:42:26 --> Utf8 Class Initialized
INFO - 2025-10-30 05:42:26 --> URI Class Initialized
INFO - 2025-10-30 05:42:26 --> Router Class Initialized
INFO - 2025-10-30 05:42:26 --> Output Class Initialized
INFO - 2025-10-30 05:42:26 --> Security Class Initialized
DEBUG - 2025-10-30 05:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:42:26 --> Input Class Initialized
INFO - 2025-10-30 05:42:26 --> Language Class Initialized
INFO - 2025-10-30 05:42:26 --> Loader Class Initialized
INFO - 2025-10-30 05:42:26 --> Helper loaded: url_helper
INFO - 2025-10-30 05:42:26 --> Database Driver Class Initialized
INFO - 2025-10-30 05:42:26 --> Controller Class Initialized
INFO - 2025-10-30 05:42:26 --> Model "Student_model" initialized
INFO - 2025-10-30 05:42:26 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:42:26 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:42:26 --> Helper loaded: form_helper
INFO - 2025-10-30 05:42:26 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:42:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:42:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 05:42:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:42:26 --> Final output sent to browser
DEBUG - 2025-10-30 05:42:26 --> Total execution time: 0.0925
INFO - 2025-10-30 05:42:28 --> Config Class Initialized
INFO - 2025-10-30 05:42:28 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:42:28 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:42:28 --> Utf8 Class Initialized
INFO - 2025-10-30 05:42:28 --> URI Class Initialized
INFO - 2025-10-30 05:42:28 --> Router Class Initialized
INFO - 2025-10-30 05:42:28 --> Output Class Initialized
INFO - 2025-10-30 05:42:28 --> Security Class Initialized
DEBUG - 2025-10-30 05:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:42:28 --> Input Class Initialized
INFO - 2025-10-30 05:42:28 --> Language Class Initialized
INFO - 2025-10-30 05:42:28 --> Loader Class Initialized
INFO - 2025-10-30 05:42:28 --> Helper loaded: url_helper
INFO - 2025-10-30 05:42:28 --> Database Driver Class Initialized
INFO - 2025-10-30 05:42:28 --> Controller Class Initialized
INFO - 2025-10-30 05:42:28 --> Model "Student_model" initialized
INFO - 2025-10-30 05:42:28 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:42:28 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:42:28 --> Helper loaded: form_helper
INFO - 2025-10-30 05:42:28 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:42:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:42:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 05:42:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:42:28 --> Final output sent to browser
DEBUG - 2025-10-30 05:42:28 --> Total execution time: 0.0596
INFO - 2025-10-30 05:42:29 --> Config Class Initialized
INFO - 2025-10-30 05:42:29 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:42:29 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:42:29 --> Utf8 Class Initialized
INFO - 2025-10-30 05:42:29 --> URI Class Initialized
INFO - 2025-10-30 05:42:29 --> Router Class Initialized
INFO - 2025-10-30 05:42:29 --> Output Class Initialized
INFO - 2025-10-30 05:42:29 --> Security Class Initialized
DEBUG - 2025-10-30 05:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:42:29 --> Input Class Initialized
INFO - 2025-10-30 05:42:29 --> Language Class Initialized
INFO - 2025-10-30 05:42:29 --> Loader Class Initialized
INFO - 2025-10-30 05:42:29 --> Helper loaded: url_helper
INFO - 2025-10-30 05:42:29 --> Database Driver Class Initialized
INFO - 2025-10-30 05:42:29 --> Controller Class Initialized
INFO - 2025-10-30 05:42:29 --> Model "Student_model" initialized
INFO - 2025-10-30 05:42:29 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:42:29 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:42:29 --> Helper loaded: form_helper
INFO - 2025-10-30 05:42:29 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:42:29 --> Final output sent to browser
DEBUG - 2025-10-30 05:42:29 --> Total execution time: 0.0451
INFO - 2025-10-30 05:42:46 --> Config Class Initialized
INFO - 2025-10-30 05:42:46 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:42:46 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:42:46 --> Utf8 Class Initialized
INFO - 2025-10-30 05:42:46 --> URI Class Initialized
INFO - 2025-10-30 05:42:46 --> Router Class Initialized
INFO - 2025-10-30 05:42:46 --> Output Class Initialized
INFO - 2025-10-30 05:42:46 --> Security Class Initialized
DEBUG - 2025-10-30 05:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:42:46 --> Input Class Initialized
INFO - 2025-10-30 05:42:46 --> Language Class Initialized
INFO - 2025-10-30 05:42:46 --> Loader Class Initialized
INFO - 2025-10-30 05:42:46 --> Helper loaded: url_helper
INFO - 2025-10-30 05:42:46 --> Database Driver Class Initialized
INFO - 2025-10-30 05:42:46 --> Controller Class Initialized
INFO - 2025-10-30 05:42:46 --> Model "Student_model" initialized
INFO - 2025-10-30 05:42:46 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:42:46 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:42:46 --> Helper loaded: form_helper
INFO - 2025-10-30 05:42:46 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:42:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 05:42:46 --> Config Class Initialized
INFO - 2025-10-30 05:42:46 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:42:46 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:42:46 --> Utf8 Class Initialized
INFO - 2025-10-30 05:42:46 --> URI Class Initialized
INFO - 2025-10-30 05:42:46 --> Router Class Initialized
INFO - 2025-10-30 05:42:46 --> Output Class Initialized
INFO - 2025-10-30 05:42:46 --> Security Class Initialized
DEBUG - 2025-10-30 05:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:42:46 --> Input Class Initialized
INFO - 2025-10-30 05:42:46 --> Language Class Initialized
INFO - 2025-10-30 05:42:46 --> Loader Class Initialized
INFO - 2025-10-30 05:42:46 --> Helper loaded: url_helper
INFO - 2025-10-30 05:42:46 --> Database Driver Class Initialized
INFO - 2025-10-30 05:42:46 --> Controller Class Initialized
INFO - 2025-10-30 05:42:46 --> Model "Student_model" initialized
INFO - 2025-10-30 05:42:46 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:42:46 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:42:46 --> Helper loaded: form_helper
INFO - 2025-10-30 05:42:46 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:42:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:42:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 05:42:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:42:46 --> Final output sent to browser
DEBUG - 2025-10-30 05:42:46 --> Total execution time: 0.0569
INFO - 2025-10-30 05:42:55 --> Config Class Initialized
INFO - 2025-10-30 05:42:55 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:42:55 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:42:55 --> Utf8 Class Initialized
INFO - 2025-10-30 05:42:55 --> URI Class Initialized
INFO - 2025-10-30 05:42:55 --> Router Class Initialized
INFO - 2025-10-30 05:42:55 --> Output Class Initialized
INFO - 2025-10-30 05:42:55 --> Security Class Initialized
DEBUG - 2025-10-30 05:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:42:55 --> Input Class Initialized
INFO - 2025-10-30 05:42:55 --> Language Class Initialized
INFO - 2025-10-30 05:42:55 --> Loader Class Initialized
INFO - 2025-10-30 05:42:55 --> Helper loaded: url_helper
INFO - 2025-10-30 05:42:55 --> Database Driver Class Initialized
INFO - 2025-10-30 05:42:55 --> Controller Class Initialized
INFO - 2025-10-30 05:42:55 --> Model "Student_model" initialized
INFO - 2025-10-30 05:42:55 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:42:55 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:42:55 --> Helper loaded: form_helper
INFO - 2025-10-30 05:42:55 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:42:55 --> Payments Controller Loaded
INFO - 2025-10-30 05:42:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:42:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 05:42:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:42:55 --> Final output sent to browser
DEBUG - 2025-10-30 05:42:55 --> Total execution time: 0.0999
INFO - 2025-10-30 05:43:19 --> Config Class Initialized
INFO - 2025-10-30 05:43:19 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:43:19 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:43:19 --> Utf8 Class Initialized
INFO - 2025-10-30 05:43:19 --> URI Class Initialized
INFO - 2025-10-30 05:43:19 --> Router Class Initialized
INFO - 2025-10-30 05:43:19 --> Output Class Initialized
INFO - 2025-10-30 05:43:19 --> Security Class Initialized
DEBUG - 2025-10-30 05:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:43:19 --> Input Class Initialized
INFO - 2025-10-30 05:43:19 --> Language Class Initialized
INFO - 2025-10-30 05:43:19 --> Loader Class Initialized
INFO - 2025-10-30 05:43:19 --> Helper loaded: url_helper
INFO - 2025-10-30 05:43:19 --> Database Driver Class Initialized
INFO - 2025-10-30 05:43:19 --> Controller Class Initialized
INFO - 2025-10-30 05:43:19 --> Model "Student_model" initialized
INFO - 2025-10-30 05:43:19 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:43:19 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:43:19 --> Helper loaded: form_helper
INFO - 2025-10-30 05:43:19 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:43:19 --> Payments Controller Loaded
INFO - 2025-10-30 05:43:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 05:43:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:43:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 05:43:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:43:19 --> Final output sent to browser
DEBUG - 2025-10-30 05:43:19 --> Total execution time: 0.0717
INFO - 2025-10-30 05:43:29 --> Config Class Initialized
INFO - 2025-10-30 05:43:29 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:43:29 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:43:29 --> Utf8 Class Initialized
INFO - 2025-10-30 05:43:29 --> URI Class Initialized
INFO - 2025-10-30 05:43:29 --> Router Class Initialized
INFO - 2025-10-30 05:43:29 --> Output Class Initialized
INFO - 2025-10-30 05:43:29 --> Security Class Initialized
DEBUG - 2025-10-30 05:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:43:29 --> Input Class Initialized
INFO - 2025-10-30 05:43:29 --> Language Class Initialized
INFO - 2025-10-30 05:43:29 --> Loader Class Initialized
INFO - 2025-10-30 05:43:29 --> Helper loaded: url_helper
INFO - 2025-10-30 05:43:29 --> Database Driver Class Initialized
INFO - 2025-10-30 05:43:29 --> Controller Class Initialized
INFO - 2025-10-30 05:43:29 --> Model "Student_model" initialized
INFO - 2025-10-30 05:43:29 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:43:29 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:43:29 --> Helper loaded: form_helper
INFO - 2025-10-30 05:43:29 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:43:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:43:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 05:43:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:43:29 --> Final output sent to browser
DEBUG - 2025-10-30 05:43:29 --> Total execution time: 0.0625
INFO - 2025-10-30 05:43:32 --> Config Class Initialized
INFO - 2025-10-30 05:43:32 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:43:32 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:43:32 --> Utf8 Class Initialized
INFO - 2025-10-30 05:43:32 --> URI Class Initialized
INFO - 2025-10-30 05:43:32 --> Router Class Initialized
INFO - 2025-10-30 05:43:32 --> Output Class Initialized
INFO - 2025-10-30 05:43:32 --> Security Class Initialized
DEBUG - 2025-10-30 05:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:43:32 --> Input Class Initialized
INFO - 2025-10-30 05:43:32 --> Language Class Initialized
INFO - 2025-10-30 05:43:32 --> Loader Class Initialized
INFO - 2025-10-30 05:43:32 --> Helper loaded: url_helper
INFO - 2025-10-30 05:43:32 --> Database Driver Class Initialized
INFO - 2025-10-30 05:43:32 --> Controller Class Initialized
INFO - 2025-10-30 05:43:32 --> Model "Student_model" initialized
INFO - 2025-10-30 05:43:32 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:43:32 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:43:32 --> Helper loaded: form_helper
INFO - 2025-10-30 05:43:32 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:43:32 --> Payments Controller Loaded
INFO - 2025-10-30 05:43:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:43:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/index.php
INFO - 2025-10-30 05:43:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:43:32 --> Final output sent to browser
DEBUG - 2025-10-30 05:43:32 --> Total execution time: 0.0727
INFO - 2025-10-30 05:43:42 --> Config Class Initialized
INFO - 2025-10-30 05:43:42 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:43:42 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:43:42 --> Utf8 Class Initialized
INFO - 2025-10-30 05:43:42 --> URI Class Initialized
INFO - 2025-10-30 05:43:42 --> Router Class Initialized
INFO - 2025-10-30 05:43:42 --> Output Class Initialized
INFO - 2025-10-30 05:43:42 --> Security Class Initialized
DEBUG - 2025-10-30 05:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:43:42 --> Input Class Initialized
INFO - 2025-10-30 05:43:42 --> Language Class Initialized
INFO - 2025-10-30 05:43:42 --> Loader Class Initialized
INFO - 2025-10-30 05:43:42 --> Helper loaded: url_helper
INFO - 2025-10-30 05:43:42 --> Database Driver Class Initialized
INFO - 2025-10-30 05:43:42 --> Controller Class Initialized
INFO - 2025-10-30 05:43:42 --> Model "Student_model" initialized
INFO - 2025-10-30 05:43:42 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:43:42 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:43:42 --> Helper loaded: form_helper
INFO - 2025-10-30 05:43:42 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:43:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:43:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 05:43:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:43:42 --> Final output sent to browser
DEBUG - 2025-10-30 05:43:42 --> Total execution time: 0.0712
INFO - 2025-10-30 05:43:44 --> Config Class Initialized
INFO - 2025-10-30 05:43:44 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:43:44 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:43:44 --> Utf8 Class Initialized
INFO - 2025-10-30 05:43:44 --> URI Class Initialized
INFO - 2025-10-30 05:43:44 --> Router Class Initialized
INFO - 2025-10-30 05:43:44 --> Output Class Initialized
INFO - 2025-10-30 05:43:44 --> Security Class Initialized
DEBUG - 2025-10-30 05:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:43:44 --> Input Class Initialized
INFO - 2025-10-30 05:43:44 --> Language Class Initialized
INFO - 2025-10-30 05:43:44 --> Loader Class Initialized
INFO - 2025-10-30 05:43:44 --> Helper loaded: url_helper
INFO - 2025-10-30 05:43:44 --> Database Driver Class Initialized
INFO - 2025-10-30 05:43:44 --> Controller Class Initialized
INFO - 2025-10-30 05:43:44 --> Model "Student_model" initialized
INFO - 2025-10-30 05:43:44 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:43:44 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:43:44 --> Helper loaded: form_helper
INFO - 2025-10-30 05:43:44 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:43:44 --> Payments Controller Loaded
INFO - 2025-10-30 05:43:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:43:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/index.php
INFO - 2025-10-30 05:43:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:43:44 --> Final output sent to browser
DEBUG - 2025-10-30 05:43:44 --> Total execution time: 0.0715
INFO - 2025-10-30 05:43:51 --> Config Class Initialized
INFO - 2025-10-30 05:43:51 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:43:51 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:43:51 --> Utf8 Class Initialized
INFO - 2025-10-30 05:43:51 --> URI Class Initialized
INFO - 2025-10-30 05:43:51 --> Router Class Initialized
INFO - 2025-10-30 05:43:51 --> Output Class Initialized
INFO - 2025-10-30 05:43:51 --> Security Class Initialized
DEBUG - 2025-10-30 05:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:43:51 --> Input Class Initialized
INFO - 2025-10-30 05:43:51 --> Language Class Initialized
INFO - 2025-10-30 05:43:51 --> Loader Class Initialized
INFO - 2025-10-30 05:43:51 --> Helper loaded: url_helper
INFO - 2025-10-30 05:43:51 --> Database Driver Class Initialized
INFO - 2025-10-30 05:43:51 --> Controller Class Initialized
INFO - 2025-10-30 05:43:51 --> Model "Student_model" initialized
INFO - 2025-10-30 05:43:51 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:43:51 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:43:51 --> Helper loaded: form_helper
INFO - 2025-10-30 05:43:51 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:43:51 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:43:51 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 05:43:51 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:43:51 --> Final output sent to browser
DEBUG - 2025-10-30 05:43:51 --> Total execution time: 0.0722
INFO - 2025-10-30 05:44:44 --> Config Class Initialized
INFO - 2025-10-30 05:44:44 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:44:44 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:44:44 --> Utf8 Class Initialized
INFO - 2025-10-30 05:44:44 --> URI Class Initialized
INFO - 2025-10-30 05:44:44 --> Router Class Initialized
INFO - 2025-10-30 05:44:44 --> Output Class Initialized
INFO - 2025-10-30 05:44:44 --> Security Class Initialized
DEBUG - 2025-10-30 05:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:44:44 --> Input Class Initialized
INFO - 2025-10-30 05:44:44 --> Language Class Initialized
INFO - 2025-10-30 05:44:44 --> Loader Class Initialized
INFO - 2025-10-30 05:44:44 --> Helper loaded: url_helper
INFO - 2025-10-30 05:44:44 --> Database Driver Class Initialized
INFO - 2025-10-30 05:44:44 --> Controller Class Initialized
INFO - 2025-10-30 05:44:44 --> Model "Student_model" initialized
INFO - 2025-10-30 05:44:44 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:44:44 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:44:44 --> Helper loaded: form_helper
INFO - 2025-10-30 05:44:44 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:44:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:44:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 05:44:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:44:44 --> Final output sent to browser
DEBUG - 2025-10-30 05:44:44 --> Total execution time: 0.1021
INFO - 2025-10-30 05:44:45 --> Config Class Initialized
INFO - 2025-10-30 05:44:45 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:44:45 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:44:45 --> Utf8 Class Initialized
INFO - 2025-10-30 05:44:45 --> URI Class Initialized
INFO - 2025-10-30 05:44:45 --> Router Class Initialized
INFO - 2025-10-30 05:44:45 --> Output Class Initialized
INFO - 2025-10-30 05:44:45 --> Security Class Initialized
DEBUG - 2025-10-30 05:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:44:45 --> Input Class Initialized
INFO - 2025-10-30 05:44:45 --> Language Class Initialized
INFO - 2025-10-30 05:44:45 --> Loader Class Initialized
INFO - 2025-10-30 05:44:45 --> Helper loaded: url_helper
INFO - 2025-10-30 05:44:45 --> Database Driver Class Initialized
INFO - 2025-10-30 05:44:45 --> Controller Class Initialized
INFO - 2025-10-30 05:44:45 --> Model "Student_model" initialized
INFO - 2025-10-30 05:44:45 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:44:45 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:44:45 --> Helper loaded: form_helper
INFO - 2025-10-30 05:44:45 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:44:45 --> Final output sent to browser
DEBUG - 2025-10-30 05:44:45 --> Total execution time: 0.0488
INFO - 2025-10-30 05:45:09 --> Config Class Initialized
INFO - 2025-10-30 05:45:09 --> Hooks Class Initialized
DEBUG - 2025-10-30 05:45:09 --> UTF-8 Support Enabled
INFO - 2025-10-30 05:45:09 --> Utf8 Class Initialized
INFO - 2025-10-30 05:45:09 --> URI Class Initialized
INFO - 2025-10-30 05:45:09 --> Router Class Initialized
INFO - 2025-10-30 05:45:09 --> Output Class Initialized
INFO - 2025-10-30 05:45:09 --> Security Class Initialized
DEBUG - 2025-10-30 05:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 05:45:09 --> Input Class Initialized
INFO - 2025-10-30 05:45:09 --> Language Class Initialized
INFO - 2025-10-30 05:45:09 --> Loader Class Initialized
INFO - 2025-10-30 05:45:09 --> Helper loaded: url_helper
INFO - 2025-10-30 05:45:09 --> Database Driver Class Initialized
INFO - 2025-10-30 05:45:09 --> Controller Class Initialized
INFO - 2025-10-30 05:45:09 --> Model "Student_model" initialized
INFO - 2025-10-30 05:45:09 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 05:45:09 --> Model "Payment_model" initialized
INFO - 2025-10-30 05:45:09 --> Helper loaded: form_helper
INFO - 2025-10-30 05:45:09 --> Form Validation Class Initialized
DEBUG - 2025-10-30 05:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 05:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 05:45:09 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 05:45:09 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 05:45:09 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 05:45:09 --> Final output sent to browser
DEBUG - 2025-10-30 05:45:09 --> Total execution time: 0.0814
INFO - 2025-10-30 06:20:15 --> Config Class Initialized
INFO - 2025-10-30 06:20:15 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:20:15 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:20:15 --> Utf8 Class Initialized
INFO - 2025-10-30 06:20:15 --> URI Class Initialized
INFO - 2025-10-30 06:20:15 --> Router Class Initialized
INFO - 2025-10-30 06:20:15 --> Output Class Initialized
INFO - 2025-10-30 06:20:15 --> Security Class Initialized
DEBUG - 2025-10-30 06:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:20:15 --> Input Class Initialized
INFO - 2025-10-30 06:20:15 --> Language Class Initialized
INFO - 2025-10-30 06:20:15 --> Loader Class Initialized
INFO - 2025-10-30 06:20:15 --> Helper loaded: url_helper
INFO - 2025-10-30 06:20:15 --> Database Driver Class Initialized
INFO - 2025-10-30 06:20:15 --> Controller Class Initialized
INFO - 2025-10-30 06:20:15 --> Model "Student_model" initialized
INFO - 2025-10-30 06:20:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:20:15 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:20:15 --> Helper loaded: form_helper
INFO - 2025-10-30 06:20:15 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:20:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 06:20:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 06:20:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 06:20:15 --> Final output sent to browser
DEBUG - 2025-10-30 06:20:15 --> Total execution time: 0.0661
INFO - 2025-10-30 06:20:19 --> Config Class Initialized
INFO - 2025-10-30 06:20:19 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:20:19 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:20:19 --> Utf8 Class Initialized
INFO - 2025-10-30 06:20:19 --> URI Class Initialized
INFO - 2025-10-30 06:20:19 --> Router Class Initialized
INFO - 2025-10-30 06:20:19 --> Output Class Initialized
INFO - 2025-10-30 06:20:19 --> Security Class Initialized
DEBUG - 2025-10-30 06:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:20:19 --> Input Class Initialized
INFO - 2025-10-30 06:20:19 --> Language Class Initialized
INFO - 2025-10-30 06:20:19 --> Loader Class Initialized
INFO - 2025-10-30 06:20:19 --> Helper loaded: url_helper
INFO - 2025-10-30 06:20:19 --> Database Driver Class Initialized
INFO - 2025-10-30 06:20:19 --> Controller Class Initialized
INFO - 2025-10-30 06:20:19 --> Model "Student_model" initialized
INFO - 2025-10-30 06:20:19 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:20:19 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:20:19 --> Helper loaded: form_helper
INFO - 2025-10-30 06:20:19 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:20:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 06:20:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 06:20:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 06:20:19 --> Final output sent to browser
DEBUG - 2025-10-30 06:20:19 --> Total execution time: 0.0750
INFO - 2025-10-30 06:20:20 --> Config Class Initialized
INFO - 2025-10-30 06:20:20 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:20:20 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:20:20 --> Utf8 Class Initialized
INFO - 2025-10-30 06:20:20 --> URI Class Initialized
INFO - 2025-10-30 06:20:20 --> Router Class Initialized
INFO - 2025-10-30 06:20:20 --> Output Class Initialized
INFO - 2025-10-30 06:20:20 --> Security Class Initialized
DEBUG - 2025-10-30 06:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:20:20 --> Input Class Initialized
INFO - 2025-10-30 06:20:20 --> Language Class Initialized
ERROR - 2025-10-30 06:20:20 --> 404 Page Not Found: Student-fees/search_student
INFO - 2025-10-30 06:20:22 --> Config Class Initialized
INFO - 2025-10-30 06:20:22 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:20:22 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:20:22 --> Utf8 Class Initialized
INFO - 2025-10-30 06:20:22 --> URI Class Initialized
INFO - 2025-10-30 06:20:22 --> Router Class Initialized
INFO - 2025-10-30 06:20:22 --> Output Class Initialized
INFO - 2025-10-30 06:20:22 --> Security Class Initialized
DEBUG - 2025-10-30 06:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:20:22 --> Input Class Initialized
INFO - 2025-10-30 06:20:22 --> Language Class Initialized
ERROR - 2025-10-30 06:20:22 --> 404 Page Not Found: Student-fees/search_student
INFO - 2025-10-30 06:20:38 --> Config Class Initialized
INFO - 2025-10-30 06:20:38 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:20:38 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:20:38 --> Utf8 Class Initialized
INFO - 2025-10-30 06:20:38 --> URI Class Initialized
INFO - 2025-10-30 06:20:38 --> Router Class Initialized
INFO - 2025-10-30 06:20:38 --> Output Class Initialized
INFO - 2025-10-30 06:20:38 --> Security Class Initialized
DEBUG - 2025-10-30 06:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:20:38 --> Input Class Initialized
INFO - 2025-10-30 06:20:38 --> Language Class Initialized
INFO - 2025-10-30 06:20:38 --> Loader Class Initialized
INFO - 2025-10-30 06:20:38 --> Helper loaded: url_helper
INFO - 2025-10-30 06:20:38 --> Database Driver Class Initialized
INFO - 2025-10-30 06:20:38 --> Controller Class Initialized
INFO - 2025-10-30 06:20:38 --> Model "Student_model" initialized
INFO - 2025-10-30 06:20:38 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:20:38 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:20:38 --> Helper loaded: form_helper
INFO - 2025-10-30 06:20:38 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:20:38 --> Final output sent to browser
DEBUG - 2025-10-30 06:20:38 --> Total execution time: 0.0844
INFO - 2025-10-30 06:20:39 --> Config Class Initialized
INFO - 2025-10-30 06:20:39 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:20:39 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:20:39 --> Utf8 Class Initialized
INFO - 2025-10-30 06:20:39 --> URI Class Initialized
INFO - 2025-10-30 06:20:39 --> Router Class Initialized
INFO - 2025-10-30 06:20:39 --> Output Class Initialized
INFO - 2025-10-30 06:20:39 --> Security Class Initialized
DEBUG - 2025-10-30 06:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:20:39 --> Input Class Initialized
INFO - 2025-10-30 06:20:39 --> Language Class Initialized
INFO - 2025-10-30 06:20:39 --> Loader Class Initialized
INFO - 2025-10-30 06:20:39 --> Helper loaded: url_helper
INFO - 2025-10-30 06:20:39 --> Database Driver Class Initialized
INFO - 2025-10-30 06:20:39 --> Controller Class Initialized
INFO - 2025-10-30 06:20:39 --> Model "Student_model" initialized
INFO - 2025-10-30 06:20:39 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:20:39 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:20:39 --> Helper loaded: form_helper
INFO - 2025-10-30 06:20:39 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:20:39 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 06:20:39 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 06:20:39 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 06:20:39 --> Final output sent to browser
DEBUG - 2025-10-30 06:20:39 --> Total execution time: 0.0479
INFO - 2025-10-30 06:20:39 --> Config Class Initialized
INFO - 2025-10-30 06:20:39 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:20:39 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:20:39 --> Utf8 Class Initialized
INFO - 2025-10-30 06:20:39 --> URI Class Initialized
INFO - 2025-10-30 06:20:39 --> Router Class Initialized
INFO - 2025-10-30 06:20:39 --> Output Class Initialized
INFO - 2025-10-30 06:20:39 --> Security Class Initialized
DEBUG - 2025-10-30 06:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:20:39 --> Input Class Initialized
INFO - 2025-10-30 06:20:39 --> Language Class Initialized
INFO - 2025-10-30 06:20:40 --> Loader Class Initialized
INFO - 2025-10-30 06:20:40 --> Helper loaded: url_helper
INFO - 2025-10-30 06:20:40 --> Database Driver Class Initialized
INFO - 2025-10-30 06:20:40 --> Controller Class Initialized
INFO - 2025-10-30 06:20:40 --> Model "Student_model" initialized
INFO - 2025-10-30 06:20:40 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:20:40 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:20:40 --> Helper loaded: form_helper
INFO - 2025-10-30 06:20:40 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:20:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 06:20:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 06:20:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 06:20:40 --> Final output sent to browser
DEBUG - 2025-10-30 06:20:40 --> Total execution time: 0.0574
INFO - 2025-10-30 06:20:40 --> Config Class Initialized
INFO - 2025-10-30 06:20:40 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:20:40 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:20:40 --> Utf8 Class Initialized
INFO - 2025-10-30 06:20:40 --> URI Class Initialized
INFO - 2025-10-30 06:20:40 --> Router Class Initialized
INFO - 2025-10-30 06:20:40 --> Output Class Initialized
INFO - 2025-10-30 06:20:40 --> Security Class Initialized
DEBUG - 2025-10-30 06:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:20:40 --> Input Class Initialized
INFO - 2025-10-30 06:20:40 --> Language Class Initialized
INFO - 2025-10-30 06:20:40 --> Loader Class Initialized
INFO - 2025-10-30 06:20:40 --> Helper loaded: url_helper
INFO - 2025-10-30 06:20:40 --> Database Driver Class Initialized
INFO - 2025-10-30 06:20:40 --> Controller Class Initialized
INFO - 2025-10-30 06:20:40 --> Model "Student_model" initialized
INFO - 2025-10-30 06:20:40 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:20:40 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:20:40 --> Helper loaded: form_helper
INFO - 2025-10-30 06:20:40 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:20:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 06:20:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 06:20:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 06:20:40 --> Final output sent to browser
DEBUG - 2025-10-30 06:20:40 --> Total execution time: 0.0540
INFO - 2025-10-30 06:20:40 --> Config Class Initialized
INFO - 2025-10-30 06:20:40 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:20:40 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:20:40 --> Utf8 Class Initialized
INFO - 2025-10-30 06:20:40 --> URI Class Initialized
INFO - 2025-10-30 06:20:40 --> Router Class Initialized
INFO - 2025-10-30 06:20:40 --> Output Class Initialized
INFO - 2025-10-30 06:20:40 --> Security Class Initialized
DEBUG - 2025-10-30 06:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:20:40 --> Input Class Initialized
INFO - 2025-10-30 06:20:40 --> Language Class Initialized
INFO - 2025-10-30 06:20:40 --> Loader Class Initialized
INFO - 2025-10-30 06:20:40 --> Helper loaded: url_helper
INFO - 2025-10-30 06:20:40 --> Database Driver Class Initialized
INFO - 2025-10-30 06:20:40 --> Controller Class Initialized
INFO - 2025-10-30 06:20:40 --> Model "Student_model" initialized
INFO - 2025-10-30 06:20:40 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:20:40 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:20:40 --> Helper loaded: form_helper
INFO - 2025-10-30 06:20:40 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:20:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 06:20:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 06:20:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 06:20:40 --> Final output sent to browser
DEBUG - 2025-10-30 06:20:40 --> Total execution time: 0.0768
INFO - 2025-10-30 06:20:41 --> Config Class Initialized
INFO - 2025-10-30 06:20:41 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:20:41 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:20:41 --> Utf8 Class Initialized
INFO - 2025-10-30 06:20:41 --> URI Class Initialized
INFO - 2025-10-30 06:20:41 --> Router Class Initialized
INFO - 2025-10-30 06:20:41 --> Output Class Initialized
INFO - 2025-10-30 06:20:41 --> Security Class Initialized
DEBUG - 2025-10-30 06:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:20:41 --> Input Class Initialized
INFO - 2025-10-30 06:20:41 --> Language Class Initialized
INFO - 2025-10-30 06:20:41 --> Loader Class Initialized
INFO - 2025-10-30 06:20:41 --> Helper loaded: url_helper
INFO - 2025-10-30 06:20:41 --> Database Driver Class Initialized
INFO - 2025-10-30 06:20:41 --> Controller Class Initialized
INFO - 2025-10-30 06:20:41 --> Model "Student_model" initialized
INFO - 2025-10-30 06:20:41 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:20:41 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:20:41 --> Helper loaded: form_helper
INFO - 2025-10-30 06:20:41 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:20:41 --> Final output sent to browser
DEBUG - 2025-10-30 06:20:41 --> Total execution time: 0.0898
INFO - 2025-10-30 06:20:49 --> Config Class Initialized
INFO - 2025-10-30 06:20:49 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:20:49 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:20:49 --> Utf8 Class Initialized
INFO - 2025-10-30 06:20:49 --> URI Class Initialized
INFO - 2025-10-30 06:20:49 --> Router Class Initialized
INFO - 2025-10-30 06:20:49 --> Output Class Initialized
INFO - 2025-10-30 06:20:49 --> Security Class Initialized
DEBUG - 2025-10-30 06:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:20:49 --> Input Class Initialized
INFO - 2025-10-30 06:20:49 --> Language Class Initialized
INFO - 2025-10-30 06:20:49 --> Loader Class Initialized
INFO - 2025-10-30 06:20:49 --> Helper loaded: url_helper
INFO - 2025-10-30 06:20:49 --> Database Driver Class Initialized
INFO - 2025-10-30 06:20:49 --> Controller Class Initialized
INFO - 2025-10-30 06:20:49 --> Model "Student_model" initialized
INFO - 2025-10-30 06:20:49 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:20:49 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:20:49 --> Helper loaded: form_helper
INFO - 2025-10-30 06:20:49 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:20:49 --> Final output sent to browser
DEBUG - 2025-10-30 06:20:49 --> Total execution time: 0.0766
INFO - 2025-10-30 06:21:26 --> Config Class Initialized
INFO - 2025-10-30 06:21:26 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:21:26 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:21:26 --> Utf8 Class Initialized
INFO - 2025-10-30 06:21:26 --> URI Class Initialized
INFO - 2025-10-30 06:21:26 --> Router Class Initialized
INFO - 2025-10-30 06:21:26 --> Output Class Initialized
INFO - 2025-10-30 06:21:26 --> Security Class Initialized
DEBUG - 2025-10-30 06:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:21:26 --> Input Class Initialized
INFO - 2025-10-30 06:21:26 --> Language Class Initialized
INFO - 2025-10-30 06:21:26 --> Loader Class Initialized
INFO - 2025-10-30 06:21:26 --> Helper loaded: url_helper
INFO - 2025-10-30 06:21:26 --> Database Driver Class Initialized
INFO - 2025-10-30 06:21:26 --> Controller Class Initialized
INFO - 2025-10-30 06:21:26 --> Model "Student_model" initialized
INFO - 2025-10-30 06:21:26 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:21:26 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:21:26 --> Helper loaded: form_helper
INFO - 2025-10-30 06:21:26 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:21:26 --> Final output sent to browser
DEBUG - 2025-10-30 06:21:26 --> Total execution time: 0.0532
INFO - 2025-10-30 06:21:33 --> Config Class Initialized
INFO - 2025-10-30 06:21:33 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:21:33 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:21:33 --> Utf8 Class Initialized
INFO - 2025-10-30 06:21:33 --> URI Class Initialized
INFO - 2025-10-30 06:21:33 --> Router Class Initialized
INFO - 2025-10-30 06:21:33 --> Output Class Initialized
INFO - 2025-10-30 06:21:33 --> Security Class Initialized
DEBUG - 2025-10-30 06:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:21:33 --> Input Class Initialized
INFO - 2025-10-30 06:21:33 --> Language Class Initialized
INFO - 2025-10-30 06:21:33 --> Loader Class Initialized
INFO - 2025-10-30 06:21:33 --> Helper loaded: url_helper
INFO - 2025-10-30 06:21:33 --> Database Driver Class Initialized
INFO - 2025-10-30 06:21:33 --> Controller Class Initialized
INFO - 2025-10-30 06:21:33 --> Model "Student_model" initialized
INFO - 2025-10-30 06:21:33 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:21:33 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:21:33 --> Helper loaded: form_helper
INFO - 2025-10-30 06:21:33 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:21:33 --> Final output sent to browser
DEBUG - 2025-10-30 06:21:33 --> Total execution time: 0.0586
INFO - 2025-10-30 06:21:38 --> Config Class Initialized
INFO - 2025-10-30 06:21:38 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:21:38 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:21:38 --> Utf8 Class Initialized
INFO - 2025-10-30 06:21:38 --> URI Class Initialized
INFO - 2025-10-30 06:21:38 --> Router Class Initialized
INFO - 2025-10-30 06:21:38 --> Output Class Initialized
INFO - 2025-10-30 06:21:38 --> Security Class Initialized
DEBUG - 2025-10-30 06:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:21:38 --> Input Class Initialized
INFO - 2025-10-30 06:21:38 --> Language Class Initialized
INFO - 2025-10-30 06:21:38 --> Loader Class Initialized
INFO - 2025-10-30 06:21:38 --> Helper loaded: url_helper
INFO - 2025-10-30 06:21:38 --> Database Driver Class Initialized
INFO - 2025-10-30 06:21:38 --> Controller Class Initialized
INFO - 2025-10-30 06:21:38 --> Model "Student_model" initialized
INFO - 2025-10-30 06:21:38 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:21:38 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:21:38 --> Helper loaded: form_helper
INFO - 2025-10-30 06:21:38 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:21:38 --> Final output sent to browser
DEBUG - 2025-10-30 06:21:38 --> Total execution time: 0.0615
INFO - 2025-10-30 06:21:39 --> Config Class Initialized
INFO - 2025-10-30 06:21:39 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:21:39 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:21:39 --> Utf8 Class Initialized
INFO - 2025-10-30 06:21:39 --> URI Class Initialized
INFO - 2025-10-30 06:21:39 --> Router Class Initialized
INFO - 2025-10-30 06:21:39 --> Output Class Initialized
INFO - 2025-10-30 06:21:39 --> Security Class Initialized
DEBUG - 2025-10-30 06:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:21:39 --> Input Class Initialized
INFO - 2025-10-30 06:21:39 --> Language Class Initialized
INFO - 2025-10-30 06:21:39 --> Loader Class Initialized
INFO - 2025-10-30 06:21:39 --> Helper loaded: url_helper
INFO - 2025-10-30 06:21:39 --> Database Driver Class Initialized
INFO - 2025-10-30 06:21:39 --> Controller Class Initialized
INFO - 2025-10-30 06:21:39 --> Model "Student_model" initialized
INFO - 2025-10-30 06:21:39 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:21:39 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:21:39 --> Helper loaded: form_helper
INFO - 2025-10-30 06:21:39 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:21:39 --> Final output sent to browser
DEBUG - 2025-10-30 06:21:39 --> Total execution time: 0.1635
INFO - 2025-10-30 06:21:42 --> Config Class Initialized
INFO - 2025-10-30 06:21:42 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:21:42 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:21:42 --> Utf8 Class Initialized
INFO - 2025-10-30 06:21:42 --> URI Class Initialized
INFO - 2025-10-30 06:21:42 --> Router Class Initialized
INFO - 2025-10-30 06:21:42 --> Output Class Initialized
INFO - 2025-10-30 06:21:42 --> Security Class Initialized
DEBUG - 2025-10-30 06:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:21:42 --> Input Class Initialized
INFO - 2025-10-30 06:21:42 --> Language Class Initialized
INFO - 2025-10-30 06:21:42 --> Loader Class Initialized
INFO - 2025-10-30 06:21:42 --> Helper loaded: url_helper
INFO - 2025-10-30 06:21:42 --> Database Driver Class Initialized
INFO - 2025-10-30 06:21:42 --> Controller Class Initialized
INFO - 2025-10-30 06:21:42 --> Model "Student_model" initialized
INFO - 2025-10-30 06:21:42 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:21:42 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:21:42 --> Helper loaded: form_helper
INFO - 2025-10-30 06:21:42 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:21:42 --> Final output sent to browser
DEBUG - 2025-10-30 06:21:42 --> Total execution time: 0.0454
INFO - 2025-10-30 06:21:43 --> Config Class Initialized
INFO - 2025-10-30 06:21:43 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:21:43 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:21:43 --> Utf8 Class Initialized
INFO - 2025-10-30 06:21:43 --> URI Class Initialized
INFO - 2025-10-30 06:21:43 --> Router Class Initialized
INFO - 2025-10-30 06:21:43 --> Output Class Initialized
INFO - 2025-10-30 06:21:43 --> Security Class Initialized
DEBUG - 2025-10-30 06:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:21:43 --> Input Class Initialized
INFO - 2025-10-30 06:21:43 --> Language Class Initialized
INFO - 2025-10-30 06:21:43 --> Loader Class Initialized
INFO - 2025-10-30 06:21:43 --> Helper loaded: url_helper
INFO - 2025-10-30 06:21:43 --> Database Driver Class Initialized
INFO - 2025-10-30 06:21:43 --> Controller Class Initialized
INFO - 2025-10-30 06:21:43 --> Model "Student_model" initialized
INFO - 2025-10-30 06:21:43 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:21:43 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:21:43 --> Helper loaded: form_helper
INFO - 2025-10-30 06:21:43 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:21:43 --> Final output sent to browser
DEBUG - 2025-10-30 06:21:43 --> Total execution time: 0.0702
INFO - 2025-10-30 06:21:44 --> Config Class Initialized
INFO - 2025-10-30 06:21:44 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:21:44 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:21:44 --> Utf8 Class Initialized
INFO - 2025-10-30 06:21:44 --> URI Class Initialized
INFO - 2025-10-30 06:21:44 --> Router Class Initialized
INFO - 2025-10-30 06:21:44 --> Output Class Initialized
INFO - 2025-10-30 06:21:44 --> Security Class Initialized
DEBUG - 2025-10-30 06:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:21:44 --> Input Class Initialized
INFO - 2025-10-30 06:21:44 --> Language Class Initialized
INFO - 2025-10-30 06:21:44 --> Loader Class Initialized
INFO - 2025-10-30 06:21:44 --> Helper loaded: url_helper
INFO - 2025-10-30 06:21:44 --> Database Driver Class Initialized
INFO - 2025-10-30 06:21:44 --> Controller Class Initialized
INFO - 2025-10-30 06:21:44 --> Model "Student_model" initialized
INFO - 2025-10-30 06:21:44 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:21:44 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:21:44 --> Helper loaded: form_helper
INFO - 2025-10-30 06:21:44 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:21:44 --> Final output sent to browser
DEBUG - 2025-10-30 06:21:44 --> Total execution time: 0.1048
INFO - 2025-10-30 06:21:54 --> Config Class Initialized
INFO - 2025-10-30 06:21:54 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:21:54 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:21:54 --> Utf8 Class Initialized
INFO - 2025-10-30 06:21:54 --> URI Class Initialized
INFO - 2025-10-30 06:21:54 --> Router Class Initialized
INFO - 2025-10-30 06:21:54 --> Output Class Initialized
INFO - 2025-10-30 06:21:54 --> Security Class Initialized
DEBUG - 2025-10-30 06:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:21:54 --> Input Class Initialized
INFO - 2025-10-30 06:21:54 --> Language Class Initialized
INFO - 2025-10-30 06:21:54 --> Loader Class Initialized
INFO - 2025-10-30 06:21:54 --> Helper loaded: url_helper
INFO - 2025-10-30 06:21:54 --> Database Driver Class Initialized
INFO - 2025-10-30 06:21:54 --> Controller Class Initialized
INFO - 2025-10-30 06:21:54 --> Model "Student_model" initialized
INFO - 2025-10-30 06:21:54 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:21:54 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:21:54 --> Helper loaded: form_helper
INFO - 2025-10-30 06:21:54 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:21:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 06:21:54 --> Config Class Initialized
INFO - 2025-10-30 06:21:54 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:21:54 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:21:54 --> Utf8 Class Initialized
INFO - 2025-10-30 06:21:54 --> URI Class Initialized
INFO - 2025-10-30 06:21:54 --> Router Class Initialized
INFO - 2025-10-30 06:21:54 --> Output Class Initialized
INFO - 2025-10-30 06:21:54 --> Security Class Initialized
DEBUG - 2025-10-30 06:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:21:54 --> Input Class Initialized
INFO - 2025-10-30 06:21:54 --> Language Class Initialized
INFO - 2025-10-30 06:21:54 --> Loader Class Initialized
INFO - 2025-10-30 06:21:54 --> Helper loaded: url_helper
INFO - 2025-10-30 06:21:54 --> Database Driver Class Initialized
INFO - 2025-10-30 06:21:54 --> Controller Class Initialized
INFO - 2025-10-30 06:21:54 --> Model "Student_model" initialized
INFO - 2025-10-30 06:21:54 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:21:54 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:21:54 --> Helper loaded: form_helper
INFO - 2025-10-30 06:21:54 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:21:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 06:21:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 06:21:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 06:21:54 --> Final output sent to browser
DEBUG - 2025-10-30 06:21:54 --> Total execution time: 0.0524
INFO - 2025-10-30 06:23:50 --> Config Class Initialized
INFO - 2025-10-30 06:23:50 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:23:50 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:23:50 --> Utf8 Class Initialized
INFO - 2025-10-30 06:23:50 --> URI Class Initialized
INFO - 2025-10-30 06:23:50 --> Router Class Initialized
INFO - 2025-10-30 06:23:50 --> Output Class Initialized
INFO - 2025-10-30 06:23:50 --> Security Class Initialized
DEBUG - 2025-10-30 06:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:23:50 --> Input Class Initialized
INFO - 2025-10-30 06:23:50 --> Language Class Initialized
INFO - 2025-10-30 06:23:50 --> Loader Class Initialized
INFO - 2025-10-30 06:23:50 --> Helper loaded: url_helper
INFO - 2025-10-30 06:23:50 --> Database Driver Class Initialized
INFO - 2025-10-30 06:23:50 --> Controller Class Initialized
INFO - 2025-10-30 06:23:50 --> Model "Student_model" initialized
INFO - 2025-10-30 06:23:50 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:23:50 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:23:50 --> Helper loaded: form_helper
INFO - 2025-10-30 06:23:50 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:23:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 06:23:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 06:23:50 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 06:23:50 --> Final output sent to browser
DEBUG - 2025-10-30 06:23:50 --> Total execution time: 0.0604
INFO - 2025-10-30 06:27:32 --> Config Class Initialized
INFO - 2025-10-30 06:27:32 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:27:32 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:27:32 --> Utf8 Class Initialized
INFO - 2025-10-30 06:27:32 --> URI Class Initialized
INFO - 2025-10-30 06:27:32 --> Router Class Initialized
INFO - 2025-10-30 06:27:32 --> Output Class Initialized
INFO - 2025-10-30 06:27:32 --> Security Class Initialized
DEBUG - 2025-10-30 06:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:27:32 --> Input Class Initialized
INFO - 2025-10-30 06:27:32 --> Language Class Initialized
INFO - 2025-10-30 06:27:32 --> Loader Class Initialized
INFO - 2025-10-30 06:27:32 --> Helper loaded: url_helper
INFO - 2025-10-30 06:27:32 --> Database Driver Class Initialized
INFO - 2025-10-30 06:27:32 --> Controller Class Initialized
INFO - 2025-10-30 06:27:32 --> Model "Student_model" initialized
INFO - 2025-10-30 06:27:32 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:27:32 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:27:32 --> Helper loaded: form_helper
INFO - 2025-10-30 06:27:32 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:27:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 06:27:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 06:27:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 06:27:32 --> Final output sent to browser
DEBUG - 2025-10-30 06:27:32 --> Total execution time: 0.0753
INFO - 2025-10-30 06:27:36 --> Config Class Initialized
INFO - 2025-10-30 06:27:36 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:27:36 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:27:36 --> Utf8 Class Initialized
INFO - 2025-10-30 06:27:36 --> URI Class Initialized
INFO - 2025-10-30 06:27:36 --> Router Class Initialized
INFO - 2025-10-30 06:27:36 --> Output Class Initialized
INFO - 2025-10-30 06:27:36 --> Security Class Initialized
DEBUG - 2025-10-30 06:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:27:36 --> Input Class Initialized
INFO - 2025-10-30 06:27:36 --> Language Class Initialized
INFO - 2025-10-30 06:27:36 --> Loader Class Initialized
INFO - 2025-10-30 06:27:36 --> Helper loaded: url_helper
INFO - 2025-10-30 06:27:36 --> Database Driver Class Initialized
INFO - 2025-10-30 06:27:36 --> Controller Class Initialized
INFO - 2025-10-30 06:27:36 --> Model "Student_model" initialized
INFO - 2025-10-30 06:27:36 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:27:36 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:27:36 --> Helper loaded: form_helper
INFO - 2025-10-30 06:27:36 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:27:36 --> Payments Controller Loaded
INFO - 2025-10-30 06:27:36 --> Config Class Initialized
INFO - 2025-10-30 06:27:36 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:27:36 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:27:36 --> Utf8 Class Initialized
INFO - 2025-10-30 06:27:36 --> URI Class Initialized
INFO - 2025-10-30 06:27:36 --> Router Class Initialized
INFO - 2025-10-30 06:27:36 --> Output Class Initialized
INFO - 2025-10-30 06:27:36 --> Security Class Initialized
DEBUG - 2025-10-30 06:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:27:36 --> Input Class Initialized
INFO - 2025-10-30 06:27:36 --> Language Class Initialized
ERROR - 2025-10-30 06:27:36 --> 404 Page Not Found: api/Mtb_gateway/get_billing_info
ERROR - 2025-10-30 06:27:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\pioneer-dental\application\controllers\Payments.php 129
INFO - 2025-10-30 06:27:36 --> Config Class Initialized
INFO - 2025-10-30 06:27:36 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:27:36 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:27:36 --> Utf8 Class Initialized
INFO - 2025-10-30 06:27:36 --> URI Class Initialized
INFO - 2025-10-30 06:27:36 --> Router Class Initialized
INFO - 2025-10-30 06:27:36 --> Output Class Initialized
INFO - 2025-10-30 06:27:36 --> Security Class Initialized
DEBUG - 2025-10-30 06:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:27:36 --> Input Class Initialized
INFO - 2025-10-30 06:27:36 --> Language Class Initialized
INFO - 2025-10-30 06:27:36 --> Loader Class Initialized
INFO - 2025-10-30 06:27:36 --> Helper loaded: url_helper
INFO - 2025-10-30 06:27:36 --> Database Driver Class Initialized
INFO - 2025-10-30 06:27:36 --> Controller Class Initialized
INFO - 2025-10-30 06:27:36 --> Model "Student_model" initialized
INFO - 2025-10-30 06:27:36 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:27:36 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:27:36 --> Helper loaded: form_helper
INFO - 2025-10-30 06:27:36 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:27:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 06:27:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 06:27:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 06:27:36 --> Final output sent to browser
DEBUG - 2025-10-30 06:27:36 --> Total execution time: 0.0562
INFO - 2025-10-30 06:27:38 --> Config Class Initialized
INFO - 2025-10-30 06:27:38 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:27:38 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:27:38 --> Utf8 Class Initialized
INFO - 2025-10-30 06:27:38 --> URI Class Initialized
INFO - 2025-10-30 06:27:38 --> Router Class Initialized
INFO - 2025-10-30 06:27:38 --> Output Class Initialized
INFO - 2025-10-30 06:27:38 --> Security Class Initialized
DEBUG - 2025-10-30 06:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:27:38 --> Input Class Initialized
INFO - 2025-10-30 06:27:38 --> Language Class Initialized
INFO - 2025-10-30 06:27:38 --> Loader Class Initialized
INFO - 2025-10-30 06:27:38 --> Helper loaded: url_helper
INFO - 2025-10-30 06:27:38 --> Database Driver Class Initialized
INFO - 2025-10-30 06:27:38 --> Controller Class Initialized
INFO - 2025-10-30 06:27:38 --> Model "Student_model" initialized
INFO - 2025-10-30 06:27:38 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:27:38 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:27:38 --> Helper loaded: form_helper
INFO - 2025-10-30 06:27:38 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:27:38 --> Payments Controller Loaded
INFO - 2025-10-30 06:27:38 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 06:27:38 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 06:27:38 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 06:27:38 --> Final output sent to browser
DEBUG - 2025-10-30 06:27:38 --> Total execution time: 0.0602
INFO - 2025-10-30 06:27:45 --> Config Class Initialized
INFO - 2025-10-30 06:27:45 --> Hooks Class Initialized
DEBUG - 2025-10-30 06:27:45 --> UTF-8 Support Enabled
INFO - 2025-10-30 06:27:45 --> Utf8 Class Initialized
INFO - 2025-10-30 06:27:45 --> URI Class Initialized
INFO - 2025-10-30 06:27:45 --> Router Class Initialized
INFO - 2025-10-30 06:27:45 --> Output Class Initialized
INFO - 2025-10-30 06:27:45 --> Security Class Initialized
DEBUG - 2025-10-30 06:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 06:27:45 --> Input Class Initialized
INFO - 2025-10-30 06:27:45 --> Language Class Initialized
INFO - 2025-10-30 06:27:45 --> Loader Class Initialized
INFO - 2025-10-30 06:27:45 --> Helper loaded: url_helper
INFO - 2025-10-30 06:27:45 --> Database Driver Class Initialized
INFO - 2025-10-30 06:27:45 --> Controller Class Initialized
INFO - 2025-10-30 06:27:45 --> Model "Student_model" initialized
INFO - 2025-10-30 06:27:45 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 06:27:45 --> Model "Payment_model" initialized
INFO - 2025-10-30 06:27:45 --> Helper loaded: form_helper
INFO - 2025-10-30 06:27:45 --> Form Validation Class Initialized
DEBUG - 2025-10-30 06:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 06:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 06:27:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 06:27:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 06:27:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 06:27:45 --> Final output sent to browser
DEBUG - 2025-10-30 06:27:45 --> Total execution time: 0.0527
INFO - 2025-10-30 07:03:32 --> Config Class Initialized
INFO - 2025-10-30 07:03:32 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:03:32 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:03:32 --> Utf8 Class Initialized
INFO - 2025-10-30 07:03:32 --> URI Class Initialized
INFO - 2025-10-30 07:03:32 --> Router Class Initialized
INFO - 2025-10-30 07:03:32 --> Output Class Initialized
INFO - 2025-10-30 07:03:32 --> Security Class Initialized
DEBUG - 2025-10-30 07:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:03:32 --> Input Class Initialized
INFO - 2025-10-30 07:03:32 --> Language Class Initialized
INFO - 2025-10-30 07:03:32 --> Loader Class Initialized
INFO - 2025-10-30 07:03:32 --> Helper loaded: url_helper
INFO - 2025-10-30 07:03:32 --> Database Driver Class Initialized
INFO - 2025-10-30 07:03:32 --> Controller Class Initialized
INFO - 2025-10-30 07:03:32 --> Model "Student_model" initialized
INFO - 2025-10-30 07:03:32 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:03:32 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:03:32 --> Helper loaded: form_helper
INFO - 2025-10-30 07:03:32 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:03:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:03:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 07:03:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:03:32 --> Final output sent to browser
DEBUG - 2025-10-30 07:03:32 --> Total execution time: 0.1370
INFO - 2025-10-30 07:03:35 --> Config Class Initialized
INFO - 2025-10-30 07:03:35 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:03:35 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:03:35 --> Utf8 Class Initialized
INFO - 2025-10-30 07:03:35 --> URI Class Initialized
INFO - 2025-10-30 07:03:35 --> Router Class Initialized
INFO - 2025-10-30 07:03:35 --> Output Class Initialized
INFO - 2025-10-30 07:03:35 --> Security Class Initialized
DEBUG - 2025-10-30 07:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:03:35 --> Input Class Initialized
INFO - 2025-10-30 07:03:35 --> Language Class Initialized
INFO - 2025-10-30 07:03:35 --> Loader Class Initialized
INFO - 2025-10-30 07:03:35 --> Helper loaded: url_helper
INFO - 2025-10-30 07:03:35 --> Database Driver Class Initialized
INFO - 2025-10-30 07:03:35 --> Controller Class Initialized
INFO - 2025-10-30 07:03:35 --> Model "Student_model" initialized
INFO - 2025-10-30 07:03:35 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:03:35 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:03:35 --> Helper loaded: form_helper
INFO - 2025-10-30 07:03:35 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:03:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:03:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 07:03:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:03:35 --> Final output sent to browser
DEBUG - 2025-10-30 07:03:35 --> Total execution time: 0.0988
INFO - 2025-10-30 07:03:37 --> Config Class Initialized
INFO - 2025-10-30 07:03:37 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:03:37 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:03:37 --> Utf8 Class Initialized
INFO - 2025-10-30 07:03:37 --> URI Class Initialized
INFO - 2025-10-30 07:03:37 --> Router Class Initialized
INFO - 2025-10-30 07:03:37 --> Output Class Initialized
INFO - 2025-10-30 07:03:37 --> Security Class Initialized
DEBUG - 2025-10-30 07:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:03:37 --> Input Class Initialized
INFO - 2025-10-30 07:03:37 --> Language Class Initialized
ERROR - 2025-10-30 07:03:37 --> 404 Page Not Found: Student_fees/search_student
INFO - 2025-10-30 07:03:40 --> Config Class Initialized
INFO - 2025-10-30 07:03:40 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:03:40 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:03:40 --> Utf8 Class Initialized
INFO - 2025-10-30 07:03:40 --> URI Class Initialized
INFO - 2025-10-30 07:03:40 --> Router Class Initialized
INFO - 2025-10-30 07:03:40 --> Output Class Initialized
INFO - 2025-10-30 07:03:40 --> Security Class Initialized
DEBUG - 2025-10-30 07:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:03:40 --> Input Class Initialized
INFO - 2025-10-30 07:03:40 --> Language Class Initialized
ERROR - 2025-10-30 07:03:40 --> 404 Page Not Found: Student_fees/search_student
INFO - 2025-10-30 07:03:42 --> Config Class Initialized
INFO - 2025-10-30 07:03:42 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:03:42 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:03:42 --> Utf8 Class Initialized
INFO - 2025-10-30 07:03:42 --> URI Class Initialized
INFO - 2025-10-30 07:03:42 --> Router Class Initialized
INFO - 2025-10-30 07:03:42 --> Output Class Initialized
INFO - 2025-10-30 07:03:42 --> Security Class Initialized
DEBUG - 2025-10-30 07:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:03:42 --> Input Class Initialized
INFO - 2025-10-30 07:03:42 --> Language Class Initialized
ERROR - 2025-10-30 07:03:42 --> 404 Page Not Found: Student_fees/search_student
INFO - 2025-10-30 07:03:48 --> Config Class Initialized
INFO - 2025-10-30 07:03:48 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:03:48 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:03:48 --> Utf8 Class Initialized
INFO - 2025-10-30 07:03:48 --> URI Class Initialized
INFO - 2025-10-30 07:03:48 --> Router Class Initialized
INFO - 2025-10-30 07:03:48 --> Output Class Initialized
INFO - 2025-10-30 07:03:48 --> Security Class Initialized
DEBUG - 2025-10-30 07:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:03:48 --> Input Class Initialized
INFO - 2025-10-30 07:03:48 --> Language Class Initialized
INFO - 2025-10-30 07:03:48 --> Loader Class Initialized
INFO - 2025-10-30 07:03:48 --> Helper loaded: url_helper
INFO - 2025-10-30 07:03:48 --> Database Driver Class Initialized
INFO - 2025-10-30 07:03:48 --> Controller Class Initialized
INFO - 2025-10-30 07:03:48 --> Model "Student_model" initialized
INFO - 2025-10-30 07:03:48 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:03:48 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:03:48 --> Helper loaded: form_helper
INFO - 2025-10-30 07:03:48 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:03:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:03:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 07:03:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:03:48 --> Final output sent to browser
DEBUG - 2025-10-30 07:03:48 --> Total execution time: 0.1340
INFO - 2025-10-30 07:03:51 --> Config Class Initialized
INFO - 2025-10-30 07:03:51 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:03:51 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:03:51 --> Utf8 Class Initialized
INFO - 2025-10-30 07:03:51 --> URI Class Initialized
INFO - 2025-10-30 07:03:52 --> Router Class Initialized
INFO - 2025-10-30 07:03:52 --> Output Class Initialized
INFO - 2025-10-30 07:03:52 --> Security Class Initialized
DEBUG - 2025-10-30 07:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:03:52 --> Input Class Initialized
INFO - 2025-10-30 07:03:52 --> Language Class Initialized
ERROR - 2025-10-30 07:03:52 --> 404 Page Not Found: Student_fees/search_student
INFO - 2025-10-30 07:03:55 --> Config Class Initialized
INFO - 2025-10-30 07:03:55 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:03:55 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:03:55 --> Utf8 Class Initialized
INFO - 2025-10-30 07:03:55 --> URI Class Initialized
INFO - 2025-10-30 07:03:55 --> Router Class Initialized
INFO - 2025-10-30 07:03:55 --> Output Class Initialized
INFO - 2025-10-30 07:03:55 --> Security Class Initialized
DEBUG - 2025-10-30 07:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:03:55 --> Input Class Initialized
INFO - 2025-10-30 07:03:55 --> Language Class Initialized
ERROR - 2025-10-30 07:03:55 --> 404 Page Not Found: Student_fees/search_student
INFO - 2025-10-30 07:03:56 --> Config Class Initialized
INFO - 2025-10-30 07:03:56 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:03:56 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:03:56 --> Utf8 Class Initialized
INFO - 2025-10-30 07:03:56 --> URI Class Initialized
INFO - 2025-10-30 07:03:56 --> Router Class Initialized
INFO - 2025-10-30 07:03:56 --> Output Class Initialized
INFO - 2025-10-30 07:03:56 --> Security Class Initialized
DEBUG - 2025-10-30 07:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:03:56 --> Input Class Initialized
INFO - 2025-10-30 07:03:56 --> Language Class Initialized
ERROR - 2025-10-30 07:03:56 --> 404 Page Not Found: Student_fees/search_student
INFO - 2025-10-30 07:03:56 --> Config Class Initialized
INFO - 2025-10-30 07:03:56 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:03:56 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:03:56 --> Utf8 Class Initialized
INFO - 2025-10-30 07:03:56 --> URI Class Initialized
INFO - 2025-10-30 07:03:56 --> Router Class Initialized
INFO - 2025-10-30 07:03:56 --> Output Class Initialized
INFO - 2025-10-30 07:03:56 --> Security Class Initialized
DEBUG - 2025-10-30 07:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:03:56 --> Input Class Initialized
INFO - 2025-10-30 07:03:56 --> Language Class Initialized
ERROR - 2025-10-30 07:03:56 --> 404 Page Not Found: Student_fees/search_student
INFO - 2025-10-30 07:03:57 --> Config Class Initialized
INFO - 2025-10-30 07:03:57 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:03:57 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:03:57 --> Utf8 Class Initialized
INFO - 2025-10-30 07:03:57 --> URI Class Initialized
INFO - 2025-10-30 07:03:57 --> Router Class Initialized
INFO - 2025-10-30 07:03:57 --> Output Class Initialized
INFO - 2025-10-30 07:03:57 --> Security Class Initialized
DEBUG - 2025-10-30 07:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:03:57 --> Input Class Initialized
INFO - 2025-10-30 07:03:57 --> Language Class Initialized
ERROR - 2025-10-30 07:03:57 --> 404 Page Not Found: Student_fees/search_student
INFO - 2025-10-30 07:04:00 --> Config Class Initialized
INFO - 2025-10-30 07:04:00 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:04:00 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:04:00 --> Utf8 Class Initialized
INFO - 2025-10-30 07:04:00 --> URI Class Initialized
INFO - 2025-10-30 07:04:00 --> Router Class Initialized
INFO - 2025-10-30 07:04:00 --> Output Class Initialized
INFO - 2025-10-30 07:04:00 --> Security Class Initialized
DEBUG - 2025-10-30 07:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:04:00 --> Input Class Initialized
INFO - 2025-10-30 07:04:00 --> Language Class Initialized
ERROR - 2025-10-30 07:04:00 --> 404 Page Not Found: Student_fees/search_student
INFO - 2025-10-30 07:04:24 --> Config Class Initialized
INFO - 2025-10-30 07:04:24 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:04:24 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:04:24 --> Utf8 Class Initialized
INFO - 2025-10-30 07:04:24 --> URI Class Initialized
INFO - 2025-10-30 07:04:24 --> Router Class Initialized
INFO - 2025-10-30 07:04:24 --> Output Class Initialized
INFO - 2025-10-30 07:04:24 --> Security Class Initialized
DEBUG - 2025-10-30 07:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:04:24 --> Input Class Initialized
INFO - 2025-10-30 07:04:24 --> Language Class Initialized
ERROR - 2025-10-30 07:04:24 --> 404 Page Not Found: Student_fees/search_student
INFO - 2025-10-30 07:05:30 --> Config Class Initialized
INFO - 2025-10-30 07:05:30 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:05:30 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:05:30 --> Utf8 Class Initialized
INFO - 2025-10-30 07:05:30 --> URI Class Initialized
INFO - 2025-10-30 07:05:30 --> Router Class Initialized
INFO - 2025-10-30 07:05:30 --> Output Class Initialized
INFO - 2025-10-30 07:05:30 --> Security Class Initialized
DEBUG - 2025-10-30 07:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:05:30 --> Input Class Initialized
INFO - 2025-10-30 07:05:30 --> Language Class Initialized
ERROR - 2025-10-30 07:05:30 --> 404 Page Not Found: Student_fees/search_student
INFO - 2025-10-30 07:05:34 --> Config Class Initialized
INFO - 2025-10-30 07:05:34 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:05:34 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:05:34 --> Utf8 Class Initialized
INFO - 2025-10-30 07:05:34 --> URI Class Initialized
DEBUG - 2025-10-30 07:05:34 --> No URI present. Default controller set.
INFO - 2025-10-30 07:05:34 --> Router Class Initialized
INFO - 2025-10-30 07:05:34 --> Output Class Initialized
INFO - 2025-10-30 07:05:34 --> Security Class Initialized
DEBUG - 2025-10-30 07:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:05:34 --> Input Class Initialized
INFO - 2025-10-30 07:05:34 --> Language Class Initialized
INFO - 2025-10-30 07:05:34 --> Loader Class Initialized
INFO - 2025-10-30 07:05:34 --> Helper loaded: url_helper
INFO - 2025-10-30 07:05:34 --> Database Driver Class Initialized
INFO - 2025-10-30 07:05:34 --> Controller Class Initialized
INFO - 2025-10-30 07:05:34 --> Model "Student_model" initialized
INFO - 2025-10-30 07:05:34 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:05:34 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 07:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:05:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:05:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-30 07:05:34 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:05:34 --> Final output sent to browser
DEBUG - 2025-10-30 07:05:34 --> Total execution time: 0.1040
INFO - 2025-10-30 07:05:34 --> Config Class Initialized
INFO - 2025-10-30 07:05:34 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:05:34 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:05:34 --> Utf8 Class Initialized
INFO - 2025-10-30 07:05:34 --> URI Class Initialized
INFO - 2025-10-30 07:05:34 --> Router Class Initialized
INFO - 2025-10-30 07:05:34 --> Output Class Initialized
INFO - 2025-10-30 07:05:34 --> Security Class Initialized
DEBUG - 2025-10-30 07:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:05:34 --> Input Class Initialized
INFO - 2025-10-30 07:05:34 --> Language Class Initialized
ERROR - 2025-10-30 07:05:34 --> 404 Page Not Found: Assets/chart.umd.js.map
INFO - 2025-10-30 07:05:37 --> Config Class Initialized
INFO - 2025-10-30 07:05:37 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:05:37 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:05:37 --> Utf8 Class Initialized
INFO - 2025-10-30 07:05:37 --> URI Class Initialized
INFO - 2025-10-30 07:05:37 --> Router Class Initialized
INFO - 2025-10-30 07:05:37 --> Output Class Initialized
INFO - 2025-10-30 07:05:37 --> Security Class Initialized
DEBUG - 2025-10-30 07:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:05:37 --> Input Class Initialized
INFO - 2025-10-30 07:05:37 --> Language Class Initialized
INFO - 2025-10-30 07:05:37 --> Loader Class Initialized
INFO - 2025-10-30 07:05:37 --> Helper loaded: url_helper
INFO - 2025-10-30 07:05:37 --> Database Driver Class Initialized
INFO - 2025-10-30 07:05:37 --> Controller Class Initialized
INFO - 2025-10-30 07:05:37 --> Model "Student_model" initialized
INFO - 2025-10-30 07:05:37 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:05:37 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:05:37 --> Helper loaded: form_helper
INFO - 2025-10-30 07:05:37 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:05:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:05:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 07:05:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:05:37 --> Final output sent to browser
DEBUG - 2025-10-30 07:05:37 --> Total execution time: 0.1117
INFO - 2025-10-30 07:05:38 --> Config Class Initialized
INFO - 2025-10-30 07:05:38 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:05:38 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:05:38 --> Utf8 Class Initialized
INFO - 2025-10-30 07:05:38 --> URI Class Initialized
INFO - 2025-10-30 07:05:38 --> Router Class Initialized
INFO - 2025-10-30 07:05:38 --> Output Class Initialized
INFO - 2025-10-30 07:05:38 --> Security Class Initialized
DEBUG - 2025-10-30 07:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:05:38 --> Input Class Initialized
INFO - 2025-10-30 07:05:38 --> Language Class Initialized
INFO - 2025-10-30 07:05:38 --> Loader Class Initialized
INFO - 2025-10-30 07:05:38 --> Helper loaded: url_helper
INFO - 2025-10-30 07:05:38 --> Database Driver Class Initialized
INFO - 2025-10-30 07:05:38 --> Controller Class Initialized
INFO - 2025-10-30 07:05:38 --> Model "Student_model" initialized
INFO - 2025-10-30 07:05:38 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:05:38 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:05:38 --> Helper loaded: form_helper
INFO - 2025-10-30 07:05:38 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:05:38 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:05:38 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 07:05:38 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:05:38 --> Final output sent to browser
DEBUG - 2025-10-30 07:05:38 --> Total execution time: 0.1014
INFO - 2025-10-30 07:05:39 --> Config Class Initialized
INFO - 2025-10-30 07:05:39 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:05:39 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:05:39 --> Utf8 Class Initialized
INFO - 2025-10-30 07:05:39 --> URI Class Initialized
INFO - 2025-10-30 07:05:39 --> Router Class Initialized
INFO - 2025-10-30 07:05:39 --> Output Class Initialized
INFO - 2025-10-30 07:05:39 --> Security Class Initialized
DEBUG - 2025-10-30 07:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:05:39 --> Input Class Initialized
INFO - 2025-10-30 07:05:39 --> Language Class Initialized
ERROR - 2025-10-30 07:05:39 --> 404 Page Not Found: Student_fees/search_student
INFO - 2025-10-30 07:05:40 --> Config Class Initialized
INFO - 2025-10-30 07:05:40 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:05:40 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:05:40 --> Utf8 Class Initialized
INFO - 2025-10-30 07:05:40 --> URI Class Initialized
INFO - 2025-10-30 07:05:40 --> Router Class Initialized
INFO - 2025-10-30 07:05:40 --> Output Class Initialized
INFO - 2025-10-30 07:05:40 --> Security Class Initialized
DEBUG - 2025-10-30 07:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:05:40 --> Input Class Initialized
INFO - 2025-10-30 07:05:40 --> Language Class Initialized
ERROR - 2025-10-30 07:05:40 --> 404 Page Not Found: Student_fees/search_student
INFO - 2025-10-30 07:05:43 --> Config Class Initialized
INFO - 2025-10-30 07:05:43 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:05:43 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:05:43 --> Utf8 Class Initialized
INFO - 2025-10-30 07:05:43 --> URI Class Initialized
INFO - 2025-10-30 07:05:43 --> Router Class Initialized
INFO - 2025-10-30 07:05:43 --> Output Class Initialized
INFO - 2025-10-30 07:05:43 --> Security Class Initialized
DEBUG - 2025-10-30 07:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:05:43 --> Input Class Initialized
INFO - 2025-10-30 07:05:43 --> Language Class Initialized
ERROR - 2025-10-30 07:05:43 --> 404 Page Not Found: Student_fees/search_student
INFO - 2025-10-30 07:05:43 --> Config Class Initialized
INFO - 2025-10-30 07:05:43 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:05:43 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:05:43 --> Utf8 Class Initialized
INFO - 2025-10-30 07:05:43 --> URI Class Initialized
INFO - 2025-10-30 07:05:43 --> Router Class Initialized
INFO - 2025-10-30 07:05:43 --> Output Class Initialized
INFO - 2025-10-30 07:05:43 --> Security Class Initialized
DEBUG - 2025-10-30 07:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:05:43 --> Input Class Initialized
INFO - 2025-10-30 07:05:43 --> Language Class Initialized
INFO - 2025-10-30 07:05:43 --> Loader Class Initialized
INFO - 2025-10-30 07:05:43 --> Helper loaded: url_helper
INFO - 2025-10-30 07:05:43 --> Database Driver Class Initialized
INFO - 2025-10-30 07:05:43 --> Controller Class Initialized
INFO - 2025-10-30 07:05:43 --> Model "Student_model" initialized
INFO - 2025-10-30 07:05:43 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:05:43 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:05:43 --> Helper loaded: form_helper
INFO - 2025-10-30 07:05:43 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:05:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:05:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 07:05:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:05:43 --> Final output sent to browser
DEBUG - 2025-10-30 07:05:43 --> Total execution time: 0.1260
INFO - 2025-10-30 07:05:43 --> Config Class Initialized
INFO - 2025-10-30 07:05:43 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:05:43 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:05:43 --> Utf8 Class Initialized
INFO - 2025-10-30 07:05:43 --> URI Class Initialized
INFO - 2025-10-30 07:05:43 --> Router Class Initialized
INFO - 2025-10-30 07:05:43 --> Output Class Initialized
INFO - 2025-10-30 07:05:43 --> Security Class Initialized
DEBUG - 2025-10-30 07:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:05:43 --> Input Class Initialized
INFO - 2025-10-30 07:05:43 --> Language Class Initialized
INFO - 2025-10-30 07:05:43 --> Loader Class Initialized
INFO - 2025-10-30 07:05:43 --> Helper loaded: url_helper
INFO - 2025-10-30 07:05:43 --> Database Driver Class Initialized
INFO - 2025-10-30 07:05:43 --> Controller Class Initialized
INFO - 2025-10-30 07:05:43 --> Model "Student_model" initialized
INFO - 2025-10-30 07:05:43 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:05:43 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:05:43 --> Helper loaded: form_helper
INFO - 2025-10-30 07:05:43 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:05:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:05:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 07:05:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:05:43 --> Final output sent to browser
DEBUG - 2025-10-30 07:05:43 --> Total execution time: 0.1235
INFO - 2025-10-30 07:05:44 --> Config Class Initialized
INFO - 2025-10-30 07:05:44 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:05:44 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:05:44 --> Utf8 Class Initialized
INFO - 2025-10-30 07:05:44 --> URI Class Initialized
INFO - 2025-10-30 07:05:44 --> Router Class Initialized
INFO - 2025-10-30 07:05:44 --> Output Class Initialized
INFO - 2025-10-30 07:05:44 --> Security Class Initialized
DEBUG - 2025-10-30 07:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:05:44 --> Input Class Initialized
INFO - 2025-10-30 07:05:44 --> Language Class Initialized
INFO - 2025-10-30 07:05:44 --> Loader Class Initialized
INFO - 2025-10-30 07:05:44 --> Helper loaded: url_helper
INFO - 2025-10-30 07:05:44 --> Database Driver Class Initialized
INFO - 2025-10-30 07:05:44 --> Controller Class Initialized
INFO - 2025-10-30 07:05:44 --> Model "Student_model" initialized
INFO - 2025-10-30 07:05:44 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:05:44 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:05:44 --> Helper loaded: form_helper
INFO - 2025-10-30 07:05:44 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:05:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:05:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 07:05:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:05:44 --> Final output sent to browser
DEBUG - 2025-10-30 07:05:44 --> Total execution time: 0.1027
INFO - 2025-10-30 07:05:44 --> Config Class Initialized
INFO - 2025-10-30 07:05:44 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:05:44 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:05:44 --> Utf8 Class Initialized
INFO - 2025-10-30 07:05:44 --> URI Class Initialized
INFO - 2025-10-30 07:05:44 --> Router Class Initialized
INFO - 2025-10-30 07:05:44 --> Output Class Initialized
INFO - 2025-10-30 07:05:44 --> Security Class Initialized
DEBUG - 2025-10-30 07:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:05:44 --> Input Class Initialized
INFO - 2025-10-30 07:05:44 --> Language Class Initialized
INFO - 2025-10-30 07:05:44 --> Loader Class Initialized
INFO - 2025-10-30 07:05:44 --> Helper loaded: url_helper
INFO - 2025-10-30 07:05:44 --> Database Driver Class Initialized
INFO - 2025-10-30 07:05:44 --> Controller Class Initialized
INFO - 2025-10-30 07:05:44 --> Model "Student_model" initialized
INFO - 2025-10-30 07:05:44 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:05:44 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:05:44 --> Helper loaded: form_helper
INFO - 2025-10-30 07:05:44 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:05:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:05:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 07:05:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:05:44 --> Final output sent to browser
DEBUG - 2025-10-30 07:05:44 --> Total execution time: 0.1068
INFO - 2025-10-30 07:05:44 --> Config Class Initialized
INFO - 2025-10-30 07:05:44 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:05:44 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:05:44 --> Utf8 Class Initialized
INFO - 2025-10-30 07:05:44 --> URI Class Initialized
INFO - 2025-10-30 07:05:44 --> Router Class Initialized
INFO - 2025-10-30 07:05:44 --> Output Class Initialized
INFO - 2025-10-30 07:05:44 --> Security Class Initialized
DEBUG - 2025-10-30 07:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:05:44 --> Input Class Initialized
INFO - 2025-10-30 07:05:44 --> Language Class Initialized
INFO - 2025-10-30 07:05:44 --> Loader Class Initialized
INFO - 2025-10-30 07:05:44 --> Helper loaded: url_helper
INFO - 2025-10-30 07:05:44 --> Database Driver Class Initialized
INFO - 2025-10-30 07:05:44 --> Controller Class Initialized
INFO - 2025-10-30 07:05:44 --> Model "Student_model" initialized
INFO - 2025-10-30 07:05:44 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:05:44 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:05:44 --> Helper loaded: form_helper
INFO - 2025-10-30 07:05:44 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:05:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:05:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 07:05:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:05:44 --> Final output sent to browser
DEBUG - 2025-10-30 07:05:44 --> Total execution time: 0.1197
INFO - 2025-10-30 07:05:44 --> Config Class Initialized
INFO - 2025-10-30 07:05:44 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:05:44 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:05:44 --> Utf8 Class Initialized
INFO - 2025-10-30 07:05:44 --> URI Class Initialized
INFO - 2025-10-30 07:05:44 --> Router Class Initialized
INFO - 2025-10-30 07:05:44 --> Output Class Initialized
INFO - 2025-10-30 07:05:44 --> Security Class Initialized
DEBUG - 2025-10-30 07:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:05:44 --> Input Class Initialized
INFO - 2025-10-30 07:05:44 --> Language Class Initialized
INFO - 2025-10-30 07:05:44 --> Loader Class Initialized
INFO - 2025-10-30 07:05:44 --> Helper loaded: url_helper
INFO - 2025-10-30 07:05:44 --> Database Driver Class Initialized
INFO - 2025-10-30 07:05:44 --> Controller Class Initialized
INFO - 2025-10-30 07:05:44 --> Model "Student_model" initialized
INFO - 2025-10-30 07:05:44 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:05:44 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:05:44 --> Helper loaded: form_helper
INFO - 2025-10-30 07:05:44 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:05:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:05:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 07:05:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:05:44 --> Final output sent to browser
DEBUG - 2025-10-30 07:05:44 --> Total execution time: 0.1028
INFO - 2025-10-30 07:05:45 --> Config Class Initialized
INFO - 2025-10-30 07:05:45 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:05:45 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:05:45 --> Utf8 Class Initialized
INFO - 2025-10-30 07:05:45 --> URI Class Initialized
INFO - 2025-10-30 07:05:45 --> Router Class Initialized
INFO - 2025-10-30 07:05:45 --> Output Class Initialized
INFO - 2025-10-30 07:05:45 --> Security Class Initialized
DEBUG - 2025-10-30 07:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:05:45 --> Input Class Initialized
INFO - 2025-10-30 07:05:45 --> Language Class Initialized
INFO - 2025-10-30 07:05:45 --> Loader Class Initialized
INFO - 2025-10-30 07:05:45 --> Helper loaded: url_helper
INFO - 2025-10-30 07:05:45 --> Database Driver Class Initialized
INFO - 2025-10-30 07:05:45 --> Controller Class Initialized
INFO - 2025-10-30 07:05:45 --> Model "Student_model" initialized
INFO - 2025-10-30 07:05:45 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:05:45 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:05:45 --> Helper loaded: form_helper
INFO - 2025-10-30 07:05:45 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:05:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:05:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 07:05:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:05:45 --> Final output sent to browser
DEBUG - 2025-10-30 07:05:45 --> Total execution time: 0.0963
INFO - 2025-10-30 07:05:45 --> Config Class Initialized
INFO - 2025-10-30 07:05:45 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:05:45 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:05:45 --> Utf8 Class Initialized
INFO - 2025-10-30 07:05:45 --> URI Class Initialized
INFO - 2025-10-30 07:05:45 --> Router Class Initialized
INFO - 2025-10-30 07:05:45 --> Output Class Initialized
INFO - 2025-10-30 07:05:45 --> Security Class Initialized
DEBUG - 2025-10-30 07:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:05:45 --> Input Class Initialized
INFO - 2025-10-30 07:05:45 --> Language Class Initialized
INFO - 2025-10-30 07:05:45 --> Loader Class Initialized
INFO - 2025-10-30 07:05:45 --> Helper loaded: url_helper
INFO - 2025-10-30 07:05:45 --> Database Driver Class Initialized
INFO - 2025-10-30 07:05:45 --> Controller Class Initialized
INFO - 2025-10-30 07:05:45 --> Model "Student_model" initialized
INFO - 2025-10-30 07:05:45 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:05:45 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:05:45 --> Helper loaded: form_helper
INFO - 2025-10-30 07:05:45 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:05:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:05:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 07:05:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:05:45 --> Final output sent to browser
DEBUG - 2025-10-30 07:05:45 --> Total execution time: 0.1217
INFO - 2025-10-30 07:05:46 --> Config Class Initialized
INFO - 2025-10-30 07:05:46 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:05:46 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:05:46 --> Utf8 Class Initialized
INFO - 2025-10-30 07:05:46 --> URI Class Initialized
INFO - 2025-10-30 07:05:46 --> Router Class Initialized
INFO - 2025-10-30 07:05:46 --> Output Class Initialized
INFO - 2025-10-30 07:05:46 --> Security Class Initialized
DEBUG - 2025-10-30 07:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:05:46 --> Input Class Initialized
INFO - 2025-10-30 07:05:46 --> Language Class Initialized
ERROR - 2025-10-30 07:05:46 --> 404 Page Not Found: Student_fees/search_student
INFO - 2025-10-30 07:13:02 --> Config Class Initialized
INFO - 2025-10-30 07:13:02 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:13:02 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:13:02 --> Utf8 Class Initialized
INFO - 2025-10-30 07:13:02 --> URI Class Initialized
INFO - 2025-10-30 07:13:02 --> Router Class Initialized
INFO - 2025-10-30 07:13:02 --> Output Class Initialized
INFO - 2025-10-30 07:13:02 --> Security Class Initialized
DEBUG - 2025-10-30 07:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:13:02 --> Input Class Initialized
INFO - 2025-10-30 07:13:02 --> Language Class Initialized
ERROR - 2025-10-30 07:13:02 --> 404 Page Not Found: Student_fees/search_student
INFO - 2025-10-30 07:13:03 --> Config Class Initialized
INFO - 2025-10-30 07:13:03 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:13:03 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:13:03 --> Utf8 Class Initialized
INFO - 2025-10-30 07:13:03 --> URI Class Initialized
INFO - 2025-10-30 07:13:03 --> Router Class Initialized
INFO - 2025-10-30 07:13:03 --> Output Class Initialized
INFO - 2025-10-30 07:13:03 --> Security Class Initialized
DEBUG - 2025-10-30 07:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:13:03 --> Input Class Initialized
INFO - 2025-10-30 07:13:03 --> Language Class Initialized
INFO - 2025-10-30 07:13:03 --> Loader Class Initialized
INFO - 2025-10-30 07:13:03 --> Helper loaded: url_helper
INFO - 2025-10-30 07:13:03 --> Database Driver Class Initialized
INFO - 2025-10-30 07:13:03 --> Controller Class Initialized
INFO - 2025-10-30 07:13:03 --> Model "Student_model" initialized
INFO - 2025-10-30 07:13:03 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:13:03 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:13:03 --> Helper loaded: form_helper
INFO - 2025-10-30 07:13:03 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:13:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:13:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 07:13:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:13:03 --> Final output sent to browser
DEBUG - 2025-10-30 07:13:03 --> Total execution time: 0.1077
INFO - 2025-10-30 07:13:05 --> Config Class Initialized
INFO - 2025-10-30 07:13:05 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:13:05 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:13:05 --> Utf8 Class Initialized
INFO - 2025-10-30 07:13:05 --> URI Class Initialized
INFO - 2025-10-30 07:13:05 --> Router Class Initialized
INFO - 2025-10-30 07:13:05 --> Output Class Initialized
INFO - 2025-10-30 07:13:05 --> Security Class Initialized
DEBUG - 2025-10-30 07:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:13:05 --> Input Class Initialized
INFO - 2025-10-30 07:13:05 --> Language Class Initialized
ERROR - 2025-10-30 07:13:05 --> 404 Page Not Found: Student_fees/search_student
INFO - 2025-10-30 07:15:54 --> Config Class Initialized
INFO - 2025-10-30 07:15:54 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:15:54 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:15:54 --> Utf8 Class Initialized
INFO - 2025-10-30 07:15:54 --> URI Class Initialized
INFO - 2025-10-30 07:15:55 --> Router Class Initialized
INFO - 2025-10-30 07:15:55 --> Output Class Initialized
INFO - 2025-10-30 07:15:55 --> Security Class Initialized
DEBUG - 2025-10-30 07:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:15:55 --> Input Class Initialized
INFO - 2025-10-30 07:15:55 --> Language Class Initialized
INFO - 2025-10-30 07:15:55 --> Loader Class Initialized
INFO - 2025-10-30 07:15:55 --> Helper loaded: url_helper
INFO - 2025-10-30 07:15:55 --> Database Driver Class Initialized
INFO - 2025-10-30 07:15:55 --> Controller Class Initialized
INFO - 2025-10-30 07:15:55 --> Model "Student_model" initialized
INFO - 2025-10-30 07:15:55 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:15:55 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:15:55 --> Helper loaded: form_helper
INFO - 2025-10-30 07:15:55 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:15:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:15:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 07:15:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:15:55 --> Final output sent to browser
DEBUG - 2025-10-30 07:15:55 --> Total execution time: 0.1051
INFO - 2025-10-30 07:15:56 --> Config Class Initialized
INFO - 2025-10-30 07:15:56 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:15:56 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:15:56 --> Utf8 Class Initialized
INFO - 2025-10-30 07:15:56 --> URI Class Initialized
INFO - 2025-10-30 07:15:56 --> Router Class Initialized
INFO - 2025-10-30 07:15:56 --> Output Class Initialized
INFO - 2025-10-30 07:15:56 --> Security Class Initialized
DEBUG - 2025-10-30 07:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:15:56 --> Input Class Initialized
INFO - 2025-10-30 07:15:56 --> Language Class Initialized
INFO - 2025-10-30 07:15:56 --> Loader Class Initialized
INFO - 2025-10-30 07:15:56 --> Helper loaded: url_helper
INFO - 2025-10-30 07:15:56 --> Database Driver Class Initialized
INFO - 2025-10-30 07:15:56 --> Controller Class Initialized
INFO - 2025-10-30 07:15:56 --> Model "Student_model" initialized
INFO - 2025-10-30 07:15:56 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:15:56 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:15:56 --> Helper loaded: form_helper
INFO - 2025-10-30 07:15:56 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:15:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:15:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 07:15:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:15:57 --> Final output sent to browser
DEBUG - 2025-10-30 07:15:57 --> Total execution time: 0.1078
INFO - 2025-10-30 07:15:57 --> Config Class Initialized
INFO - 2025-10-30 07:15:57 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:15:57 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:15:57 --> Utf8 Class Initialized
INFO - 2025-10-30 07:15:57 --> URI Class Initialized
INFO - 2025-10-30 07:15:57 --> Router Class Initialized
INFO - 2025-10-30 07:15:57 --> Output Class Initialized
INFO - 2025-10-30 07:15:57 --> Security Class Initialized
DEBUG - 2025-10-30 07:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:15:57 --> Input Class Initialized
INFO - 2025-10-30 07:15:57 --> Language Class Initialized
INFO - 2025-10-30 07:15:57 --> Loader Class Initialized
INFO - 2025-10-30 07:15:57 --> Helper loaded: url_helper
INFO - 2025-10-30 07:15:57 --> Database Driver Class Initialized
INFO - 2025-10-30 07:15:57 --> Controller Class Initialized
INFO - 2025-10-30 07:15:57 --> Model "Student_model" initialized
INFO - 2025-10-30 07:15:57 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:15:57 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:15:57 --> Helper loaded: form_helper
INFO - 2025-10-30 07:15:57 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:15:57 --> Final output sent to browser
DEBUG - 2025-10-30 07:15:57 --> Total execution time: 0.0846
INFO - 2025-10-30 07:16:26 --> Config Class Initialized
INFO - 2025-10-30 07:16:26 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:16:26 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:16:26 --> Utf8 Class Initialized
INFO - 2025-10-30 07:16:26 --> URI Class Initialized
INFO - 2025-10-30 07:16:26 --> Router Class Initialized
INFO - 2025-10-30 07:16:26 --> Output Class Initialized
INFO - 2025-10-30 07:16:26 --> Security Class Initialized
DEBUG - 2025-10-30 07:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:16:26 --> Input Class Initialized
INFO - 2025-10-30 07:16:26 --> Language Class Initialized
INFO - 2025-10-30 07:16:26 --> Loader Class Initialized
INFO - 2025-10-30 07:16:26 --> Helper loaded: url_helper
INFO - 2025-10-30 07:16:26 --> Database Driver Class Initialized
INFO - 2025-10-30 07:16:26 --> Controller Class Initialized
INFO - 2025-10-30 07:16:26 --> Model "Student_model" initialized
INFO - 2025-10-30 07:16:26 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:16:26 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:16:26 --> Helper loaded: form_helper
INFO - 2025-10-30 07:16:26 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:16:26 --> Final output sent to browser
DEBUG - 2025-10-30 07:16:26 --> Total execution time: 0.0729
INFO - 2025-10-30 07:16:26 --> Config Class Initialized
INFO - 2025-10-30 07:16:26 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:16:26 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:16:26 --> Utf8 Class Initialized
INFO - 2025-10-30 07:16:26 --> URI Class Initialized
INFO - 2025-10-30 07:16:26 --> Router Class Initialized
INFO - 2025-10-30 07:16:26 --> Output Class Initialized
INFO - 2025-10-30 07:16:26 --> Security Class Initialized
DEBUG - 2025-10-30 07:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:16:26 --> Input Class Initialized
INFO - 2025-10-30 07:16:26 --> Language Class Initialized
INFO - 2025-10-30 07:16:26 --> Loader Class Initialized
INFO - 2025-10-30 07:16:26 --> Helper loaded: url_helper
INFO - 2025-10-30 07:16:26 --> Database Driver Class Initialized
INFO - 2025-10-30 07:16:26 --> Controller Class Initialized
INFO - 2025-10-30 07:16:26 --> Model "Student_model" initialized
INFO - 2025-10-30 07:16:26 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:16:26 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:16:26 --> Helper loaded: form_helper
INFO - 2025-10-30 07:16:26 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:16:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:16:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 07:16:26 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:16:26 --> Final output sent to browser
DEBUG - 2025-10-30 07:16:26 --> Total execution time: 0.0955
INFO - 2025-10-30 07:16:28 --> Config Class Initialized
INFO - 2025-10-30 07:16:28 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:16:28 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:16:28 --> Utf8 Class Initialized
INFO - 2025-10-30 07:16:28 --> URI Class Initialized
INFO - 2025-10-30 07:16:28 --> Router Class Initialized
INFO - 2025-10-30 07:16:28 --> Output Class Initialized
INFO - 2025-10-30 07:16:28 --> Security Class Initialized
DEBUG - 2025-10-30 07:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:16:28 --> Input Class Initialized
INFO - 2025-10-30 07:16:28 --> Language Class Initialized
INFO - 2025-10-30 07:16:28 --> Loader Class Initialized
INFO - 2025-10-30 07:16:28 --> Helper loaded: url_helper
INFO - 2025-10-30 07:16:28 --> Database Driver Class Initialized
INFO - 2025-10-30 07:16:28 --> Controller Class Initialized
INFO - 2025-10-30 07:16:28 --> Model "Student_model" initialized
INFO - 2025-10-30 07:16:28 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:16:28 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:16:28 --> Helper loaded: form_helper
INFO - 2025-10-30 07:16:28 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:16:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:16:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/edit.php
INFO - 2025-10-30 07:16:28 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:16:28 --> Final output sent to browser
DEBUG - 2025-10-30 07:16:28 --> Total execution time: 0.0902
INFO - 2025-10-30 07:16:35 --> Config Class Initialized
INFO - 2025-10-30 07:16:35 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:16:35 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:16:35 --> Utf8 Class Initialized
INFO - 2025-10-30 07:16:35 --> URI Class Initialized
INFO - 2025-10-30 07:16:35 --> Router Class Initialized
INFO - 2025-10-30 07:16:35 --> Output Class Initialized
INFO - 2025-10-30 07:16:35 --> Security Class Initialized
DEBUG - 2025-10-30 07:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:16:35 --> Input Class Initialized
INFO - 2025-10-30 07:16:35 --> Language Class Initialized
INFO - 2025-10-30 07:16:35 --> Loader Class Initialized
INFO - 2025-10-30 07:16:35 --> Helper loaded: url_helper
INFO - 2025-10-30 07:16:35 --> Database Driver Class Initialized
INFO - 2025-10-30 07:16:35 --> Controller Class Initialized
INFO - 2025-10-30 07:16:35 --> Model "Student_model" initialized
INFO - 2025-10-30 07:16:35 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:16:35 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:16:35 --> Helper loaded: form_helper
INFO - 2025-10-30 07:16:35 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:16:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 07:16:35 --> Config Class Initialized
INFO - 2025-10-30 07:16:35 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:16:35 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:16:35 --> Utf8 Class Initialized
INFO - 2025-10-30 07:16:35 --> URI Class Initialized
INFO - 2025-10-30 07:16:35 --> Router Class Initialized
INFO - 2025-10-30 07:16:35 --> Output Class Initialized
INFO - 2025-10-30 07:16:35 --> Security Class Initialized
DEBUG - 2025-10-30 07:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:16:35 --> Input Class Initialized
INFO - 2025-10-30 07:16:35 --> Language Class Initialized
INFO - 2025-10-30 07:16:35 --> Loader Class Initialized
INFO - 2025-10-30 07:16:35 --> Helper loaded: url_helper
INFO - 2025-10-30 07:16:35 --> Database Driver Class Initialized
INFO - 2025-10-30 07:16:35 --> Controller Class Initialized
INFO - 2025-10-30 07:16:35 --> Model "Student_model" initialized
INFO - 2025-10-30 07:16:35 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:16:35 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:16:35 --> Helper loaded: form_helper
INFO - 2025-10-30 07:16:35 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:16:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:16:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 07:16:35 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:16:35 --> Final output sent to browser
DEBUG - 2025-10-30 07:16:35 --> Total execution time: 0.1161
INFO - 2025-10-30 07:19:57 --> Config Class Initialized
INFO - 2025-10-30 07:19:57 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:19:57 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:19:57 --> Utf8 Class Initialized
INFO - 2025-10-30 07:19:57 --> URI Class Initialized
INFO - 2025-10-30 07:19:57 --> Router Class Initialized
INFO - 2025-10-30 07:19:57 --> Output Class Initialized
INFO - 2025-10-30 07:19:57 --> Security Class Initialized
DEBUG - 2025-10-30 07:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:19:57 --> Input Class Initialized
INFO - 2025-10-30 07:19:57 --> Language Class Initialized
INFO - 2025-10-30 07:19:57 --> Loader Class Initialized
INFO - 2025-10-30 07:19:57 --> Helper loaded: url_helper
INFO - 2025-10-30 07:19:57 --> Database Driver Class Initialized
INFO - 2025-10-30 07:19:57 --> Controller Class Initialized
INFO - 2025-10-30 07:19:57 --> Model "Student_model" initialized
INFO - 2025-10-30 07:19:57 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:19:57 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:19:57 --> Helper loaded: form_helper
INFO - 2025-10-30 07:19:57 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:19:57 --> Payments Controller Loaded
INFO - 2025-10-30 07:19:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:19:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 07:19:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:19:57 --> Final output sent to browser
DEBUG - 2025-10-30 07:19:57 --> Total execution time: 0.1239
INFO - 2025-10-30 07:20:14 --> Config Class Initialized
INFO - 2025-10-30 07:20:14 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:20:14 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:20:14 --> Utf8 Class Initialized
INFO - 2025-10-30 07:20:14 --> URI Class Initialized
INFO - 2025-10-30 07:20:14 --> Router Class Initialized
INFO - 2025-10-30 07:20:14 --> Output Class Initialized
INFO - 2025-10-30 07:20:14 --> Security Class Initialized
DEBUG - 2025-10-30 07:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:20:14 --> Input Class Initialized
INFO - 2025-10-30 07:20:14 --> Language Class Initialized
INFO - 2025-10-30 07:20:14 --> Loader Class Initialized
INFO - 2025-10-30 07:20:14 --> Helper loaded: url_helper
INFO - 2025-10-30 07:20:14 --> Database Driver Class Initialized
INFO - 2025-10-30 07:20:14 --> Controller Class Initialized
INFO - 2025-10-30 07:20:14 --> Model "Student_model" initialized
INFO - 2025-10-30 07:20:14 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:20:14 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:20:14 --> Helper loaded: form_helper
INFO - 2025-10-30 07:20:14 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:20:14 --> Payments Controller Loaded
INFO - 2025-10-30 07:20:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 07:20:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:20:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 07:20:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:20:14 --> Final output sent to browser
DEBUG - 2025-10-30 07:20:14 --> Total execution time: 0.1085
INFO - 2025-10-30 07:20:22 --> Config Class Initialized
INFO - 2025-10-30 07:20:22 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:20:22 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:20:22 --> Utf8 Class Initialized
INFO - 2025-10-30 07:20:22 --> URI Class Initialized
INFO - 2025-10-30 07:20:22 --> Router Class Initialized
INFO - 2025-10-30 07:20:22 --> Output Class Initialized
INFO - 2025-10-30 07:20:22 --> Security Class Initialized
DEBUG - 2025-10-30 07:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:20:22 --> Input Class Initialized
INFO - 2025-10-30 07:20:22 --> Language Class Initialized
INFO - 2025-10-30 07:20:22 --> Loader Class Initialized
INFO - 2025-10-30 07:20:23 --> Helper loaded: url_helper
INFO - 2025-10-30 07:20:23 --> Database Driver Class Initialized
INFO - 2025-10-30 07:20:23 --> Controller Class Initialized
INFO - 2025-10-30 07:20:23 --> Model "Student_model" initialized
INFO - 2025-10-30 07:20:23 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:20:23 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:20:23 --> Helper loaded: form_helper
INFO - 2025-10-30 07:20:23 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:20:23 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:20:23 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 07:20:23 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:20:23 --> Final output sent to browser
DEBUG - 2025-10-30 07:20:23 --> Total execution time: 0.0860
INFO - 2025-10-30 07:20:24 --> Config Class Initialized
INFO - 2025-10-30 07:20:24 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:20:24 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:20:24 --> Utf8 Class Initialized
INFO - 2025-10-30 07:20:24 --> URI Class Initialized
INFO - 2025-10-30 07:20:24 --> Router Class Initialized
INFO - 2025-10-30 07:20:24 --> Output Class Initialized
INFO - 2025-10-30 07:20:24 --> Security Class Initialized
DEBUG - 2025-10-30 07:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:20:24 --> Input Class Initialized
INFO - 2025-10-30 07:20:24 --> Language Class Initialized
INFO - 2025-10-30 07:20:24 --> Loader Class Initialized
INFO - 2025-10-30 07:20:24 --> Helper loaded: url_helper
INFO - 2025-10-30 07:20:24 --> Database Driver Class Initialized
INFO - 2025-10-30 07:20:24 --> Controller Class Initialized
INFO - 2025-10-30 07:20:24 --> Model "Student_model" initialized
INFO - 2025-10-30 07:20:24 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:20:24 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:20:24 --> Helper loaded: form_helper
INFO - 2025-10-30 07:20:24 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:20:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:20:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 07:20:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:20:24 --> Final output sent to browser
DEBUG - 2025-10-30 07:20:24 --> Total execution time: 0.1246
INFO - 2025-10-30 07:20:32 --> Config Class Initialized
INFO - 2025-10-30 07:20:32 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:20:32 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:20:32 --> Utf8 Class Initialized
INFO - 2025-10-30 07:20:32 --> URI Class Initialized
INFO - 2025-10-30 07:20:32 --> Router Class Initialized
INFO - 2025-10-30 07:20:32 --> Output Class Initialized
INFO - 2025-10-30 07:20:32 --> Security Class Initialized
DEBUG - 2025-10-30 07:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:20:32 --> Input Class Initialized
INFO - 2025-10-30 07:20:32 --> Language Class Initialized
INFO - 2025-10-30 07:20:32 --> Loader Class Initialized
INFO - 2025-10-30 07:20:32 --> Helper loaded: url_helper
INFO - 2025-10-30 07:20:32 --> Database Driver Class Initialized
INFO - 2025-10-30 07:20:32 --> Controller Class Initialized
INFO - 2025-10-30 07:20:32 --> Model "Student_model" initialized
INFO - 2025-10-30 07:20:32 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:20:32 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:20:32 --> Helper loaded: form_helper
INFO - 2025-10-30 07:20:32 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:20:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:20:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/edit.php
INFO - 2025-10-30 07:20:32 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:20:32 --> Final output sent to browser
DEBUG - 2025-10-30 07:20:32 --> Total execution time: 0.1173
INFO - 2025-10-30 07:20:37 --> Config Class Initialized
INFO - 2025-10-30 07:20:37 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:20:37 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:20:37 --> Utf8 Class Initialized
INFO - 2025-10-30 07:20:37 --> URI Class Initialized
INFO - 2025-10-30 07:20:37 --> Router Class Initialized
INFO - 2025-10-30 07:20:37 --> Output Class Initialized
INFO - 2025-10-30 07:20:37 --> Security Class Initialized
DEBUG - 2025-10-30 07:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:20:37 --> Input Class Initialized
INFO - 2025-10-30 07:20:37 --> Language Class Initialized
INFO - 2025-10-30 07:20:37 --> Loader Class Initialized
INFO - 2025-10-30 07:20:37 --> Helper loaded: url_helper
INFO - 2025-10-30 07:20:37 --> Database Driver Class Initialized
INFO - 2025-10-30 07:20:37 --> Controller Class Initialized
INFO - 2025-10-30 07:20:37 --> Model "Student_model" initialized
INFO - 2025-10-30 07:20:37 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:20:37 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:20:37 --> Helper loaded: form_helper
INFO - 2025-10-30 07:20:37 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:20:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:20:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 07:20:37 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:20:37 --> Final output sent to browser
DEBUG - 2025-10-30 07:20:37 --> Total execution time: 0.1026
INFO - 2025-10-30 07:20:39 --> Config Class Initialized
INFO - 2025-10-30 07:20:39 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:20:39 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:20:39 --> Utf8 Class Initialized
INFO - 2025-10-30 07:20:39 --> URI Class Initialized
INFO - 2025-10-30 07:20:39 --> Router Class Initialized
INFO - 2025-10-30 07:20:39 --> Output Class Initialized
INFO - 2025-10-30 07:20:39 --> Security Class Initialized
DEBUG - 2025-10-30 07:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:20:39 --> Input Class Initialized
INFO - 2025-10-30 07:20:39 --> Language Class Initialized
INFO - 2025-10-30 07:20:39 --> Loader Class Initialized
INFO - 2025-10-30 07:20:39 --> Helper loaded: url_helper
INFO - 2025-10-30 07:20:39 --> Database Driver Class Initialized
INFO - 2025-10-30 07:20:39 --> Controller Class Initialized
INFO - 2025-10-30 07:20:39 --> Model "Student_model" initialized
INFO - 2025-10-30 07:20:39 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:20:39 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:20:39 --> Helper loaded: form_helper
INFO - 2025-10-30 07:20:39 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:20:39 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:20:39 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 07:20:39 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:20:39 --> Final output sent to browser
DEBUG - 2025-10-30 07:20:39 --> Total execution time: 0.0909
INFO - 2025-10-30 07:20:44 --> Config Class Initialized
INFO - 2025-10-30 07:20:44 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:20:44 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:20:44 --> Utf8 Class Initialized
INFO - 2025-10-30 07:20:44 --> URI Class Initialized
INFO - 2025-10-30 07:20:44 --> Router Class Initialized
INFO - 2025-10-30 07:20:44 --> Output Class Initialized
INFO - 2025-10-30 07:20:44 --> Security Class Initialized
DEBUG - 2025-10-30 07:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:20:44 --> Input Class Initialized
INFO - 2025-10-30 07:20:44 --> Language Class Initialized
INFO - 2025-10-30 07:20:44 --> Loader Class Initialized
INFO - 2025-10-30 07:20:44 --> Helper loaded: url_helper
INFO - 2025-10-30 07:20:44 --> Database Driver Class Initialized
INFO - 2025-10-30 07:20:45 --> Controller Class Initialized
INFO - 2025-10-30 07:20:45 --> Model "Student_model" initialized
INFO - 2025-10-30 07:20:45 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:20:45 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:20:45 --> Helper loaded: form_helper
INFO - 2025-10-30 07:20:45 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:20:45 --> Payments Controller Loaded
INFO - 2025-10-30 07:20:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:20:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 07:20:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:20:45 --> Final output sent to browser
DEBUG - 2025-10-30 07:20:45 --> Total execution time: 0.1186
INFO - 2025-10-30 07:20:56 --> Config Class Initialized
INFO - 2025-10-30 07:20:56 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:20:56 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:20:56 --> Utf8 Class Initialized
INFO - 2025-10-30 07:20:56 --> URI Class Initialized
INFO - 2025-10-30 07:20:56 --> Router Class Initialized
INFO - 2025-10-30 07:20:56 --> Output Class Initialized
INFO - 2025-10-30 07:20:56 --> Security Class Initialized
DEBUG - 2025-10-30 07:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:20:56 --> Input Class Initialized
INFO - 2025-10-30 07:20:56 --> Language Class Initialized
INFO - 2025-10-30 07:20:56 --> Loader Class Initialized
INFO - 2025-10-30 07:20:56 --> Helper loaded: url_helper
INFO - 2025-10-30 07:20:56 --> Database Driver Class Initialized
INFO - 2025-10-30 07:20:56 --> Controller Class Initialized
INFO - 2025-10-30 07:20:56 --> Model "Student_model" initialized
INFO - 2025-10-30 07:20:56 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:20:56 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:20:56 --> Helper loaded: form_helper
INFO - 2025-10-30 07:20:56 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:20:56 --> Payments Controller Loaded
INFO - 2025-10-30 07:20:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 07:20:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:20:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 07:20:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:20:56 --> Final output sent to browser
DEBUG - 2025-10-30 07:20:56 --> Total execution time: 0.0918
INFO - 2025-10-30 07:30:40 --> Config Class Initialized
INFO - 2025-10-30 07:30:40 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:30:40 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:30:40 --> Utf8 Class Initialized
INFO - 2025-10-30 07:30:40 --> URI Class Initialized
INFO - 2025-10-30 07:30:40 --> Router Class Initialized
INFO - 2025-10-30 07:30:40 --> Output Class Initialized
INFO - 2025-10-30 07:30:40 --> Security Class Initialized
DEBUG - 2025-10-30 07:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:30:40 --> Input Class Initialized
INFO - 2025-10-30 07:30:40 --> Language Class Initialized
INFO - 2025-10-30 07:30:40 --> Loader Class Initialized
INFO - 2025-10-30 07:30:40 --> Helper loaded: url_helper
INFO - 2025-10-30 07:30:40 --> Database Driver Class Initialized
INFO - 2025-10-30 07:30:40 --> Controller Class Initialized
INFO - 2025-10-30 07:30:40 --> Model "Student_model" initialized
INFO - 2025-10-30 07:30:40 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:30:40 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:30:40 --> Helper loaded: form_helper
INFO - 2025-10-30 07:30:40 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:30:40 --> Payments Controller Loaded
INFO - 2025-10-30 07:30:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 07:30:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:30:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 07:30:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:30:40 --> Final output sent to browser
DEBUG - 2025-10-30 07:30:40 --> Total execution time: 0.0706
INFO - 2025-10-30 07:30:44 --> Config Class Initialized
INFO - 2025-10-30 07:30:44 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:30:44 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:30:44 --> Utf8 Class Initialized
INFO - 2025-10-30 07:30:44 --> URI Class Initialized
INFO - 2025-10-30 07:30:44 --> Router Class Initialized
INFO - 2025-10-30 07:30:44 --> Output Class Initialized
INFO - 2025-10-30 07:30:44 --> Security Class Initialized
DEBUG - 2025-10-30 07:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:30:44 --> Input Class Initialized
INFO - 2025-10-30 07:30:44 --> Language Class Initialized
INFO - 2025-10-30 07:30:44 --> Loader Class Initialized
INFO - 2025-10-30 07:30:44 --> Helper loaded: url_helper
INFO - 2025-10-30 07:30:44 --> Database Driver Class Initialized
INFO - 2025-10-30 07:30:44 --> Controller Class Initialized
INFO - 2025-10-30 07:30:44 --> Model "Student_model" initialized
INFO - 2025-10-30 07:30:44 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:30:44 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:30:44 --> Helper loaded: form_helper
INFO - 2025-10-30 07:30:44 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:30:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:30:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 07:30:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:30:44 --> Final output sent to browser
DEBUG - 2025-10-30 07:30:44 --> Total execution time: 0.0953
INFO - 2025-10-30 07:30:46 --> Config Class Initialized
INFO - 2025-10-30 07:30:46 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:30:46 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:30:46 --> Utf8 Class Initialized
INFO - 2025-10-30 07:30:46 --> URI Class Initialized
INFO - 2025-10-30 07:30:46 --> Router Class Initialized
INFO - 2025-10-30 07:30:46 --> Output Class Initialized
INFO - 2025-10-30 07:30:46 --> Security Class Initialized
DEBUG - 2025-10-30 07:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:30:46 --> Input Class Initialized
INFO - 2025-10-30 07:30:46 --> Language Class Initialized
INFO - 2025-10-30 07:30:46 --> Loader Class Initialized
INFO - 2025-10-30 07:30:46 --> Helper loaded: url_helper
INFO - 2025-10-30 07:30:46 --> Database Driver Class Initialized
INFO - 2025-10-30 07:30:46 --> Controller Class Initialized
INFO - 2025-10-30 07:30:46 --> Model "Student_model" initialized
INFO - 2025-10-30 07:30:46 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:30:46 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:30:46 --> Helper loaded: form_helper
INFO - 2025-10-30 07:30:46 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:30:46 --> Payments Controller Loaded
INFO - 2025-10-30 07:30:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:30:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 07:30:46 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:30:46 --> Final output sent to browser
DEBUG - 2025-10-30 07:30:46 --> Total execution time: 0.1048
INFO - 2025-10-30 07:30:54 --> Config Class Initialized
INFO - 2025-10-30 07:30:54 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:30:54 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:30:54 --> Utf8 Class Initialized
INFO - 2025-10-30 07:30:54 --> URI Class Initialized
INFO - 2025-10-30 07:30:54 --> Router Class Initialized
INFO - 2025-10-30 07:30:54 --> Output Class Initialized
INFO - 2025-10-30 07:30:54 --> Security Class Initialized
DEBUG - 2025-10-30 07:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:30:54 --> Input Class Initialized
INFO - 2025-10-30 07:30:54 --> Language Class Initialized
INFO - 2025-10-30 07:30:54 --> Loader Class Initialized
INFO - 2025-10-30 07:30:54 --> Helper loaded: url_helper
INFO - 2025-10-30 07:30:54 --> Database Driver Class Initialized
INFO - 2025-10-30 07:30:54 --> Controller Class Initialized
INFO - 2025-10-30 07:30:54 --> Model "Student_model" initialized
INFO - 2025-10-30 07:30:54 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:30:54 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:30:54 --> Helper loaded: form_helper
INFO - 2025-10-30 07:30:54 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:30:54 --> Payments Controller Loaded
INFO - 2025-10-30 07:30:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 07:30:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:30:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 07:30:54 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:30:54 --> Final output sent to browser
DEBUG - 2025-10-30 07:30:54 --> Total execution time: 0.0909
INFO - 2025-10-30 07:32:55 --> Config Class Initialized
INFO - 2025-10-30 07:32:55 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:32:55 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:32:55 --> Utf8 Class Initialized
INFO - 2025-10-30 07:32:55 --> URI Class Initialized
DEBUG - 2025-10-30 07:32:55 --> No URI present. Default controller set.
INFO - 2025-10-30 07:32:55 --> Router Class Initialized
INFO - 2025-10-30 07:32:55 --> Output Class Initialized
INFO - 2025-10-30 07:32:55 --> Security Class Initialized
DEBUG - 2025-10-30 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:32:55 --> Input Class Initialized
INFO - 2025-10-30 07:32:55 --> Language Class Initialized
INFO - 2025-10-30 07:32:55 --> Loader Class Initialized
INFO - 2025-10-30 07:32:55 --> Helper loaded: url_helper
INFO - 2025-10-30 07:32:55 --> Database Driver Class Initialized
INFO - 2025-10-30 07:32:55 --> Controller Class Initialized
INFO - 2025-10-30 07:32:55 --> Model "Student_model" initialized
INFO - 2025-10-30 07:32:55 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:32:55 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 07:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:32:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:32:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-30 07:32:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:32:55 --> Final output sent to browser
DEBUG - 2025-10-30 07:32:55 --> Total execution time: 0.0994
INFO - 2025-10-30 07:32:56 --> Config Class Initialized
INFO - 2025-10-30 07:32:56 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:32:56 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:32:56 --> Utf8 Class Initialized
INFO - 2025-10-30 07:32:56 --> URI Class Initialized
INFO - 2025-10-30 07:32:56 --> Router Class Initialized
INFO - 2025-10-30 07:32:56 --> Output Class Initialized
INFO - 2025-10-30 07:32:56 --> Security Class Initialized
DEBUG - 2025-10-30 07:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:32:56 --> Input Class Initialized
INFO - 2025-10-30 07:32:56 --> Language Class Initialized
ERROR - 2025-10-30 07:32:56 --> 404 Page Not Found: Assets/chart.umd.js.map
INFO - 2025-10-30 07:32:58 --> Config Class Initialized
INFO - 2025-10-30 07:32:58 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:32:58 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:32:58 --> Utf8 Class Initialized
INFO - 2025-10-30 07:32:58 --> URI Class Initialized
INFO - 2025-10-30 07:32:58 --> Router Class Initialized
INFO - 2025-10-30 07:32:58 --> Output Class Initialized
INFO - 2025-10-30 07:32:58 --> Security Class Initialized
DEBUG - 2025-10-30 07:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:32:58 --> Input Class Initialized
INFO - 2025-10-30 07:32:58 --> Language Class Initialized
INFO - 2025-10-30 07:32:58 --> Loader Class Initialized
INFO - 2025-10-30 07:32:58 --> Helper loaded: url_helper
INFO - 2025-10-30 07:32:58 --> Database Driver Class Initialized
INFO - 2025-10-30 07:32:58 --> Controller Class Initialized
INFO - 2025-10-30 07:32:58 --> Model "Student_model" initialized
INFO - 2025-10-30 07:32:58 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:32:58 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:32:58 --> Helper loaded: form_helper
INFO - 2025-10-30 07:32:58 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:32:58 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:32:58 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 07:32:58 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:32:58 --> Final output sent to browser
DEBUG - 2025-10-30 07:32:58 --> Total execution time: 0.0701
INFO - 2025-10-30 07:33:02 --> Config Class Initialized
INFO - 2025-10-30 07:33:02 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:33:02 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:33:02 --> Utf8 Class Initialized
INFO - 2025-10-30 07:33:02 --> URI Class Initialized
INFO - 2025-10-30 07:33:02 --> Router Class Initialized
INFO - 2025-10-30 07:33:02 --> Output Class Initialized
INFO - 2025-10-30 07:33:02 --> Security Class Initialized
DEBUG - 2025-10-30 07:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:33:02 --> Input Class Initialized
INFO - 2025-10-30 07:33:02 --> Language Class Initialized
INFO - 2025-10-30 07:33:02 --> Loader Class Initialized
INFO - 2025-10-30 07:33:02 --> Helper loaded: url_helper
INFO - 2025-10-30 07:33:02 --> Database Driver Class Initialized
INFO - 2025-10-30 07:33:02 --> Controller Class Initialized
INFO - 2025-10-30 07:33:02 --> Model "Student_model" initialized
INFO - 2025-10-30 07:33:02 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:33:02 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:33:02 --> Helper loaded: form_helper
INFO - 2025-10-30 07:33:02 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:33:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:33:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/edit.php
INFO - 2025-10-30 07:33:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:33:02 --> Final output sent to browser
DEBUG - 2025-10-30 07:33:02 --> Total execution time: 0.0809
INFO - 2025-10-30 07:33:06 --> Config Class Initialized
INFO - 2025-10-30 07:33:06 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:33:06 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:33:06 --> Utf8 Class Initialized
INFO - 2025-10-30 07:33:06 --> URI Class Initialized
INFO - 2025-10-30 07:33:06 --> Router Class Initialized
INFO - 2025-10-30 07:33:06 --> Output Class Initialized
INFO - 2025-10-30 07:33:06 --> Security Class Initialized
DEBUG - 2025-10-30 07:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:33:06 --> Input Class Initialized
INFO - 2025-10-30 07:33:06 --> Language Class Initialized
INFO - 2025-10-30 07:33:06 --> Loader Class Initialized
INFO - 2025-10-30 07:33:06 --> Helper loaded: url_helper
INFO - 2025-10-30 07:33:06 --> Database Driver Class Initialized
INFO - 2025-10-30 07:33:06 --> Controller Class Initialized
INFO - 2025-10-30 07:33:06 --> Model "Student_model" initialized
INFO - 2025-10-30 07:33:06 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:33:06 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:33:06 --> Helper loaded: form_helper
INFO - 2025-10-30 07:33:06 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:33:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:33:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 07:33:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:33:06 --> Final output sent to browser
DEBUG - 2025-10-30 07:33:06 --> Total execution time: 0.0834
INFO - 2025-10-30 07:33:08 --> Config Class Initialized
INFO - 2025-10-30 07:33:08 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:33:08 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:33:08 --> Utf8 Class Initialized
INFO - 2025-10-30 07:33:08 --> URI Class Initialized
INFO - 2025-10-30 07:33:08 --> Router Class Initialized
INFO - 2025-10-30 07:33:08 --> Output Class Initialized
INFO - 2025-10-30 07:33:08 --> Security Class Initialized
DEBUG - 2025-10-30 07:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:33:08 --> Input Class Initialized
INFO - 2025-10-30 07:33:08 --> Language Class Initialized
INFO - 2025-10-30 07:33:08 --> Loader Class Initialized
INFO - 2025-10-30 07:33:08 --> Helper loaded: url_helper
INFO - 2025-10-30 07:33:08 --> Database Driver Class Initialized
INFO - 2025-10-30 07:33:08 --> Controller Class Initialized
INFO - 2025-10-30 07:33:08 --> Model "Student_model" initialized
INFO - 2025-10-30 07:33:08 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:33:08 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:33:08 --> Helper loaded: form_helper
INFO - 2025-10-30 07:33:08 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:33:08 --> Payments Controller Loaded
INFO - 2025-10-30 07:33:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:33:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 07:33:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:33:08 --> Final output sent to browser
DEBUG - 2025-10-30 07:33:08 --> Total execution time: 0.0625
INFO - 2025-10-30 07:33:19 --> Config Class Initialized
INFO - 2025-10-30 07:33:19 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:33:19 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:33:19 --> Utf8 Class Initialized
INFO - 2025-10-30 07:33:19 --> URI Class Initialized
INFO - 2025-10-30 07:33:19 --> Router Class Initialized
INFO - 2025-10-30 07:33:19 --> Output Class Initialized
INFO - 2025-10-30 07:33:19 --> Security Class Initialized
DEBUG - 2025-10-30 07:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:33:19 --> Input Class Initialized
INFO - 2025-10-30 07:33:19 --> Language Class Initialized
INFO - 2025-10-30 07:33:19 --> Loader Class Initialized
INFO - 2025-10-30 07:33:19 --> Helper loaded: url_helper
INFO - 2025-10-30 07:33:19 --> Database Driver Class Initialized
INFO - 2025-10-30 07:33:19 --> Controller Class Initialized
INFO - 2025-10-30 07:33:19 --> Model "Student_model" initialized
INFO - 2025-10-30 07:33:19 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:33:19 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:33:19 --> Helper loaded: form_helper
INFO - 2025-10-30 07:33:19 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:33:19 --> Payments Controller Loaded
INFO - 2025-10-30 07:33:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 07:33:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:33:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 07:33:19 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:33:19 --> Final output sent to browser
DEBUG - 2025-10-30 07:33:19 --> Total execution time: 0.0695
INFO - 2025-10-30 07:35:40 --> Config Class Initialized
INFO - 2025-10-30 07:35:40 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:35:40 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:35:40 --> Utf8 Class Initialized
INFO - 2025-10-30 07:35:40 --> URI Class Initialized
DEBUG - 2025-10-30 07:35:40 --> No URI present. Default controller set.
INFO - 2025-10-30 07:35:40 --> Router Class Initialized
INFO - 2025-10-30 07:35:40 --> Output Class Initialized
INFO - 2025-10-30 07:35:40 --> Security Class Initialized
DEBUG - 2025-10-30 07:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:35:40 --> Input Class Initialized
INFO - 2025-10-30 07:35:40 --> Language Class Initialized
INFO - 2025-10-30 07:35:40 --> Loader Class Initialized
INFO - 2025-10-30 07:35:40 --> Helper loaded: url_helper
INFO - 2025-10-30 07:35:40 --> Database Driver Class Initialized
INFO - 2025-10-30 07:35:40 --> Controller Class Initialized
INFO - 2025-10-30 07:35:40 --> Model "Student_model" initialized
INFO - 2025-10-30 07:35:40 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:35:40 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 07:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:35:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:35:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-30 07:35:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:35:40 --> Final output sent to browser
DEBUG - 2025-10-30 07:35:40 --> Total execution time: 0.0899
INFO - 2025-10-30 07:35:40 --> Config Class Initialized
INFO - 2025-10-30 07:35:40 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:35:40 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:35:40 --> Utf8 Class Initialized
INFO - 2025-10-30 07:35:40 --> URI Class Initialized
INFO - 2025-10-30 07:35:40 --> Router Class Initialized
INFO - 2025-10-30 07:35:40 --> Output Class Initialized
INFO - 2025-10-30 07:35:40 --> Security Class Initialized
DEBUG - 2025-10-30 07:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:35:40 --> Input Class Initialized
INFO - 2025-10-30 07:35:40 --> Language Class Initialized
ERROR - 2025-10-30 07:35:40 --> 404 Page Not Found: Assets/chart.umd.js.map
INFO - 2025-10-30 07:35:42 --> Config Class Initialized
INFO - 2025-10-30 07:35:42 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:35:42 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:35:42 --> Utf8 Class Initialized
INFO - 2025-10-30 07:35:42 --> URI Class Initialized
INFO - 2025-10-30 07:35:42 --> Router Class Initialized
INFO - 2025-10-30 07:35:42 --> Output Class Initialized
INFO - 2025-10-30 07:35:42 --> Security Class Initialized
DEBUG - 2025-10-30 07:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:35:42 --> Input Class Initialized
INFO - 2025-10-30 07:35:42 --> Language Class Initialized
INFO - 2025-10-30 07:35:42 --> Loader Class Initialized
INFO - 2025-10-30 07:35:42 --> Helper loaded: url_helper
INFO - 2025-10-30 07:35:42 --> Database Driver Class Initialized
INFO - 2025-10-30 07:35:42 --> Controller Class Initialized
INFO - 2025-10-30 07:35:42 --> Model "Student_model" initialized
INFO - 2025-10-30 07:35:42 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:35:42 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:35:42 --> Helper loaded: form_helper
INFO - 2025-10-30 07:35:42 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:35:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:35:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 07:35:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:35:42 --> Final output sent to browser
DEBUG - 2025-10-30 07:35:42 --> Total execution time: 0.0742
INFO - 2025-10-30 07:35:45 --> Config Class Initialized
INFO - 2025-10-30 07:35:45 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:35:45 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:35:45 --> Utf8 Class Initialized
INFO - 2025-10-30 07:35:45 --> URI Class Initialized
INFO - 2025-10-30 07:35:45 --> Router Class Initialized
INFO - 2025-10-30 07:35:45 --> Output Class Initialized
INFO - 2025-10-30 07:35:45 --> Security Class Initialized
DEBUG - 2025-10-30 07:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:35:45 --> Input Class Initialized
INFO - 2025-10-30 07:35:45 --> Language Class Initialized
INFO - 2025-10-30 07:35:45 --> Loader Class Initialized
INFO - 2025-10-30 07:35:45 --> Helper loaded: url_helper
INFO - 2025-10-30 07:35:45 --> Database Driver Class Initialized
INFO - 2025-10-30 07:35:45 --> Controller Class Initialized
INFO - 2025-10-30 07:35:45 --> Model "Student_model" initialized
INFO - 2025-10-30 07:35:45 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:35:45 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:35:45 --> Helper loaded: form_helper
INFO - 2025-10-30 07:35:45 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:35:45 --> Payments Controller Loaded
INFO - 2025-10-30 07:35:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:35:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 07:35:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:35:45 --> Final output sent to browser
DEBUG - 2025-10-30 07:35:45 --> Total execution time: 0.0643
INFO - 2025-10-30 07:35:52 --> Config Class Initialized
INFO - 2025-10-30 07:35:52 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:35:52 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:35:52 --> Utf8 Class Initialized
INFO - 2025-10-30 07:35:52 --> URI Class Initialized
INFO - 2025-10-30 07:35:52 --> Router Class Initialized
INFO - 2025-10-30 07:35:52 --> Output Class Initialized
INFO - 2025-10-30 07:35:52 --> Security Class Initialized
DEBUG - 2025-10-30 07:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:35:52 --> Input Class Initialized
INFO - 2025-10-30 07:35:52 --> Language Class Initialized
INFO - 2025-10-30 07:35:52 --> Loader Class Initialized
INFO - 2025-10-30 07:35:52 --> Helper loaded: url_helper
INFO - 2025-10-30 07:35:52 --> Database Driver Class Initialized
INFO - 2025-10-30 07:35:52 --> Controller Class Initialized
INFO - 2025-10-30 07:35:52 --> Model "Student_model" initialized
INFO - 2025-10-30 07:35:52 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:35:52 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:35:52 --> Helper loaded: form_helper
INFO - 2025-10-30 07:35:52 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:35:52 --> Payments Controller Loaded
INFO - 2025-10-30 07:35:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 07:35:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:35:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 07:35:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:35:52 --> Final output sent to browser
DEBUG - 2025-10-30 07:35:52 --> Total execution time: 0.0731
INFO - 2025-10-30 07:35:58 --> Config Class Initialized
INFO - 2025-10-30 07:35:58 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:35:58 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:35:58 --> Utf8 Class Initialized
INFO - 2025-10-30 07:35:58 --> URI Class Initialized
INFO - 2025-10-30 07:35:58 --> Router Class Initialized
INFO - 2025-10-30 07:35:58 --> Output Class Initialized
INFO - 2025-10-30 07:35:58 --> Security Class Initialized
DEBUG - 2025-10-30 07:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:35:58 --> Input Class Initialized
INFO - 2025-10-30 07:35:58 --> Language Class Initialized
INFO - 2025-10-30 07:35:58 --> Loader Class Initialized
INFO - 2025-10-30 07:35:58 --> Helper loaded: url_helper
INFO - 2025-10-30 07:35:58 --> Database Driver Class Initialized
INFO - 2025-10-30 07:35:58 --> Controller Class Initialized
INFO - 2025-10-30 07:35:58 --> Model "Student_model" initialized
INFO - 2025-10-30 07:35:58 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:35:58 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:35:58 --> Helper loaded: form_helper
INFO - 2025-10-30 07:35:58 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:35:58 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:35:58 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 07:35:58 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:35:58 --> Final output sent to browser
DEBUG - 2025-10-30 07:35:58 --> Total execution time: 0.0707
INFO - 2025-10-30 07:36:02 --> Config Class Initialized
INFO - 2025-10-30 07:36:02 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:36:02 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:36:02 --> Utf8 Class Initialized
INFO - 2025-10-30 07:36:02 --> URI Class Initialized
INFO - 2025-10-30 07:36:02 --> Router Class Initialized
INFO - 2025-10-30 07:36:02 --> Output Class Initialized
INFO - 2025-10-30 07:36:02 --> Security Class Initialized
DEBUG - 2025-10-30 07:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:36:02 --> Input Class Initialized
INFO - 2025-10-30 07:36:02 --> Language Class Initialized
INFO - 2025-10-30 07:36:02 --> Loader Class Initialized
INFO - 2025-10-30 07:36:02 --> Helper loaded: url_helper
INFO - 2025-10-30 07:36:02 --> Database Driver Class Initialized
INFO - 2025-10-30 07:36:02 --> Controller Class Initialized
INFO - 2025-10-30 07:36:02 --> Model "Student_model" initialized
INFO - 2025-10-30 07:36:02 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:36:02 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:36:02 --> Helper loaded: form_helper
INFO - 2025-10-30 07:36:02 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:36:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:36:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 07:36:02 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:36:02 --> Final output sent to browser
DEBUG - 2025-10-30 07:36:02 --> Total execution time: 0.0716
INFO - 2025-10-30 07:36:10 --> Config Class Initialized
INFO - 2025-10-30 07:36:10 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:36:10 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:36:10 --> Utf8 Class Initialized
INFO - 2025-10-30 07:36:10 --> URI Class Initialized
INFO - 2025-10-30 07:36:10 --> Router Class Initialized
INFO - 2025-10-30 07:36:10 --> Output Class Initialized
INFO - 2025-10-30 07:36:10 --> Security Class Initialized
DEBUG - 2025-10-30 07:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:36:10 --> Input Class Initialized
INFO - 2025-10-30 07:36:10 --> Language Class Initialized
INFO - 2025-10-30 07:36:10 --> Loader Class Initialized
INFO - 2025-10-30 07:36:10 --> Helper loaded: url_helper
INFO - 2025-10-30 07:36:10 --> Database Driver Class Initialized
INFO - 2025-10-30 07:36:10 --> Controller Class Initialized
INFO - 2025-10-30 07:36:10 --> Model "Student_model" initialized
INFO - 2025-10-30 07:36:10 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:36:10 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:36:10 --> Helper loaded: form_helper
INFO - 2025-10-30 07:36:10 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:36:10 --> Payments Controller Loaded
INFO - 2025-10-30 07:36:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:36:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 07:36:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:36:10 --> Final output sent to browser
DEBUG - 2025-10-30 07:36:10 --> Total execution time: 0.0895
INFO - 2025-10-30 07:36:12 --> Config Class Initialized
INFO - 2025-10-30 07:36:12 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:36:12 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:36:12 --> Utf8 Class Initialized
INFO - 2025-10-30 07:36:12 --> URI Class Initialized
INFO - 2025-10-30 07:36:12 --> Router Class Initialized
INFO - 2025-10-30 07:36:12 --> Output Class Initialized
INFO - 2025-10-30 07:36:12 --> Security Class Initialized
DEBUG - 2025-10-30 07:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:36:12 --> Input Class Initialized
INFO - 2025-10-30 07:36:12 --> Language Class Initialized
INFO - 2025-10-30 07:36:12 --> Loader Class Initialized
INFO - 2025-10-30 07:36:12 --> Helper loaded: url_helper
INFO - 2025-10-30 07:36:12 --> Database Driver Class Initialized
INFO - 2025-10-30 07:36:12 --> Controller Class Initialized
INFO - 2025-10-30 07:36:12 --> Model "Student_model" initialized
INFO - 2025-10-30 07:36:12 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:36:12 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:36:12 --> Helper loaded: form_helper
INFO - 2025-10-30 07:36:12 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:36:12 --> Payments Controller Loaded
INFO - 2025-10-30 07:36:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 07:36:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:36:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 07:36:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:36:12 --> Final output sent to browser
DEBUG - 2025-10-30 07:36:12 --> Total execution time: 0.0623
INFO - 2025-10-30 07:36:25 --> Config Class Initialized
INFO - 2025-10-30 07:36:25 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:36:25 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:36:25 --> Utf8 Class Initialized
INFO - 2025-10-30 07:36:25 --> URI Class Initialized
INFO - 2025-10-30 07:36:25 --> Router Class Initialized
INFO - 2025-10-30 07:36:25 --> Output Class Initialized
INFO - 2025-10-30 07:36:25 --> Security Class Initialized
DEBUG - 2025-10-30 07:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:36:25 --> Input Class Initialized
INFO - 2025-10-30 07:36:25 --> Language Class Initialized
INFO - 2025-10-30 07:36:25 --> Loader Class Initialized
INFO - 2025-10-30 07:36:25 --> Helper loaded: url_helper
INFO - 2025-10-30 07:36:25 --> Database Driver Class Initialized
INFO - 2025-10-30 07:36:25 --> Controller Class Initialized
INFO - 2025-10-30 07:36:25 --> Model "Student_model" initialized
INFO - 2025-10-30 07:36:25 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:36:25 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:36:25 --> Helper loaded: form_helper
INFO - 2025-10-30 07:36:25 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:36:25 --> Payments Controller Loaded
INFO - 2025-10-30 07:36:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 07:36:25 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:36:25 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 07:36:25 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:36:25 --> Final output sent to browser
DEBUG - 2025-10-30 07:36:25 --> Total execution time: 0.0625
INFO - 2025-10-30 07:46:04 --> Config Class Initialized
INFO - 2025-10-30 07:46:04 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:46:04 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:46:04 --> Utf8 Class Initialized
INFO - 2025-10-30 07:46:04 --> URI Class Initialized
INFO - 2025-10-30 07:46:04 --> Router Class Initialized
INFO - 2025-10-30 07:46:04 --> Output Class Initialized
INFO - 2025-10-30 07:46:04 --> Security Class Initialized
DEBUG - 2025-10-30 07:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:46:04 --> Input Class Initialized
INFO - 2025-10-30 07:46:04 --> Language Class Initialized
INFO - 2025-10-30 07:46:04 --> Loader Class Initialized
INFO - 2025-10-30 07:46:04 --> Helper loaded: url_helper
INFO - 2025-10-30 07:46:04 --> Database Driver Class Initialized
INFO - 2025-10-30 07:46:04 --> Controller Class Initialized
INFO - 2025-10-30 07:46:04 --> Model "Student_model" initialized
INFO - 2025-10-30 07:46:04 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:46:04 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:46:04 --> Helper loaded: form_helper
INFO - 2025-10-30 07:46:04 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:46:04 --> Payments Controller Loaded
INFO - 2025-10-30 07:46:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 07:46:04 --> Config Class Initialized
INFO - 2025-10-30 07:46:04 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:46:04 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:46:04 --> Utf8 Class Initialized
INFO - 2025-10-30 07:46:04 --> URI Class Initialized
INFO - 2025-10-30 07:46:04 --> Router Class Initialized
INFO - 2025-10-30 07:46:04 --> Output Class Initialized
INFO - 2025-10-30 07:46:04 --> Security Class Initialized
DEBUG - 2025-10-30 07:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:46:04 --> Input Class Initialized
INFO - 2025-10-30 07:46:04 --> Language Class Initialized
INFO - 2025-10-30 07:46:04 --> Loader Class Initialized
INFO - 2025-10-30 07:46:04 --> Helper loaded: url_helper
INFO - 2025-10-30 07:46:04 --> Database Driver Class Initialized
INFO - 2025-10-30 07:46:04 --> Controller Class Initialized
INFO - 2025-10-30 07:46:04 --> Model "Student_model" initialized
INFO - 2025-10-30 07:46:04 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:46:04 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:46:04 --> Helper loaded: form_helper
INFO - 2025-10-30 07:46:04 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:46:04 --> Payments Controller Loaded
INFO - 2025-10-30 07:46:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:46:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/receipt.php
INFO - 2025-10-30 07:46:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:46:04 --> Final output sent to browser
DEBUG - 2025-10-30 07:46:04 --> Total execution time: 0.0600
INFO - 2025-10-30 07:46:22 --> Config Class Initialized
INFO - 2025-10-30 07:46:22 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:46:22 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:46:22 --> Utf8 Class Initialized
INFO - 2025-10-30 07:46:22 --> URI Class Initialized
INFO - 2025-10-30 07:46:22 --> Router Class Initialized
INFO - 2025-10-30 07:46:22 --> Output Class Initialized
INFO - 2025-10-30 07:46:22 --> Security Class Initialized
DEBUG - 2025-10-30 07:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:46:22 --> Input Class Initialized
INFO - 2025-10-30 07:46:22 --> Language Class Initialized
INFO - 2025-10-30 07:46:22 --> Loader Class Initialized
INFO - 2025-10-30 07:46:22 --> Helper loaded: url_helper
INFO - 2025-10-30 07:46:22 --> Database Driver Class Initialized
INFO - 2025-10-30 07:46:22 --> Controller Class Initialized
INFO - 2025-10-30 07:46:22 --> Model "Student_model" initialized
INFO - 2025-10-30 07:46:22 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:46:22 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:46:22 --> Helper loaded: form_helper
INFO - 2025-10-30 07:46:22 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:46:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:46:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 07:46:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:46:22 --> Final output sent to browser
DEBUG - 2025-10-30 07:46:22 --> Total execution time: 0.0786
INFO - 2025-10-30 07:46:31 --> Config Class Initialized
INFO - 2025-10-30 07:46:31 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:46:31 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:46:31 --> Utf8 Class Initialized
INFO - 2025-10-30 07:46:31 --> URI Class Initialized
INFO - 2025-10-30 07:46:31 --> Router Class Initialized
INFO - 2025-10-30 07:46:31 --> Output Class Initialized
INFO - 2025-10-30 07:46:31 --> Security Class Initialized
DEBUG - 2025-10-30 07:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:46:31 --> Input Class Initialized
INFO - 2025-10-30 07:46:31 --> Language Class Initialized
INFO - 2025-10-30 07:46:31 --> Loader Class Initialized
INFO - 2025-10-30 07:46:31 --> Helper loaded: url_helper
INFO - 2025-10-30 07:46:31 --> Database Driver Class Initialized
INFO - 2025-10-30 07:46:31 --> Controller Class Initialized
INFO - 2025-10-30 07:46:31 --> Model "Student_model" initialized
INFO - 2025-10-30 07:46:31 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:46:31 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:46:31 --> Helper loaded: form_helper
INFO - 2025-10-30 07:46:31 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:46:31 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:46:31 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 07:46:31 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:46:31 --> Final output sent to browser
DEBUG - 2025-10-30 07:46:31 --> Total execution time: 0.0621
INFO - 2025-10-30 07:46:41 --> Config Class Initialized
INFO - 2025-10-30 07:46:41 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:46:41 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:46:41 --> Utf8 Class Initialized
INFO - 2025-10-30 07:46:41 --> URI Class Initialized
INFO - 2025-10-30 07:46:41 --> Router Class Initialized
INFO - 2025-10-30 07:46:41 --> Output Class Initialized
INFO - 2025-10-30 07:46:41 --> Security Class Initialized
DEBUG - 2025-10-30 07:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:46:41 --> Input Class Initialized
INFO - 2025-10-30 07:46:41 --> Language Class Initialized
INFO - 2025-10-30 07:46:41 --> Loader Class Initialized
INFO - 2025-10-30 07:46:41 --> Helper loaded: url_helper
INFO - 2025-10-30 07:46:41 --> Database Driver Class Initialized
INFO - 2025-10-30 07:46:41 --> Controller Class Initialized
INFO - 2025-10-30 07:46:41 --> Model "Student_model" initialized
INFO - 2025-10-30 07:46:41 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:46:41 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:46:41 --> Helper loaded: form_helper
INFO - 2025-10-30 07:46:41 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:46:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:46:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 07:46:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:46:41 --> Final output sent to browser
DEBUG - 2025-10-30 07:46:41 --> Total execution time: 0.0656
INFO - 2025-10-30 07:46:48 --> Config Class Initialized
INFO - 2025-10-30 07:46:48 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:46:48 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:46:48 --> Utf8 Class Initialized
INFO - 2025-10-30 07:46:48 --> URI Class Initialized
INFO - 2025-10-30 07:46:48 --> Router Class Initialized
INFO - 2025-10-30 07:46:48 --> Output Class Initialized
INFO - 2025-10-30 07:46:48 --> Security Class Initialized
DEBUG - 2025-10-30 07:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:46:48 --> Input Class Initialized
INFO - 2025-10-30 07:46:48 --> Language Class Initialized
INFO - 2025-10-30 07:46:48 --> Loader Class Initialized
INFO - 2025-10-30 07:46:48 --> Helper loaded: url_helper
INFO - 2025-10-30 07:46:48 --> Database Driver Class Initialized
INFO - 2025-10-30 07:46:48 --> Controller Class Initialized
INFO - 2025-10-30 07:46:48 --> Model "Student_model" initialized
INFO - 2025-10-30 07:46:48 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:46:48 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:46:48 --> Helper loaded: form_helper
INFO - 2025-10-30 07:46:48 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:46:48 --> Payments Controller Loaded
INFO - 2025-10-30 07:46:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:46:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 07:46:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:46:48 --> Final output sent to browser
DEBUG - 2025-10-30 07:46:48 --> Total execution time: 0.0638
INFO - 2025-10-30 07:47:13 --> Config Class Initialized
INFO - 2025-10-30 07:47:13 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:47:13 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:47:13 --> Utf8 Class Initialized
INFO - 2025-10-30 07:47:13 --> URI Class Initialized
INFO - 2025-10-30 07:47:13 --> Router Class Initialized
INFO - 2025-10-30 07:47:13 --> Output Class Initialized
INFO - 2025-10-30 07:47:13 --> Security Class Initialized
DEBUG - 2025-10-30 07:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:47:13 --> Input Class Initialized
INFO - 2025-10-30 07:47:13 --> Language Class Initialized
INFO - 2025-10-30 07:47:13 --> Loader Class Initialized
INFO - 2025-10-30 07:47:13 --> Helper loaded: url_helper
INFO - 2025-10-30 07:47:13 --> Database Driver Class Initialized
INFO - 2025-10-30 07:47:13 --> Controller Class Initialized
INFO - 2025-10-30 07:47:13 --> Model "Student_model" initialized
INFO - 2025-10-30 07:47:13 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:47:13 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:47:13 --> Helper loaded: form_helper
INFO - 2025-10-30 07:47:13 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:47:13 --> Payments Controller Loaded
INFO - 2025-10-30 07:47:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 07:47:13 --> Config Class Initialized
INFO - 2025-10-30 07:47:13 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:47:13 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:47:13 --> Utf8 Class Initialized
INFO - 2025-10-30 07:47:13 --> URI Class Initialized
INFO - 2025-10-30 07:47:13 --> Router Class Initialized
INFO - 2025-10-30 07:47:13 --> Output Class Initialized
INFO - 2025-10-30 07:47:13 --> Security Class Initialized
DEBUG - 2025-10-30 07:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:47:13 --> Input Class Initialized
INFO - 2025-10-30 07:47:13 --> Language Class Initialized
INFO - 2025-10-30 07:47:13 --> Loader Class Initialized
INFO - 2025-10-30 07:47:13 --> Helper loaded: url_helper
INFO - 2025-10-30 07:47:13 --> Database Driver Class Initialized
INFO - 2025-10-30 07:47:13 --> Controller Class Initialized
INFO - 2025-10-30 07:47:13 --> Model "Student_model" initialized
INFO - 2025-10-30 07:47:13 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:47:13 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:47:13 --> Helper loaded: form_helper
INFO - 2025-10-30 07:47:13 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:47:13 --> Payments Controller Loaded
INFO - 2025-10-30 07:47:13 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:47:13 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/receipt.php
INFO - 2025-10-30 07:47:13 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:47:13 --> Final output sent to browser
DEBUG - 2025-10-30 07:47:13 --> Total execution time: 0.0559
INFO - 2025-10-30 07:47:35 --> Config Class Initialized
INFO - 2025-10-30 07:47:35 --> Hooks Class Initialized
DEBUG - 2025-10-30 07:47:35 --> UTF-8 Support Enabled
INFO - 2025-10-30 07:47:35 --> Utf8 Class Initialized
INFO - 2025-10-30 07:47:35 --> URI Class Initialized
INFO - 2025-10-30 07:47:35 --> Router Class Initialized
INFO - 2025-10-30 07:47:35 --> Output Class Initialized
INFO - 2025-10-30 07:47:35 --> Security Class Initialized
DEBUG - 2025-10-30 07:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 07:47:36 --> Input Class Initialized
INFO - 2025-10-30 07:47:36 --> Language Class Initialized
INFO - 2025-10-30 07:47:36 --> Loader Class Initialized
INFO - 2025-10-30 07:47:36 --> Helper loaded: url_helper
INFO - 2025-10-30 07:47:36 --> Database Driver Class Initialized
INFO - 2025-10-30 07:47:36 --> Controller Class Initialized
INFO - 2025-10-30 07:47:36 --> Model "Student_model" initialized
INFO - 2025-10-30 07:47:36 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 07:47:36 --> Model "Payment_model" initialized
INFO - 2025-10-30 07:47:36 --> Helper loaded: form_helper
INFO - 2025-10-30 07:47:36 --> Form Validation Class Initialized
DEBUG - 2025-10-30 07:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 07:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 07:47:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 07:47:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 07:47:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 07:47:36 --> Final output sent to browser
DEBUG - 2025-10-30 07:47:36 --> Total execution time: 0.0674
INFO - 2025-10-30 09:16:44 --> Config Class Initialized
INFO - 2025-10-30 09:16:44 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:16:44 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:16:44 --> Utf8 Class Initialized
INFO - 2025-10-30 09:16:44 --> URI Class Initialized
INFO - 2025-10-30 09:16:44 --> Router Class Initialized
INFO - 2025-10-30 09:16:44 --> Output Class Initialized
INFO - 2025-10-30 09:16:44 --> Security Class Initialized
DEBUG - 2025-10-30 09:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:16:44 --> Input Class Initialized
INFO - 2025-10-30 09:16:44 --> Language Class Initialized
INFO - 2025-10-30 09:16:44 --> Loader Class Initialized
INFO - 2025-10-30 09:16:44 --> Helper loaded: url_helper
INFO - 2025-10-30 09:16:44 --> Database Driver Class Initialized
INFO - 2025-10-30 09:16:44 --> Controller Class Initialized
INFO - 2025-10-30 09:16:44 --> Model "Student_model" initialized
INFO - 2025-10-30 09:16:44 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:16:44 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:16:44 --> Helper loaded: form_helper
INFO - 2025-10-30 09:16:44 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:16:44 --> Payments Controller Loaded
INFO - 2025-10-30 09:16:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:16:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 09:16:44 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:16:44 --> Final output sent to browser
DEBUG - 2025-10-30 09:16:44 --> Total execution time: 0.0619
INFO - 2025-10-30 09:16:48 --> Config Class Initialized
INFO - 2025-10-30 09:16:48 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:16:48 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:16:48 --> Utf8 Class Initialized
INFO - 2025-10-30 09:16:48 --> URI Class Initialized
INFO - 2025-10-30 09:16:48 --> Router Class Initialized
INFO - 2025-10-30 09:16:48 --> Output Class Initialized
INFO - 2025-10-30 09:16:48 --> Security Class Initialized
DEBUG - 2025-10-30 09:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:16:48 --> Input Class Initialized
INFO - 2025-10-30 09:16:48 --> Language Class Initialized
INFO - 2025-10-30 09:16:48 --> Loader Class Initialized
INFO - 2025-10-30 09:16:48 --> Helper loaded: url_helper
INFO - 2025-10-30 09:16:48 --> Database Driver Class Initialized
INFO - 2025-10-30 09:16:48 --> Controller Class Initialized
INFO - 2025-10-30 09:16:48 --> Model "Student_model" initialized
INFO - 2025-10-30 09:16:48 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:16:48 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:16:48 --> Helper loaded: form_helper
INFO - 2025-10-30 09:16:48 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:16:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:16:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 09:16:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:16:48 --> Final output sent to browser
DEBUG - 2025-10-30 09:16:48 --> Total execution time: 0.0770
INFO - 2025-10-30 09:16:52 --> Config Class Initialized
INFO - 2025-10-30 09:16:52 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:16:52 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:16:52 --> Utf8 Class Initialized
INFO - 2025-10-30 09:16:52 --> URI Class Initialized
INFO - 2025-10-30 09:16:52 --> Router Class Initialized
INFO - 2025-10-30 09:16:52 --> Output Class Initialized
INFO - 2025-10-30 09:16:52 --> Security Class Initialized
DEBUG - 2025-10-30 09:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:16:52 --> Input Class Initialized
INFO - 2025-10-30 09:16:52 --> Language Class Initialized
INFO - 2025-10-30 09:16:52 --> Loader Class Initialized
INFO - 2025-10-30 09:16:52 --> Helper loaded: url_helper
INFO - 2025-10-30 09:16:52 --> Database Driver Class Initialized
INFO - 2025-10-30 09:16:52 --> Controller Class Initialized
INFO - 2025-10-30 09:16:52 --> Model "Student_model" initialized
INFO - 2025-10-30 09:16:52 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:16:52 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:16:52 --> Helper loaded: form_helper
INFO - 2025-10-30 09:16:52 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:16:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:16:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 09:16:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:16:52 --> Final output sent to browser
DEBUG - 2025-10-30 09:16:52 --> Total execution time: 0.0925
INFO - 2025-10-30 09:16:56 --> Config Class Initialized
INFO - 2025-10-30 09:16:56 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:16:56 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:16:56 --> Utf8 Class Initialized
INFO - 2025-10-30 09:16:56 --> URI Class Initialized
INFO - 2025-10-30 09:16:56 --> Router Class Initialized
INFO - 2025-10-30 09:16:56 --> Output Class Initialized
INFO - 2025-10-30 09:16:56 --> Security Class Initialized
DEBUG - 2025-10-30 09:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:16:56 --> Input Class Initialized
INFO - 2025-10-30 09:16:56 --> Language Class Initialized
INFO - 2025-10-30 09:16:56 --> Loader Class Initialized
INFO - 2025-10-30 09:16:56 --> Helper loaded: url_helper
INFO - 2025-10-30 09:16:56 --> Database Driver Class Initialized
INFO - 2025-10-30 09:16:56 --> Controller Class Initialized
INFO - 2025-10-30 09:16:56 --> Model "Student_model" initialized
INFO - 2025-10-30 09:16:56 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:16:56 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:16:56 --> Helper loaded: form_helper
INFO - 2025-10-30 09:16:56 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:16:56 --> Payments Controller Loaded
INFO - 2025-10-30 09:16:56 --> Config Class Initialized
INFO - 2025-10-30 09:16:56 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:16:56 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:16:56 --> Utf8 Class Initialized
INFO - 2025-10-30 09:16:56 --> URI Class Initialized
INFO - 2025-10-30 09:16:56 --> Router Class Initialized
INFO - 2025-10-30 09:16:56 --> Output Class Initialized
INFO - 2025-10-30 09:16:56 --> Security Class Initialized
DEBUG - 2025-10-30 09:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:16:56 --> Input Class Initialized
INFO - 2025-10-30 09:16:56 --> Language Class Initialized
INFO - 2025-10-30 09:16:56 --> Loader Class Initialized
INFO - 2025-10-30 09:16:56 --> Helper loaded: url_helper
INFO - 2025-10-30 09:16:56 --> Database Driver Class Initialized
INFO - 2025-10-30 09:16:56 --> Controller Class Initialized
INFO - 2025-10-30 09:16:56 --> Model "Student_model" initialized
INFO - 2025-10-30 09:16:56 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:16:56 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:16:56 --> Helper loaded: form_helper
INFO - 2025-10-30 09:16:56 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:16:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:16:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 09:16:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:16:56 --> Final output sent to browser
DEBUG - 2025-10-30 09:16:56 --> Total execution time: 0.0634
INFO - 2025-10-30 09:17:01 --> Config Class Initialized
INFO - 2025-10-30 09:17:01 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:17:01 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:17:01 --> Utf8 Class Initialized
INFO - 2025-10-30 09:17:01 --> URI Class Initialized
INFO - 2025-10-30 09:17:01 --> Router Class Initialized
INFO - 2025-10-30 09:17:01 --> Output Class Initialized
INFO - 2025-10-30 09:17:01 --> Security Class Initialized
DEBUG - 2025-10-30 09:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:17:01 --> Input Class Initialized
INFO - 2025-10-30 09:17:01 --> Language Class Initialized
INFO - 2025-10-30 09:17:01 --> Loader Class Initialized
INFO - 2025-10-30 09:17:01 --> Helper loaded: url_helper
INFO - 2025-10-30 09:17:01 --> Database Driver Class Initialized
INFO - 2025-10-30 09:17:01 --> Controller Class Initialized
INFO - 2025-10-30 09:17:01 --> Model "Student_model" initialized
INFO - 2025-10-30 09:17:01 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:17:01 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:17:01 --> Helper loaded: form_helper
INFO - 2025-10-30 09:17:01 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:17:01 --> Payments Controller Loaded
INFO - 2025-10-30 09:17:01 --> Config Class Initialized
INFO - 2025-10-30 09:17:01 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:17:01 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:17:01 --> Utf8 Class Initialized
INFO - 2025-10-30 09:17:01 --> URI Class Initialized
INFO - 2025-10-30 09:17:01 --> Router Class Initialized
INFO - 2025-10-30 09:17:01 --> Output Class Initialized
INFO - 2025-10-30 09:17:01 --> Security Class Initialized
DEBUG - 2025-10-30 09:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:17:01 --> Input Class Initialized
INFO - 2025-10-30 09:17:01 --> Language Class Initialized
INFO - 2025-10-30 09:17:01 --> Loader Class Initialized
INFO - 2025-10-30 09:17:01 --> Helper loaded: url_helper
INFO - 2025-10-30 09:17:01 --> Database Driver Class Initialized
INFO - 2025-10-30 09:17:01 --> Controller Class Initialized
INFO - 2025-10-30 09:17:01 --> Model "Student_model" initialized
INFO - 2025-10-30 09:17:01 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:17:01 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:17:01 --> Helper loaded: form_helper
INFO - 2025-10-30 09:17:01 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:17:01 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:17:01 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 09:17:01 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:17:01 --> Final output sent to browser
DEBUG - 2025-10-30 09:17:01 --> Total execution time: 0.0651
INFO - 2025-10-30 09:17:04 --> Config Class Initialized
INFO - 2025-10-30 09:17:04 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:17:04 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:17:04 --> Utf8 Class Initialized
INFO - 2025-10-30 09:17:04 --> URI Class Initialized
INFO - 2025-10-30 09:17:04 --> Router Class Initialized
INFO - 2025-10-30 09:17:04 --> Output Class Initialized
INFO - 2025-10-30 09:17:04 --> Security Class Initialized
DEBUG - 2025-10-30 09:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:17:04 --> Input Class Initialized
INFO - 2025-10-30 09:17:04 --> Language Class Initialized
INFO - 2025-10-30 09:17:04 --> Loader Class Initialized
INFO - 2025-10-30 09:17:04 --> Helper loaded: url_helper
INFO - 2025-10-30 09:17:04 --> Database Driver Class Initialized
INFO - 2025-10-30 09:17:04 --> Controller Class Initialized
INFO - 2025-10-30 09:17:04 --> Model "Student_model" initialized
INFO - 2025-10-30 09:17:04 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:17:04 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:17:04 --> Helper loaded: form_helper
INFO - 2025-10-30 09:17:04 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:17:04 --> Payments Controller Loaded
INFO - 2025-10-30 09:17:04 --> Config Class Initialized
INFO - 2025-10-30 09:17:04 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:17:04 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:17:04 --> Utf8 Class Initialized
INFO - 2025-10-30 09:17:04 --> URI Class Initialized
INFO - 2025-10-30 09:17:04 --> Router Class Initialized
INFO - 2025-10-30 09:17:04 --> Output Class Initialized
INFO - 2025-10-30 09:17:04 --> Security Class Initialized
DEBUG - 2025-10-30 09:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:17:04 --> Input Class Initialized
INFO - 2025-10-30 09:17:04 --> Language Class Initialized
INFO - 2025-10-30 09:17:04 --> Loader Class Initialized
INFO - 2025-10-30 09:17:04 --> Helper loaded: url_helper
INFO - 2025-10-30 09:17:04 --> Database Driver Class Initialized
INFO - 2025-10-30 09:17:04 --> Controller Class Initialized
INFO - 2025-10-30 09:17:04 --> Model "Student_model" initialized
INFO - 2025-10-30 09:17:04 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:17:04 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:17:04 --> Helper loaded: form_helper
INFO - 2025-10-30 09:17:04 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:17:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:17:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 09:17:04 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:17:04 --> Final output sent to browser
DEBUG - 2025-10-30 09:17:04 --> Total execution time: 0.0623
INFO - 2025-10-30 09:17:13 --> Config Class Initialized
INFO - 2025-10-30 09:17:13 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:17:13 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:17:13 --> Utf8 Class Initialized
INFO - 2025-10-30 09:17:13 --> URI Class Initialized
INFO - 2025-10-30 09:17:13 --> Router Class Initialized
INFO - 2025-10-30 09:17:13 --> Output Class Initialized
INFO - 2025-10-30 09:17:13 --> Security Class Initialized
DEBUG - 2025-10-30 09:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:17:13 --> Input Class Initialized
INFO - 2025-10-30 09:17:13 --> Language Class Initialized
INFO - 2025-10-30 09:17:13 --> Loader Class Initialized
INFO - 2025-10-30 09:17:13 --> Helper loaded: url_helper
INFO - 2025-10-30 09:17:13 --> Database Driver Class Initialized
INFO - 2025-10-30 09:17:13 --> Controller Class Initialized
INFO - 2025-10-30 09:17:13 --> Model "Student_model" initialized
INFO - 2025-10-30 09:17:13 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:17:13 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:17:13 --> Helper loaded: form_helper
INFO - 2025-10-30 09:17:13 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:17:13 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:17:13 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 09:17:13 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:17:13 --> Final output sent to browser
DEBUG - 2025-10-30 09:17:13 --> Total execution time: 0.0993
INFO - 2025-10-30 09:17:17 --> Config Class Initialized
INFO - 2025-10-30 09:17:17 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:17:17 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:17:17 --> Utf8 Class Initialized
INFO - 2025-10-30 09:17:17 --> URI Class Initialized
INFO - 2025-10-30 09:17:17 --> Router Class Initialized
INFO - 2025-10-30 09:17:17 --> Output Class Initialized
INFO - 2025-10-30 09:17:17 --> Security Class Initialized
DEBUG - 2025-10-30 09:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:17:17 --> Input Class Initialized
INFO - 2025-10-30 09:17:17 --> Language Class Initialized
INFO - 2025-10-30 09:17:17 --> Loader Class Initialized
INFO - 2025-10-30 09:17:17 --> Helper loaded: url_helper
INFO - 2025-10-30 09:17:17 --> Database Driver Class Initialized
INFO - 2025-10-30 09:17:17 --> Controller Class Initialized
INFO - 2025-10-30 09:17:17 --> Model "Student_model" initialized
INFO - 2025-10-30 09:17:17 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:17:17 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:17:17 --> Helper loaded: form_helper
INFO - 2025-10-30 09:17:17 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:17:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:17:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 09:17:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:17:17 --> Final output sent to browser
DEBUG - 2025-10-30 09:17:17 --> Total execution time: 0.0565
INFO - 2025-10-30 09:17:21 --> Config Class Initialized
INFO - 2025-10-30 09:17:21 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:17:21 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:17:21 --> Utf8 Class Initialized
INFO - 2025-10-30 09:17:21 --> URI Class Initialized
INFO - 2025-10-30 09:17:21 --> Router Class Initialized
INFO - 2025-10-30 09:17:21 --> Output Class Initialized
INFO - 2025-10-30 09:17:21 --> Security Class Initialized
DEBUG - 2025-10-30 09:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:17:21 --> Input Class Initialized
INFO - 2025-10-30 09:17:21 --> Language Class Initialized
INFO - 2025-10-30 09:17:21 --> Loader Class Initialized
INFO - 2025-10-30 09:17:21 --> Helper loaded: url_helper
INFO - 2025-10-30 09:17:21 --> Database Driver Class Initialized
INFO - 2025-10-30 09:17:21 --> Controller Class Initialized
INFO - 2025-10-30 09:17:21 --> Model "Student_model" initialized
INFO - 2025-10-30 09:17:21 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:17:21 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:17:21 --> Helper loaded: form_helper
INFO - 2025-10-30 09:17:21 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:17:21 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:17:21 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 09:17:21 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:17:21 --> Final output sent to browser
DEBUG - 2025-10-30 09:17:21 --> Total execution time: 0.0986
INFO - 2025-10-30 09:17:48 --> Config Class Initialized
INFO - 2025-10-30 09:17:48 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:17:48 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:17:48 --> Utf8 Class Initialized
INFO - 2025-10-30 09:17:48 --> URI Class Initialized
INFO - 2025-10-30 09:17:48 --> Router Class Initialized
INFO - 2025-10-30 09:17:48 --> Output Class Initialized
INFO - 2025-10-30 09:17:48 --> Security Class Initialized
DEBUG - 2025-10-30 09:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:17:48 --> Input Class Initialized
INFO - 2025-10-30 09:17:48 --> Language Class Initialized
INFO - 2025-10-30 09:17:48 --> Loader Class Initialized
INFO - 2025-10-30 09:17:48 --> Helper loaded: url_helper
INFO - 2025-10-30 09:17:48 --> Database Driver Class Initialized
INFO - 2025-10-30 09:17:48 --> Controller Class Initialized
INFO - 2025-10-30 09:17:48 --> Model "Student_model" initialized
INFO - 2025-10-30 09:17:48 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:17:48 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:17:48 --> Helper loaded: form_helper
INFO - 2025-10-30 09:17:48 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:17:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:17:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 09:17:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:17:48 --> Final output sent to browser
DEBUG - 2025-10-30 09:17:48 --> Total execution time: 0.0710
INFO - 2025-10-30 09:46:00 --> Config Class Initialized
INFO - 2025-10-30 09:46:00 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:46:00 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:46:00 --> Utf8 Class Initialized
INFO - 2025-10-30 09:46:00 --> URI Class Initialized
INFO - 2025-10-30 09:46:00 --> Router Class Initialized
INFO - 2025-10-30 09:46:00 --> Output Class Initialized
INFO - 2025-10-30 09:46:00 --> Security Class Initialized
DEBUG - 2025-10-30 09:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:46:00 --> Input Class Initialized
INFO - 2025-10-30 09:46:00 --> Language Class Initialized
INFO - 2025-10-30 09:46:00 --> Loader Class Initialized
INFO - 2025-10-30 09:46:00 --> Helper loaded: url_helper
INFO - 2025-10-30 09:46:00 --> Database Driver Class Initialized
INFO - 2025-10-30 09:46:00 --> Controller Class Initialized
INFO - 2025-10-30 09:46:00 --> Model "Student_model" initialized
INFO - 2025-10-30 09:46:00 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:46:00 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:46:00 --> Helper loaded: form_helper
INFO - 2025-10-30 09:46:00 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:46:00 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:46:00 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 09:46:00 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:46:00 --> Final output sent to browser
DEBUG - 2025-10-30 09:46:00 --> Total execution time: 0.0872
INFO - 2025-10-30 09:46:06 --> Config Class Initialized
INFO - 2025-10-30 09:46:06 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:46:06 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:46:06 --> Utf8 Class Initialized
INFO - 2025-10-30 09:46:06 --> URI Class Initialized
INFO - 2025-10-30 09:46:06 --> Router Class Initialized
INFO - 2025-10-30 09:46:06 --> Output Class Initialized
INFO - 2025-10-30 09:46:06 --> Security Class Initialized
DEBUG - 2025-10-30 09:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:46:06 --> Input Class Initialized
INFO - 2025-10-30 09:46:06 --> Language Class Initialized
INFO - 2025-10-30 09:46:06 --> Loader Class Initialized
INFO - 2025-10-30 09:46:06 --> Helper loaded: url_helper
INFO - 2025-10-30 09:46:06 --> Database Driver Class Initialized
INFO - 2025-10-30 09:46:06 --> Controller Class Initialized
INFO - 2025-10-30 09:46:06 --> Model "Student_model" initialized
INFO - 2025-10-30 09:46:06 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:46:06 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:46:06 --> Helper loaded: form_helper
INFO - 2025-10-30 09:46:06 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:46:06 --> Payments Controller Loaded
INFO - 2025-10-30 09:46:06 --> Config Class Initialized
INFO - 2025-10-30 09:46:06 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:46:06 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:46:06 --> Utf8 Class Initialized
INFO - 2025-10-30 09:46:06 --> URI Class Initialized
INFO - 2025-10-30 09:46:06 --> Router Class Initialized
INFO - 2025-10-30 09:46:06 --> Output Class Initialized
INFO - 2025-10-30 09:46:06 --> Security Class Initialized
DEBUG - 2025-10-30 09:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:46:06 --> Input Class Initialized
INFO - 2025-10-30 09:46:06 --> Language Class Initialized
INFO - 2025-10-30 09:46:06 --> Loader Class Initialized
INFO - 2025-10-30 09:46:06 --> Helper loaded: url_helper
INFO - 2025-10-30 09:46:06 --> Database Driver Class Initialized
INFO - 2025-10-30 09:46:06 --> Controller Class Initialized
INFO - 2025-10-30 09:46:06 --> Model "Student_model" initialized
INFO - 2025-10-30 09:46:06 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:46:06 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:46:06 --> Helper loaded: form_helper
INFO - 2025-10-30 09:46:06 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:46:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:46:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 09:46:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:46:06 --> Final output sent to browser
DEBUG - 2025-10-30 09:46:06 --> Total execution time: 0.0611
INFO - 2025-10-30 09:46:09 --> Config Class Initialized
INFO - 2025-10-30 09:46:09 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:46:09 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:46:09 --> Utf8 Class Initialized
INFO - 2025-10-30 09:46:09 --> URI Class Initialized
INFO - 2025-10-30 09:46:09 --> Router Class Initialized
INFO - 2025-10-30 09:46:09 --> Output Class Initialized
INFO - 2025-10-30 09:46:09 --> Security Class Initialized
DEBUG - 2025-10-30 09:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:46:09 --> Input Class Initialized
INFO - 2025-10-30 09:46:09 --> Language Class Initialized
INFO - 2025-10-30 09:46:09 --> Loader Class Initialized
INFO - 2025-10-30 09:46:09 --> Helper loaded: url_helper
INFO - 2025-10-30 09:46:09 --> Database Driver Class Initialized
INFO - 2025-10-30 09:46:09 --> Controller Class Initialized
INFO - 2025-10-30 09:46:09 --> Model "Student_model" initialized
INFO - 2025-10-30 09:46:09 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:46:09 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:46:09 --> Helper loaded: form_helper
INFO - 2025-10-30 09:46:09 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:46:09 --> Payments Controller Loaded
INFO - 2025-10-30 09:46:09 --> Config Class Initialized
INFO - 2025-10-30 09:46:09 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:46:09 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:46:09 --> Utf8 Class Initialized
INFO - 2025-10-30 09:46:09 --> URI Class Initialized
INFO - 2025-10-30 09:46:09 --> Router Class Initialized
INFO - 2025-10-30 09:46:09 --> Output Class Initialized
INFO - 2025-10-30 09:46:09 --> Security Class Initialized
DEBUG - 2025-10-30 09:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:46:09 --> Input Class Initialized
INFO - 2025-10-30 09:46:09 --> Language Class Initialized
INFO - 2025-10-30 09:46:09 --> Loader Class Initialized
INFO - 2025-10-30 09:46:09 --> Helper loaded: url_helper
INFO - 2025-10-30 09:46:09 --> Database Driver Class Initialized
INFO - 2025-10-30 09:46:09 --> Controller Class Initialized
INFO - 2025-10-30 09:46:09 --> Model "Student_model" initialized
INFO - 2025-10-30 09:46:09 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:46:09 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:46:09 --> Helper loaded: form_helper
INFO - 2025-10-30 09:46:09 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:46:09 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:46:09 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 09:46:09 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:46:09 --> Final output sent to browser
DEBUG - 2025-10-30 09:46:09 --> Total execution time: 0.0531
INFO - 2025-10-30 09:46:15 --> Config Class Initialized
INFO - 2025-10-30 09:46:15 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:46:15 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:46:15 --> Utf8 Class Initialized
INFO - 2025-10-30 09:46:15 --> URI Class Initialized
INFO - 2025-10-30 09:46:15 --> Router Class Initialized
INFO - 2025-10-30 09:46:15 --> Output Class Initialized
INFO - 2025-10-30 09:46:15 --> Security Class Initialized
DEBUG - 2025-10-30 09:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:46:15 --> Input Class Initialized
INFO - 2025-10-30 09:46:15 --> Language Class Initialized
INFO - 2025-10-30 09:46:15 --> Loader Class Initialized
INFO - 2025-10-30 09:46:15 --> Helper loaded: url_helper
INFO - 2025-10-30 09:46:15 --> Database Driver Class Initialized
INFO - 2025-10-30 09:46:15 --> Controller Class Initialized
INFO - 2025-10-30 09:46:15 --> Model "Student_model" initialized
INFO - 2025-10-30 09:46:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:46:15 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:46:15 --> Helper loaded: form_helper
INFO - 2025-10-30 09:46:15 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:46:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:46:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 09:46:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:46:15 --> Final output sent to browser
DEBUG - 2025-10-30 09:46:15 --> Total execution time: 0.0957
INFO - 2025-10-30 09:46:18 --> Config Class Initialized
INFO - 2025-10-30 09:46:18 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:46:18 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:46:18 --> Utf8 Class Initialized
INFO - 2025-10-30 09:46:18 --> URI Class Initialized
INFO - 2025-10-30 09:46:18 --> Router Class Initialized
INFO - 2025-10-30 09:46:18 --> Output Class Initialized
INFO - 2025-10-30 09:46:18 --> Security Class Initialized
DEBUG - 2025-10-30 09:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:46:18 --> Input Class Initialized
INFO - 2025-10-30 09:46:18 --> Language Class Initialized
INFO - 2025-10-30 09:46:18 --> Loader Class Initialized
INFO - 2025-10-30 09:46:18 --> Helper loaded: url_helper
INFO - 2025-10-30 09:46:18 --> Database Driver Class Initialized
INFO - 2025-10-30 09:46:18 --> Controller Class Initialized
INFO - 2025-10-30 09:46:18 --> Model "Student_model" initialized
INFO - 2025-10-30 09:46:18 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:46:18 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:46:18 --> Helper loaded: form_helper
INFO - 2025-10-30 09:46:18 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:46:18 --> Payments Controller Loaded
INFO - 2025-10-30 09:46:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:46:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/index.php
INFO - 2025-10-30 09:46:18 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:46:18 --> Final output sent to browser
DEBUG - 2025-10-30 09:46:18 --> Total execution time: 0.0869
INFO - 2025-10-30 09:46:21 --> Config Class Initialized
INFO - 2025-10-30 09:46:21 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:46:21 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:46:21 --> Utf8 Class Initialized
INFO - 2025-10-30 09:46:21 --> URI Class Initialized
INFO - 2025-10-30 09:46:21 --> Router Class Initialized
INFO - 2025-10-30 09:46:21 --> Output Class Initialized
INFO - 2025-10-30 09:46:21 --> Security Class Initialized
DEBUG - 2025-10-30 09:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:46:21 --> Input Class Initialized
INFO - 2025-10-30 09:46:21 --> Language Class Initialized
INFO - 2025-10-30 09:46:21 --> Loader Class Initialized
INFO - 2025-10-30 09:46:21 --> Helper loaded: url_helper
INFO - 2025-10-30 09:46:21 --> Database Driver Class Initialized
INFO - 2025-10-30 09:46:21 --> Controller Class Initialized
INFO - 2025-10-30 09:46:21 --> Model "Student_model" initialized
INFO - 2025-10-30 09:46:21 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:46:21 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:46:21 --> Helper loaded: form_helper
INFO - 2025-10-30 09:46:21 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:46:21 --> Payments Controller Loaded
INFO - 2025-10-30 09:46:21 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:46:21 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/receipt.php
INFO - 2025-10-30 09:46:21 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:46:21 --> Final output sent to browser
DEBUG - 2025-10-30 09:46:21 --> Total execution time: 0.0907
INFO - 2025-10-30 09:46:25 --> Config Class Initialized
INFO - 2025-10-30 09:46:25 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:46:25 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:46:25 --> Utf8 Class Initialized
INFO - 2025-10-30 09:46:25 --> URI Class Initialized
INFO - 2025-10-30 09:46:25 --> Router Class Initialized
INFO - 2025-10-30 09:46:25 --> Output Class Initialized
INFO - 2025-10-30 09:46:25 --> Security Class Initialized
DEBUG - 2025-10-30 09:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:46:25 --> Input Class Initialized
INFO - 2025-10-30 09:46:25 --> Language Class Initialized
INFO - 2025-10-30 09:46:25 --> Loader Class Initialized
INFO - 2025-10-30 09:46:25 --> Helper loaded: url_helper
INFO - 2025-10-30 09:46:25 --> Database Driver Class Initialized
INFO - 2025-10-30 09:46:25 --> Controller Class Initialized
INFO - 2025-10-30 09:46:25 --> Model "Student_model" initialized
INFO - 2025-10-30 09:46:25 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:46:25 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:46:25 --> Helper loaded: form_helper
INFO - 2025-10-30 09:46:25 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:46:25 --> Payments Controller Loaded
INFO - 2025-10-30 09:46:25 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:46:25 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/receipt.php
INFO - 2025-10-30 09:46:25 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:46:25 --> Final output sent to browser
DEBUG - 2025-10-30 09:46:25 --> Total execution time: 0.0904
INFO - 2025-10-30 09:46:41 --> Config Class Initialized
INFO - 2025-10-30 09:46:41 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:46:41 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:46:41 --> Utf8 Class Initialized
INFO - 2025-10-30 09:46:41 --> URI Class Initialized
INFO - 2025-10-30 09:46:41 --> Router Class Initialized
INFO - 2025-10-30 09:46:41 --> Output Class Initialized
INFO - 2025-10-30 09:46:41 --> Security Class Initialized
DEBUG - 2025-10-30 09:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:46:41 --> Input Class Initialized
INFO - 2025-10-30 09:46:41 --> Language Class Initialized
INFO - 2025-10-30 09:46:41 --> Loader Class Initialized
INFO - 2025-10-30 09:46:41 --> Helper loaded: url_helper
INFO - 2025-10-30 09:46:41 --> Database Driver Class Initialized
INFO - 2025-10-30 09:46:41 --> Controller Class Initialized
INFO - 2025-10-30 09:46:41 --> Model "Student_model" initialized
INFO - 2025-10-30 09:46:41 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:46:41 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:46:41 --> Helper loaded: form_helper
INFO - 2025-10-30 09:46:41 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:46:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:46:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 09:46:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:46:41 --> Final output sent to browser
DEBUG - 2025-10-30 09:46:41 --> Total execution time: 0.0797
INFO - 2025-10-30 09:46:43 --> Config Class Initialized
INFO - 2025-10-30 09:46:43 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:46:43 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:46:43 --> Utf8 Class Initialized
INFO - 2025-10-30 09:46:43 --> URI Class Initialized
INFO - 2025-10-30 09:46:43 --> Router Class Initialized
INFO - 2025-10-30 09:46:43 --> Output Class Initialized
INFO - 2025-10-30 09:46:43 --> Security Class Initialized
DEBUG - 2025-10-30 09:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:46:43 --> Input Class Initialized
INFO - 2025-10-30 09:46:43 --> Language Class Initialized
INFO - 2025-10-30 09:46:43 --> Loader Class Initialized
INFO - 2025-10-30 09:46:43 --> Helper loaded: url_helper
INFO - 2025-10-30 09:46:43 --> Database Driver Class Initialized
INFO - 2025-10-30 09:46:43 --> Controller Class Initialized
INFO - 2025-10-30 09:46:43 --> Model "Student_model" initialized
INFO - 2025-10-30 09:46:43 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:46:43 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:46:43 --> Helper loaded: form_helper
INFO - 2025-10-30 09:46:43 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:46:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:46:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 09:46:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:46:43 --> Final output sent to browser
DEBUG - 2025-10-30 09:46:43 --> Total execution time: 0.0955
INFO - 2025-10-30 09:46:47 --> Config Class Initialized
INFO - 2025-10-30 09:46:47 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:46:47 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:46:47 --> Utf8 Class Initialized
INFO - 2025-10-30 09:46:47 --> URI Class Initialized
DEBUG - 2025-10-30 09:46:47 --> No URI present. Default controller set.
INFO - 2025-10-30 09:46:47 --> Router Class Initialized
INFO - 2025-10-30 09:46:47 --> Output Class Initialized
INFO - 2025-10-30 09:46:47 --> Security Class Initialized
DEBUG - 2025-10-30 09:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:46:47 --> Input Class Initialized
INFO - 2025-10-30 09:46:47 --> Language Class Initialized
INFO - 2025-10-30 09:46:47 --> Loader Class Initialized
INFO - 2025-10-30 09:46:47 --> Helper loaded: url_helper
INFO - 2025-10-30 09:46:47 --> Database Driver Class Initialized
INFO - 2025-10-30 09:46:47 --> Controller Class Initialized
INFO - 2025-10-30 09:46:47 --> Model "Student_model" initialized
INFO - 2025-10-30 09:46:47 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:46:47 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 09:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:46:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:46:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-30 09:46:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:46:48 --> Final output sent to browser
DEBUG - 2025-10-30 09:46:48 --> Total execution time: 0.0982
INFO - 2025-10-30 09:47:06 --> Config Class Initialized
INFO - 2025-10-30 09:47:06 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:47:06 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:47:06 --> Utf8 Class Initialized
INFO - 2025-10-30 09:47:06 --> URI Class Initialized
INFO - 2025-10-30 09:47:06 --> Router Class Initialized
INFO - 2025-10-30 09:47:06 --> Output Class Initialized
INFO - 2025-10-30 09:47:06 --> Security Class Initialized
DEBUG - 2025-10-30 09:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:47:06 --> Input Class Initialized
INFO - 2025-10-30 09:47:06 --> Language Class Initialized
INFO - 2025-10-30 09:47:06 --> Loader Class Initialized
INFO - 2025-10-30 09:47:06 --> Helper loaded: url_helper
INFO - 2025-10-30 09:47:06 --> Database Driver Class Initialized
INFO - 2025-10-30 09:47:06 --> Controller Class Initialized
INFO - 2025-10-30 09:47:06 --> Model "Student_model" initialized
INFO - 2025-10-30 09:47:06 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:47:06 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:47:06 --> Helper loaded: form_helper
INFO - 2025-10-30 09:47:06 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:47:06 --> Payments Controller Loaded
INFO - 2025-10-30 09:47:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:47:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/index.php
INFO - 2025-10-30 09:47:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:47:06 --> Final output sent to browser
DEBUG - 2025-10-30 09:47:06 --> Total execution time: 0.0679
INFO - 2025-10-30 09:47:08 --> Config Class Initialized
INFO - 2025-10-30 09:47:08 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:47:08 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:47:08 --> Utf8 Class Initialized
INFO - 2025-10-30 09:47:08 --> URI Class Initialized
INFO - 2025-10-30 09:47:08 --> Router Class Initialized
INFO - 2025-10-30 09:47:08 --> Output Class Initialized
INFO - 2025-10-30 09:47:08 --> Security Class Initialized
DEBUG - 2025-10-30 09:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:47:08 --> Input Class Initialized
INFO - 2025-10-30 09:47:08 --> Language Class Initialized
INFO - 2025-10-30 09:47:08 --> Loader Class Initialized
INFO - 2025-10-30 09:47:08 --> Helper loaded: url_helper
INFO - 2025-10-30 09:47:08 --> Database Driver Class Initialized
INFO - 2025-10-30 09:47:08 --> Controller Class Initialized
INFO - 2025-10-30 09:47:08 --> Model "Student_model" initialized
INFO - 2025-10-30 09:47:08 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:47:08 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:47:08 --> Helper loaded: form_helper
INFO - 2025-10-30 09:47:08 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:47:08 --> Payments Controller Loaded
INFO - 2025-10-30 09:47:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:47:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/receipt.php
INFO - 2025-10-30 09:47:08 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:47:08 --> Final output sent to browser
DEBUG - 2025-10-30 09:47:08 --> Total execution time: 0.0768
INFO - 2025-10-30 09:47:12 --> Config Class Initialized
INFO - 2025-10-30 09:47:12 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:47:12 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:47:12 --> Utf8 Class Initialized
INFO - 2025-10-30 09:47:12 --> URI Class Initialized
INFO - 2025-10-30 09:47:12 --> Router Class Initialized
INFO - 2025-10-30 09:47:12 --> Output Class Initialized
INFO - 2025-10-30 09:47:12 --> Security Class Initialized
DEBUG - 2025-10-30 09:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:47:12 --> Input Class Initialized
INFO - 2025-10-30 09:47:12 --> Language Class Initialized
INFO - 2025-10-30 09:47:12 --> Loader Class Initialized
INFO - 2025-10-30 09:47:12 --> Helper loaded: url_helper
INFO - 2025-10-30 09:47:12 --> Database Driver Class Initialized
INFO - 2025-10-30 09:47:12 --> Controller Class Initialized
INFO - 2025-10-30 09:47:12 --> Model "Student_model" initialized
INFO - 2025-10-30 09:47:12 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:47:12 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:47:12 --> Helper loaded: form_helper
INFO - 2025-10-30 09:47:12 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:47:12 --> Payments Controller Loaded
INFO - 2025-10-30 09:47:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:47:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/index.php
INFO - 2025-10-30 09:47:12 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:47:12 --> Final output sent to browser
DEBUG - 2025-10-30 09:47:12 --> Total execution time: 0.0591
INFO - 2025-10-30 09:47:14 --> Config Class Initialized
INFO - 2025-10-30 09:47:14 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:47:14 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:47:14 --> Utf8 Class Initialized
INFO - 2025-10-30 09:47:14 --> URI Class Initialized
INFO - 2025-10-30 09:47:14 --> Router Class Initialized
INFO - 2025-10-30 09:47:14 --> Output Class Initialized
INFO - 2025-10-30 09:47:15 --> Security Class Initialized
DEBUG - 2025-10-30 09:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:47:15 --> Input Class Initialized
INFO - 2025-10-30 09:47:15 --> Language Class Initialized
INFO - 2025-10-30 09:47:15 --> Loader Class Initialized
INFO - 2025-10-30 09:47:15 --> Helper loaded: url_helper
INFO - 2025-10-30 09:47:15 --> Database Driver Class Initialized
INFO - 2025-10-30 09:47:15 --> Controller Class Initialized
INFO - 2025-10-30 09:47:15 --> Model "Student_model" initialized
INFO - 2025-10-30 09:47:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:47:15 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:47:15 --> Helper loaded: form_helper
INFO - 2025-10-30 09:47:15 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:47:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:47:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 09:47:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:47:15 --> Final output sent to browser
DEBUG - 2025-10-30 09:47:15 --> Total execution time: 0.0823
INFO - 2025-10-30 09:47:33 --> Config Class Initialized
INFO - 2025-10-30 09:47:33 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:47:33 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:47:33 --> Utf8 Class Initialized
INFO - 2025-10-30 09:47:33 --> URI Class Initialized
INFO - 2025-10-30 09:47:33 --> Router Class Initialized
INFO - 2025-10-30 09:47:33 --> Output Class Initialized
INFO - 2025-10-30 09:47:33 --> Security Class Initialized
DEBUG - 2025-10-30 09:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:47:33 --> Input Class Initialized
INFO - 2025-10-30 09:47:33 --> Language Class Initialized
INFO - 2025-10-30 09:47:33 --> Loader Class Initialized
INFO - 2025-10-30 09:47:33 --> Helper loaded: url_helper
INFO - 2025-10-30 09:47:33 --> Database Driver Class Initialized
INFO - 2025-10-30 09:47:33 --> Controller Class Initialized
INFO - 2025-10-30 09:47:33 --> Model "Student_model" initialized
INFO - 2025-10-30 09:47:33 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:47:33 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:47:33 --> Helper loaded: form_helper
INFO - 2025-10-30 09:47:33 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:47:33 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:47:33 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 09:47:33 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:47:33 --> Final output sent to browser
DEBUG - 2025-10-30 09:47:33 --> Total execution time: 0.0856
INFO - 2025-10-30 09:47:36 --> Config Class Initialized
INFO - 2025-10-30 09:47:36 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:47:36 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:47:36 --> Utf8 Class Initialized
INFO - 2025-10-30 09:47:36 --> URI Class Initialized
INFO - 2025-10-30 09:47:36 --> Router Class Initialized
INFO - 2025-10-30 09:47:36 --> Output Class Initialized
INFO - 2025-10-30 09:47:36 --> Security Class Initialized
DEBUG - 2025-10-30 09:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:47:36 --> Input Class Initialized
INFO - 2025-10-30 09:47:36 --> Language Class Initialized
INFO - 2025-10-30 09:47:36 --> Loader Class Initialized
INFO - 2025-10-30 09:47:36 --> Helper loaded: url_helper
INFO - 2025-10-30 09:47:36 --> Database Driver Class Initialized
INFO - 2025-10-30 09:47:36 --> Controller Class Initialized
INFO - 2025-10-30 09:47:36 --> Model "Student_model" initialized
INFO - 2025-10-30 09:47:36 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:47:36 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:47:36 --> Helper loaded: form_helper
INFO - 2025-10-30 09:47:36 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:47:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:47:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 09:47:36 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:47:36 --> Final output sent to browser
DEBUG - 2025-10-30 09:47:36 --> Total execution time: 0.0715
INFO - 2025-10-30 09:47:38 --> Config Class Initialized
INFO - 2025-10-30 09:47:38 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:47:38 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:47:38 --> Utf8 Class Initialized
INFO - 2025-10-30 09:47:38 --> URI Class Initialized
INFO - 2025-10-30 09:47:38 --> Router Class Initialized
INFO - 2025-10-30 09:47:38 --> Output Class Initialized
INFO - 2025-10-30 09:47:38 --> Security Class Initialized
DEBUG - 2025-10-30 09:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:47:38 --> Input Class Initialized
INFO - 2025-10-30 09:47:38 --> Language Class Initialized
INFO - 2025-10-30 09:47:38 --> Loader Class Initialized
INFO - 2025-10-30 09:47:38 --> Helper loaded: url_helper
INFO - 2025-10-30 09:47:38 --> Database Driver Class Initialized
INFO - 2025-10-30 09:47:38 --> Controller Class Initialized
INFO - 2025-10-30 09:47:38 --> Model "Student_model" initialized
INFO - 2025-10-30 09:47:38 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:47:38 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:47:38 --> Helper loaded: form_helper
INFO - 2025-10-30 09:47:38 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:47:38 --> Payments Controller Loaded
INFO - 2025-10-30 09:47:38 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:47:38 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/index.php
INFO - 2025-10-30 09:47:38 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:47:38 --> Final output sent to browser
DEBUG - 2025-10-30 09:47:38 --> Total execution time: 0.0651
INFO - 2025-10-30 09:47:40 --> Config Class Initialized
INFO - 2025-10-30 09:47:40 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:47:40 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:47:40 --> Utf8 Class Initialized
INFO - 2025-10-30 09:47:40 --> URI Class Initialized
DEBUG - 2025-10-30 09:47:40 --> No URI present. Default controller set.
INFO - 2025-10-30 09:47:40 --> Router Class Initialized
INFO - 2025-10-30 09:47:40 --> Output Class Initialized
INFO - 2025-10-30 09:47:40 --> Security Class Initialized
DEBUG - 2025-10-30 09:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:47:40 --> Input Class Initialized
INFO - 2025-10-30 09:47:40 --> Language Class Initialized
INFO - 2025-10-30 09:47:40 --> Loader Class Initialized
INFO - 2025-10-30 09:47:40 --> Helper loaded: url_helper
INFO - 2025-10-30 09:47:40 --> Database Driver Class Initialized
INFO - 2025-10-30 09:47:40 --> Controller Class Initialized
INFO - 2025-10-30 09:47:40 --> Model "Student_model" initialized
INFO - 2025-10-30 09:47:40 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:47:40 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 09:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:47:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:47:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-30 09:47:40 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:47:40 --> Final output sent to browser
DEBUG - 2025-10-30 09:47:40 --> Total execution time: 0.0700
INFO - 2025-10-30 09:47:41 --> Config Class Initialized
INFO - 2025-10-30 09:47:41 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:47:41 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:47:41 --> Utf8 Class Initialized
INFO - 2025-10-30 09:47:41 --> URI Class Initialized
INFO - 2025-10-30 09:47:41 --> Router Class Initialized
INFO - 2025-10-30 09:47:41 --> Output Class Initialized
INFO - 2025-10-30 09:47:41 --> Security Class Initialized
DEBUG - 2025-10-30 09:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:47:41 --> Input Class Initialized
INFO - 2025-10-30 09:47:41 --> Language Class Initialized
INFO - 2025-10-30 09:47:41 --> Loader Class Initialized
INFO - 2025-10-30 09:47:41 --> Helper loaded: url_helper
INFO - 2025-10-30 09:47:41 --> Database Driver Class Initialized
INFO - 2025-10-30 09:47:41 --> Controller Class Initialized
INFO - 2025-10-30 09:47:41 --> Model "Student_model" initialized
INFO - 2025-10-30 09:47:41 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:47:41 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:47:41 --> Helper loaded: form_helper
INFO - 2025-10-30 09:47:41 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:47:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:47:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 09:47:41 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:47:41 --> Final output sent to browser
DEBUG - 2025-10-30 09:47:41 --> Total execution time: 0.0766
INFO - 2025-10-30 09:47:42 --> Config Class Initialized
INFO - 2025-10-30 09:47:42 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:47:42 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:47:42 --> Utf8 Class Initialized
INFO - 2025-10-30 09:47:42 --> URI Class Initialized
INFO - 2025-10-30 09:47:42 --> Router Class Initialized
INFO - 2025-10-30 09:47:42 --> Output Class Initialized
INFO - 2025-10-30 09:47:42 --> Security Class Initialized
DEBUG - 2025-10-30 09:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:47:42 --> Input Class Initialized
INFO - 2025-10-30 09:47:42 --> Language Class Initialized
INFO - 2025-10-30 09:47:42 --> Loader Class Initialized
INFO - 2025-10-30 09:47:42 --> Helper loaded: url_helper
INFO - 2025-10-30 09:47:42 --> Database Driver Class Initialized
INFO - 2025-10-30 09:47:42 --> Controller Class Initialized
INFO - 2025-10-30 09:47:42 --> Model "Student_model" initialized
INFO - 2025-10-30 09:47:42 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:47:42 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:47:42 --> Helper loaded: form_helper
INFO - 2025-10-30 09:47:42 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:47:42 --> Payments Controller Loaded
INFO - 2025-10-30 09:47:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:47:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/index.php
INFO - 2025-10-30 09:47:42 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:47:42 --> Final output sent to browser
DEBUG - 2025-10-30 09:47:42 --> Total execution time: 0.0841
INFO - 2025-10-30 09:47:43 --> Config Class Initialized
INFO - 2025-10-30 09:47:43 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:47:43 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:47:43 --> Utf8 Class Initialized
INFO - 2025-10-30 09:47:43 --> URI Class Initialized
INFO - 2025-10-30 09:47:43 --> Router Class Initialized
INFO - 2025-10-30 09:47:43 --> Output Class Initialized
INFO - 2025-10-30 09:47:43 --> Security Class Initialized
DEBUG - 2025-10-30 09:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:47:43 --> Input Class Initialized
INFO - 2025-10-30 09:47:43 --> Language Class Initialized
INFO - 2025-10-30 09:47:43 --> Loader Class Initialized
INFO - 2025-10-30 09:47:43 --> Helper loaded: url_helper
INFO - 2025-10-30 09:47:43 --> Database Driver Class Initialized
INFO - 2025-10-30 09:47:43 --> Controller Class Initialized
INFO - 2025-10-30 09:47:43 --> Model "Student_model" initialized
INFO - 2025-10-30 09:47:43 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:47:43 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:47:43 --> Helper loaded: form_helper
INFO - 2025-10-30 09:47:43 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:47:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:47:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 09:47:43 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:47:43 --> Final output sent to browser
DEBUG - 2025-10-30 09:47:43 --> Total execution time: 0.0779
INFO - 2025-10-30 09:47:53 --> Config Class Initialized
INFO - 2025-10-30 09:47:53 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:47:53 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:47:53 --> Utf8 Class Initialized
INFO - 2025-10-30 09:47:53 --> URI Class Initialized
INFO - 2025-10-30 09:47:53 --> Router Class Initialized
INFO - 2025-10-30 09:47:53 --> Output Class Initialized
INFO - 2025-10-30 09:47:53 --> Security Class Initialized
DEBUG - 2025-10-30 09:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:47:53 --> Input Class Initialized
INFO - 2025-10-30 09:47:53 --> Language Class Initialized
INFO - 2025-10-30 09:47:53 --> Loader Class Initialized
INFO - 2025-10-30 09:47:53 --> Helper loaded: url_helper
INFO - 2025-10-30 09:47:53 --> Database Driver Class Initialized
INFO - 2025-10-30 09:47:53 --> Controller Class Initialized
INFO - 2025-10-30 09:47:53 --> Model "Student_model" initialized
INFO - 2025-10-30 09:47:53 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:47:53 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:47:53 --> Helper loaded: form_helper
INFO - 2025-10-30 09:47:53 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:47:53 --> Payments Controller Loaded
INFO - 2025-10-30 09:47:53 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:47:53 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 09:47:53 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:47:53 --> Final output sent to browser
DEBUG - 2025-10-30 09:47:53 --> Total execution time: 0.0721
INFO - 2025-10-30 09:47:55 --> Config Class Initialized
INFO - 2025-10-30 09:47:55 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:47:55 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:47:55 --> Utf8 Class Initialized
INFO - 2025-10-30 09:47:55 --> URI Class Initialized
INFO - 2025-10-30 09:47:55 --> Router Class Initialized
INFO - 2025-10-30 09:47:55 --> Output Class Initialized
INFO - 2025-10-30 09:47:55 --> Security Class Initialized
DEBUG - 2025-10-30 09:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:47:55 --> Input Class Initialized
INFO - 2025-10-30 09:47:55 --> Language Class Initialized
INFO - 2025-10-30 09:47:55 --> Loader Class Initialized
INFO - 2025-10-30 09:47:55 --> Helper loaded: url_helper
INFO - 2025-10-30 09:47:55 --> Database Driver Class Initialized
INFO - 2025-10-30 09:47:55 --> Controller Class Initialized
INFO - 2025-10-30 09:47:55 --> Model "Student_model" initialized
INFO - 2025-10-30 09:47:55 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:47:55 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:47:55 --> Helper loaded: form_helper
INFO - 2025-10-30 09:47:55 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:47:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:47:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 09:47:55 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:47:55 --> Final output sent to browser
DEBUG - 2025-10-30 09:47:55 --> Total execution time: 0.0758
INFO - 2025-10-30 09:47:58 --> Config Class Initialized
INFO - 2025-10-30 09:47:58 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:47:58 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:47:58 --> Utf8 Class Initialized
INFO - 2025-10-30 09:47:58 --> URI Class Initialized
INFO - 2025-10-30 09:47:58 --> Router Class Initialized
INFO - 2025-10-30 09:47:58 --> Output Class Initialized
INFO - 2025-10-30 09:47:58 --> Security Class Initialized
DEBUG - 2025-10-30 09:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:47:58 --> Input Class Initialized
INFO - 2025-10-30 09:47:58 --> Language Class Initialized
INFO - 2025-10-30 09:47:58 --> Loader Class Initialized
INFO - 2025-10-30 09:47:58 --> Helper loaded: url_helper
INFO - 2025-10-30 09:47:58 --> Database Driver Class Initialized
INFO - 2025-10-30 09:47:58 --> Controller Class Initialized
INFO - 2025-10-30 09:47:58 --> Model "Student_model" initialized
INFO - 2025-10-30 09:47:58 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:47:58 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:47:58 --> Helper loaded: form_helper
INFO - 2025-10-30 09:47:58 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:47:58 --> Payments Controller Loaded
INFO - 2025-10-30 09:47:58 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:47:58 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/index.php
INFO - 2025-10-30 09:47:58 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:47:58 --> Final output sent to browser
DEBUG - 2025-10-30 09:47:58 --> Total execution time: 0.0605
INFO - 2025-10-30 09:47:59 --> Config Class Initialized
INFO - 2025-10-30 09:47:59 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:47:59 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:47:59 --> Utf8 Class Initialized
INFO - 2025-10-30 09:47:59 --> URI Class Initialized
INFO - 2025-10-30 09:47:59 --> Router Class Initialized
INFO - 2025-10-30 09:47:59 --> Output Class Initialized
INFO - 2025-10-30 09:47:59 --> Security Class Initialized
DEBUG - 2025-10-30 09:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:47:59 --> Input Class Initialized
INFO - 2025-10-30 09:47:59 --> Language Class Initialized
INFO - 2025-10-30 09:47:59 --> Loader Class Initialized
INFO - 2025-10-30 09:47:59 --> Helper loaded: url_helper
INFO - 2025-10-30 09:47:59 --> Database Driver Class Initialized
INFO - 2025-10-30 09:47:59 --> Controller Class Initialized
INFO - 2025-10-30 09:47:59 --> Model "Student_model" initialized
INFO - 2025-10-30 09:47:59 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:47:59 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:47:59 --> Helper loaded: form_helper
INFO - 2025-10-30 09:47:59 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:47:59 --> Payments Controller Loaded
INFO - 2025-10-30 09:47:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:47:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/receipt.php
INFO - 2025-10-30 09:47:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:47:59 --> Final output sent to browser
DEBUG - 2025-10-30 09:47:59 --> Total execution time: 0.0741
INFO - 2025-10-30 09:48:05 --> Config Class Initialized
INFO - 2025-10-30 09:48:05 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:48:05 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:48:05 --> Utf8 Class Initialized
INFO - 2025-10-30 09:48:05 --> URI Class Initialized
INFO - 2025-10-30 09:48:05 --> Router Class Initialized
INFO - 2025-10-30 09:48:05 --> Output Class Initialized
INFO - 2025-10-30 09:48:05 --> Security Class Initialized
DEBUG - 2025-10-30 09:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:48:05 --> Input Class Initialized
INFO - 2025-10-30 09:48:05 --> Language Class Initialized
INFO - 2025-10-30 09:48:05 --> Loader Class Initialized
INFO - 2025-10-30 09:48:05 --> Helper loaded: url_helper
INFO - 2025-10-30 09:48:05 --> Database Driver Class Initialized
INFO - 2025-10-30 09:48:05 --> Controller Class Initialized
INFO - 2025-10-30 09:48:05 --> Model "Student_model" initialized
INFO - 2025-10-30 09:48:05 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:48:05 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:48:05 --> Helper loaded: form_helper
INFO - 2025-10-30 09:48:05 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:48:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:48:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 09:48:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:48:05 --> Final output sent to browser
DEBUG - 2025-10-30 09:48:05 --> Total execution time: 0.1104
INFO - 2025-10-30 09:48:05 --> Config Class Initialized
INFO - 2025-10-30 09:48:05 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:48:05 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:48:05 --> Utf8 Class Initialized
INFO - 2025-10-30 09:48:05 --> URI Class Initialized
INFO - 2025-10-30 09:48:05 --> Router Class Initialized
INFO - 2025-10-30 09:48:05 --> Output Class Initialized
INFO - 2025-10-30 09:48:05 --> Security Class Initialized
DEBUG - 2025-10-30 09:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:48:05 --> Input Class Initialized
INFO - 2025-10-30 09:48:05 --> Language Class Initialized
INFO - 2025-10-30 09:48:05 --> Loader Class Initialized
INFO - 2025-10-30 09:48:05 --> Helper loaded: url_helper
INFO - 2025-10-30 09:48:05 --> Database Driver Class Initialized
INFO - 2025-10-30 09:48:05 --> Controller Class Initialized
INFO - 2025-10-30 09:48:05 --> Model "Student_model" initialized
INFO - 2025-10-30 09:48:05 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:48:05 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:48:05 --> Helper loaded: form_helper
INFO - 2025-10-30 09:48:05 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:48:05 --> Payments Controller Loaded
INFO - 2025-10-30 09:48:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:48:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/index.php
INFO - 2025-10-30 09:48:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:48:05 --> Final output sent to browser
DEBUG - 2025-10-30 09:48:05 --> Total execution time: 0.0828
INFO - 2025-10-30 09:48:07 --> Config Class Initialized
INFO - 2025-10-30 09:48:07 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:48:07 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:48:07 --> Utf8 Class Initialized
INFO - 2025-10-30 09:48:07 --> URI Class Initialized
INFO - 2025-10-30 09:48:07 --> Router Class Initialized
INFO - 2025-10-30 09:48:07 --> Output Class Initialized
INFO - 2025-10-30 09:48:07 --> Security Class Initialized
DEBUG - 2025-10-30 09:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:48:07 --> Input Class Initialized
INFO - 2025-10-30 09:48:07 --> Language Class Initialized
INFO - 2025-10-30 09:48:07 --> Loader Class Initialized
INFO - 2025-10-30 09:48:07 --> Helper loaded: url_helper
INFO - 2025-10-30 09:48:07 --> Database Driver Class Initialized
INFO - 2025-10-30 09:48:07 --> Controller Class Initialized
INFO - 2025-10-30 09:48:07 --> Model "Student_model" initialized
INFO - 2025-10-30 09:48:07 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:48:07 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:48:07 --> Helper loaded: form_helper
INFO - 2025-10-30 09:48:07 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:48:07 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:48:07 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 09:48:07 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:48:07 --> Final output sent to browser
DEBUG - 2025-10-30 09:48:07 --> Total execution time: 0.0666
INFO - 2025-10-30 09:48:10 --> Config Class Initialized
INFO - 2025-10-30 09:48:10 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:48:10 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:48:10 --> Utf8 Class Initialized
INFO - 2025-10-30 09:48:10 --> URI Class Initialized
INFO - 2025-10-30 09:48:10 --> Router Class Initialized
INFO - 2025-10-30 09:48:10 --> Output Class Initialized
INFO - 2025-10-30 09:48:10 --> Security Class Initialized
DEBUG - 2025-10-30 09:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:48:10 --> Input Class Initialized
INFO - 2025-10-30 09:48:10 --> Language Class Initialized
INFO - 2025-10-30 09:48:10 --> Loader Class Initialized
INFO - 2025-10-30 09:48:10 --> Helper loaded: url_helper
INFO - 2025-10-30 09:48:10 --> Database Driver Class Initialized
INFO - 2025-10-30 09:48:10 --> Controller Class Initialized
INFO - 2025-10-30 09:48:10 --> Model "Student_model" initialized
INFO - 2025-10-30 09:48:10 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:48:10 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:48:10 --> Helper loaded: form_helper
INFO - 2025-10-30 09:48:10 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:48:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:48:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 09:48:10 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:48:10 --> Final output sent to browser
DEBUG - 2025-10-30 09:48:10 --> Total execution time: 0.0711
INFO - 2025-10-30 09:48:11 --> Config Class Initialized
INFO - 2025-10-30 09:48:11 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:48:11 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:48:11 --> Utf8 Class Initialized
INFO - 2025-10-30 09:48:11 --> URI Class Initialized
DEBUG - 2025-10-30 09:48:11 --> No URI present. Default controller set.
INFO - 2025-10-30 09:48:11 --> Router Class Initialized
INFO - 2025-10-30 09:48:11 --> Output Class Initialized
INFO - 2025-10-30 09:48:11 --> Security Class Initialized
DEBUG - 2025-10-30 09:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:48:11 --> Input Class Initialized
INFO - 2025-10-30 09:48:11 --> Language Class Initialized
INFO - 2025-10-30 09:48:11 --> Loader Class Initialized
INFO - 2025-10-30 09:48:11 --> Helper loaded: url_helper
INFO - 2025-10-30 09:48:11 --> Database Driver Class Initialized
INFO - 2025-10-30 09:48:11 --> Controller Class Initialized
INFO - 2025-10-30 09:48:11 --> Model "Student_model" initialized
INFO - 2025-10-30 09:48:11 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:48:11 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 09:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:48:11 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:48:11 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-30 09:48:11 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:48:11 --> Final output sent to browser
DEBUG - 2025-10-30 09:48:11 --> Total execution time: 0.0935
INFO - 2025-10-30 09:48:22 --> Config Class Initialized
INFO - 2025-10-30 09:48:22 --> Hooks Class Initialized
DEBUG - 2025-10-30 09:48:22 --> UTF-8 Support Enabled
INFO - 2025-10-30 09:48:22 --> Utf8 Class Initialized
INFO - 2025-10-30 09:48:22 --> URI Class Initialized
INFO - 2025-10-30 09:48:22 --> Router Class Initialized
INFO - 2025-10-30 09:48:22 --> Output Class Initialized
INFO - 2025-10-30 09:48:22 --> Security Class Initialized
DEBUG - 2025-10-30 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 09:48:22 --> Input Class Initialized
INFO - 2025-10-30 09:48:22 --> Language Class Initialized
INFO - 2025-10-30 09:48:22 --> Loader Class Initialized
INFO - 2025-10-30 09:48:22 --> Helper loaded: url_helper
INFO - 2025-10-30 09:48:22 --> Database Driver Class Initialized
INFO - 2025-10-30 09:48:22 --> Controller Class Initialized
INFO - 2025-10-30 09:48:22 --> Model "Student_model" initialized
INFO - 2025-10-30 09:48:22 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 09:48:22 --> Model "Payment_model" initialized
INFO - 2025-10-30 09:48:22 --> Helper loaded: form_helper
INFO - 2025-10-30 09:48:22 --> Form Validation Class Initialized
DEBUG - 2025-10-30 09:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 09:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 09:48:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 09:48:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 09:48:22 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 09:48:22 --> Final output sent to browser
DEBUG - 2025-10-30 09:48:22 --> Total execution time: 0.1004
INFO - 2025-10-30 12:13:45 --> Config Class Initialized
INFO - 2025-10-30 12:13:45 --> Hooks Class Initialized
DEBUG - 2025-10-30 12:13:45 --> UTF-8 Support Enabled
INFO - 2025-10-30 12:13:45 --> Utf8 Class Initialized
INFO - 2025-10-30 12:13:45 --> URI Class Initialized
INFO - 2025-10-30 12:13:45 --> Router Class Initialized
INFO - 2025-10-30 12:13:45 --> Output Class Initialized
INFO - 2025-10-30 12:13:45 --> Security Class Initialized
DEBUG - 2025-10-30 12:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 12:13:45 --> Input Class Initialized
INFO - 2025-10-30 12:13:45 --> Language Class Initialized
INFO - 2025-10-30 12:13:45 --> Loader Class Initialized
INFO - 2025-10-30 12:13:45 --> Helper loaded: url_helper
INFO - 2025-10-30 12:13:45 --> Database Driver Class Initialized
INFO - 2025-10-30 12:13:45 --> Controller Class Initialized
INFO - 2025-10-30 12:13:45 --> Model "Student_model" initialized
INFO - 2025-10-30 12:13:45 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 12:13:45 --> Model "Payment_model" initialized
INFO - 2025-10-30 12:13:45 --> Helper loaded: form_helper
INFO - 2025-10-30 12:13:45 --> Form Validation Class Initialized
DEBUG - 2025-10-30 12:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 12:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 12:13:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 12:13:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 12:13:45 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 12:13:45 --> Final output sent to browser
DEBUG - 2025-10-30 12:13:45 --> Total execution time: 0.0772
INFO - 2025-10-30 12:13:47 --> Config Class Initialized
INFO - 2025-10-30 12:13:47 --> Hooks Class Initialized
DEBUG - 2025-10-30 12:13:47 --> UTF-8 Support Enabled
INFO - 2025-10-30 12:13:47 --> Utf8 Class Initialized
INFO - 2025-10-30 12:13:47 --> URI Class Initialized
INFO - 2025-10-30 12:13:47 --> Router Class Initialized
INFO - 2025-10-30 12:13:47 --> Output Class Initialized
INFO - 2025-10-30 12:13:47 --> Security Class Initialized
DEBUG - 2025-10-30 12:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 12:13:47 --> Input Class Initialized
INFO - 2025-10-30 12:13:47 --> Language Class Initialized
INFO - 2025-10-30 12:13:47 --> Loader Class Initialized
INFO - 2025-10-30 12:13:47 --> Helper loaded: url_helper
INFO - 2025-10-30 12:13:47 --> Database Driver Class Initialized
INFO - 2025-10-30 12:13:47 --> Controller Class Initialized
INFO - 2025-10-30 12:13:47 --> Model "Student_model" initialized
INFO - 2025-10-30 12:13:47 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 12:13:47 --> Model "Payment_model" initialized
INFO - 2025-10-30 12:13:47 --> Helper loaded: form_helper
INFO - 2025-10-30 12:13:47 --> Form Validation Class Initialized
DEBUG - 2025-10-30 12:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 12:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 12:13:47 --> Payments Controller Loaded
INFO - 2025-10-30 12:13:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 12:13:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\payments/create.php
INFO - 2025-10-30 12:13:47 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 12:13:47 --> Final output sent to browser
DEBUG - 2025-10-30 12:13:47 --> Total execution time: 0.0740
INFO - 2025-10-30 12:13:49 --> Config Class Initialized
INFO - 2025-10-30 12:13:49 --> Hooks Class Initialized
DEBUG - 2025-10-30 12:13:49 --> UTF-8 Support Enabled
INFO - 2025-10-30 12:13:49 --> Utf8 Class Initialized
INFO - 2025-10-30 12:13:49 --> URI Class Initialized
INFO - 2025-10-30 12:13:49 --> Router Class Initialized
INFO - 2025-10-30 12:13:49 --> Output Class Initialized
INFO - 2025-10-30 12:13:49 --> Security Class Initialized
DEBUG - 2025-10-30 12:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 12:13:49 --> Input Class Initialized
INFO - 2025-10-30 12:13:49 --> Language Class Initialized
INFO - 2025-10-30 12:13:49 --> Loader Class Initialized
INFO - 2025-10-30 12:13:49 --> Helper loaded: url_helper
INFO - 2025-10-30 12:13:49 --> Database Driver Class Initialized
INFO - 2025-10-30 12:13:49 --> Controller Class Initialized
INFO - 2025-10-30 12:13:49 --> Model "Student_model" initialized
INFO - 2025-10-30 12:13:49 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 12:13:49 --> Model "Payment_model" initialized
INFO - 2025-10-30 12:13:49 --> Helper loaded: form_helper
INFO - 2025-10-30 12:13:49 --> Form Validation Class Initialized
DEBUG - 2025-10-30 12:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 12:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 12:13:49 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 12:13:49 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 12:13:49 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 12:13:49 --> Final output sent to browser
DEBUG - 2025-10-30 12:13:49 --> Total execution time: 0.0782
INFO - 2025-10-30 12:22:49 --> Config Class Initialized
INFO - 2025-10-30 12:22:49 --> Hooks Class Initialized
DEBUG - 2025-10-30 12:22:49 --> UTF-8 Support Enabled
INFO - 2025-10-30 12:22:49 --> Utf8 Class Initialized
INFO - 2025-10-30 12:22:49 --> URI Class Initialized
DEBUG - 2025-10-30 12:22:49 --> No URI present. Default controller set.
INFO - 2025-10-30 12:22:49 --> Router Class Initialized
INFO - 2025-10-30 12:22:49 --> Output Class Initialized
INFO - 2025-10-30 12:22:49 --> Security Class Initialized
DEBUG - 2025-10-30 12:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 12:22:49 --> Input Class Initialized
INFO - 2025-10-30 12:22:49 --> Language Class Initialized
INFO - 2025-10-30 12:22:49 --> Loader Class Initialized
INFO - 2025-10-30 12:22:49 --> Helper loaded: url_helper
INFO - 2025-10-30 12:22:49 --> Database Driver Class Initialized
INFO - 2025-10-30 12:22:49 --> Controller Class Initialized
INFO - 2025-10-30 12:22:49 --> Model "Student_model" initialized
INFO - 2025-10-30 12:22:49 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 12:22:49 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 12:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 12:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 12:22:49 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 12:22:49 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-30 12:22:49 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 12:22:49 --> Final output sent to browser
DEBUG - 2025-10-30 12:22:49 --> Total execution time: 0.0944
INFO - 2025-10-30 12:25:24 --> Config Class Initialized
INFO - 2025-10-30 12:25:24 --> Hooks Class Initialized
DEBUG - 2025-10-30 12:25:24 --> UTF-8 Support Enabled
INFO - 2025-10-30 12:25:24 --> Utf8 Class Initialized
INFO - 2025-10-30 12:25:24 --> URI Class Initialized
DEBUG - 2025-10-30 12:25:24 --> No URI present. Default controller set.
INFO - 2025-10-30 12:25:24 --> Router Class Initialized
INFO - 2025-10-30 12:25:24 --> Output Class Initialized
INFO - 2025-10-30 12:25:24 --> Security Class Initialized
DEBUG - 2025-10-30 12:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 12:25:24 --> Input Class Initialized
INFO - 2025-10-30 12:25:24 --> Language Class Initialized
INFO - 2025-10-30 12:25:24 --> Loader Class Initialized
INFO - 2025-10-30 12:25:24 --> Helper loaded: url_helper
INFO - 2025-10-30 12:25:24 --> Database Driver Class Initialized
INFO - 2025-10-30 12:25:24 --> Controller Class Initialized
INFO - 2025-10-30 12:25:24 --> Model "Student_model" initialized
INFO - 2025-10-30 12:25:24 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 12:25:24 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 12:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 12:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 12:25:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 12:25:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-30 12:25:24 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 12:25:24 --> Final output sent to browser
DEBUG - 2025-10-30 12:25:24 --> Total execution time: 0.0840
INFO - 2025-10-30 12:25:29 --> Config Class Initialized
INFO - 2025-10-30 12:25:29 --> Hooks Class Initialized
DEBUG - 2025-10-30 12:25:29 --> UTF-8 Support Enabled
INFO - 2025-10-30 12:25:29 --> Utf8 Class Initialized
INFO - 2025-10-30 12:25:29 --> URI Class Initialized
INFO - 2025-10-30 12:25:29 --> Router Class Initialized
INFO - 2025-10-30 12:25:29 --> Output Class Initialized
INFO - 2025-10-30 12:25:29 --> Security Class Initialized
DEBUG - 2025-10-30 12:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 12:25:29 --> Input Class Initialized
INFO - 2025-10-30 12:25:29 --> Language Class Initialized
INFO - 2025-10-30 12:25:29 --> Loader Class Initialized
INFO - 2025-10-30 12:25:29 --> Helper loaded: url_helper
INFO - 2025-10-30 12:25:29 --> Database Driver Class Initialized
INFO - 2025-10-30 12:25:29 --> Controller Class Initialized
INFO - 2025-10-30 12:25:29 --> Model "Student_model" initialized
INFO - 2025-10-30 12:25:29 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 12:25:29 --> Model "Payment_model" initialized
INFO - 2025-10-30 12:25:29 --> Helper loaded: form_helper
INFO - 2025-10-30 12:25:29 --> Form Validation Class Initialized
DEBUG - 2025-10-30 12:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 12:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 12:25:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 12:25:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 12:25:29 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 12:25:29 --> Final output sent to browser
DEBUG - 2025-10-30 12:25:29 --> Total execution time: 0.0605
INFO - 2025-10-30 12:25:56 --> Config Class Initialized
INFO - 2025-10-30 12:25:56 --> Hooks Class Initialized
DEBUG - 2025-10-30 12:25:56 --> UTF-8 Support Enabled
INFO - 2025-10-30 12:25:56 --> Utf8 Class Initialized
INFO - 2025-10-30 12:25:56 --> URI Class Initialized
INFO - 2025-10-30 12:25:56 --> Router Class Initialized
INFO - 2025-10-30 12:25:56 --> Output Class Initialized
INFO - 2025-10-30 12:25:56 --> Security Class Initialized
DEBUG - 2025-10-30 12:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 12:25:56 --> Input Class Initialized
INFO - 2025-10-30 12:25:56 --> Language Class Initialized
INFO - 2025-10-30 12:25:56 --> Loader Class Initialized
INFO - 2025-10-30 12:25:56 --> Helper loaded: url_helper
INFO - 2025-10-30 12:25:56 --> Database Driver Class Initialized
INFO - 2025-10-30 12:25:56 --> Controller Class Initialized
INFO - 2025-10-30 12:25:56 --> Model "Student_model" initialized
INFO - 2025-10-30 12:25:56 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 12:25:56 --> Model "Payment_model" initialized
INFO - 2025-10-30 12:25:56 --> Helper loaded: form_helper
INFO - 2025-10-30 12:25:56 --> Form Validation Class Initialized
DEBUG - 2025-10-30 12:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 12:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 12:25:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 12:25:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 12:25:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 12:25:56 --> Final output sent to browser
DEBUG - 2025-10-30 12:25:56 --> Total execution time: 0.0660
INFO - 2025-10-30 12:25:59 --> Config Class Initialized
INFO - 2025-10-30 12:25:59 --> Hooks Class Initialized
DEBUG - 2025-10-30 12:25:59 --> UTF-8 Support Enabled
INFO - 2025-10-30 12:25:59 --> Utf8 Class Initialized
INFO - 2025-10-30 12:25:59 --> URI Class Initialized
INFO - 2025-10-30 12:25:59 --> Router Class Initialized
INFO - 2025-10-30 12:25:59 --> Output Class Initialized
INFO - 2025-10-30 12:25:59 --> Security Class Initialized
DEBUG - 2025-10-30 12:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 12:25:59 --> Input Class Initialized
INFO - 2025-10-30 12:25:59 --> Language Class Initialized
INFO - 2025-10-30 12:25:59 --> Loader Class Initialized
INFO - 2025-10-30 12:25:59 --> Helper loaded: url_helper
INFO - 2025-10-30 12:25:59 --> Database Driver Class Initialized
INFO - 2025-10-30 12:25:59 --> Controller Class Initialized
INFO - 2025-10-30 12:25:59 --> Model "Student_model" initialized
INFO - 2025-10-30 12:25:59 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 12:25:59 --> Model "Payment_model" initialized
INFO - 2025-10-30 12:25:59 --> Helper loaded: form_helper
INFO - 2025-10-30 12:25:59 --> Form Validation Class Initialized
DEBUG - 2025-10-30 12:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 12:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 12:25:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 12:25:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 12:25:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 12:25:59 --> Final output sent to browser
DEBUG - 2025-10-30 12:25:59 --> Total execution time: 0.0672
INFO - 2025-10-30 12:29:07 --> Config Class Initialized
INFO - 2025-10-30 12:29:07 --> Hooks Class Initialized
DEBUG - 2025-10-30 12:29:07 --> UTF-8 Support Enabled
INFO - 2025-10-30 12:29:07 --> Utf8 Class Initialized
INFO - 2025-10-30 12:29:07 --> URI Class Initialized
INFO - 2025-10-30 12:29:07 --> Router Class Initialized
INFO - 2025-10-30 12:29:07 --> Output Class Initialized
INFO - 2025-10-30 12:29:07 --> Security Class Initialized
DEBUG - 2025-10-30 12:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 12:29:07 --> Input Class Initialized
INFO - 2025-10-30 12:29:07 --> Language Class Initialized
INFO - 2025-10-30 12:29:07 --> Loader Class Initialized
INFO - 2025-10-30 12:29:07 --> Helper loaded: url_helper
INFO - 2025-10-30 12:29:07 --> Database Driver Class Initialized
INFO - 2025-10-30 12:29:07 --> Controller Class Initialized
INFO - 2025-10-30 12:29:07 --> Model "Student_model" initialized
INFO - 2025-10-30 12:29:07 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 12:29:07 --> Model "Payment_model" initialized
INFO - 2025-10-30 12:29:07 --> Helper loaded: form_helper
INFO - 2025-10-30 12:29:07 --> Form Validation Class Initialized
DEBUG - 2025-10-30 12:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 12:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 12:29:07 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 12:29:07 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/create.php
INFO - 2025-10-30 12:29:07 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 12:29:07 --> Final output sent to browser
DEBUG - 2025-10-30 12:29:07 --> Total execution time: 0.0917
INFO - 2025-10-30 12:29:07 --> Config Class Initialized
INFO - 2025-10-30 12:29:07 --> Hooks Class Initialized
DEBUG - 2025-10-30 12:29:07 --> UTF-8 Support Enabled
INFO - 2025-10-30 12:29:07 --> Utf8 Class Initialized
INFO - 2025-10-30 12:29:07 --> URI Class Initialized
INFO - 2025-10-30 12:29:07 --> Router Class Initialized
INFO - 2025-10-30 12:29:07 --> Output Class Initialized
INFO - 2025-10-30 12:29:07 --> Security Class Initialized
DEBUG - 2025-10-30 12:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 12:29:07 --> Input Class Initialized
INFO - 2025-10-30 12:29:07 --> Language Class Initialized
INFO - 2025-10-30 12:29:07 --> Loader Class Initialized
INFO - 2025-10-30 12:29:07 --> Helper loaded: url_helper
INFO - 2025-10-30 12:29:07 --> Database Driver Class Initialized
INFO - 2025-10-30 12:29:07 --> Controller Class Initialized
INFO - 2025-10-30 12:29:07 --> Model "Student_model" initialized
INFO - 2025-10-30 12:29:07 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 12:29:07 --> Model "Payment_model" initialized
INFO - 2025-10-30 12:29:07 --> Helper loaded: form_helper
INFO - 2025-10-30 12:29:07 --> Form Validation Class Initialized
DEBUG - 2025-10-30 12:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 12:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 12:29:07 --> Final output sent to browser
DEBUG - 2025-10-30 12:29:07 --> Total execution time: 0.0580
INFO - 2025-10-30 12:29:14 --> Config Class Initialized
INFO - 2025-10-30 12:29:14 --> Hooks Class Initialized
DEBUG - 2025-10-30 12:29:14 --> UTF-8 Support Enabled
INFO - 2025-10-30 12:29:14 --> Utf8 Class Initialized
INFO - 2025-10-30 12:29:14 --> URI Class Initialized
INFO - 2025-10-30 12:29:14 --> Router Class Initialized
INFO - 2025-10-30 12:29:14 --> Output Class Initialized
INFO - 2025-10-30 12:29:14 --> Security Class Initialized
DEBUG - 2025-10-30 12:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 12:29:14 --> Input Class Initialized
INFO - 2025-10-30 12:29:14 --> Language Class Initialized
INFO - 2025-10-30 12:29:14 --> Loader Class Initialized
INFO - 2025-10-30 12:29:14 --> Helper loaded: url_helper
INFO - 2025-10-30 12:29:14 --> Database Driver Class Initialized
INFO - 2025-10-30 12:29:14 --> Controller Class Initialized
INFO - 2025-10-30 12:29:14 --> Model "Student_model" initialized
INFO - 2025-10-30 12:29:14 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 12:29:14 --> Model "Payment_model" initialized
INFO - 2025-10-30 12:29:14 --> Helper loaded: form_helper
INFO - 2025-10-30 12:29:14 --> Form Validation Class Initialized
DEBUG - 2025-10-30 12:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 12:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 12:29:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-10-30 12:29:15 --> Config Class Initialized
INFO - 2025-10-30 12:29:15 --> Hooks Class Initialized
DEBUG - 2025-10-30 12:29:15 --> UTF-8 Support Enabled
INFO - 2025-10-30 12:29:15 --> Utf8 Class Initialized
INFO - 2025-10-30 12:29:15 --> URI Class Initialized
INFO - 2025-10-30 12:29:15 --> Router Class Initialized
INFO - 2025-10-30 12:29:15 --> Output Class Initialized
INFO - 2025-10-30 12:29:15 --> Security Class Initialized
DEBUG - 2025-10-30 12:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 12:29:15 --> Input Class Initialized
INFO - 2025-10-30 12:29:15 --> Language Class Initialized
INFO - 2025-10-30 12:29:15 --> Loader Class Initialized
INFO - 2025-10-30 12:29:15 --> Helper loaded: url_helper
INFO - 2025-10-30 12:29:15 --> Database Driver Class Initialized
INFO - 2025-10-30 12:29:15 --> Controller Class Initialized
INFO - 2025-10-30 12:29:15 --> Model "Student_model" initialized
INFO - 2025-10-30 12:29:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 12:29:15 --> Model "Payment_model" initialized
INFO - 2025-10-30 12:29:15 --> Helper loaded: form_helper
INFO - 2025-10-30 12:29:15 --> Form Validation Class Initialized
DEBUG - 2025-10-30 12:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 12:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 12:29:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 12:29:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 12:29:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 12:29:15 --> Final output sent to browser
DEBUG - 2025-10-30 12:29:15 --> Total execution time: 0.0840
INFO - 2025-10-30 12:59:02 --> Config Class Initialized
INFO - 2025-10-30 12:59:02 --> Hooks Class Initialized
DEBUG - 2025-10-30 12:59:02 --> UTF-8 Support Enabled
INFO - 2025-10-30 12:59:02 --> Utf8 Class Initialized
INFO - 2025-10-30 12:59:02 --> URI Class Initialized
INFO - 2025-10-30 12:59:02 --> Router Class Initialized
INFO - 2025-10-30 12:59:02 --> Output Class Initialized
INFO - 2025-10-30 12:59:02 --> Security Class Initialized
DEBUG - 2025-10-30 12:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 12:59:02 --> Input Class Initialized
INFO - 2025-10-30 12:59:02 --> Language Class Initialized
ERROR - 2025-10-30 12:59:02 --> 404 Page Not Found: Test-cron/index
INFO - 2025-10-30 13:01:43 --> Config Class Initialized
INFO - 2025-10-30 13:01:43 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:01:43 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:01:43 --> Utf8 Class Initialized
INFO - 2025-10-30 13:01:43 --> URI Class Initialized
INFO - 2025-10-30 13:01:43 --> Router Class Initialized
INFO - 2025-10-30 13:01:43 --> Output Class Initialized
INFO - 2025-10-30 13:01:43 --> Security Class Initialized
DEBUG - 2025-10-30 13:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:01:43 --> Input Class Initialized
INFO - 2025-10-30 13:01:43 --> Language Class Initialized
INFO - 2025-10-30 13:01:43 --> Loader Class Initialized
INFO - 2025-10-30 13:01:43 --> Helper loaded: url_helper
INFO - 2025-10-30 13:01:43 --> Database Driver Class Initialized
INFO - 2025-10-30 13:01:43 --> Controller Class Initialized
INFO - 2025-10-30 13:01:43 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:01:43 --> Model "Student_model" initialized
INFO - 2025-10-30 13:01:43 --> Final output sent to browser
DEBUG - 2025-10-30 13:01:43 --> Total execution time: 0.0545
INFO - 2025-10-30 13:01:55 --> Config Class Initialized
INFO - 2025-10-30 13:01:55 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:01:55 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:01:55 --> Utf8 Class Initialized
INFO - 2025-10-30 13:01:55 --> URI Class Initialized
INFO - 2025-10-30 13:01:55 --> Router Class Initialized
INFO - 2025-10-30 13:01:55 --> Output Class Initialized
INFO - 2025-10-30 13:01:55 --> Security Class Initialized
DEBUG - 2025-10-30 13:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:01:55 --> Input Class Initialized
INFO - 2025-10-30 13:01:55 --> Language Class Initialized
ERROR - 2025-10-30 13:01:55 --> 404 Page Not Found: Test-cron/generate-custom
INFO - 2025-10-30 13:07:10 --> Config Class Initialized
INFO - 2025-10-30 13:07:10 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:07:10 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:07:10 --> Utf8 Class Initialized
INFO - 2025-10-30 13:07:10 --> URI Class Initialized
INFO - 2025-10-30 13:07:10 --> Router Class Initialized
INFO - 2025-10-30 13:07:10 --> Output Class Initialized
INFO - 2025-10-30 13:07:10 --> Security Class Initialized
DEBUG - 2025-10-30 13:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:07:10 --> Input Class Initialized
INFO - 2025-10-30 13:07:10 --> Language Class Initialized
INFO - 2025-10-30 13:07:10 --> Loader Class Initialized
INFO - 2025-10-30 13:07:10 --> Helper loaded: url_helper
INFO - 2025-10-30 13:07:10 --> Database Driver Class Initialized
INFO - 2025-10-30 13:07:10 --> Controller Class Initialized
INFO - 2025-10-30 13:07:10 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:08:57 --> Config Class Initialized
INFO - 2025-10-30 13:08:57 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:08:57 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:08:57 --> Utf8 Class Initialized
INFO - 2025-10-30 13:08:57 --> URI Class Initialized
INFO - 2025-10-30 13:08:57 --> Router Class Initialized
INFO - 2025-10-30 13:08:57 --> Output Class Initialized
INFO - 2025-10-30 13:08:57 --> Security Class Initialized
DEBUG - 2025-10-30 13:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:08:57 --> Input Class Initialized
INFO - 2025-10-30 13:08:57 --> Language Class Initialized
ERROR - 2025-10-30 13:08:57 --> 404 Page Not Found: Cron/generate-monthly-bills
INFO - 2025-10-30 13:10:19 --> Config Class Initialized
INFO - 2025-10-30 13:10:19 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:10:19 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:10:19 --> Utf8 Class Initialized
INFO - 2025-10-30 13:10:19 --> URI Class Initialized
INFO - 2025-10-30 13:10:19 --> Router Class Initialized
INFO - 2025-10-30 13:10:19 --> Output Class Initialized
INFO - 2025-10-30 13:10:19 --> Security Class Initialized
DEBUG - 2025-10-30 13:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:10:19 --> Input Class Initialized
INFO - 2025-10-30 13:10:19 --> Language Class Initialized
ERROR - 2025-10-30 13:10:19 --> 404 Page Not Found: Cron/generate-monthly-bills
INFO - 2025-10-30 13:12:13 --> Config Class Initialized
INFO - 2025-10-30 13:12:13 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:12:13 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:12:13 --> Utf8 Class Initialized
INFO - 2025-10-30 13:12:13 --> URI Class Initialized
INFO - 2025-10-30 13:12:13 --> Router Class Initialized
INFO - 2025-10-30 13:12:13 --> Output Class Initialized
INFO - 2025-10-30 13:12:13 --> Security Class Initialized
DEBUG - 2025-10-30 13:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:12:13 --> Input Class Initialized
INFO - 2025-10-30 13:12:13 --> Language Class Initialized
ERROR - 2025-10-30 13:12:13 --> 404 Page Not Found: Cron/generate-monthly-bills
INFO - 2025-10-30 13:12:44 --> Config Class Initialized
INFO - 2025-10-30 13:12:44 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:12:44 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:12:44 --> Utf8 Class Initialized
INFO - 2025-10-30 13:12:44 --> URI Class Initialized
INFO - 2025-10-30 13:12:44 --> Router Class Initialized
INFO - 2025-10-30 13:12:44 --> Output Class Initialized
INFO - 2025-10-30 13:12:44 --> Security Class Initialized
DEBUG - 2025-10-30 13:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:12:44 --> Input Class Initialized
INFO - 2025-10-30 13:12:44 --> Language Class Initialized
ERROR - 2025-10-30 13:12:44 --> 404 Page Not Found: Cron/generate-monthly-bills
INFO - 2025-10-30 13:39:04 --> Config Class Initialized
INFO - 2025-10-30 13:39:04 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:39:04 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:39:04 --> Utf8 Class Initialized
INFO - 2025-10-30 13:39:04 --> URI Class Initialized
INFO - 2025-10-30 13:39:04 --> Router Class Initialized
INFO - 2025-10-30 13:39:04 --> Output Class Initialized
INFO - 2025-10-30 13:39:04 --> Security Class Initialized
DEBUG - 2025-10-30 13:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:39:04 --> Input Class Initialized
INFO - 2025-10-30 13:39:04 --> Language Class Initialized
INFO - 2025-10-30 13:39:04 --> Loader Class Initialized
INFO - 2025-10-30 13:39:04 --> Helper loaded: url_helper
INFO - 2025-10-30 13:39:04 --> Database Driver Class Initialized
INFO - 2025-10-30 13:39:04 --> Controller Class Initialized
INFO - 2025-10-30 13:39:04 --> Model "Student_model" initialized
INFO - 2025-10-30 13:39:04 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:39:04 --> Model "Payment_model" initialized
INFO - 2025-10-30 13:39:05 --> Helper loaded: form_helper
INFO - 2025-10-30 13:39:05 --> Form Validation Class Initialized
DEBUG - 2025-10-30 13:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:39:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:39:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 13:39:05 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:39:05 --> Final output sent to browser
DEBUG - 2025-10-30 13:39:05 --> Total execution time: 0.0629
INFO - 2025-10-30 13:39:05 --> Config Class Initialized
INFO - 2025-10-30 13:39:05 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:39:05 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:39:05 --> Utf8 Class Initialized
INFO - 2025-10-30 13:39:05 --> URI Class Initialized
INFO - 2025-10-30 13:39:05 --> Router Class Initialized
INFO - 2025-10-30 13:39:05 --> Output Class Initialized
INFO - 2025-10-30 13:39:05 --> Security Class Initialized
DEBUG - 2025-10-30 13:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:39:05 --> Input Class Initialized
INFO - 2025-10-30 13:39:05 --> Language Class Initialized
INFO - 2025-10-30 13:39:05 --> Loader Class Initialized
INFO - 2025-10-30 13:39:05 --> Helper loaded: url_helper
INFO - 2025-10-30 13:39:05 --> Database Driver Class Initialized
INFO - 2025-10-30 13:39:05 --> Controller Class Initialized
INFO - 2025-10-30 13:39:05 --> Model "Student_model" initialized
INFO - 2025-10-30 13:39:05 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:39:05 --> Model "Payment_model" initialized
INFO - 2025-10-30 13:39:05 --> Helper loaded: form_helper
INFO - 2025-10-30 13:39:06 --> Form Validation Class Initialized
DEBUG - 2025-10-30 13:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:39:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:39:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 13:39:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:39:06 --> Final output sent to browser
DEBUG - 2025-10-30 13:39:06 --> Total execution time: 0.0545
INFO - 2025-10-30 13:39:06 --> Config Class Initialized
INFO - 2025-10-30 13:39:06 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:39:06 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:39:06 --> Utf8 Class Initialized
INFO - 2025-10-30 13:39:06 --> URI Class Initialized
INFO - 2025-10-30 13:39:06 --> Router Class Initialized
INFO - 2025-10-30 13:39:06 --> Output Class Initialized
INFO - 2025-10-30 13:39:06 --> Security Class Initialized
DEBUG - 2025-10-30 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:39:06 --> Input Class Initialized
INFO - 2025-10-30 13:39:06 --> Language Class Initialized
INFO - 2025-10-30 13:39:06 --> Loader Class Initialized
INFO - 2025-10-30 13:39:06 --> Helper loaded: url_helper
INFO - 2025-10-30 13:39:06 --> Database Driver Class Initialized
INFO - 2025-10-30 13:39:06 --> Controller Class Initialized
INFO - 2025-10-30 13:39:06 --> Model "Student_model" initialized
INFO - 2025-10-30 13:39:06 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:39:06 --> Model "Payment_model" initialized
INFO - 2025-10-30 13:39:06 --> Helper loaded: form_helper
INFO - 2025-10-30 13:39:06 --> Form Validation Class Initialized
DEBUG - 2025-10-30 13:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:39:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:39:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 13:39:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:39:06 --> Final output sent to browser
DEBUG - 2025-10-30 13:39:06 --> Total execution time: 0.0919
INFO - 2025-10-30 13:39:06 --> Config Class Initialized
INFO - 2025-10-30 13:39:06 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:39:06 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:39:06 --> Utf8 Class Initialized
INFO - 2025-10-30 13:39:06 --> URI Class Initialized
INFO - 2025-10-30 13:39:06 --> Router Class Initialized
INFO - 2025-10-30 13:39:06 --> Output Class Initialized
INFO - 2025-10-30 13:39:06 --> Security Class Initialized
DEBUG - 2025-10-30 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:39:06 --> Input Class Initialized
INFO - 2025-10-30 13:39:06 --> Language Class Initialized
INFO - 2025-10-30 13:39:06 --> Loader Class Initialized
INFO - 2025-10-30 13:39:06 --> Helper loaded: url_helper
INFO - 2025-10-30 13:39:06 --> Database Driver Class Initialized
INFO - 2025-10-30 13:39:06 --> Controller Class Initialized
INFO - 2025-10-30 13:39:06 --> Model "Student_model" initialized
INFO - 2025-10-30 13:39:06 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:39:06 --> Model "Payment_model" initialized
INFO - 2025-10-30 13:39:06 --> Helper loaded: form_helper
INFO - 2025-10-30 13:39:06 --> Form Validation Class Initialized
DEBUG - 2025-10-30 13:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:39:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:39:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 13:39:06 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:39:06 --> Final output sent to browser
DEBUG - 2025-10-30 13:39:06 --> Total execution time: 0.0631
INFO - 2025-10-30 13:39:14 --> Config Class Initialized
INFO - 2025-10-30 13:39:14 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:39:14 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:39:14 --> Utf8 Class Initialized
INFO - 2025-10-30 13:39:14 --> URI Class Initialized
INFO - 2025-10-30 13:39:14 --> Router Class Initialized
INFO - 2025-10-30 13:39:14 --> Output Class Initialized
INFO - 2025-10-30 13:39:14 --> Security Class Initialized
DEBUG - 2025-10-30 13:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:39:14 --> Input Class Initialized
INFO - 2025-10-30 13:39:14 --> Language Class Initialized
INFO - 2025-10-30 13:39:14 --> Loader Class Initialized
INFO - 2025-10-30 13:39:14 --> Helper loaded: url_helper
INFO - 2025-10-30 13:39:14 --> Database Driver Class Initialized
INFO - 2025-10-30 13:39:14 --> Controller Class Initialized
INFO - 2025-10-30 13:39:14 --> Model "Student_model" initialized
INFO - 2025-10-30 13:39:14 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:39:14 --> Model "Payment_model" initialized
INFO - 2025-10-30 13:39:14 --> Helper loaded: form_helper
INFO - 2025-10-30 13:39:14 --> Form Validation Class Initialized
DEBUG - 2025-10-30 13:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:39:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:39:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 13:39:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:39:14 --> Final output sent to browser
DEBUG - 2025-10-30 13:39:14 --> Total execution time: 0.0682
INFO - 2025-10-30 13:39:15 --> Config Class Initialized
INFO - 2025-10-30 13:39:15 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:39:15 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:39:15 --> Utf8 Class Initialized
INFO - 2025-10-30 13:39:15 --> URI Class Initialized
INFO - 2025-10-30 13:39:15 --> Router Class Initialized
INFO - 2025-10-30 13:39:15 --> Output Class Initialized
INFO - 2025-10-30 13:39:15 --> Security Class Initialized
DEBUG - 2025-10-30 13:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:39:15 --> Input Class Initialized
INFO - 2025-10-30 13:39:15 --> Language Class Initialized
INFO - 2025-10-30 13:39:15 --> Loader Class Initialized
INFO - 2025-10-30 13:39:15 --> Helper loaded: url_helper
INFO - 2025-10-30 13:39:15 --> Database Driver Class Initialized
INFO - 2025-10-30 13:39:15 --> Controller Class Initialized
INFO - 2025-10-30 13:39:15 --> Model "Student_model" initialized
INFO - 2025-10-30 13:39:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:39:15 --> Model "Payment_model" initialized
INFO - 2025-10-30 13:39:15 --> Helper loaded: form_helper
INFO - 2025-10-30 13:39:15 --> Form Validation Class Initialized
DEBUG - 2025-10-30 13:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:39:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:39:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 13:39:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:39:15 --> Final output sent to browser
DEBUG - 2025-10-30 13:39:15 --> Total execution time: 0.0598
INFO - 2025-10-30 13:39:15 --> Config Class Initialized
INFO - 2025-10-30 13:39:15 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:39:15 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:39:15 --> Utf8 Class Initialized
INFO - 2025-10-30 13:39:15 --> URI Class Initialized
INFO - 2025-10-30 13:39:15 --> Router Class Initialized
INFO - 2025-10-30 13:39:15 --> Output Class Initialized
INFO - 2025-10-30 13:39:15 --> Security Class Initialized
DEBUG - 2025-10-30 13:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:39:15 --> Input Class Initialized
INFO - 2025-10-30 13:39:15 --> Language Class Initialized
INFO - 2025-10-30 13:39:15 --> Loader Class Initialized
INFO - 2025-10-30 13:39:15 --> Helper loaded: url_helper
INFO - 2025-10-30 13:39:15 --> Database Driver Class Initialized
INFO - 2025-10-30 13:39:15 --> Controller Class Initialized
INFO - 2025-10-30 13:39:15 --> Model "Student_model" initialized
INFO - 2025-10-30 13:39:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:39:15 --> Model "Payment_model" initialized
INFO - 2025-10-30 13:39:15 --> Helper loaded: form_helper
INFO - 2025-10-30 13:39:15 --> Form Validation Class Initialized
DEBUG - 2025-10-30 13:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:39:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:39:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 13:39:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:39:15 --> Final output sent to browser
DEBUG - 2025-10-30 13:39:15 --> Total execution time: 0.0658
INFO - 2025-10-30 13:39:15 --> Config Class Initialized
INFO - 2025-10-30 13:39:15 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:39:15 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:39:15 --> Utf8 Class Initialized
INFO - 2025-10-30 13:39:15 --> URI Class Initialized
INFO - 2025-10-30 13:39:15 --> Router Class Initialized
INFO - 2025-10-30 13:39:15 --> Output Class Initialized
INFO - 2025-10-30 13:39:15 --> Security Class Initialized
DEBUG - 2025-10-30 13:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:39:15 --> Input Class Initialized
INFO - 2025-10-30 13:39:15 --> Language Class Initialized
INFO - 2025-10-30 13:39:15 --> Loader Class Initialized
INFO - 2025-10-30 13:39:15 --> Helper loaded: url_helper
INFO - 2025-10-30 13:39:15 --> Database Driver Class Initialized
INFO - 2025-10-30 13:39:15 --> Controller Class Initialized
INFO - 2025-10-30 13:39:15 --> Model "Student_model" initialized
INFO - 2025-10-30 13:39:15 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:39:15 --> Model "Payment_model" initialized
INFO - 2025-10-30 13:39:15 --> Helper loaded: form_helper
INFO - 2025-10-30 13:39:15 --> Form Validation Class Initialized
DEBUG - 2025-10-30 13:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:39:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:39:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 13:39:15 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:39:15 --> Final output sent to browser
DEBUG - 2025-10-30 13:39:15 --> Total execution time: 0.0786
INFO - 2025-10-30 13:39:16 --> Config Class Initialized
INFO - 2025-10-30 13:39:16 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:39:16 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:39:16 --> Utf8 Class Initialized
INFO - 2025-10-30 13:39:16 --> URI Class Initialized
INFO - 2025-10-30 13:39:16 --> Router Class Initialized
INFO - 2025-10-30 13:39:16 --> Output Class Initialized
INFO - 2025-10-30 13:39:16 --> Security Class Initialized
DEBUG - 2025-10-30 13:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:39:16 --> Input Class Initialized
INFO - 2025-10-30 13:39:16 --> Language Class Initialized
INFO - 2025-10-30 13:39:16 --> Loader Class Initialized
INFO - 2025-10-30 13:39:16 --> Helper loaded: url_helper
INFO - 2025-10-30 13:39:16 --> Database Driver Class Initialized
INFO - 2025-10-30 13:39:16 --> Controller Class Initialized
INFO - 2025-10-30 13:39:16 --> Model "Student_model" initialized
INFO - 2025-10-30 13:39:16 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:39:16 --> Model "Payment_model" initialized
INFO - 2025-10-30 13:39:16 --> Helper loaded: form_helper
INFO - 2025-10-30 13:39:16 --> Form Validation Class Initialized
DEBUG - 2025-10-30 13:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:39:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:39:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 13:39:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:39:16 --> Final output sent to browser
DEBUG - 2025-10-30 13:39:16 --> Total execution time: 0.0673
INFO - 2025-10-30 13:39:16 --> Config Class Initialized
INFO - 2025-10-30 13:39:16 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:39:16 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:39:16 --> Utf8 Class Initialized
INFO - 2025-10-30 13:39:16 --> URI Class Initialized
INFO - 2025-10-30 13:39:16 --> Router Class Initialized
INFO - 2025-10-30 13:39:16 --> Output Class Initialized
INFO - 2025-10-30 13:39:16 --> Security Class Initialized
DEBUG - 2025-10-30 13:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:39:16 --> Input Class Initialized
INFO - 2025-10-30 13:39:16 --> Language Class Initialized
INFO - 2025-10-30 13:39:16 --> Loader Class Initialized
INFO - 2025-10-30 13:39:16 --> Helper loaded: url_helper
INFO - 2025-10-30 13:39:16 --> Database Driver Class Initialized
INFO - 2025-10-30 13:39:16 --> Controller Class Initialized
INFO - 2025-10-30 13:39:16 --> Model "Student_model" initialized
INFO - 2025-10-30 13:39:16 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:39:16 --> Model "Payment_model" initialized
INFO - 2025-10-30 13:39:16 --> Helper loaded: form_helper
INFO - 2025-10-30 13:39:16 --> Form Validation Class Initialized
DEBUG - 2025-10-30 13:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:39:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:39:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 13:39:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:39:16 --> Final output sent to browser
DEBUG - 2025-10-30 13:39:16 --> Total execution time: 0.0526
INFO - 2025-10-30 13:39:16 --> Config Class Initialized
INFO - 2025-10-30 13:39:16 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:39:16 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:39:16 --> Utf8 Class Initialized
INFO - 2025-10-30 13:39:16 --> URI Class Initialized
INFO - 2025-10-30 13:39:16 --> Router Class Initialized
INFO - 2025-10-30 13:39:16 --> Output Class Initialized
INFO - 2025-10-30 13:39:16 --> Security Class Initialized
DEBUG - 2025-10-30 13:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:39:16 --> Input Class Initialized
INFO - 2025-10-30 13:39:16 --> Language Class Initialized
INFO - 2025-10-30 13:39:16 --> Loader Class Initialized
INFO - 2025-10-30 13:39:16 --> Helper loaded: url_helper
INFO - 2025-10-30 13:39:16 --> Database Driver Class Initialized
INFO - 2025-10-30 13:39:16 --> Controller Class Initialized
INFO - 2025-10-30 13:39:16 --> Model "Student_model" initialized
INFO - 2025-10-30 13:39:16 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:39:16 --> Model "Payment_model" initialized
INFO - 2025-10-30 13:39:16 --> Helper loaded: form_helper
INFO - 2025-10-30 13:39:16 --> Form Validation Class Initialized
DEBUG - 2025-10-30 13:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:39:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:39:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 13:39:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:39:16 --> Final output sent to browser
DEBUG - 2025-10-30 13:39:16 --> Total execution time: 0.0954
INFO - 2025-10-30 13:39:16 --> Config Class Initialized
INFO - 2025-10-30 13:39:16 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:39:16 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:39:16 --> Utf8 Class Initialized
INFO - 2025-10-30 13:39:16 --> URI Class Initialized
INFO - 2025-10-30 13:39:16 --> Router Class Initialized
INFO - 2025-10-30 13:39:16 --> Output Class Initialized
INFO - 2025-10-30 13:39:16 --> Security Class Initialized
DEBUG - 2025-10-30 13:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:39:16 --> Input Class Initialized
INFO - 2025-10-30 13:39:16 --> Language Class Initialized
INFO - 2025-10-30 13:39:16 --> Loader Class Initialized
INFO - 2025-10-30 13:39:16 --> Helper loaded: url_helper
INFO - 2025-10-30 13:39:16 --> Database Driver Class Initialized
INFO - 2025-10-30 13:39:16 --> Controller Class Initialized
INFO - 2025-10-30 13:39:16 --> Model "Student_model" initialized
INFO - 2025-10-30 13:39:16 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:39:16 --> Model "Payment_model" initialized
INFO - 2025-10-30 13:39:16 --> Helper loaded: form_helper
INFO - 2025-10-30 13:39:16 --> Form Validation Class Initialized
DEBUG - 2025-10-30 13:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:39:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:39:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 13:39:16 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:39:16 --> Final output sent to browser
DEBUG - 2025-10-30 13:39:16 --> Total execution time: 0.0611
INFO - 2025-10-30 13:39:17 --> Config Class Initialized
INFO - 2025-10-30 13:39:17 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:39:17 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:39:17 --> Utf8 Class Initialized
INFO - 2025-10-30 13:39:17 --> URI Class Initialized
DEBUG - 2025-10-30 13:39:17 --> No URI present. Default controller set.
INFO - 2025-10-30 13:39:17 --> Router Class Initialized
INFO - 2025-10-30 13:39:17 --> Output Class Initialized
INFO - 2025-10-30 13:39:17 --> Security Class Initialized
DEBUG - 2025-10-30 13:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:39:17 --> Input Class Initialized
INFO - 2025-10-30 13:39:17 --> Language Class Initialized
INFO - 2025-10-30 13:39:17 --> Loader Class Initialized
INFO - 2025-10-30 13:39:17 --> Helper loaded: url_helper
INFO - 2025-10-30 13:39:17 --> Database Driver Class Initialized
INFO - 2025-10-30 13:39:17 --> Controller Class Initialized
INFO - 2025-10-30 13:39:17 --> Model "Student_model" initialized
INFO - 2025-10-30 13:39:17 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:39:17 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 13:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:39:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:39:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-30 13:39:17 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:39:17 --> Final output sent to browser
DEBUG - 2025-10-30 13:39:17 --> Total execution time: 0.0602
INFO - 2025-10-30 13:41:00 --> Config Class Initialized
INFO - 2025-10-30 13:41:00 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:41:00 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:41:00 --> Utf8 Class Initialized
INFO - 2025-10-30 13:41:00 --> URI Class Initialized
DEBUG - 2025-10-30 13:41:00 --> No URI present. Default controller set.
INFO - 2025-10-30 13:41:00 --> Router Class Initialized
INFO - 2025-10-30 13:41:00 --> Output Class Initialized
INFO - 2025-10-30 13:41:00 --> Security Class Initialized
DEBUG - 2025-10-30 13:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:41:00 --> Input Class Initialized
INFO - 2025-10-30 13:41:00 --> Language Class Initialized
INFO - 2025-10-30 13:41:00 --> Loader Class Initialized
INFO - 2025-10-30 13:41:00 --> Helper loaded: url_helper
INFO - 2025-10-30 13:41:00 --> Database Driver Class Initialized
INFO - 2025-10-30 13:41:00 --> Controller Class Initialized
INFO - 2025-10-30 13:41:00 --> Model "Student_model" initialized
INFO - 2025-10-30 13:41:00 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:41:00 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 13:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:41:00 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:41:00 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-30 13:41:00 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:41:00 --> Final output sent to browser
DEBUG - 2025-10-30 13:41:00 --> Total execution time: 0.0637
INFO - 2025-10-30 13:41:14 --> Config Class Initialized
INFO - 2025-10-30 13:41:14 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:41:14 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:41:14 --> Utf8 Class Initialized
INFO - 2025-10-30 13:41:14 --> URI Class Initialized
INFO - 2025-10-30 13:41:14 --> Router Class Initialized
INFO - 2025-10-30 13:41:14 --> Output Class Initialized
INFO - 2025-10-30 13:41:14 --> Security Class Initialized
DEBUG - 2025-10-30 13:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:41:14 --> Input Class Initialized
INFO - 2025-10-30 13:41:14 --> Language Class Initialized
INFO - 2025-10-30 13:41:14 --> Loader Class Initialized
INFO - 2025-10-30 13:41:14 --> Helper loaded: url_helper
INFO - 2025-10-30 13:41:14 --> Database Driver Class Initialized
INFO - 2025-10-30 13:41:14 --> Controller Class Initialized
INFO - 2025-10-30 13:41:14 --> Model "Student_model" initialized
INFO - 2025-10-30 13:41:14 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:41:14 --> Model "Payment_model" initialized
INFO - 2025-10-30 13:41:14 --> Helper loaded: form_helper
INFO - 2025-10-30 13:41:14 --> Form Validation Class Initialized
DEBUG - 2025-10-30 13:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:41:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:41:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 13:41:14 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:41:14 --> Final output sent to browser
DEBUG - 2025-10-30 13:41:14 --> Total execution time: 0.0712
INFO - 2025-10-30 13:41:56 --> Config Class Initialized
INFO - 2025-10-30 13:41:56 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:41:56 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:41:56 --> Utf8 Class Initialized
INFO - 2025-10-30 13:41:56 --> URI Class Initialized
INFO - 2025-10-30 13:41:56 --> Router Class Initialized
INFO - 2025-10-30 13:41:56 --> Output Class Initialized
INFO - 2025-10-30 13:41:56 --> Security Class Initialized
DEBUG - 2025-10-30 13:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:41:56 --> Input Class Initialized
INFO - 2025-10-30 13:41:56 --> Language Class Initialized
INFO - 2025-10-30 13:41:56 --> Loader Class Initialized
INFO - 2025-10-30 13:41:56 --> Helper loaded: url_helper
INFO - 2025-10-30 13:41:56 --> Database Driver Class Initialized
INFO - 2025-10-30 13:41:56 --> Controller Class Initialized
INFO - 2025-10-30 13:41:56 --> Model "Student_model" initialized
INFO - 2025-10-30 13:41:56 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:41:56 --> Model "Payment_model" initialized
INFO - 2025-10-30 13:41:56 --> Helper loaded: form_helper
INFO - 2025-10-30 13:41:56 --> Form Validation Class Initialized
DEBUG - 2025-10-30 13:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:41:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:41:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 13:41:56 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:41:56 --> Final output sent to browser
DEBUG - 2025-10-30 13:41:56 --> Total execution time: 0.0731
INFO - 2025-10-30 13:41:57 --> Config Class Initialized
INFO - 2025-10-30 13:41:57 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:41:57 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:41:57 --> Utf8 Class Initialized
INFO - 2025-10-30 13:41:57 --> URI Class Initialized
INFO - 2025-10-30 13:41:57 --> Router Class Initialized
INFO - 2025-10-30 13:41:57 --> Output Class Initialized
INFO - 2025-10-30 13:41:57 --> Security Class Initialized
DEBUG - 2025-10-30 13:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:41:57 --> Input Class Initialized
INFO - 2025-10-30 13:41:57 --> Language Class Initialized
INFO - 2025-10-30 13:41:57 --> Loader Class Initialized
INFO - 2025-10-30 13:41:57 --> Helper loaded: url_helper
INFO - 2025-10-30 13:41:57 --> Database Driver Class Initialized
INFO - 2025-10-30 13:41:57 --> Controller Class Initialized
INFO - 2025-10-30 13:41:57 --> Model "Student_model" initialized
INFO - 2025-10-30 13:41:57 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:41:57 --> Model "Payment_model" initialized
INFO - 2025-10-30 13:41:57 --> Helper loaded: form_helper
INFO - 2025-10-30 13:41:57 --> Form Validation Class Initialized
DEBUG - 2025-10-30 13:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:41:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:41:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 13:41:57 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:41:57 --> Final output sent to browser
DEBUG - 2025-10-30 13:41:57 --> Total execution time: 0.0577
INFO - 2025-10-30 13:41:59 --> Config Class Initialized
INFO - 2025-10-30 13:41:59 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:41:59 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:41:59 --> Utf8 Class Initialized
INFO - 2025-10-30 13:41:59 --> URI Class Initialized
INFO - 2025-10-30 13:41:59 --> Router Class Initialized
INFO - 2025-10-30 13:41:59 --> Output Class Initialized
INFO - 2025-10-30 13:41:59 --> Security Class Initialized
DEBUG - 2025-10-30 13:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:41:59 --> Input Class Initialized
INFO - 2025-10-30 13:41:59 --> Language Class Initialized
INFO - 2025-10-30 13:41:59 --> Loader Class Initialized
INFO - 2025-10-30 13:41:59 --> Helper loaded: url_helper
INFO - 2025-10-30 13:41:59 --> Database Driver Class Initialized
INFO - 2025-10-30 13:41:59 --> Controller Class Initialized
INFO - 2025-10-30 13:41:59 --> Model "Student_model" initialized
INFO - 2025-10-30 13:41:59 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:41:59 --> Model "Payment_model" initialized
INFO - 2025-10-30 13:41:59 --> Helper loaded: form_helper
INFO - 2025-10-30 13:41:59 --> Form Validation Class Initialized
DEBUG - 2025-10-30 13:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:41:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:41:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 13:41:59 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:41:59 --> Final output sent to browser
DEBUG - 2025-10-30 13:41:59 --> Total execution time: 0.0778
INFO - 2025-10-30 13:42:09 --> Config Class Initialized
INFO - 2025-10-30 13:42:09 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:42:09 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:42:09 --> Utf8 Class Initialized
INFO - 2025-10-30 13:42:09 --> URI Class Initialized
INFO - 2025-10-30 13:42:09 --> Router Class Initialized
INFO - 2025-10-30 13:42:09 --> Output Class Initialized
INFO - 2025-10-30 13:42:09 --> Security Class Initialized
DEBUG - 2025-10-30 13:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:42:09 --> Input Class Initialized
INFO - 2025-10-30 13:42:09 --> Language Class Initialized
INFO - 2025-10-30 13:42:09 --> Loader Class Initialized
INFO - 2025-10-30 13:42:09 --> Helper loaded: url_helper
INFO - 2025-10-30 13:42:09 --> Database Driver Class Initialized
INFO - 2025-10-30 13:42:09 --> Controller Class Initialized
INFO - 2025-10-30 13:42:09 --> Model "Student_model" initialized
INFO - 2025-10-30 13:42:09 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:42:09 --> Model "Payment_model" initialized
INFO - 2025-10-30 13:42:09 --> Helper loaded: form_helper
INFO - 2025-10-30 13:42:09 --> Form Validation Class Initialized
DEBUG - 2025-10-30 13:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-10-30 13:42:09 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 13:42:09 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/view.php
INFO - 2025-10-30 13:42:09 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 13:42:09 --> Final output sent to browser
DEBUG - 2025-10-30 13:42:09 --> Total execution time: 0.0577
INFO - 2025-10-30 13:43:53 --> Config Class Initialized
INFO - 2025-10-30 13:43:53 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:43:53 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:43:53 --> Utf8 Class Initialized
INFO - 2025-10-30 13:43:53 --> URI Class Initialized
INFO - 2025-10-30 13:43:53 --> Router Class Initialized
INFO - 2025-10-30 13:43:53 --> Output Class Initialized
INFO - 2025-10-30 13:43:53 --> Security Class Initialized
DEBUG - 2025-10-30 13:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:43:53 --> Input Class Initialized
INFO - 2025-10-30 13:43:53 --> Language Class Initialized
ERROR - 2025-10-30 13:43:53 --> Severity: error --> Exception: Class "CodeIgniter\Controller" not found C:\xampp\htdocs\pioneer-dental\application\controllers\BaseController.php 6
INFO - 2025-10-30 13:45:35 --> Config Class Initialized
INFO - 2025-10-30 13:45:35 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:45:35 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:45:35 --> Utf8 Class Initialized
INFO - 2025-10-30 13:45:35 --> URI Class Initialized
INFO - 2025-10-30 13:45:35 --> Router Class Initialized
INFO - 2025-10-30 13:45:35 --> Output Class Initialized
INFO - 2025-10-30 13:45:35 --> Security Class Initialized
DEBUG - 2025-10-30 13:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:45:35 --> Input Class Initialized
INFO - 2025-10-30 13:45:35 --> Language Class Initialized
ERROR - 2025-10-30 13:45:35 --> Severity: error --> Exception: Class "CodeIgniter\Controller" not found C:\xampp\htdocs\pioneer-dental\application\controllers\BaseController.php 6
INFO - 2025-10-30 13:45:36 --> Config Class Initialized
INFO - 2025-10-30 13:45:36 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:45:36 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:45:36 --> Utf8 Class Initialized
INFO - 2025-10-30 13:45:36 --> URI Class Initialized
INFO - 2025-10-30 13:45:36 --> Router Class Initialized
INFO - 2025-10-30 13:45:36 --> Output Class Initialized
INFO - 2025-10-30 13:45:36 --> Security Class Initialized
DEBUG - 2025-10-30 13:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:45:36 --> Input Class Initialized
INFO - 2025-10-30 13:45:36 --> Language Class Initialized
ERROR - 2025-10-30 13:45:36 --> Severity: error --> Exception: Class "CodeIgniter\Controller" not found C:\xampp\htdocs\pioneer-dental\application\controllers\BaseController.php 6
INFO - 2025-10-30 13:45:36 --> Config Class Initialized
INFO - 2025-10-30 13:45:36 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:45:36 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:45:36 --> Utf8 Class Initialized
INFO - 2025-10-30 13:45:36 --> URI Class Initialized
INFO - 2025-10-30 13:45:36 --> Router Class Initialized
INFO - 2025-10-30 13:45:36 --> Output Class Initialized
INFO - 2025-10-30 13:45:36 --> Security Class Initialized
DEBUG - 2025-10-30 13:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:45:36 --> Input Class Initialized
INFO - 2025-10-30 13:45:36 --> Language Class Initialized
ERROR - 2025-10-30 13:45:36 --> Severity: error --> Exception: Class "CodeIgniter\Controller" not found C:\xampp\htdocs\pioneer-dental\application\controllers\BaseController.php 6
INFO - 2025-10-30 13:45:36 --> Config Class Initialized
INFO - 2025-10-30 13:45:36 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:45:36 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:45:36 --> Utf8 Class Initialized
INFO - 2025-10-30 13:45:36 --> URI Class Initialized
INFO - 2025-10-30 13:45:36 --> Router Class Initialized
INFO - 2025-10-30 13:45:36 --> Output Class Initialized
INFO - 2025-10-30 13:45:36 --> Security Class Initialized
DEBUG - 2025-10-30 13:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:45:36 --> Input Class Initialized
INFO - 2025-10-30 13:45:36 --> Language Class Initialized
ERROR - 2025-10-30 13:45:36 --> Severity: error --> Exception: Class "CodeIgniter\Controller" not found C:\xampp\htdocs\pioneer-dental\application\controllers\BaseController.php 6
INFO - 2025-10-30 13:46:55 --> Config Class Initialized
INFO - 2025-10-30 13:46:55 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:46:55 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:46:55 --> Utf8 Class Initialized
INFO - 2025-10-30 13:46:55 --> URI Class Initialized
INFO - 2025-10-30 13:46:55 --> Router Class Initialized
INFO - 2025-10-30 13:46:55 --> Output Class Initialized
INFO - 2025-10-30 13:46:55 --> Security Class Initialized
DEBUG - 2025-10-30 13:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:46:55 --> Input Class Initialized
INFO - 2025-10-30 13:46:55 --> Language Class Initialized
ERROR - 2025-10-30 13:46:55 --> Severity: error --> Exception: Class "CodeIgniter\Controller" not found C:\xampp\htdocs\pioneer-dental\application\controllers\BaseController.php 6
INFO - 2025-10-30 13:53:00 --> Config Class Initialized
INFO - 2025-10-30 13:53:00 --> Hooks Class Initialized
DEBUG - 2025-10-30 13:53:00 --> UTF-8 Support Enabled
INFO - 2025-10-30 13:53:00 --> Utf8 Class Initialized
INFO - 2025-10-30 13:53:00 --> URI Class Initialized
DEBUG - 2025-10-30 13:53:00 --> No URI present. Default controller set.
INFO - 2025-10-30 13:53:00 --> Router Class Initialized
INFO - 2025-10-30 13:53:00 --> Output Class Initialized
INFO - 2025-10-30 13:53:00 --> Security Class Initialized
DEBUG - 2025-10-30 13:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 13:53:00 --> Input Class Initialized
INFO - 2025-10-30 13:53:00 --> Language Class Initialized
INFO - 2025-10-30 13:53:00 --> Loader Class Initialized
INFO - 2025-10-30 13:53:00 --> Helper loaded: url_helper
INFO - 2025-10-30 13:53:00 --> Database Driver Class Initialized
INFO - 2025-10-30 13:53:00 --> Controller Class Initialized
INFO - 2025-10-30 13:53:00 --> Model "Student_model" initialized
INFO - 2025-10-30 13:53:00 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 13:53:00 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 13:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 13:53:00 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-30 13:53:00 --> Query error: Unknown column 'month' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `student_fees`
WHERE `month` = '10'
AND `year` = '2025'
INFO - 2025-10-30 13:53:00 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-30 14:01:30 --> Config Class Initialized
INFO - 2025-10-30 14:01:30 --> Hooks Class Initialized
DEBUG - 2025-10-30 14:01:30 --> UTF-8 Support Enabled
INFO - 2025-10-30 14:01:30 --> Utf8 Class Initialized
INFO - 2025-10-30 14:01:30 --> URI Class Initialized
DEBUG - 2025-10-30 14:01:30 --> No URI present. Default controller set.
INFO - 2025-10-30 14:01:30 --> Router Class Initialized
INFO - 2025-10-30 14:01:30 --> Output Class Initialized
INFO - 2025-10-30 14:01:30 --> Security Class Initialized
DEBUG - 2025-10-30 14:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 14:01:30 --> Input Class Initialized
INFO - 2025-10-30 14:01:30 --> Language Class Initialized
INFO - 2025-10-30 14:01:30 --> Loader Class Initialized
INFO - 2025-10-30 14:01:30 --> Helper loaded: url_helper
INFO - 2025-10-30 14:01:30 --> Database Driver Class Initialized
INFO - 2025-10-30 14:01:30 --> Controller Class Initialized
INFO - 2025-10-30 14:01:30 --> Model "Student_model" initialized
INFO - 2025-10-30 14:01:30 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 14:01:30 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 14:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 14:01:30 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-30 14:01:30 --> Query error: Table 'pioneer_dental_db.students' doesn't exist - Invalid query: SELECT `id`, `monthly_fee`
FROM `students`
INFO - 2025-10-30 14:01:30 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-30 14:05:06 --> Config Class Initialized
INFO - 2025-10-30 14:05:06 --> Hooks Class Initialized
DEBUG - 2025-10-30 14:05:06 --> UTF-8 Support Enabled
INFO - 2025-10-30 14:05:06 --> Utf8 Class Initialized
INFO - 2025-10-30 14:05:06 --> URI Class Initialized
INFO - 2025-10-30 14:05:06 --> Router Class Initialized
INFO - 2025-10-30 14:05:06 --> Output Class Initialized
INFO - 2025-10-30 14:05:06 --> Security Class Initialized
DEBUG - 2025-10-30 14:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 14:05:06 --> Input Class Initialized
INFO - 2025-10-30 14:05:06 --> Language Class Initialized
ERROR - 2025-10-30 14:05:06 --> 404 Page Not Found: Generate-monthly-fee/index
INFO - 2025-10-30 14:05:12 --> Config Class Initialized
INFO - 2025-10-30 14:05:12 --> Hooks Class Initialized
DEBUG - 2025-10-30 14:05:12 --> UTF-8 Support Enabled
INFO - 2025-10-30 14:05:12 --> Utf8 Class Initialized
INFO - 2025-10-30 14:05:12 --> URI Class Initialized
DEBUG - 2025-10-30 14:05:12 --> No URI present. Default controller set.
INFO - 2025-10-30 14:05:12 --> Router Class Initialized
INFO - 2025-10-30 14:05:12 --> Output Class Initialized
INFO - 2025-10-30 14:05:12 --> Security Class Initialized
DEBUG - 2025-10-30 14:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 14:05:12 --> Input Class Initialized
INFO - 2025-10-30 14:05:12 --> Language Class Initialized
INFO - 2025-10-30 14:05:12 --> Loader Class Initialized
INFO - 2025-10-30 14:05:12 --> Helper loaded: url_helper
INFO - 2025-10-30 14:05:12 --> Database Driver Class Initialized
INFO - 2025-10-30 14:05:12 --> Controller Class Initialized
INFO - 2025-10-30 14:05:12 --> Model "Student_model" initialized
INFO - 2025-10-30 14:05:12 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 14:05:12 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 14:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 14:05:12 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-30 14:05:12 --> Query error: Unknown column 'monthly_fee' in 'field list' - Invalid query: SELECT `id`, `monthly_fee`
FROM `student`
INFO - 2025-10-30 14:05:12 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-30 14:05:12 --> Config Class Initialized
INFO - 2025-10-30 14:05:12 --> Hooks Class Initialized
DEBUG - 2025-10-30 14:05:12 --> UTF-8 Support Enabled
INFO - 2025-10-30 14:05:12 --> Utf8 Class Initialized
INFO - 2025-10-30 14:05:12 --> URI Class Initialized
DEBUG - 2025-10-30 14:05:12 --> No URI present. Default controller set.
INFO - 2025-10-30 14:05:12 --> Router Class Initialized
INFO - 2025-10-30 14:05:12 --> Output Class Initialized
INFO - 2025-10-30 14:05:12 --> Security Class Initialized
DEBUG - 2025-10-30 14:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 14:05:12 --> Input Class Initialized
INFO - 2025-10-30 14:05:12 --> Language Class Initialized
INFO - 2025-10-30 14:05:12 --> Loader Class Initialized
INFO - 2025-10-30 14:05:12 --> Helper loaded: url_helper
INFO - 2025-10-30 14:05:12 --> Database Driver Class Initialized
INFO - 2025-10-30 14:05:12 --> Controller Class Initialized
INFO - 2025-10-30 14:05:12 --> Model "Student_model" initialized
INFO - 2025-10-30 14:05:12 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 14:05:12 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 14:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 14:05:12 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-30 14:05:12 --> Query error: Unknown column 'monthly_fee' in 'field list' - Invalid query: SELECT `id`, `monthly_fee`
FROM `student`
INFO - 2025-10-30 14:05:12 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-30 14:08:06 --> Config Class Initialized
INFO - 2025-10-30 14:08:06 --> Hooks Class Initialized
DEBUG - 2025-10-30 14:08:06 --> UTF-8 Support Enabled
INFO - 2025-10-30 14:08:06 --> Utf8 Class Initialized
INFO - 2025-10-30 14:08:06 --> URI Class Initialized
DEBUG - 2025-10-30 14:08:06 --> No URI present. Default controller set.
INFO - 2025-10-30 14:08:06 --> Router Class Initialized
INFO - 2025-10-30 14:08:06 --> Output Class Initialized
INFO - 2025-10-30 14:08:06 --> Security Class Initialized
DEBUG - 2025-10-30 14:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 14:08:06 --> Input Class Initialized
INFO - 2025-10-30 14:08:06 --> Language Class Initialized
INFO - 2025-10-30 14:08:06 --> Loader Class Initialized
INFO - 2025-10-30 14:08:06 --> Helper loaded: url_helper
INFO - 2025-10-30 14:08:06 --> Database Driver Class Initialized
INFO - 2025-10-30 14:08:06 --> Controller Class Initialized
INFO - 2025-10-30 14:08:06 --> Model "Student_model" initialized
INFO - 2025-10-30 14:08:06 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 14:08:06 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 14:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 14:08:06 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-30 14:08:06 --> Query error: Unknown column 'monthly_fee' in 'field list' - Invalid query: SELECT `id`, `monthly_fee`
FROM `student`
INFO - 2025-10-30 14:08:06 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-30 14:08:07 --> Config Class Initialized
INFO - 2025-10-30 14:08:07 --> Hooks Class Initialized
DEBUG - 2025-10-30 14:08:07 --> UTF-8 Support Enabled
INFO - 2025-10-30 14:08:07 --> Utf8 Class Initialized
INFO - 2025-10-30 14:08:07 --> URI Class Initialized
DEBUG - 2025-10-30 14:08:07 --> No URI present. Default controller set.
INFO - 2025-10-30 14:08:07 --> Router Class Initialized
INFO - 2025-10-30 14:08:07 --> Output Class Initialized
INFO - 2025-10-30 14:08:07 --> Security Class Initialized
DEBUG - 2025-10-30 14:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 14:08:07 --> Input Class Initialized
INFO - 2025-10-30 14:08:07 --> Language Class Initialized
INFO - 2025-10-30 14:08:07 --> Loader Class Initialized
INFO - 2025-10-30 14:08:07 --> Helper loaded: url_helper
INFO - 2025-10-30 14:08:07 --> Database Driver Class Initialized
INFO - 2025-10-30 14:08:07 --> Controller Class Initialized
INFO - 2025-10-30 14:08:07 --> Model "Student_model" initialized
INFO - 2025-10-30 14:08:07 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 14:08:07 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 14:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 14:08:07 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-30 14:08:07 --> Query error: Unknown column 'monthly_fee' in 'field list' - Invalid query: SELECT `id`, `monthly_fee`
FROM `student`
INFO - 2025-10-30 14:08:07 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-30 14:08:07 --> Config Class Initialized
INFO - 2025-10-30 14:08:07 --> Hooks Class Initialized
DEBUG - 2025-10-30 14:08:07 --> UTF-8 Support Enabled
INFO - 2025-10-30 14:08:07 --> Utf8 Class Initialized
INFO - 2025-10-30 14:08:07 --> URI Class Initialized
DEBUG - 2025-10-30 14:08:07 --> No URI present. Default controller set.
INFO - 2025-10-30 14:08:07 --> Router Class Initialized
INFO - 2025-10-30 14:08:07 --> Output Class Initialized
INFO - 2025-10-30 14:08:07 --> Security Class Initialized
DEBUG - 2025-10-30 14:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 14:08:07 --> Input Class Initialized
INFO - 2025-10-30 14:08:07 --> Language Class Initialized
INFO - 2025-10-30 14:08:07 --> Loader Class Initialized
INFO - 2025-10-30 14:08:07 --> Helper loaded: url_helper
INFO - 2025-10-30 14:08:07 --> Database Driver Class Initialized
INFO - 2025-10-30 14:08:07 --> Controller Class Initialized
INFO - 2025-10-30 14:08:07 --> Model "Student_model" initialized
INFO - 2025-10-30 14:08:07 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 14:08:07 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 14:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 14:08:07 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-30 14:08:07 --> Query error: Unknown column 'monthly_fee' in 'field list' - Invalid query: SELECT `id`, `monthly_fee`
FROM `student`
INFO - 2025-10-30 14:08:07 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-30 14:08:40 --> Config Class Initialized
INFO - 2025-10-30 14:08:40 --> Hooks Class Initialized
DEBUG - 2025-10-30 14:08:40 --> UTF-8 Support Enabled
INFO - 2025-10-30 14:08:40 --> Utf8 Class Initialized
INFO - 2025-10-30 14:08:40 --> URI Class Initialized
DEBUG - 2025-10-30 14:08:40 --> No URI present. Default controller set.
INFO - 2025-10-30 14:08:40 --> Router Class Initialized
INFO - 2025-10-30 14:08:40 --> Output Class Initialized
INFO - 2025-10-30 14:08:40 --> Security Class Initialized
DEBUG - 2025-10-30 14:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 14:08:40 --> Input Class Initialized
INFO - 2025-10-30 14:08:40 --> Language Class Initialized
INFO - 2025-10-30 14:08:40 --> Loader Class Initialized
INFO - 2025-10-30 14:08:40 --> Helper loaded: url_helper
INFO - 2025-10-30 14:08:40 --> Database Driver Class Initialized
INFO - 2025-10-30 14:08:40 --> Controller Class Initialized
INFO - 2025-10-30 14:08:40 --> Model "Student_model" initialized
INFO - 2025-10-30 14:08:40 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 14:08:40 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 14:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 14:08:40 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-30 14:08:40 --> Query error: Unknown column 'base_amount' in 'field list' - Invalid query: SELECT `id`, `base_amount`
FROM `student`
INFO - 2025-10-30 14:08:40 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-30 14:08:41 --> Config Class Initialized
INFO - 2025-10-30 14:08:41 --> Hooks Class Initialized
DEBUG - 2025-10-30 14:08:41 --> UTF-8 Support Enabled
INFO - 2025-10-30 14:08:41 --> Utf8 Class Initialized
INFO - 2025-10-30 14:08:41 --> URI Class Initialized
DEBUG - 2025-10-30 14:08:41 --> No URI present. Default controller set.
INFO - 2025-10-30 14:08:41 --> Router Class Initialized
INFO - 2025-10-30 14:08:41 --> Output Class Initialized
INFO - 2025-10-30 14:08:41 --> Security Class Initialized
DEBUG - 2025-10-30 14:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 14:08:41 --> Input Class Initialized
INFO - 2025-10-30 14:08:41 --> Language Class Initialized
INFO - 2025-10-30 14:08:41 --> Loader Class Initialized
INFO - 2025-10-30 14:08:41 --> Helper loaded: url_helper
INFO - 2025-10-30 14:08:42 --> Database Driver Class Initialized
INFO - 2025-10-30 14:08:42 --> Controller Class Initialized
INFO - 2025-10-30 14:08:42 --> Model "Student_model" initialized
INFO - 2025-10-30 14:08:42 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 14:08:42 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 14:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 14:08:42 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-30 14:08:42 --> Query error: Unknown column 'base_amount' in 'field list' - Invalid query: SELECT `id`, `base_amount`
FROM `student`
INFO - 2025-10-30 14:08:42 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-30 14:09:40 --> Config Class Initialized
INFO - 2025-10-30 14:09:40 --> Hooks Class Initialized
DEBUG - 2025-10-30 14:09:40 --> UTF-8 Support Enabled
INFO - 2025-10-30 14:09:40 --> Utf8 Class Initialized
INFO - 2025-10-30 14:09:40 --> URI Class Initialized
DEBUG - 2025-10-30 14:09:40 --> No URI present. Default controller set.
INFO - 2025-10-30 14:09:40 --> Router Class Initialized
INFO - 2025-10-30 14:09:40 --> Output Class Initialized
INFO - 2025-10-30 14:09:40 --> Security Class Initialized
DEBUG - 2025-10-30 14:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 14:09:40 --> Input Class Initialized
INFO - 2025-10-30 14:09:40 --> Language Class Initialized
INFO - 2025-10-30 14:09:40 --> Loader Class Initialized
INFO - 2025-10-30 14:09:40 --> Helper loaded: url_helper
INFO - 2025-10-30 14:09:40 --> Database Driver Class Initialized
INFO - 2025-10-30 14:09:40 --> Controller Class Initialized
INFO - 2025-10-30 14:09:40 --> Model "Student_model" initialized
INFO - 2025-10-30 14:09:40 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 14:09:40 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 14:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 14:09:40 --> Session: Class initialized using 'files' driver.
ERROR - 2025-10-30 14:09:40 --> Query error: Unknown column 'monthly_fee' in 'field list' - Invalid query: SELECT `id`, `monthly_fee`
FROM `student`
INFO - 2025-10-30 14:09:40 --> Language file loaded: language/english/db_lang.php
INFO - 2025-10-30 14:15:48 --> Config Class Initialized
INFO - 2025-10-30 14:15:48 --> Hooks Class Initialized
DEBUG - 2025-10-30 14:15:48 --> UTF-8 Support Enabled
INFO - 2025-10-30 14:15:48 --> Utf8 Class Initialized
INFO - 2025-10-30 14:15:48 --> URI Class Initialized
DEBUG - 2025-10-30 14:15:48 --> No URI present. Default controller set.
INFO - 2025-10-30 14:15:48 --> Router Class Initialized
INFO - 2025-10-30 14:15:48 --> Output Class Initialized
INFO - 2025-10-30 14:15:48 --> Security Class Initialized
DEBUG - 2025-10-30 14:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 14:15:48 --> Input Class Initialized
INFO - 2025-10-30 14:15:48 --> Language Class Initialized
INFO - 2025-10-30 14:15:48 --> Loader Class Initialized
INFO - 2025-10-30 14:15:48 --> Helper loaded: url_helper
INFO - 2025-10-30 14:15:48 --> Database Driver Class Initialized
INFO - 2025-10-30 14:15:48 --> Controller Class Initialized
INFO - 2025-10-30 14:15:48 --> Model "Student_model" initialized
INFO - 2025-10-30 14:15:48 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 14:15:48 --> Model "Payment_model" initialized
DEBUG - 2025-10-30 14:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 14:15:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-10-30 14:15:48 --> Auto Fee Insert: No monthly fee record found in fees_master.
INFO - 2025-10-30 14:15:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 14:15:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\dashboard/index.php
INFO - 2025-10-30 14:15:48 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 14:15:48 --> Final output sent to browser
DEBUG - 2025-10-30 14:15:48 --> Total execution time: 0.0958
INFO - 2025-10-30 14:15:52 --> Config Class Initialized
INFO - 2025-10-30 14:15:52 --> Hooks Class Initialized
DEBUG - 2025-10-30 14:15:52 --> UTF-8 Support Enabled
INFO - 2025-10-30 14:15:52 --> Utf8 Class Initialized
INFO - 2025-10-30 14:15:52 --> URI Class Initialized
INFO - 2025-10-30 14:15:52 --> Router Class Initialized
INFO - 2025-10-30 14:15:52 --> Output Class Initialized
INFO - 2025-10-30 14:15:52 --> Security Class Initialized
DEBUG - 2025-10-30 14:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 14:15:52 --> Input Class Initialized
INFO - 2025-10-30 14:15:52 --> Language Class Initialized
INFO - 2025-10-30 14:15:52 --> Loader Class Initialized
INFO - 2025-10-30 14:15:52 --> Helper loaded: url_helper
INFO - 2025-10-30 14:15:52 --> Database Driver Class Initialized
INFO - 2025-10-30 14:15:52 --> Controller Class Initialized
INFO - 2025-10-30 14:15:52 --> Model "Student_model" initialized
INFO - 2025-10-30 14:15:52 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 14:15:52 --> Model "Payment_model" initialized
INFO - 2025-10-30 14:15:52 --> Helper loaded: form_helper
INFO - 2025-10-30 14:15:52 --> Form Validation Class Initialized
DEBUG - 2025-10-30 14:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 14:15:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-10-30 14:15:52 --> Auto Fee Insert: No monthly fee record found in fees_master.
INFO - 2025-10-30 14:15:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 14:15:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 14:15:52 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 14:15:52 --> Final output sent to browser
DEBUG - 2025-10-30 14:15:52 --> Total execution time: 0.0760
INFO - 2025-10-30 14:16:03 --> Config Class Initialized
INFO - 2025-10-30 14:16:03 --> Hooks Class Initialized
DEBUG - 2025-10-30 14:16:03 --> UTF-8 Support Enabled
INFO - 2025-10-30 14:16:03 --> Utf8 Class Initialized
INFO - 2025-10-30 14:16:03 --> URI Class Initialized
INFO - 2025-10-30 14:16:03 --> Router Class Initialized
INFO - 2025-10-30 14:16:03 --> Output Class Initialized
INFO - 2025-10-30 14:16:03 --> Security Class Initialized
DEBUG - 2025-10-30 14:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-10-30 14:16:03 --> Input Class Initialized
INFO - 2025-10-30 14:16:03 --> Language Class Initialized
INFO - 2025-10-30 14:16:03 --> Loader Class Initialized
INFO - 2025-10-30 14:16:03 --> Helper loaded: url_helper
INFO - 2025-10-30 14:16:03 --> Database Driver Class Initialized
INFO - 2025-10-30 14:16:03 --> Controller Class Initialized
INFO - 2025-10-30 14:16:03 --> Model "Student_model" initialized
INFO - 2025-10-30 14:16:03 --> Model "Student_fee_model" initialized
INFO - 2025-10-30 14:16:03 --> Model "Payment_model" initialized
INFO - 2025-10-30 14:16:03 --> Helper loaded: form_helper
INFO - 2025-10-30 14:16:03 --> Form Validation Class Initialized
DEBUG - 2025-10-30 14:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-10-30 14:16:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-10-30 14:16:03 --> Auto Fee Insert: No monthly fee record found in fees_master.
INFO - 2025-10-30 14:16:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/header.php
INFO - 2025-10-30 14:16:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\student_fees/index.php
INFO - 2025-10-30 14:16:03 --> File loaded: C:\xampp\htdocs\pioneer-dental\application\views\templates/footer.php
INFO - 2025-10-30 14:16:03 --> Final output sent to browser
DEBUG - 2025-10-30 14:16:03 --> Total execution time: 0.0628
