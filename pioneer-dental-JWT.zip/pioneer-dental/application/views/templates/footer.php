 </div>
    <footer class="mt-5 py-4 bg-light text-center">
        <p class="text-muted mb-0">&copy; <?= date('Y') ?> Pioneer Dental College. All rights reserved.</p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</html>